import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { PROJECTS_INDEX, SanityProject } from '../data/mockSanityData';
import { buildSanityImageUrl } from '../lib/sanityClient';
import { ArrowRight, ArrowUpRight } from 'lucide-react';

export const ProjectIndexSection: React.FC = () => {
  const { locale, navigateTo, t } = useLanguage();
  const [hoveredProject, setHoveredProject] = useState<SanityProject | null>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  const prefix = locale === 'en' ? '/en' : '';

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // Offset slightly from cursor so it doesn't block clicks
      setMousePosition({
        x: e.clientX + 24,
        y: e.clientY - 160,
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleRowClick = (slug: string) => {
    navigateTo(`${prefix}/realisations/${slug}/`);
  };

  return (
    <section className="py-28 md:py-40 bg-[#F5F3EF] text-[#111111] relative overflow-hidden">
      {/* Floating Cursor Preview (Desktop Only) */}
      <div className="hidden lg:block pointer-events-none fixed z-40 top-0 left-0">
        <AnimatePresence>
          {hoveredProject && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 15 }}
              animate={{
                opacity: 1,
                scale: 1,
                x: mousePosition.x,
                y: mousePosition.y,
              }}
              exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
              transition={{
                type: 'spring',
                stiffness: 150,
                damping: 20,
                mass: 0.2,
              }}
              className="w-[380px] h-[310px] xl:w-[440px] xl:h-[350px] overflow-hidden shadow-2xl bg-[#111111] border border-black/10 relative"
            >
              <img
                src={buildSanityImageUrl(hoveredProject.previewImage.url, {
                  width: 772,
                  height: 630,
                  quality: 80,
                  fit: 'crop',
                  auto: 'format',
                })}
                alt={hoveredProject.previewImage.alt}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-4 text-white">
                <span className="text-xs uppercase tracking-widest font-sans opacity-80">
                  {hoveredProject.type === 'villa' ? 'Villa Contemporaine' : "Chalet d'Exception"}
                </span>
                <span className="font-serif text-xl font-light">
                  {hoveredProject.title}
                </span>
                <span className="text-[11px] text-stone-300 font-mono">
                  [ {hoveredProject.area} m² ] · [ {hoveredProject.location} ]
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-14 border-b border-[#111111]/15">
          <div>
            <span className="text-xs uppercase tracking-[0.24em] text-[#8E8880] block mb-2 font-sans">
              4.4 · {t.projectIndex.subtitle}
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-light tracking-tight text-[#111111]">
              {t.projectIndex.title}
            </h2>
          </div>

          <p className="text-sm text-stone-600 max-w-md font-sans">
            {locale === 'fr'
              ? "Chaque ouvrage est une réponse sur-mesure à la topographie, aux vents et à la lumière d'un paysage d'exception."
              : "Every project is a bespoke response to the topography, breezes, and light of an extraordinary terrain."}
          </p>
        </div>

        {/* Typographic List of 11 Projects */}
        <div className="divide-y divide-[#111111]/10">
          {PROJECTS_INDEX.map((project, idx) => (
            <div
              key={project._id}
              onMouseEnter={() => setHoveredProject(project)}
              onMouseLeave={() => setHoveredProject(null)}
              onClick={() => handleRowClick(project.slug)}
              className="group py-7 sm:py-9 cursor-pointer transition-colors hover:bg-stone-200/40 px-2 sm:px-4 -mx-2 sm:-mx-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && handleRowClick(project.slug)}
            >
              {/* Left Column: Index Number & Project Name */}
              <div className="flex items-baseline gap-4 sm:gap-8">
                <span className="font-mono text-xs text-stone-400 w-6">
                  {String(idx + 1).padStart(2, '0')}
                </span>
                <span className="font-serif text-2xl sm:text-3xl md:text-4xl lg:text-4xl font-light text-[#111111] group-hover:translate-x-2 transition-transform duration-300">
                  {project.title}
                </span>
              </div>

              {/* Mobile Thumbnail View */}
              <div className="block lg:hidden my-2">
                <div className="aspect-[16/9] w-full max-w-sm overflow-hidden bg-stone-300 rounded-xs">
                  <img
                    src={buildSanityImageUrl(project.previewImage.url, {
                      width: 600,
                      height: 380,
                      quality: 80,
                      fit: 'crop',
                      auto: 'format',
                    })}
                    alt={project.title}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
              </div>

              {/* Right Column: Area & Location in brackets / discreet format */}
              <div className="flex items-center justify-between md:justify-end gap-6 sm:gap-10 text-xs sm:text-sm font-sans text-stone-600">
                <div className="flex items-center gap-4">
                  <span className="font-mono text-stone-800 tracking-wider">
                    [ {project.area} m² ]
                  </span>
                  <span className="text-stone-400" aria-hidden="true">·</span>
                  <span className="font-medium text-stone-800 tracking-wide">
                    {project.location}
                  </span>
                </div>

                <div className="w-8 h-8 rounded-full border border-stone-300 flex items-center justify-center group-hover:bg-[#111111] group-hover:text-white group-hover:border-[#111111] transition-all">
                  <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Final CTA "Nos réalisations" -> /realisations/ */}
        <div className="pt-16 sm:pt-20 flex justify-center">
          <button
            onClick={() => navigateTo(`${prefix}/realisations/`)}
            className="group inline-flex items-center gap-4 px-8 py-4 bg-[#111111] text-[#F5F3EF] hover:bg-stone-800 transition-colors uppercase tracking-[0.2em] text-xs font-semibold focus:outline-none"
          >
            <span>{t.projectIndex.allProjectsCta}</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default ProjectIndexSection;
