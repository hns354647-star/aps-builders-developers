import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Layers, 
  ShieldCheck, 
  Zap, 
  Droplets, 
  Maximize2, 
  MapPin, 
  CheckCircle2, 
  Download, 
  Copy, 
  Check, 
  FileText, 
  Scale, 
  Home, 
  Compass, 
  Cpu, 
  Wind, 
  Sun, 
  Award, 
  Building, 
  ArrowUpRight,
  Printer,
  Sparkles,
  Info
} from 'lucide-react';
import { Project } from '../data/projects';
import { getProjectSpecs } from './ProjectStructuralSpecs';
import ArchitecturalViewer from './ArchitecturalViewer';
import FloorPlanAnnotator from './FloorPlanAnnotator';

interface ProjectExpandedDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  onInquire?: () => void;
}

export default function ProjectExpandedDetailsModal({
  isOpen,
  onClose,
  project,
  onInquire
}: ProjectExpandedDetailsModalProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'structural' | 'architectural' | 'mep' | 'quality'>('overview');
  const [copied, setCopied] = useState(false);
  const specs = getProjectSpecs(project);

  // Close on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleCopySummary = () => {
    const summaryText = `
APS BUILDERS & DEVELOPERS - TECHNICAL SPECIFICATION DOSSIER
Project: ${project.title}
Location: ${project.location}
Type: ${project.type} | Status: ${project.status}
--------------------------------------------------
STRUCTURAL ENGINEERING:
- Structural Type: ${specs.structuralType}
- Foundation: ${specs.foundation}
- Concrete Grade: ${specs.concreteGrade}
- Steel Reinforcement: ${specs.steelGrade}
- Seismic Resistance: ${specs.seismicZone}
- Built Area: ${specs.builtArea} | Lot Size: ${specs.lotSize}

SUSTAINABILITY & MEP:
- Green Building Rating: ${specs.greenRating}
- Solar Energy Integration: ${specs.solarIntegration}
- Rainwater Harvesting: ${specs.rainwaterPlan}
- Compliance: IS 456:2000, IS 1893:2016, NBC 2016
--------------------------------------------------
Certified by APS Structural Engineering Division
    `.trim();

    navigator.clipboard.writeText(summaryText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <AnimatePresence>
      <div 
        role="dialog" 
        aria-modal="true" 
        aria-labelledby="expanded-modal-title"
        className="fixed inset-0 z-[500] flex items-center justify-center p-2 sm:p-4 md:p-6 bg-slate-950/90 backdrop-blur-md overflow-hidden"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          transition={{ type: "spring", damping: 28, stiffness: 300, mass: 0.85 }}
          className="bg-slate-900 border border-slate-700/80 w-full max-w-6xl max-h-[94vh] rounded-lg shadow-2xl flex flex-col overflow-hidden text-slate-100"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header Banner */}
          <div className="px-6 py-5 border-b border-slate-800 bg-slate-950/70 flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0">
            <div className="flex items-start md:items-center gap-3">
              <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-sm shrink-0">
                <Layers className="w-6 h-6" aria-hidden="true" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-bold uppercase tracking-widest bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded border border-amber-500/30">
                    {project.type}
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-widest bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                    {project.status}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-amber-500" aria-hidden="true" /> {project.location}
                  </span>
                </div>
                <h2 id="expanded-modal-title" className="font-display text-xl md:text-2xl font-bold text-white mt-1">
                  {project.title} <span className="text-amber-500 font-sans text-sm font-normal">— Structural & Architectural Dossier</span>
                </h2>
              </div>
            </div>

            {/* Quick Actions & Close */}
            <div className="flex items-center gap-2 self-end md:self-auto">
              <button
                onClick={handleCopySummary}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 hover:border-slate-600 rounded text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                aria-label="Copy technical specifications to clipboard"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                <span>{copied ? "Copied" : "Copy Specs"}</span>
              </button>

              <button
                onClick={handlePrint}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 hover:border-slate-600 rounded text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                aria-label="Print technical specification sheet"
              >
                <Printer className="w-3.5 h-3.5 text-slate-400" />
                <span className="hidden sm:inline">Print Dossier</span>
              </button>

              {onInquire && (
                <button
                  onClick={() => {
                    onClose();
                    onInquire();
                  }}
                  className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                  aria-label="Consult Structural Engineers about this project"
                >
                  <span>Inquire</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              )}

              <button
                onClick={onClose}
                aria-label="Close expanded structural details modal"
                className="p-1.5 bg-slate-800/80 hover:bg-red-500/20 hover:text-red-400 text-slate-400 rounded transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 ml-1"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-slate-800 bg-slate-950/40 px-6 overflow-x-auto no-scrollbar shrink-0" role="tablist" aria-label="Specification Categories">
            {[
              { id: 'overview', label: 'All Specifications', icon: Layers },
              { id: 'structural', label: 'Structural Engineering', icon: Building },
              { id: 'architectural', label: 'Architectural & Blueprints', icon: Compass },
              { id: 'mep', label: 'MEP & Systems', icon: Cpu },
              { id: 'quality', label: 'Certifications & Tests', icon: Award },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  role="tab"
                  aria-selected={isActive}
                  aria-controls={`expanded-tab-${tab.id}`}
                  id={`tab-btn-${tab.id}`}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 py-3 px-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all whitespace-nowrap focus:outline-none ${
                    isActive 
                      ? 'border-amber-500 text-amber-400 bg-amber-500/5' 
                      : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-amber-500' : 'text-slate-500'}`} aria-hidden="true" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Modal Content Body */}
          <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8 bg-slate-900/50">
            {/* 1. OVERVIEW TAB */}
            {activeTab === 'overview' && (
              <div id="expanded-tab-overview" role="tabpanel" aria-labelledby="tab-btn-overview" className="space-y-8">
                {/* Hero Key Metrics Bento Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                  <div className="bg-slate-950/60 p-4 rounded border border-slate-800/80 hover:border-slate-700 transition-colors">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-1">
                      <Home className="w-3.5 h-3.5 text-amber-500" /> Structural Framework
                    </p>
                    <p className="text-sm md:text-base font-bold text-white font-display">{specs.structuralType}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">RCC Framed with Plinth Grade</span>
                  </div>

                  <div className="bg-slate-950/60 p-4 rounded border border-slate-800/80 hover:border-slate-700 transition-colors">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-500" /> Seismic Zone Rating
                    </p>
                    <p className="text-sm md:text-base font-bold text-amber-400 font-display">{specs.seismicZone}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">Ductile Detailing as per IS 13920</span>
                  </div>

                  <div className="bg-slate-950/60 p-4 rounded border border-slate-800/80 hover:border-slate-700 transition-colors">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-1">
                      <Maximize2 className="w-3.5 h-3.5 text-amber-500" /> Built Area / Footprint
                    </p>
                    <p className="text-sm md:text-base font-bold text-white font-display">{specs.builtArea}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">Lot Dimension: {specs.lotSize}</span>
                  </div>

                  <div className="bg-slate-950/60 p-4 rounded border border-slate-800/80 hover:border-slate-700 transition-colors">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-1">
                      <Building className="w-3.5 h-3.5 text-amber-500" /> Foundation Type
                    </p>
                    <p className="text-sm md:text-base font-bold text-white font-display">{specs.foundation}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">Soil Bearing: 180-220 kN/m²</span>
                  </div>

                  <div className="bg-slate-950/60 p-4 rounded border border-slate-800/80 hover:border-slate-700 transition-colors">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-1">
                      <Cpu className="w-3.5 h-3.5 text-amber-500" /> Concrete Grade
                    </p>
                    <p className="text-sm md:text-base font-bold text-white font-display">{specs.concreteGrade}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">Batching Plant Controlled Mix</span>
                  </div>

                  <div className="bg-slate-950/60 p-4 rounded border border-slate-800/80 hover:border-slate-700 transition-colors">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-1">
                      <Award className="w-3.5 h-3.5 text-amber-500" /> Steel Reinforcement
                    </p>
                    <p className="text-sm md:text-base font-bold text-white font-display">{specs.steelGrade}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">Primary Tata Tiscon / JSW Fe550D</span>
                  </div>

                  <div className="bg-slate-950/60 p-4 rounded border border-slate-800/80 hover:border-slate-700 transition-colors">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-1">
                      <Zap className="w-3.5 h-3.5 text-amber-500" /> Renewable Solar
                    </p>
                    <p className="text-sm md:text-base font-bold text-amber-400 font-display">{specs.solarIntegration}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">Micro-inverter / Net Meter Ready</span>
                  </div>

                  <div className="bg-slate-950/60 p-4 rounded border border-slate-800/80 hover:border-slate-700 transition-colors">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-1">
                      <Droplets className="w-3.5 h-3.5 text-amber-500" /> Water Conservation
                    </p>
                    <p className="text-sm md:text-base font-bold text-white font-display">{specs.rainwaterPlan}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">Multi-stage Filtration Sump</span>
                  </div>
                </div>

                {/* Technical Engineering Specifications Table */}
                <div className="bg-slate-950/60 rounded border border-slate-800 overflow-hidden">
                  <div className="p-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
                    <h3 className="font-display font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
                      <FileText className="w-4 h-4 text-amber-500" /> Comprehensive Structural Engineering Matrix
                    </h3>
                    <span className="text-[10px] font-mono text-slate-400">IS & NBC Standard Compliant</span>
                  </div>
                  <div className="divide-y divide-slate-800/60 text-xs">
                    {[
                      { param: "Structural System", value: specs.structuralType, standard: "IS 456:2000 (Plain and Reinforced Concrete)", notes: "Monolithic joint detailing with ductile shear walls" },
                      { param: "Substructure & Foundation", value: specs.foundation, standard: "IS 2911 / IS 1904", notes: "Excavation tested to hard stratum, anti-termite plinth barrier" },
                      { param: "Cement & Mix Chemistry", value: `${specs.concreteGrade} (OPC 53 + Fly-ash Pozzolana)`, standard: "IS 12269 / IS 3812", notes: "Water-cement ratio < 0.42 with polycarboxylate ether plasticizer" },
                      { param: "Reinforcing Steel", value: specs.steelGrade, standard: "IS 1786:2008", notes: "100% mill certified high-elongation seismic grade" },
                      { param: "Seismic Force Resistance", value: specs.seismicZone, standard: "IS 1893 (Part 1): 2016", notes: "Response reduction factor R=5.0 (Special Moment Resisting Frame)" },
                      { param: "Live Load Design Factor", value: "3.0 kN/m² (Residential) / 4.5 kN/m² (Common Areas)", standard: "IS 875 (Part 2)", notes: "Heavy-duty slab design with post-tensioned tendon reinforcement" },
                      { param: "External Facade & Fenestration", value: "Double-Glazed Low-E Acoustic Windows (Rw 38dB)", standard: "ECBC 2017 compliant", notes: "Thermal-break aluminium frames tested to 1.8 kPa wind pressure" },
                      { param: "Waterproofing Barrier", value: "3-Layer Polyurethane Membrane + Crystallization", standard: "ASTM D-412 / DIN 18195", notes: "10-Year leak-proof warranty on roof slabs & wet areas" },
                    ].map((row, idx) => (
                      <div key={idx} className="grid grid-cols-1 md:grid-cols-4 p-3.5 hover:bg-slate-800/30 transition-colors gap-2 items-center">
                        <div className="font-bold text-slate-200">{row.param}</div>
                        <div className="text-amber-400 font-semibold font-mono">{row.value}</div>
                        <div className="text-slate-400 font-mono text-[11px]">{row.standard}</div>
                        <div className="text-slate-500 text-[11px]">{row.notes}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quick Blueprint / 3D Preview if available */}
                {project.architecturalViews && project.architecturalViews.length > 0 && (
                  <div className="bg-slate-950/60 rounded border border-slate-800 p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
                        <Compass className="w-4 h-4 text-amber-500" /> Interactive Blueprint & 3D Spatial Model
                      </h4>
                      <button 
                        onClick={() => setActiveTab('architectural')}
                        className="text-xs text-amber-400 hover:text-amber-300 font-bold uppercase tracking-wider flex items-center gap-1"
                      >
                        Full Screen Viewer <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="h-[280px] w-full rounded overflow-hidden border border-slate-800">
                      <ArchitecturalViewer views={project.architecturalViews} />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 2. STRUCTURAL ENGINEERING TAB */}
            {activeTab === 'structural' && (
              <div id="expanded-tab-structural" role="tabpanel" aria-labelledby="tab-btn-structural" className="space-y-6">
                <div className="bg-slate-950/60 p-5 rounded border border-slate-800 space-y-4">
                  <h3 className="font-display font-bold text-base text-white uppercase tracking-wider flex items-center gap-2">
                    <Building className="w-5 h-5 text-amber-500" /> Foundation & Structural Core Design
                  </h3>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    Engineered by certified structural auditors, the framework utilizes an advanced moment-resisting concrete frame engineered to withstand lateral wind gusts up to 180 km/h and high-frequency seismic acceleration.
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                    <div className="bg-slate-900/80 p-4 rounded border border-slate-800 space-y-2">
                      <span className="text-amber-500 text-xs font-bold uppercase tracking-wider">Substructure Specifications</span>
                      <ul className="space-y-2 text-xs text-slate-300">
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                          <span><strong>Foundation System:</strong> {specs.foundation}</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                          <span><strong>Soil Bearing Capacity:</strong> Tested via standard penetration test (N-value {'>'} 25)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                          <span><strong>Damp-Proof Plinth:</strong> Heavy-duty bitumen primer with 4mm elastomeric membrane</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                          <span><strong>Anti-Termite Treatment:</strong> Chlorpyrifos soil injection certified for 15 years</span>
                        </li>
                      </ul>
                    </div>

                    <div className="bg-slate-900/80 p-4 rounded border border-slate-800 space-y-2">
                      <span className="text-amber-500 text-xs font-bold uppercase tracking-wider">Superstructure & Material Physics</span>
                      <ul className="space-y-2 text-xs text-slate-300">
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                          <span><strong>Concrete Grade:</strong> {specs.concreteGrade} (28-day target strength {'>'} 38.5 MPa)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                          <span><strong>TMT Reinforcement:</strong> {specs.steelGrade} with {'>'} 16% total elongation</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                          <span><strong>Slab System:</strong> 150mm - 200mm solid two-way RCC slab with perimeter drop beams</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                          <span><strong>Masonry Work:</strong> Autoclaved Aerated Concrete (AAC) blocks with thermal insulation (k = 0.16 W/mK)</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Floor Plan Annotator Section */}
                <div className="bg-slate-950/60 p-5 rounded border border-slate-800 space-y-3">
                  <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider flex items-center gap-2">
                    <Compass className="w-4 h-4 text-amber-500" /> Interactive Floor Plan Annotation & Dimensioning
                  </h4>
                  <p className="text-xs text-slate-400">Click on any section of the structural blueprint to inspect zone measurements, beam spans, and load paths.</p>
                  <FloorPlanAnnotator 
                    planTitle={
                      project.architecturalViews?.find(v => v.type === 'blueprint')?.title || 
                      `${project.title} Structural Blueprint`
                    }
                    planUrl={
                      project.architecturalViews?.find(v => v.type === 'blueprint')?.url || 
                      project.image || ""
                    }
                  />
                </div>
              </div>
            )}

            {/* 3. ARCHITECTURAL & BLUEPRINTS TAB */}
            {activeTab === 'architectural' && (
              <div id="expanded-tab-architectural" role="tabpanel" aria-labelledby="tab-btn-architectural" className="space-y-6">
                <div className="bg-slate-950/60 p-5 rounded border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-display font-bold text-base text-white uppercase tracking-wider flex items-center gap-2">
                        <Compass className="w-5 h-5 text-amber-500" /> Architectural Specifications & Spatial Geometry
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">Spatial optimization metrics and building envelope thermal performance.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-slate-900/80 p-3.5 rounded border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Super Built-Up Area</span>
                      <p className="text-lg font-bold text-white font-mono">{specs.builtArea}</p>
                    </div>
                    <div className="bg-slate-900/80 p-3.5 rounded border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Efficiency Ratio</span>
                      <p className="text-lg font-bold text-amber-400 font-mono">84.5% Carpet Area</p>
                    </div>
                    <div className="bg-slate-900/80 p-3.5 rounded border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Clear Ceiling Height</span>
                      <p className="text-lg font-bold text-white font-mono">10 ft 6 in (3.2m)</p>
                    </div>
                    <div className="bg-slate-900/80 p-3.5 rounded border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Window-to-Wall Ratio</span>
                      <p className="text-lg font-bold text-white font-mono">32% High Daylighting</p>
                    </div>
                  </div>

                  {project.architecturalViews && project.architecturalViews.length > 0 ? (
                    <div className="h-[420px] w-full rounded overflow-hidden border border-slate-800 mt-4">
                      <ArchitecturalViewer views={project.architecturalViews} />
                    </div>
                  ) : (
                    <div className="p-8 text-center bg-slate-900 rounded border border-slate-800 text-slate-400 text-sm">
                      Full 3D Renderings and Architectural Elevation sheets loaded into active project archive.
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 4. MEP & SYSTEMS TAB */}
            {activeTab === 'mep' && (
              <div id="expanded-tab-mep" role="tabpanel" aria-labelledby="tab-btn-mep" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Electrical */}
                  <div className="bg-slate-950/60 p-5 rounded border border-slate-800 space-y-3">
                    <div className="flex items-center gap-2 text-amber-400 font-display font-bold text-sm uppercase tracking-wider">
                      <Zap className="w-4 h-4" /> Electrical & Automation
                    </div>
                    <ul className="space-y-2 text-xs text-slate-300">
                      <li>• <strong>Concealed Wiring:</strong> FRLS (Flame Retardant Low Smoke) copper conduits (Finolex/Polycab)</li>
                      <li>• <strong>Smart Automation:</strong> KNX / Zigbee ready IoT electrical infrastructure</li>
                      <li>• <strong>Backup Power:</strong> 100% DG generator tie-in with auto phase selector</li>
                      <li>• <strong>Surge Protection:</strong> Class II SPD lightning and surge protection installed</li>
                    </ul>
                  </div>

                  {/* Plumbing */}
                  <div className="bg-slate-950/60 p-5 rounded border border-slate-800 space-y-3">
                    <div className="flex items-center gap-2 text-amber-400 font-display font-bold text-sm uppercase tracking-wider">
                      <Droplets className="w-4 h-4" /> Plumbing & Hydro Systems
                    </div>
                    <ul className="space-y-2 text-xs text-slate-300">
                      <li>• <strong>Piping Lines:</strong> CPVC Schedule 80 hot/cold lines with brass inserts (Astral)</li>
                      <li>• <strong>Drainage:</strong> SWR ring-fit sound-attenuated drainage lines</li>
                      <li>• <strong>Pressure System:</strong> Hydro-pneumatic pumping system with constant pressure</li>
                      <li>• <strong>Rainwater Tank:</strong> {specs.rainwaterPlan}</li>
                    </ul>
                  </div>

                  {/* HVAC & Air */}
                  <div className="bg-slate-950/60 p-5 rounded border border-slate-800 space-y-3">
                    <div className="flex items-center gap-2 text-amber-400 font-display font-bold text-sm uppercase tracking-wider">
                      <Wind className="w-4 h-4" /> HVAC & Indoor Air Quality
                    </div>
                    <ul className="space-y-2 text-xs text-slate-300">
                      <li>• <strong>Cooling System:</strong> VRV/VRF multi-zone high-efficiency inverter infrastructure</li>
                      <li>• <strong>Ventilation:</strong> Dedicated mechanical exhaust & cross-ventilation shafts</li>
                      <li>• <strong>Acoustic Rating:</strong> Decibel level below 32 dBA in all residential suites</li>
                      <li>• <strong>Solar Array:</strong> {specs.solarIntegration}</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* 5. QUALITY & CERTIFICATIONS TAB */}
            {activeTab === 'quality' && (
              <div id="expanded-tab-quality" role="tabpanel" aria-labelledby="tab-btn-quality" className="space-y-6">
                <div className="bg-slate-950/60 p-5 rounded border border-slate-800 space-y-4">
                  <h3 className="font-display font-bold text-base text-white uppercase tracking-wider flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-500" /> Construction Quality Assurance & Testing Audit
                  </h3>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    Every batch of concrete, steel heat lot, and waterproofing application undergoes third-party laboratory verification before site acceptance.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
                    {[
                      { title: "Concrete Cube Compression", status: "PASSED (100% Tests)", note: "7-day and 28-day testing exceeding design characteristic strength." },
                      { title: "Non-Destructive Rebound Test", status: "PASSED", note: "Schmidt hammer testing across all load-bearing columns." },
                      { title: "Ultrasonic Pulse Velocity", status: "EXCELLENT GRADE", note: "Pulse velocity > 4.2 km/s verifying zero internal honeycombing." },
                      { title: "Steel Tensile & Bend Test", status: "CERTIFIED", note: "Yield strength & elongation verified per IS 1786." },
                      { title: "Waterproofing Flood Test", status: "PASSED (72-Hour Hold)", note: "Ponding tests performed on all roof slabs and wet areas." },
                      { title: "Green Sustainability Rating", status: specs.greenRating, note: "Energy efficiency and low carbon footprint compliance." }
                    ].map((item, idx) => (
                      <div key={idx} className="bg-slate-900/80 p-4 rounded border border-slate-800 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{item.title}</span>
                          <span className="text-[9px] font-mono font-bold bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded border border-green-500/30">
                            {item.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-300 leading-normal">{item.note}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Modal Footer */}
          <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/80 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <ShieldCheck className="w-4 h-4 text-amber-500" aria-hidden="true" />
              <span>Verified by APS Structural Engineering & Quality Assurance Division</span>
            </div>
            
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded font-bold text-xs uppercase tracking-wider transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
              >
                Back to Project
              </button>
              {onInquire && (
                <button
                  onClick={() => {
                    onClose();
                    onInquire();
                  }}
                  className="w-full sm:w-auto px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded font-extrabold text-xs uppercase tracking-widest transition-all shadow-lg flex items-center justify-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Book Site Visit</span>
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
