import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Building2, Compass, ShieldCheck } from 'lucide-react';

interface MovingBrandBackgroundProps {
  variant?: 'hero' | 'ambient' | 'full';
  className?: string;
}

export default function MovingBrandBackground({ 
  variant = 'hero',
  className = '' 
}: MovingBrandBackgroundProps) {
  const phrase1 = "APS BUILDERS & DEVELOPERS • ARCHITECTURAL EXCELLENCE • LUXURY RESIDENCES • COMMERCIAL SPACES • KERALA • SINCE 2012 • ";
  const phrase2 = "APS BUILDERS & DEVELOPERS • MASTER CRAFTSMANSHIP • SUSTAINABLE ECO-VILLAS • ENGINEERING PRECISION • 100+ LANDMARKS • ";
  const phrase3 = "APS BUILDERS & DEVELOPERS • CRAFTING STRUCTURES THAT LAST • VASTU COMPLIANT • PREMIER BUILDERS • ";

  if (variant === 'ambient') {
    return (
      <div className={`overflow-hidden pointer-events-none select-none py-3 bg-slate-950 text-white/20 border-y border-white/5 ${className}`}>
        <motion.div 
          className="flex whitespace-nowrap text-xs font-black uppercase tracking-[0.35em]"
          animate={{ x: [0, -1000] }}
          transition={{
            repeat: Infinity,
            repeatType: 'loop',
            duration: 25,
            ease: 'linear'
          }}
        >
          <span className="flex items-center gap-6 mr-6">
            <span className="text-amber-500 font-extrabold flex items-center gap-2">
              <Building2 className="w-3.5 h-3.5" /> APS BUILDERS & DEVELOPERS
            </span>
            <span>•</span>
            <span>KERALA&apos;S PREMIER CONSTRUCTION FIRM</span>
            <span>•</span>
            <span className="text-amber-500 font-extrabold flex items-center gap-2">
              <Compass className="w-3.5 h-3.5" /> ARCHITECTURAL EXCELLENCE
            </span>
            <span>•</span>
            <span>CRAFTING STRUCTURES THAT LAST</span>
            <span>•</span>
            <span className="text-amber-500 font-extrabold flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5" /> 100+ DELIVERED PROJECTS
            </span>
            <span>•</span>
          </span>
          <span className="flex items-center gap-6 mr-6">
            <span className="text-amber-500 font-extrabold flex items-center gap-2">
              <Building2 className="w-3.5 h-3.5" /> APS BUILDERS & DEVELOPERS
            </span>
            <span>•</span>
            <span>KERALA&apos;S PREMIER CONSTRUCTION FIRM</span>
            <span>•</span>
            <span className="text-amber-500 font-extrabold flex items-center gap-2">
              <Compass className="w-3.5 h-3.5" /> ARCHITECTURAL EXCELLENCE
            </span>
            <span>•</span>
            <span>CRAFTING STRUCTURES THAT LAST</span>
            <span>•</span>
            <span className="text-amber-500 font-extrabold flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5" /> 100+ DELIVERED PROJECTS
            </span>
            <span>•</span>
          </span>
        </motion.div>
      </div>
    );
  }

  return (
    <div className={`absolute inset-0 pointer-events-none select-none overflow-hidden flex flex-col justify-around z-0 ${className}`}>
      {/* Top Stream: Moving Left to Right */}
      <div className="relative w-full opacity-20 -rotate-2 transform scale-105 origin-left">
        <motion.div
          className="flex whitespace-nowrap font-display font-black text-4xl sm:text-6xl md:text-8xl tracking-wider text-transparent"
          style={{
            WebkitTextStroke: '1px rgba(255, 255, 255, 0.4)',
            textShadow: '0 0 20px rgba(245, 158, 11, 0.1)'
          }}
          animate={{ x: [-1500, 0] }}
          transition={{
            repeat: Infinity,
            repeatType: 'loop',
            duration: 35,
            ease: 'linear'
          }}
        >
          <span className="mr-8 inline-block">{phrase1}</span>
          <span className="mr-8 inline-block">{phrase1}</span>
          <span className="mr-8 inline-block">{phrase1}</span>
        </motion.div>
      </div>

      {/* Middle Stream: Huge Bold Center Moving Right to Left */}
      <div className="relative w-full opacity-25 rotate-1 transform scale-110">
        <motion.div
          className="flex whitespace-nowrap font-display font-black text-5xl sm:text-7xl md:text-9xl lg:text-[11rem] tracking-tighter"
          style={{
            WebkitTextStroke: '1.5px rgba(245, 158, 11, 0.45)',
            color: 'transparent'
          }}
          animate={{ x: [0, -1800] }}
          transition={{
            repeat: Infinity,
            repeatType: 'loop',
            duration: 40,
            ease: 'linear'
          }}
        >
          <span className="mr-12 inline-block flex items-center gap-6">
            <span className="text-amber-500/30">★</span> {phrase2}
          </span>
          <span className="mr-12 inline-block flex items-center gap-6">
            <span className="text-amber-500/30">★</span> {phrase2}
          </span>
          <span className="mr-12 inline-block flex items-center gap-6">
            <span className="text-amber-500/30">★</span> {phrase2}
          </span>
        </motion.div>
      </div>

      {/* Bottom Stream: Moving Left to Right */}
      <div className="relative w-full opacity-15 -rotate-1 transform scale-105">
        <motion.div
          className="flex whitespace-nowrap font-display font-extrabold text-3xl sm:text-5xl md:text-7xl tracking-widest text-white/30"
          animate={{ x: [-1400, 0] }}
          transition={{
            repeat: Infinity,
            repeatType: 'loop',
            duration: 30,
            ease: 'linear'
          }}
        >
          <span className="mr-8 inline-block">{phrase3}</span>
          <span className="mr-8 inline-block">{phrase3}</span>
          <span className="mr-8 inline-block">{phrase3}</span>
        </motion.div>
      </div>
    </div>
  );
}
