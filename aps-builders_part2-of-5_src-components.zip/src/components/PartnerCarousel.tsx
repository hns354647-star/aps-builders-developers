import React from 'react';
import { motion } from 'motion/react';

const partners = [
  { name: "CEMENTO+", color: "text-slate-400" },
  { name: "IRON CORE", color: "text-slate-500" },
  { name: "GLASS & CO", color: "text-slate-400" },
  { name: "VANTABLUE", color: "text-slate-500" },
  { name: "OAKWOOD", color: "text-slate-400" },
  { name: "SOLARIS", color: "text-slate-500" },
  { name: "MODERN BRICK", color: "text-slate-400" },
  { name: "URBAN STEEL", color: "text-slate-500" },
  { name: "TECHFLOW", color: "text-slate-400" },
  { name: "PRIME QUARRY", color: "text-slate-500" },
];

export default function PartnerCarousel() {
  // Duplicate partners array to ensure seamless infinite scroll
  const repeatedPartners = [...partners, ...partners, ...partners];

  return (
    <section className="py-12 bg-slate-100 border-y border-slate-200 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 mb-8 text-center">
        <span className="text-[10px] font-bold uppercase tracking-[0.4em] text-slate-400">
          Our Strategic Global Partners
        </span>
      </div>
      
      <motion.div 
        className="relative flex"
        onMouseEnter={() => {}} // Could add pause logic here if needed, but let's use transition-play-state
      >
        {/* Shadow Overlay Left */}
        <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-slate-100 to-transparent z-10 pointer-events-none" />
        
        <motion.div 
          className="flex items-center gap-16 whitespace-nowrap py-4"
          initial={{ x: 0 }}
          animate={{
            x: ["0%", "-50%"], 
          }}
          transition={{
            duration: 60,
            repeat: Infinity,
            ease: "linear",
          }}
          whileHover={{ animationPlayState: "paused" }} // Note: Framer motion style syntax
          style={{ cursor: 'grab' }}
        >
          {repeatedPartners.map((partner, index) => (
            <div 
              key={`${partner.name}-${index}`} 
              className="group flex flex-col items-center justify-center grayscale hover:grayscale-0 transition-all duration-700"
            >
              <span className={`font-display text-2xl font-black tracking-tighter opacity-20 group-hover:opacity-100 transition-all cursor-default ${partner.color} scale-90 group-hover:scale-105`}>
                {partner.name}
              </span>
              <div className="w-0 group-hover:w-full h-[1px] bg-amber-600 transition-all duration-700 mt-2" />
            </div>
          ))}
        </motion.div>

        {/* Shadow Overlay Right */}
        <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-slate-100 to-transparent z-10 pointer-events-none" />
      </motion.div>
    </section>
  );
}
