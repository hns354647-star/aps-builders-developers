import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { TrendingUp, Info, ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';

interface ROIChartProps {
  initialInvestment: number;
  projectTitle: string;
}

interface DataPoint {
  year: number;
  value: number;
}

export default function ProjectROIChart({ initialInvestment, projectTitle }: ROIChartProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoveredData, setHoveredData] = useState<DataPoint | null>(null);

  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;

    // Clear previous SVG content
    d3.select(svgRef.current).selectAll("*").remove();

    const margin = { top: 40, right: 40, bottom: 40, left: 60 };
    const width = containerRef.current.clientWidth - margin.left - margin.right;
    const height = 300 - margin.top - margin.bottom;

    const svg = d3.select(svgRef.current)
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // Generate ROI Data: 7% annual appreciation for Kerala Real Estate (Premium)
    const annualAppreciation = 0.07;
    const data: DataPoint[] = Array.from({ length: 21 }, (_, i) => ({
      year: i,
      value: initialInvestment * Math.pow(1 + annualAppreciation, i)
    }));

    // Scales
    const x = d3.scaleLinear()
      .domain([0, 20])
      .range([0, width]);

    const y = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.value) || 0])
      .range([height, 0]);

    // Grid lines
    svg.append("g")
      .attr("class", "grid")
      .attr("opacity", 0.1)
      .call(d3.axisLeft(y)
        .tickSize(-width)
        .tickFormat(() => "")
      );

    // Axes
    svg.append("g")
      .attr("transform", `translate(0,${height})`)
      .attr("class", "text-[10px] font-mono text-slate-400")
      .call(d3.axisBottom(x).ticks(5).tickFormat(d => `Yr ${d}`));

    svg.append("g")
      .attr("class", "text-[10px] font-mono text-slate-400")
      .call(d3.axisLeft(y).ticks(5).tickFormat(d => `₹${(Number(d) / 100000).toFixed(0)}L`));

    // Area Generator
    const area = d3.area<DataPoint>()
      .x(d => x(d.year))
      .y0(height)
      .y1(d => y(d.value))
      .curve(d3.curveCardinal);

    // Add Area
    svg.append("path")
      .datum(data)
      .attr("fill", "url(#roi-gradient)")
      .attr("d", area);

    // Line Generator
    const line = d3.line<DataPoint>()
      .x(d => x(d.year))
      .y(d => y(d.value))
      .curve(d3.curveCardinal);

    // Gradient definition
    const defs = d3.select(svgRef.current).append("defs");
    const gradient = defs.append("linearGradient")
      .attr("id", "roi-gradient")
      .attr("x1", "0%").attr("y1", "0%")
      .attr("x2", "0%").attr("y2", "100%");

    gradient.append("stop").attr("offset", "0%").attr("stop-color", "#d97706").attr("stop-opacity", 0.2);
    gradient.append("stop").attr("offset", "100%").attr("stop-color", "#d97706").attr("stop-opacity", 0);

    // Add Line
    const path = svg.append("path")
      .datum(data)
      .attr("fill", "none")
      .attr("stroke", "#d97706")
      .attr("stroke-width", 2)
      .attr("d", line);

    // Animation
    const totalLength = (path.node() as SVGPathElement).getTotalLength();
    path
      .attr("stroke-dasharray", totalLength + " " + totalLength)
      .attr("stroke-dashoffset", totalLength)
      .transition()
      .duration(2000)
      .ease(d3.easeCubicOut)
      .attr("stroke-dashoffset", 0);

    // Interactivity: Overlay for mouse tracking
    const bisect = d3.bisector<DataPoint, number>(d => d.year).left;

    svg.append("rect")
      .attr("width", width)
      .attr("height", height)
      .attr("fill", "transparent")
      .on("mousemove", (event) => {
        const [mouseX] = d3.pointer(event);
        const x0 = x.invert(mouseX);
        const i = bisect(data, x0, 1);
        const d0 = data[i - 1];
        const d1 = data[i];
        const d = x0 - d0.year > d1.year - x0 ? d1 : d0;
        setHoveredData(d);
      })
      .on("mouseleave", () => setHoveredData(null));

  }, [initialInvestment]);

  const stats = [
    { label: '5 Year Value', year: 5 },
    { label: '10 Year Value', year: 10 },
    { label: '20 Year Value', year: 20 }
  ];

  const calculateValue = (years: number) => {
    return initialInvestment * Math.pow(1.07, years);
  };

  return (
    <div className="bg-white border border-slate-100 p-6 rounded-sm space-y-6 overflow-hidden">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
            <div className="p-1.5 bg-amber-50 rounded-full">
                <TrendingUp className="w-3.5 h-3.5 text-amber-600" />
            </div>
            <h4 className="text-[10px] font-bold text-slate-900 uppercase tracking-widest leading-none">Investment ROI Analysis: {projectTitle}</h4>
        </div>
        <div className="flex items-center gap-1 text-[8px] font-bold text-slate-400 uppercase tracking-widest">
            <Info className="w-3 h-3" />
            Compounded Appreciation
        </div>
      </div>

      <div ref={containerRef} className="relative h-[300px] w-full">
        <svg ref={svgRef} className="w-full h-full" />
        
        {/* Cursor/Tooltip Line */}
        {hoveredData && (
            <div 
                className="absolute top-[40px] bottom-[40px] w-px bg-amber-600/30 pointer-events-none transition-all duration-75"
                style={{ left: `${60 + (hoveredData.year / 20) * (containerRef.current?.clientWidth! - 100)}px` }}
            >
                <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-2 py-1 rounded text-[9px] font-mono whitespace-nowrap shadow-xl">
                    Year {hoveredData.year}: ₹{(hoveredData.value / 100000).toFixed(1)}L
                </div>
                <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 w-2 h-2 bg-amber-600 rounded-full ring-4 ring-amber-600/20" />
            </div>
        )}
      </div>

      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-100">
        {stats.map((s) => {
          const value = calculateValue(s.year);
          const roi = ((value - initialInvestment) / initialInvestment) * 100;
          return (
            <div key={s.year} className="space-y-1 p-3 bg-slate-50 border border-slate-100 rounded-sm">
              <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">{s.label}</p>
              <div className="flex items-baseline gap-1">
                <span className="text-sm font-bold text-slate-900">₹{(value / 100000).toFixed(1)}L</span>
                <span className="text-[9px] font-mono font-bold text-emerald-600">+{roi.toFixed(0)}%</span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex items-start gap-2 bg-amber-50 p-3 rounded-sm border border-amber-100">
        <ArrowUpRight className="w-3.5 h-3.5 text-amber-600 mt-0.5 flex-shrink-0" />
        <p className="text-[9px] text-amber-900 leading-relaxed font-medium">
          <span className="font-bold">STRATEGIC OUTLOOK:</span> Typical premium residential assets in this sector see a consistent 7% annual value appreciation. This forecast includes built-up equity and land value appreciation over 20 years.
        </p>
      </div>
    </div>
  );
}
