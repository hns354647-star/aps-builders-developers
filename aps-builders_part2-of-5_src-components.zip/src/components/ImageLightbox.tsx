import React, { useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { buildSanityImageUrl } from '../lib/sanityClient';

export interface LightboxImage {
  url: string;
  alt: string;
  caption?: string;
  category?: string;
}

interface ImageLightboxProps {
  isOpen: boolean;
  onClose: () => void;
  images: LightboxImage[];
  currentIndex: number;
  onNavigate: (newIndex: number) => void;
}

export const ImageLightbox: React.FC<ImageLightboxProps> = ({
  isOpen,
  onClose,
  images,
  currentIndex,
  onNavigate,
}) => {
  const currentImage = images[currentIndex];

  const handleNext = useCallback(() => {
    if (images.length <= 1) return;
    onNavigate((currentIndex + 1) % images.length);
  }, [currentIndex, images.length, onNavigate]);

  const handlePrev = useCallback(() => {
    if (images.length <= 1) return;
    onNavigate((currentIndex - 1 + images.length) % images.length);
  }, [currentIndex, images.length, onNavigate]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, handleNext, handlePrev]);

  if (!isOpen || !currentImage) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="fixed inset-0 z-50 bg-black/95 text-white flex flex-col justify-between p-4 sm:p-8"
        role="dialog"
        aria-modal="true"
      >
        {/* Top Control Bar */}
        <div className="flex items-center justify-between z-10 w-full max-w-7xl mx-auto">
          <div className="text-xs uppercase tracking-[0.2em] text-stone-400 font-mono">
            {currentIndex + 1} / {images.length}
            {currentImage.category && <span className="ml-3 text-stone-200">· {currentImage.category}</span>}
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-white transition-colors focus:outline-none"
            aria-label="Fermer la vue plein écran"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Center Image Container */}
        <div className="relative flex-1 flex items-center justify-center my-4 overflow-hidden max-w-6xl mx-auto w-full">
          {images.length > 1 && (
            <button
              onClick={handlePrev}
              className="absolute left-2 sm:left-4 z-20 p-3 bg-black/50 hover:bg-black/80 rounded-full text-white transition-colors focus:outline-none"
              aria-label="Photo précédente"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
          )}

          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            className="max-h-[80vh] flex items-center justify-center"
          >
            <img
              src={buildSanityImageUrl(currentImage.url, {
                width: 1800,
                quality: 85,
                auto: 'format',
              })}
              alt={currentImage.alt}
              className="max-h-[78vh] max-w-full object-contain shadow-2xl"
            />
          </motion.div>

          {images.length > 1 && (
            <button
              onClick={handleNext}
              className="absolute right-2 sm:right-4 z-20 p-3 bg-black/50 hover:bg-black/80 rounded-full text-white transition-colors focus:outline-none"
              aria-label="Photo suivante"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          )}
        </div>

        {/* Bottom Caption Bar */}
        <div className="w-full max-w-4xl mx-auto text-center z-10">
          {currentImage.caption && (
            <p className="text-sm font-light text-stone-300 font-sans tracking-wide">
              {currentImage.caption}
            </p>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default ImageLightbox;
