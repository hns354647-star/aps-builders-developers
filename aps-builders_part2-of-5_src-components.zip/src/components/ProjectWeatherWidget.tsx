import React, { useState, useEffect } from 'react';
import { Cloud, Sun, CloudRain, Thermometer, Droplets, Wind, RefreshCcw } from 'lucide-react';
import { motion } from 'motion/react';

interface WeatherWidgetProps {
  location: string;
}

export default function ProjectWeatherWidget({ location }: WeatherWidgetProps) {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({
    temp: 29,
    condition: 'Partly Cloudy',
    humidity: 78,
    wind: 12,
    status: 'Optimal for Structural Work'
  });

  useEffect(() => {
    // Mocking an API fetch for site-specific weather
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1200);
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return (
      <div className="bg-slate-50 border border-slate-100 p-4 rounded-sm animate-pulse flex items-center justify-center gap-4 h-[100px]">
        <RefreshCcw className="w-4 h-4 text-slate-300 animate-spin" />
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">Architectural Site Telemetry...</span>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-50 border border-slate-100 p-4 rounded-sm space-y-4"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Cloud className="w-4 h-4 text-amber-600" />
          <h4 className="text-[10px] font-bold text-slate-900 uppercase tracking-widest">Site Conditions: {location}</h4>
        </div>
        <div className="px-2 py-0.5 bg-emerald-100 rounded-full">
           <span className="text-[7px] font-bold text-emerald-700 uppercase tracking-widest">Live</span>
        </div>
      </div>

      <div className="flex items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Sun className="w-8 h-8 text-amber-500" />
            <Cloud className="absolute -bottom-1 -right-1 w-5 h-5 text-slate-400 fill-white" />
          </div>
          <div>
            <div className="text-2xl font-mono font-bold text-slate-900">{data.temp}°C</div>
            <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">{data.condition}</p>
          </div>
        </div>

        <div className="flex-1 space-y-2 border-l border-slate-200 pl-6">
           <div className="flex items-center justify-between">
              <div className="flex items-center gap-1 text-slate-400">
                <Droplets className="w-3 h-3" />
                <span className="text-[8px] font-bold uppercase tracking-tighter">Humidity</span>
              </div>
              <span className="text-[9px] font-bold text-slate-900">{data.humidity}%</span>
           </div>
           <div className="flex items-center justify-between">
              <div className="flex items-center gap-1 text-slate-400">
                <Wind className="w-3 h-3" />
                <span className="text-[8px] font-bold uppercase tracking-tighter">Wind Speed</span>
              </div>
              <span className="text-[9px] font-bold text-slate-900">{data.wind} km/h</span>
           </div>
        </div>
      </div>

      <div className="pt-2 border-t border-slate-200">
         <p className="text-[8px] italic text-amber-700 font-medium">
           NOTE: {data.status} based on current humidity levels.
         </p>
      </div>
    </motion.div>
  );
}
