import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { createXRStore, XR } from '@react-three/xr';
import { MaterialType } from './MaterialCustomizer';

const store = createXRStore({
  depthSensing: true,
  handTracking: true,
  hitTest: true,
});

interface ARVisualizerProps {
  materialId: MaterialType;
  isOpen: boolean;
  onClose: () => void;
}

const materialConfigs: Record<MaterialType, { color: string; roughness: number; metalness: number }> = {
  original: { color: '#e2e8f0', roughness: 0.8, metalness: 0 },
  marble: { color: '#ffffff', roughness: 0.1, metalness: 0.1 },
  granite: { color: '#1e293b', roughness: 0.3, metalness: 0.2 },
  oak: { color: '#fef3c7', roughness: 0.7, metalness: 0 },
  slate: { color: '#475569', roughness: 0.9, metalness: 0 },
};

function ARScene({ materialId }: { materialId: MaterialType }) {
  const config = materialConfigs[materialId];

  return (
    <>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      
      {/* Sample "Surface" for AR preview */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1, -2]}>
        <planeGeometry args={[2, 2]} />
        <meshStandardMaterial 
          color={config.color} 
          roughness={config.roughness} 
          metalness={config.metalness}
        />
      </mesh>

      {/* Decorative Pillar to see material applied to volume */}
      <mesh position={[1, 0, -3]}>
        <cylinderGeometry args={[0.2, 0.2, 2, 32]} />
        <meshStandardMaterial 
           color={config.color} 
           roughness={config.roughness} 
           metalness={config.metalness}
        />
      </mesh>
    </>
  );
}

export default function ARVisualizer({ materialId, isOpen, onClose }: ARVisualizerProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[300] bg-black/90 flex flex-col items-center justify-center p-6">
      <div className="absolute top-6 right-6 z-[310]">
        <button 
          onClick={onClose}
          className="bg-white/10 hover:bg-white/20 text-white p-3 rounded-full backdrop-blur-md transition-colors"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      <div className="text-center mb-8 space-y-2">
        <h2 className="text-2xl font-display font-bold text-white uppercase tracking-wider">Augmented Reality Preview</h2>
        <p className="text-slate-400 text-sm max-w-sm mx-auto">
          Project the <strong>{materialId}</strong> finish onto your physical environment. 
          Tap "Start AR" and point your camera at a flat surface.
        </p>
      </div>

      <div className="w-full max-w-2xl h-[400px] bg-slate-900 rounded-sm border border-white/10 relative overflow-hidden">
        <button 
          onClick={() => store.enterAR()}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-[310] bg-amber-600 text-white font-bold px-8 py-4 rounded-full shadow-xl hover:bg-amber-700 transition-colors uppercase tracking-widest text-xs"
        >
          Start AR Experience
        </button>
        <Canvas>
          <XR store={store}>
            <Suspense fallback={null}>
              <ARScene materialId={materialId} />
            </Suspense>
          </XR>
        </Canvas>
      </div>

      <div className="mt-8 flex gap-4 text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">
        <span className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          WebXR Support Detected
        </span>
        <span>•</span>
        <span>Mobile Optimized</span>
      </div>
    </div>
  );
}
