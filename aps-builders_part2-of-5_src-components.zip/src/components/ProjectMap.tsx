import React, { useState, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  TransformWrapper, 
  TransformComponent, 
  useControls 
} from 'react-zoom-pan-pinch';
import { 
  MapPin, 
  Building2, 
  Home as HomeIcon, 
  School, 
  ArrowRight, 
  Layers, 
  Sparkles, 
  Compass, 
  Mountain, 
  Waves, 
  Trees, 
  CheckCircle2, 
  Clock, 
  Eye, 
  ExternalLink,
  ChevronRight,
  ChevronLeft,
  ShieldCheck,
  Zap,
  Info,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Maximize2,
  Move,
  X,
  Target
} from 'lucide-react';
import { PROJECTS, Project } from '../data/projects';

export interface RegionData {
  id: string;
  name: string;
  shortName: string;
  district: string;
  svgPath: string;
  labelCoord: { x: number; y: number };
  pinCoord: { x: number; y: number };
  terrainType: string;
  climate: string;
  soilFoundation: string;
  icon: typeof Mountain | typeof Waves | typeof Trees | typeof Building2;
  architectureFocus: string;
  elevation: string;
  colorAccent: string;
  fillColor: string;
  activeFill: string;
}

export const REGIONS: RegionData[] = [
  {
    id: 'ernakulam',
    name: 'Ernakulam & Kochi Metropolis',
    shortName: 'Kochi & Ernakulam',
    district: 'Ernakulam',
    svgPath: 'M 140 330 L 195 320 L 235 340 L 245 390 L 205 425 L 155 420 L 125 385 Z',
    labelCoord: { x: 180, y: 375 },
    pinCoord: { x: 175, y: 370 },
    terrainType: 'Coastal Estuarine & Urban Waterfront',
    climate: 'Tropical Maritime (85% Avg. Humidity)',
    soilFoundation: 'Deep Marine Clay & Alluvial Piling',
    icon: Building2,
    architectureFocus: 'High-rise structural glazing, saline-resistant coatings, smart climate automation & waterfront cantilever decks.',
    elevation: '2 - 12m ASL',
    colorAccent: 'text-amber-500',
    fillColor: 'fill-amber-500/10 hover:fill-amber-500/25',
    activeFill: 'fill-amber-500/35'
  },
  {
    id: 'thrissur',
    name: 'Thrissur Cultural Heartland',
    shortName: 'Thrissur',
    district: 'Thrissur',
    svgPath: 'M 160 220 L 230 210 L 270 245 L 260 300 L 220 325 L 155 315 L 140 265 Z',
    labelCoord: { x: 205, y: 265 },
    pinCoord: { x: 200, y: 260 },
    terrainType: 'Central Midlands & Lowland Plains',
    climate: 'Warm Humid Monsoonal',
    soilFoundation: 'Lateritic Red Loam with High Bearing Capacity',
    icon: Trees,
    architectureFocus: 'Neo-vernacular traditional courtyard palaces (Nalukettu), handcrafted teak pillars, and sustainable cross-ventilation.',
    elevation: '15 - 45m ASL',
    colorAccent: 'text-emerald-500',
    fillColor: 'fill-emerald-500/10 hover:fill-emerald-500/25',
    activeFill: 'fill-emerald-500/35'
  },
  {
    id: 'idukki',
    name: 'Idukki High Ranges & Munnar',
    shortName: 'Idukki',
    district: 'Idukki',
    svgPath: 'M 255 310 L 320 290 L 375 330 L 360 410 L 295 440 L 245 400 L 240 345 Z',
    labelCoord: { x: 305, y: 365 },
    pinCoord: { x: 310, y: 350 },
    terrainType: 'Rugged Mountain Slope & Shola Highlands',
    climate: 'Sub-Tropical Highland Mist (15°C - 24°C)',
    soilFoundation: 'Granite Bedrock & Reinforced Contour Terracing',
    icon: Mountain,
    architectureFocus: 'Slope-stabilized cantilever villas, seismic-resistant foundation grids, thermal glazing, and panoramic tea-estate viewports.',
    elevation: '850 - 1,450m ASL',
    colorAccent: 'text-indigo-400',
    fillColor: 'fill-indigo-500/10 hover:fill-indigo-500/25',
    activeFill: 'fill-indigo-500/35'
  },
  {
    id: 'alappuzha',
    name: 'Alappuzha Backwaters & Kuttanad',
    shortName: 'Alappuzha',
    district: 'Alappuzha',
    svgPath: 'M 130 430 L 180 430 L 195 490 L 175 550 L 125 540 L 115 480 Z',
    labelCoord: { x: 155, y: 490 },
    pinCoord: { x: 150, y: 485 },
    terrainType: 'Deltaic Waterway & Backwater Shoreline',
    climate: 'Equatorial Humid & Tidal Influence',
    soilFoundation: 'Hydraulic Micro-Piling & Water-Resistant Plinths',
    icon: Waves,
    architectureFocus: 'Hydro-isolated foundations, high-tide flood protection, permeable timber framing, and heritage sloped gables.',
    elevation: '-1.5 - 5m ASL (Below Sea Level in Kuttanad)',
    colorAccent: 'text-cyan-400',
    fillColor: 'fill-cyan-500/10 hover:fill-cyan-500/25',
    activeFill: 'fill-cyan-500/35'
  },
  {
    id: 'kottayam',
    name: 'Kottayam Plantation Hinterland',
    shortName: 'Kottayam',
    district: 'Kottayam',
    svgPath: 'M 195 435 L 260 430 L 285 485 L 250 540 L 190 535 L 185 475 Z',
    labelCoord: { x: 230, y: 485 },
    pinCoord: { x: 235, y: 475 },
    terrainType: 'Undulating Laterite Hills & Rubber Plantations',
    climate: 'Moderate Tropical with Plentiful Rainfall',
    soilFoundation: 'Firm Laterite Subgrade & Hardpan',
    icon: Trees,
    architectureFocus: 'Net-zero sustainable homes, integrated solar arrays, rainwater recharging, and bioclimatic thermal mass walls.',
    elevation: '30 - 120m ASL',
    colorAccent: 'text-amber-400',
    fillColor: 'fill-amber-500/10 hover:fill-amber-500/25',
    activeFill: 'fill-amber-500/35'
  },
  {
    id: 'pathanamthitta',
    name: 'Pathanamthitta Sacred Midlands',
    shortName: 'Pathanamthitta',
    district: 'Pathanamthitta',
    svgPath: 'M 255 520 L 320 500 L 340 570 L 290 615 L 235 595 L 245 540 Z',
    labelCoord: { x: 285, y: 560 },
    pinCoord: { x: 290, y: 550 },
    terrainType: 'Forest Foothills & River Valleys',
    climate: 'Tropical Forest Microclimate',
    soilFoundation: 'Red Gravel & Compact Silt Subbase',
    icon: Mountain,
    architectureFocus: 'Acoustic institutional complexes, expansive auditoriums, stone-masonry accents, and durable low-maintenance structures.',
    elevation: '60 - 320m ASL',
    colorAccent: 'text-teal-400',
    fillColor: 'fill-teal-500/10 hover:fill-teal-500/25',
    activeFill: 'fill-teal-500/35'
  },
  {
    id: 'coastal_malabar',
    name: 'Malabar North Coastal Belt',
    shortName: 'Coastal Kerala',
    district: 'Coastal Kerala',
    svgPath: 'M 90 90 L 160 80 L 195 130 L 180 200 L 140 210 L 85 150 Z',
    labelCoord: { x: 135, y: 145 },
    pinCoord: { x: 135, y: 135 },
    terrainType: 'Arabian Sea Shoreline & Coastal Cliffs',
    climate: 'Maritime Monsoonal & Heavy Sea Spray',
    soilFoundation: 'Cliffside Anchored Caissons & Marine Piles',
    icon: Waves,
    architectureFocus: 'Oceanfront sanctuaries, infinity pool cantilevers, hurricane-rated glass, and architectural raw stone.',
    elevation: '0 - 45m ASL',
    colorAccent: 'text-sky-400',
    fillColor: 'fill-sky-500/10 hover:fill-sky-500/25',
    activeFill: 'fill-sky-500/35'
  }
];

interface ProjectMapProps {
  onSelectProject?: (project: Project) => void;
}

// Inner Controls component to interface with react-zoom-pan-pinch hooks
function MapZoomControls({ currentScale }: { currentScale: number }) {
  const { zoomIn, zoomOut, resetTransform } = useControls();

  return (
    <div className="absolute top-3 right-3 z-30 flex flex-col gap-1.5 bg-slate-950/85 backdrop-blur-md p-1.5 rounded-xl border border-slate-700/80 shadow-2xl">
      <button
        onClick={() => zoomIn(0.3)}
        className="w-8 h-8 rounded-lg bg-slate-900 hover:bg-amber-500 hover:text-slate-950 text-slate-200 border border-slate-800 flex items-center justify-center transition-all shadow-sm"
        title="Zoom In (+)"
        id="map-zoom-in-btn"
      >
        <ZoomIn className="w-4 h-4" />
      </button>
      <button
        onClick={() => zoomOut(0.3)}
        className="w-8 h-8 rounded-lg bg-slate-900 hover:bg-amber-500 hover:text-slate-950 text-slate-200 border border-slate-800 flex items-center justify-center transition-all shadow-sm"
        title="Zoom Out (-)"
        id="map-zoom-out-btn"
      >
        <ZoomOut className="w-4 h-4" />
      </button>
      <button
        onClick={() => resetTransform(300)}
        className="w-8 h-8 rounded-lg bg-slate-900 hover:bg-amber-500 hover:text-slate-950 text-slate-200 border border-slate-800 flex items-center justify-center transition-all shadow-sm"
        title="Reset Zoom & Pan"
        id="map-zoom-reset-btn"
      >
        <RotateCcw className="w-3.5 h-3.5" />
      </button>
      <div className="text-[9px] font-mono text-center text-amber-400/90 font-bold px-1 py-0.5 border-t border-slate-800/80 mt-0.5">
        {Math.round(currentScale * 100)}%
      </div>
    </div>
  );
}

export default function ProjectMap({ onSelectProject }: ProjectMapProps) {
  const [selectedRegionId, setSelectedRegionId] = useState<string>('ernakulam');
  const [hoveredRegionId, setHoveredRegionId] = useState<string | null>(null);
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [hoveredProject, setHoveredProject] = useState<Project | null>(null);
  const [mapScale, setMapScale] = useState<number>(1);
  
  // Interactive Hotspot Popover Card state
  const [activeHotspotCard, setActiveHotspotCard] = useState<{
    region: RegionData;
    projectIndex: number;
  } | null>({
    region: REGIONS[0],
    projectIndex: 0
  });

  // Active region data object
  const activeRegion = useMemo(() => {
    return REGIONS.find(r => r.id === selectedRegionId) || REGIONS[0];
  }, [selectedRegionId]);

  // Projects belonging to a specific region
  const getProjectsInRegion = (region: RegionData) => {
    return PROJECTS.filter(p => {
      const loc = p.location.toLowerCase();
      const dist = region.district.toLowerCase();
      const shortN = region.shortName.toLowerCase();
      
      if (region.id === 'ernakulam') {
        return loc.includes('ernakulam') || loc.includes('kochi');
      }
      if (region.id === 'alappuzha') {
        return loc.includes('alappuzha') || loc.includes('nedumudy');
      }
      if (region.id === 'idukki') {
        return loc.includes('idukki') || loc.includes('chinnakanal');
      }
      if (region.id === 'coastal_malabar') {
        return loc.includes('coastal') || p.id === 'crystal-point';
      }
      return loc.includes(dist) || loc.includes(shortN);
    });
  };

  // Projects currently displayed in the summary card based on active region & filters
  const regionProjects = useMemo(() => {
    const list = getProjectsInRegion(activeRegion);
    if (typeFilter === 'All') return list;
    return list.filter(p => p.type.toLowerCase() === typeFilter.toLowerCase());
  }, [activeRegion, typeFilter]);

  // Aggregate stats for the selected region
  const regionStats = useMemo(() => {
    const allInRegion = getProjectsInRegion(activeRegion);
    const completed = allInRegion.filter(p => p.status === 'Completed').length;
    const inProgress = allInRegion.filter(p => p.status === 'Under Construction').length;
    const planning = allInRegion.filter(p => p.status === 'Planning' || p.status === 'Featured').length;
    const totalCost = allInRegion.reduce((sum, p) => sum + (p.cost || 25000000), 0);

    return {
      total: allInRegion.length,
      completed,
      inProgress,
      planning,
      totalCostFormatted: totalCost >= 10000000 
        ? `₹${(totalCost / 10000000).toFixed(1)} Cr` 
        : `₹${(totalCost / 100000).toFixed(1)} Lakh`
    };
  }, [activeRegion]);

  // Handle clicking on a regional hotspot
  const handleHotspotClick = (region: RegionData, explicitProject?: Project) => {
    setSelectedRegionId(region.id);
    const inRegion = getProjectsInRegion(region);
    let pIdx = 0;
    if (explicitProject) {
      const foundIdx = inRegion.findIndex(p => p.id === explicitProject.id);
      if (foundIdx !== -1) pIdx = foundIdx;
    }
    setActiveHotspotCard({
      region,
      projectIndex: pIdx
    });
  };

  const hotspotProjects = useMemo(() => {
    if (!activeHotspotCard) return [];
    return getProjectsInRegion(activeHotspotCard.region);
  }, [activeHotspotCard]);

  const activeHotspotProject = useMemo(() => {
    if (!activeHotspotCard || hotspotProjects.length === 0) return null;
    const idx = Math.min(activeHotspotCard.projectIndex, hotspotProjects.length - 1);
    return hotspotProjects[idx];
  }, [activeHotspotCard, hotspotProjects]);

  return (
    <section className="py-20 lg:py-28 bg-[#090e1a] text-slate-100 overflow-hidden relative" id="project-map">
      {/* Background Decorative Grids */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:24px_24px] opacity-20 pointer-events-none" />
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6 border-b border-slate-800/80 pb-8">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full text-amber-400 font-mono text-[11px] uppercase tracking-wider font-semibold">
              <Compass className="w-3.5 h-3.5 animate-spin-slow" />
              Interactive Geospatial Map with Zoom & Pan
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight">
              Architectural Footprints <br />
              <span className="bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500 bg-clip-text text-transparent">
                Across Regional Kerala
              </span>
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
              Use mouse drag or pinch gestures to pan and zoom across Kerala. Click any regional hotspot, district boundary, or beacon pin to instantly pop up project summary cards and engineering blueprints.
            </p>
          </div>

          {/* Quick Region Selector Pills */}
          <div className="flex flex-wrap gap-1.5 items-center max-w-md self-start md:self-end">
            <span className="text-[10px] text-slate-500 uppercase tracking-widest font-mono font-bold mr-1">
              Select Zone:
            </span>
            {REGIONS.map((region) => {
              const isSelected = selectedRegionId === region.id;
              const count = getProjectsInRegion(region).length;
              return (
                <button
                  key={region.id}
                  onClick={() => handleHotspotClick(region)}
                  className={`px-3 py-1.5 rounded text-[11px] font-medium transition-all flex items-center gap-1.5 border ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 font-bold border-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.35)]'
                      : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
                  }`}
                  id={`region-btn-${region.id}`}
                >
                  <span>{region.shortName}</span>
                  <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold ${isSelected ? 'bg-black/20 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Grid: Interactive Localized SVG Map + Area Summary Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT: Zoom & Pan SVG Vector Map (5 Cols) */}
          <div className="lg:col-span-5 w-full bg-[#0c1322] border border-slate-800/90 rounded-2xl p-5 relative shadow-2xl flex flex-col items-center justify-between min-h-[620px]">
            
            {/* Map HUD Header */}
            <div className="w-full flex items-center justify-between border-b border-slate-800/80 pb-3 mb-2">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="font-mono text-[10px] uppercase tracking-wider text-slate-400 font-bold">
                  Vector Map • Zoom & Pan Enabled
                </span>
              </div>
              <div className="text-[10px] font-mono text-amber-400/90 font-semibold flex items-center gap-1.5">
                <Move className="w-3 h-3 text-slate-400" />
                <span>Drag to Pan • Pinch to Zoom</span>
              </div>
            </div>

            {/* Transform Container with react-zoom-pan-pinch */}
            <div className="relative w-full h-[460px] overflow-hidden rounded-xl bg-slate-950/60 border border-slate-800/60 flex items-center justify-center">
              
              <TransformWrapper
                initialScale={1}
                minScale={0.75}
                maxScale={4}
                centerOnInit={true}
                wheel={{ step: 0.12 }}
                pinch={{ step: 4 }}
                doubleClick={{ mode: 'zoomIn', step: 0.5 }}
                panning={{ velocityDisabled: false }}
                onTransform={(ref) => {
                  setMapScale(ref.state.scale);
                }}
              >
                {({ zoomIn, zoomOut, resetTransform }) => (
                  <>
                    <MapZoomControls currentScale={mapScale} />

                    <TransformComponent
                      wrapperClass="!w-full !h-full cursor-grab active:cursor-grabbing"
                      contentClass="!w-full !h-full flex items-center justify-center"
                    >
                      <div className="relative w-full max-w-[340px] aspect-[520/780] select-none p-2">
                        
                        {/* Background Coastline & Neon Glow SVG */}
                        <svg 
                          viewBox="0 0 450 750" 
                          className="w-full h-full filter drop-shadow-[0_0_20px_rgba(245,158,11,0.12)]"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <defs>
                            {/* Neon Glow Filters */}
                            <filter id="glow-amber" x="-20%" y="-20%" width="140%" height="140%">
                              <feGaussianBlur stdDeviation="6" result="blur" />
                              <feComposite in="SourceGraphic" in2="blur" operator="over" />
                            </filter>
                            <linearGradient id="activeRegionGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.55" />
                              <stop offset="100%" stopColor="#d97706" stopOpacity="0.20" />
                            </linearGradient>
                            <linearGradient id="mapCoastGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                              <stop offset="0%" stopColor="#0284c7" stopOpacity="0.18" />
                              <stop offset="100%" stopColor="transparent" stopOpacity="0" />
                            </linearGradient>
                            <linearGradient id="hotspotPulseGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#fbbf24" stopOpacity="0.9" />
                              <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.4" />
                            </linearGradient>
                          </defs>

                          {/* Ambient Coastal Water Shelf */}
                          <path 
                            d="M 60 70 Q 110 350 100 700 L 40 700 L 40 70 Z" 
                            fill="url(#mapCoastGradient)"
                            className="pointer-events-none"
                          />

                          {/* State Outline Boundary Line (Subtle) */}
                          <path
                            d="M 80 80 Q 180 60 210 130 Q 290 220 380 320 Q 370 450 350 570 Q 270 680 150 710 Q 110 600 110 440 Q 140 280 80 80 Z"
                            fill="none"
                            stroke="#1e293b"
                            strokeWidth="1.5"
                            strokeDasharray="4 4"
                            className="pointer-events-none opacity-60"
                          />

                          {/* Render Each Localized Region Polygon (Hotspots) */}
                          {REGIONS.map((region) => {
                            const isSelected = selectedRegionId === region.id;
                            const isHovered = hoveredRegionId === region.id;
                            const count = getProjectsInRegion(region).length;

                            return (
                              <g 
                                key={region.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleHotspotClick(region);
                                }}
                                onMouseEnter={() => setHoveredRegionId(region.id)}
                                onMouseLeave={() => setHoveredRegionId(null)}
                                className="cursor-pointer transition-all duration-300"
                                id={`svg-region-${region.id}`}
                              >
                                {/* Region Boundary Polygon */}
                                <path
                                  d={region.svgPath}
                                  fill={isSelected ? "url(#activeRegionGradient)" : undefined}
                                  className={`transition-all duration-300 ${
                                    isSelected
                                      ? 'stroke-amber-400 stroke-[2.5px] filter drop-shadow-[0_0_12px_rgba(245,158,11,0.6)]'
                                      : isHovered
                                      ? 'stroke-slate-300 stroke-[1.5px] fill-slate-700/40'
                                      : `${region.fillColor} stroke-slate-700/60 stroke-1`
                                  }`}
                                />

                                {/* Region Name Tag */}
                                <text
                                  x={region.labelCoord.x}
                                  y={region.labelCoord.y}
                                  textAnchor="middle"
                                  className={`text-[9px] font-mono font-bold tracking-tight pointer-events-none select-none transition-colors duration-200 ${
                                    isSelected 
                                      ? 'fill-amber-300 font-extrabold text-[10px]' 
                                      : isHovered 
                                      ? 'fill-white' 
                                      : 'fill-slate-400'
                                  }`}
                                >
                                  {region.shortName}
                                </text>

                                {/* Projects Counter Chip on Map */}
                                <circle
                                  cx={region.labelCoord.x}
                                  cy={region.labelCoord.y + 12}
                                  r="6.5"
                                  className={isSelected ? 'fill-amber-500' : 'fill-slate-800 stroke-slate-700'}
                                />
                                <text
                                  x={region.labelCoord.x}
                                  y={region.labelCoord.y + 15}
                                  textAnchor="middle"
                                  className={`text-[8px] font-mono font-extrabold pointer-events-none ${
                                    isSelected ? 'fill-slate-950 font-black' : 'fill-slate-300'
                                  }`}
                                >
                                  {count}
                                </text>

                                {/* Hotspot Radar Sonar Rings & Center Core */}
                                <g 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleHotspotClick(region);
                                  }}
                                  className="cursor-pointer"
                                >
                                  <circle
                                    cx={region.pinCoord.x}
                                    cy={region.pinCoord.y}
                                    r={isSelected ? 7 : 5}
                                    className={`transition-all duration-300 ${
                                      isSelected ? 'fill-amber-400 stroke-slate-950 stroke-2' : 'fill-amber-500/80 stroke-slate-900 stroke-1'
                                    }`}
                                  />
                                  <circle
                                    cx={region.pinCoord.x}
                                    cy={region.pinCoord.y}
                                    r={isSelected ? 15 : 10}
                                    className={`stroke-amber-400/80 stroke-1 fill-none ${isSelected ? 'animate-ping' : 'opacity-40'}`}
                                  />
                                  {isSelected && (
                                    <circle
                                      cx={region.pinCoord.x}
                                      cy={region.pinCoord.y}
                                      r="24"
                                      className="stroke-amber-500/40 stroke-1 fill-none opacity-60"
                                    />
                                  )}
                                </g>
                              </g>
                            );
                          })}

                          {/* Individual Project Beacon Pins */}
                          {PROJECTS.map((p, idx) => {
                            const reg = REGIONS.find(r => {
                              const loc = p.location.toLowerCase();
                              return loc.includes(r.district.toLowerCase()) || loc.includes(r.shortName.toLowerCase());
                            }) || REGIONS[0];

                            const isRegionActive = reg.id === selectedRegionId;
                            const angle = (idx * 137.5) * (Math.PI / 180);
                            const radius = idx % 2 === 0 ? 14 : 22;
                            const pinX = reg.pinCoord.x + Math.cos(angle) * (isRegionActive ? radius : radius * 0.4);
                            const pinY = reg.pinCoord.y + Math.sin(angle) * (isRegionActive ? radius : radius * 0.4);

                            return (
                              <g 
                                key={p.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleHotspotClick(reg, p);
                                }}
                                onMouseEnter={() => setHoveredProject(p)}
                                onMouseLeave={() => setHoveredProject(null)}
                                className="cursor-pointer group"
                              >
                                <circle
                                  cx={pinX}
                                  cy={pinY}
                                  r={isRegionActive ? 4 : 2.5}
                                  className={`transition-all duration-300 ${
                                    isRegionActive 
                                      ? 'fill-amber-400 stroke-slate-950 stroke-[1.5px] group-hover:scale-125' 
                                      : 'fill-slate-500 opacity-40'
                                  }`}
                                />
                              </g>
                            );
                          })}
                        </svg>

                        {/* Hover Tooltip Overlay on Vector Map */}
                        <AnimatePresence>
                          {hoveredProject && (
                            <motion.div
                              initial={{ opacity: 0, scale: 0.9, y: 5 }}
                              animate={{ opacity: 1, scale: 1, y: 0 }}
                              exit={{ opacity: 0, scale: 0.9, y: 5 }}
                              className="absolute bottom-4 left-4 right-4 bg-slate-900/95 border border-amber-500/50 backdrop-blur-md p-2.5 rounded-lg shadow-2xl z-20 pointer-events-none"
                            >
                              <div className="flex items-center justify-between text-[9px] font-mono text-amber-400 mb-0.5">
                                <span className="font-bold">{hoveredProject.type}</span>
                                <span>{hoveredProject.status}</span>
                              </div>
                              <div className="text-xs font-bold text-white truncate">{hoveredProject.title}</div>
                              <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                                <MapPin className="w-2.5 h-2.5 text-amber-400 shrink-0" />
                                {hoveredProject.location}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    </TransformComponent>
                  </>
                )}
              </TransformWrapper>
            </div>

            {/* Hotspot Floating Project Summary Card Dock (Bottom of map container) */}
            {activeHotspotProject && activeHotspotCard && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full mt-3 bg-slate-900/95 border border-amber-500/40 rounded-xl p-3 shadow-2xl text-left relative overflow-hidden"
                id="hotspot-summary-card"
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                    <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-wider">
                      Hotspot Insight • {activeHotspotCard.region.shortName}
                    </span>
                  </div>

                  {/* Hotspot Cluster Switcher */}
                  {hotspotProjects.length > 1 && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => {
                          const nextIdx = (activeHotspotCard.projectIndex - 1 + hotspotProjects.length) % hotspotProjects.length;
                          setActiveHotspotCard({ ...activeHotspotCard, projectIndex: nextIdx });
                        }}
                        className="p-1 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700"
                        title="Previous project in hotspot"
                      >
                        <ChevronLeft className="w-3 h-3" />
                      </button>
                      <span className="text-[9px] font-mono text-slate-400">
                        {activeHotspotCard.projectIndex + 1}/{hotspotProjects.length}
                      </span>
                      <button
                        onClick={() => {
                          const nextIdx = (activeHotspotCard.projectIndex + 1) % hotspotProjects.length;
                          setActiveHotspotCard({ ...activeHotspotCard, projectIndex: nextIdx });
                        }}
                        className="p-1 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700"
                        title="Next project in hotspot"
                      >
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-lg overflow-hidden bg-slate-950 shrink-0 border border-slate-800">
                    <img 
                      src={activeHotspotProject.image} 
                      alt={activeHotspotProject.title}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h5 className="text-xs font-bold text-white truncate group-hover:text-amber-400">
                      {activeHotspotProject.title}
                    </h5>
                    <p className="text-[10px] text-slate-400 flex items-center gap-1 truncate mt-0.5">
                      <MapPin className="w-2.5 h-2.5 text-amber-500 shrink-0" />
                      {activeHotspotProject.location}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[9px] font-bold uppercase px-1.5 py-0.2 bg-amber-500/20 text-amber-400 rounded">
                        {activeHotspotProject.type}
                      </span>
                      <span className="text-[9px] font-mono text-slate-400">
                        {activeHotspotProject.status}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => onSelectProject ? onSelectProject(activeHotspotProject) : null}
                    className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-[10px] font-bold uppercase tracking-wider rounded-lg shrink-0 transition-colors shadow flex items-center gap-1"
                    id={`view-blueprint-${activeHotspotProject.id}`}
                  >
                    <span>Inspect</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* Map Legend */}
            <div className="w-full pt-3 mt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-sm bg-amber-500/40 border border-amber-400" />
                  <span>Active Hotspot</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-amber-400" />
                  <span>Project Site</span>
                </div>
              </div>
              <span className="text-slate-500 hidden sm:inline">Click hotspot to preview card</span>
            </div>
          </div>

          {/* RIGHT: Selected Area Summary Card & Projects Portfolio (7 Cols) */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            
            {/* AREA SUMMARY CARD (Main Highlight Card) */}
            <motion.div 
              key={activeRegion.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              className="bg-[#0c1322] border border-slate-800/90 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden"
              id="area-summary-card"
            >
              {/* Region Theme Background Glow Accent */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

              {/* Area Summary Card Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-6 mb-6">
                <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="px-2.5 py-0.5 rounded bg-amber-500/15 border border-amber-500/30 text-amber-400 font-mono text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                      <Target className="w-3 h-3 text-amber-400" />
                      Hotspot Regional Focus • {activeRegion.district}
                    </span>
                    <span className="text-slate-500 text-xs font-mono font-medium">
                      {activeRegion.elevation}
                    </span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-display font-extrabold text-white">
                    {activeRegion.name}
                  </h3>
                </div>

                <div className="flex items-center gap-3 self-start sm:self-auto bg-slate-900/90 border border-slate-800 px-4 py-2.5 rounded-xl">
                  <activeRegion.icon className={`w-6 h-6 ${activeRegion.colorAccent} shrink-0`} />
                  <div>
                    <div className="text-[10px] font-mono text-slate-500 uppercase tracking-widest font-bold">Terrain Class</div>
                    <div className="text-xs font-semibold text-slate-200">{activeRegion.terrainType.split('&')[0]}</div>
                  </div>
                </div>
              </div>

              {/* Area Key Metrics 4-Box Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                <div className="bg-slate-900/60 border border-slate-800/80 p-3.5 rounded-xl">
                  <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1 mb-1">
                    <Building2 className="w-3 h-3 text-amber-400" /> Active Sites
                  </div>
                  <div className="text-2xl font-mono font-extrabold text-white">
                    {regionStats.total}
                  </div>
                  <div className="text-[10px] text-slate-500 font-medium">Distinct Locations</div>
                </div>

                <div className="bg-slate-900/60 border border-slate-800/80 p-3.5 rounded-xl">
                  <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1 mb-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Completed
                  </div>
                  <div className="text-2xl font-mono font-extrabold text-emerald-400">
                    {regionStats.completed}
                  </div>
                  <div className="text-[10px] text-slate-500 font-medium">Delivered Handover</div>
                </div>

                <div className="bg-slate-900/60 border border-slate-800/80 p-3.5 rounded-xl">
                  <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1 mb-1">
                    <Clock className="w-3 h-3 text-cyan-400" /> Active Build
                  </div>
                  <div className="text-2xl font-mono font-extrabold text-cyan-400">
                    {regionStats.inProgress + regionStats.planning}
                  </div>
                  <div className="text-[10px] text-slate-500 font-medium">In Construction/Plan</div>
                </div>

                <div className="bg-slate-900/60 border border-slate-800/80 p-3.5 rounded-xl">
                  <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1 mb-1">
                    <Zap className="w-3 h-3 text-amber-400" /> Regional Scale
                  </div>
                  <div className="text-2xl font-mono font-extrabold text-amber-300">
                    {regionStats.totalCostFormatted}
                  </div>
                  <div className="text-[10px] text-slate-500 font-medium">Capital Deployment</div>
                </div>
              </div>

              {/* Regional Engineering & Climate Specifications */}
              <div className="bg-slate-900/40 border border-slate-800/60 p-4 rounded-xl space-y-3 mb-6">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">
                  <ShieldCheck className="w-4 h-4" /> Architectural & Soil Adaptation Report
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {activeRegion.architectureFocus}
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-800/60 text-[11px] font-mono">
                  <div className="text-slate-400">
                    <span className="text-slate-500">Foundation Base:</span> {activeRegion.soilFoundation}
                  </div>
                  <div className="text-slate-400">
                    <span className="text-slate-500">Climate Factor:</span> {activeRegion.climate}
                  </div>
                </div>
              </div>

              {/* Projects in this Region Section */}
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
                      <Layers className="w-4 h-4 text-amber-400" /> 
                      Hotspot Projects in {activeRegion.shortName} ({regionProjects.length})
                    </h4>
                  </div>

                  {/* Filter Pills */}
                  <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
                    {['All', 'Residential', 'Commercial', 'Institutional', 'Infrastructure'].map((t) => (
                      <button
                        key={t}
                        onClick={() => setTypeFilter(t)}
                        className={`px-2 py-1 rounded text-[10px] font-medium uppercase tracking-wider transition-colors shrink-0 ${
                          typeFilter === t
                            ? 'bg-amber-500 text-slate-950 font-bold'
                            : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Projects Card List */}
                {regionProjects.length === 0 ? (
                  <div className="p-8 text-center bg-slate-900/30 border border-dashed border-slate-800 rounded-xl">
                    <p className="text-xs text-slate-500">No projects matching the "{typeFilter}" filter in {activeRegion.shortName}.</p>
                    <button 
                      onClick={() => setTypeFilter('All')} 
                      className="mt-2 text-xs font-semibold text-amber-400 hover:underline"
                    >
                      Show all {activeRegion.shortName} projects
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {regionProjects.map((project) => {
                      const isCompleted = project.status === 'Completed';
                      const isConstruction = project.status === 'Under Construction';

                      return (
                        <div
                          key={project.id}
                          onClick={() => onSelectProject ? onSelectProject(project) : null}
                          className="group bg-slate-900/70 hover:bg-slate-800/80 border border-slate-800 hover:border-amber-500/50 p-3.5 rounded-xl transition-all duration-200 cursor-pointer flex flex-col justify-between"
                          id={`project-card-${project.id}`}
                        >
                          <div>
                            {/* Card Image & Badges */}
                            <div className="relative aspect-[16/9] w-full rounded-lg overflow-hidden mb-3 bg-slate-950">
                              <img 
                                src={project.image} 
                                alt={project.title}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                                referrerPolicy="no-referrer"
                              />
                              <div className="absolute top-2 left-2 flex gap-1">
                                <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-black/75 backdrop-blur-md text-amber-400 border border-white/10">
                                  {project.type}
                                </span>
                              </div>
                              <div className="absolute top-2 right-2">
                                <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                                  isCompleted 
                                    ? 'bg-emerald-500/90 text-slate-950' 
                                    : isConstruction 
                                    ? 'bg-cyan-500/90 text-slate-950' 
                                    : 'bg-amber-500/90 text-slate-950'
                                }`}>
                                  {project.status}
                                </span>
                              </div>
                            </div>

                            {/* Title and location */}
                            <h5 className="font-bold text-white text-sm group-hover:text-amber-400 transition-colors line-clamp-1 mb-1">
                              {project.title}
                            </h5>
                            <p className="text-[11px] text-slate-400 flex items-center gap-1 mb-2">
                              <MapPin className="w-3 h-3 text-amber-500 shrink-0" />
                              {project.location}
                            </p>

                            {/* Milestone / Info */}
                            {project.milestone && (
                              <div className="text-[10px] font-mono text-slate-400 bg-slate-950/60 px-2 py-1 rounded border border-slate-800 mb-2 flex items-center justify-between">
                                <span className="text-slate-500">Stage:</span>
                                <span className="text-amber-300 font-semibold">{project.milestone}</span>
                              </div>
                            )}
                          </div>

                          {/* Action CTA */}
                          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-bold text-amber-400 group-hover:text-amber-300">
                            <span className="uppercase tracking-wider">Inspect Blueprint Specs</span>
                            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Summary Card Footer CTA */}
              <div className="mt-8 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-xs text-slate-400 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>Planning a residential or commercial build in <strong>{activeRegion.shortName}</strong>?</span>
                </div>
                <a
                  href="#contact"
                  className="w-full sm:w-auto px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg uppercase tracking-wider transition-colors shadow-lg flex items-center justify-center gap-2"
                >
                  Schedule Site Survey in {activeRegion.shortName}
                  <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>

            </motion.div>

          </div>
        </div>

      </div>
    </section>
  );
}
