import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Check, Loader2, User, Mail, Phone, Briefcase, Link2, AlertCircle, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { careerApplicationSchema, validateField } from '../schemas/validationSchemas';

interface CareerApplicationFormProps {
  onClose: () => void;
  t: (key: string) => string;
  playSuccessSound: () => void;
}

export default function CareerApplicationForm({ onClose, t, playSuccessSound }: CareerApplicationFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    position: '',
    portfolioLink: ''
  });

  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleFieldChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));

    // Instant validation if already touched
    if (touched[field]) {
      const error = validateField(careerApplicationSchema, field, value);
      setErrors(prev => {
        const next = { ...prev };
        if (error) {
          next[field] = error;
        } else {
          delete next[field];
        }
        return next;
      });
    }
  };

  const handleFieldBlur = (field: keyof typeof formData) => {
    setTouched(prev => ({ ...prev, [field]: true }));
    const error = validateField(careerApplicationSchema, field, formData[field]);
    setErrors(prev => {
      const next = { ...prev };
      if (error) {
        next[field] = error;
      } else {
        delete next[field];
      }
      return next;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Mark all as touched
    const allTouched: Record<string, boolean> = {
      name: true,
      email: true,
      phone: true,
      position: true,
      portfolioLink: true
    };
    setTouched(allTouched);

    const parseResult = careerApplicationSchema.safeParse(formData);

    if (!parseResult.success) {
      const fieldErrors: Record<string, string> = {};
      const issues = parseResult.error.issues || (parseResult.error as any).errors || [];
      issues.forEach((err: any) => {
        const pathKey = err.path[0] as string;
        if (pathKey && !fieldErrors[pathKey]) {
          fieldErrors[pathKey] = err.message;
        }
      });
      setErrors(fieldErrors);
      return;
    }

    setErrors({});
    setIsSubmitting(true);

    // Simulate server submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      playSuccessSound();
      confetti({
        particleCount: 150,
        spread: 80,
        origin: { y: 0.7 },
        colors: ['#d97706', '#0f172a', '#ffffff']
      });

      setTimeout(() => {
        onClose();
        setIsSuccess(false);
        setFormData({
          name: '',
          email: '',
          phone: '',
          position: '',
          portfolioLink: ''
        });
        setTouched({});
        setErrors({});
      }, 2500);
    }, 1200);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="p-8 flex items-center justify-between border-b border-slate-100">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            <span className="text-[10px] font-bold text-amber-600 uppercase tracking-widest">
              Talent Acquisition
            </span>
          </div>
          <h2 className="font-display text-2xl font-bold text-slate-900">{t('joinOurTeam')}</h2>
          <p className="text-xs text-slate-500 font-semibold uppercase tracking-widest">Build your future with APS</p>
        </div>
        <button 
          onClick={onClose}
          aria-label="Close career drawer"
          className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-8">
        <form className="space-y-6" onSubmit={handleSubmit} noValidate>
          {isSuccess ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-emerald-50 border border-emerald-100 p-8 rounded-sm text-center space-y-4"
            >
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <Check className="w-7 h-7" />
              </div>
              <div className="space-y-2">
                <h4 className="text-slate-900 font-bold uppercase text-sm tracking-widest">{t('applicationSuccess')}</h4>
                <p className="text-xs text-slate-600 font-medium">{t('recruitmentTeam')}</p>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider mt-2">Closing automatically...</p>
              </div>
            </motion.div>
          ) : (
            <>
              {/* Full Name */}
              <div className="space-y-1">
                <div className="flex items-center justify-between ml-1">
                  <label htmlFor="career-name" className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Full Name *
                  </label>
                  {touched.name && !errors.name && formData.name && (
                    <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Valid
                    </span>
                  )}
                </div>
                <div className="relative">
                  <User className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${errors.name ? 'text-red-400' : 'text-slate-400'}`} />
                  <input 
                    id="career-name"
                    type="text" 
                    value={formData.name}
                    onChange={(e) => handleFieldChange('name', e.target.value)}
                    onBlur={() => handleFieldBlur('name')}
                    placeholder="e.g. Ananya Nair"
                    aria-invalid={errors.name ? 'true' : 'false'}
                    aria-describedby={errors.name ? 'career-name-error' : undefined}
                    className={`w-full pl-12 pr-4 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all ${
                      errors.name 
                        ? 'border-red-500 bg-red-50/20 focus:border-red-600 focus:ring-1 focus:ring-red-500' 
                        : touched.name && formData.name 
                          ? 'border-emerald-500 focus:border-emerald-600' 
                          : 'border-slate-200 focus:border-amber-600 focus:bg-white'
                    }`}
                  />
                </div>
                {errors.name && (
                  <p id="career-name-error" className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
                    <AlertCircle className="w-3 h-3 shrink-0" /> {errors.name}
                  </p>
                )}
              </div>

              {/* Email Address */}
              <div className="space-y-1">
                <div className="flex items-center justify-between ml-1">
                  <label htmlFor="career-email" className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Email Address *
                  </label>
                  {touched.email && !errors.email && formData.email && (
                    <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Valid
                    </span>
                  )}
                </div>
                <div className="relative">
                  <Mail className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${errors.email ? 'text-red-400' : 'text-slate-400'}`} />
                  <input 
                    id="career-email"
                    type="email" 
                    value={formData.email}
                    onChange={(e) => handleFieldChange('email', e.target.value)}
                    onBlur={() => handleFieldBlur('email')}
                    placeholder="email@example.com"
                    aria-invalid={errors.email ? 'true' : 'false'}
                    aria-describedby={errors.email ? 'career-email-error' : undefined}
                    className={`w-full pl-12 pr-4 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all ${
                      errors.email 
                        ? 'border-red-500 bg-red-50/20 focus:border-red-600 focus:ring-1 focus:ring-red-500' 
                        : touched.email && formData.email 
                          ? 'border-emerald-500 focus:border-emerald-600' 
                          : 'border-slate-200 focus:border-amber-600 focus:bg-white'
                    }`}
                  />
                </div>
                {errors.email && (
                  <p id="career-email-error" className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
                    <AlertCircle className="w-3 h-3 shrink-0" /> {errors.email}
                  </p>
                )}
              </div>

              {/* Phone Number */}
              <div className="space-y-1">
                <div className="flex items-center justify-between ml-1">
                  <label htmlFor="career-phone" className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Phone Number *
                  </label>
                  {touched.phone && !errors.phone && formData.phone && (
                    <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Valid
                    </span>
                  )}
                </div>
                <div className="relative">
                  <Phone className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${errors.phone ? 'text-red-400' : 'text-slate-400'}`} />
                  <input 
                    id="career-phone"
                    type="tel" 
                    value={formData.phone}
                    onChange={(e) => handleFieldChange('phone', e.target.value)}
                    onBlur={() => handleFieldBlur('phone')}
                    placeholder="+91 98765 43210"
                    aria-invalid={errors.phone ? 'true' : 'false'}
                    aria-describedby={errors.phone ? 'career-phone-error' : undefined}
                    className={`w-full pl-12 pr-4 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all ${
                      errors.phone 
                        ? 'border-red-500 bg-red-50/20 focus:border-red-600 focus:ring-1 focus:ring-red-500' 
                        : touched.phone && formData.phone 
                          ? 'border-emerald-500 focus:border-emerald-600' 
                          : 'border-slate-200 focus:border-amber-600 focus:bg-white'
                    }`}
                  />
                </div>
                {errors.phone && (
                  <p id="career-phone-error" className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
                    <AlertCircle className="w-3 h-3 shrink-0" /> {errors.phone}
                  </p>
                )}
              </div>

              {/* Position Selection */}
              <div className="space-y-1">
                <div className="flex items-center justify-between ml-1">
                  <label htmlFor="career-position" className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    {t('position')} *
                  </label>
                  {touched.position && !errors.position && formData.position && (
                    <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Valid
                    </span>
                  )}
                </div>
                <div className="relative">
                  <Briefcase className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${errors.position ? 'text-red-400' : 'text-slate-400'}`} />
                  <select 
                    id="career-position"
                    value={formData.position}
                    onChange={(e) => handleFieldChange('position', e.target.value)}
                    onBlur={() => handleFieldBlur('position')}
                    aria-invalid={errors.position ? 'true' : 'false'}
                    aria-describedby={errors.position ? 'career-position-error' : undefined}
                    className={`w-full pl-12 pr-8 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all cursor-pointer ${
                      errors.position 
                        ? 'border-red-500 bg-red-50/20 focus:border-red-600 focus:ring-1 focus:ring-red-500' 
                        : touched.position && formData.position 
                          ? 'border-emerald-500 focus:border-emerald-600' 
                          : 'border-slate-200 focus:border-amber-600 focus:bg-white'
                    }`}
                  >
                    <option value="">Select Target Position</option>
                    <option value="architect">Senior Architect (8+ yrs exp)</option>
                    <option value="project-mgr">Project Manager (Civil / MEP)</option>
                    <option value="site-eng">Site Engineer (Structural)</option>
                    <option value="interior-designer">Luxury Interior Designer</option>
                    <option value="intern">Architecture & Planning Intern</option>
                  </select>
                </div>
                {errors.position && (
                  <p id="career-position-error" className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
                    <AlertCircle className="w-3 h-3 shrink-0" /> {errors.position}
                  </p>
                )}
              </div>

              {/* Portfolio Link */}
              <div className="space-y-1">
                <div className="flex items-center justify-between ml-1">
                  <label htmlFor="career-portfolio" className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    {t('portfolioUrl')} *
                  </label>
                  {touched.portfolioLink && !errors.portfolioLink && formData.portfolioLink && (
                    <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Valid
                    </span>
                  )}
                </div>
                <div className="relative">
                  <Link2 className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${errors.portfolioLink ? 'text-red-400' : 'text-slate-400'}`} />
                  <input 
                    id="career-portfolio"
                    type="url" 
                    value={formData.portfolioLink}
                    onChange={(e) => handleFieldChange('portfolioLink', e.target.value)}
                    onBlur={() => handleFieldBlur('portfolioLink')}
                    placeholder="https://linkedin.com/in/... or Google Drive / Behance"
                    aria-invalid={errors.portfolioLink ? 'true' : 'false'}
                    aria-describedby={errors.portfolioLink ? 'career-portfolio-error' : undefined}
                    className={`w-full pl-12 pr-4 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all ${
                      errors.portfolioLink 
                        ? 'border-red-500 bg-red-50/20 focus:border-red-600 focus:ring-1 focus:ring-red-500' 
                        : touched.portfolioLink && formData.portfolioLink 
                          ? 'border-emerald-500 focus:border-emerald-600' 
                          : 'border-slate-200 focus:border-amber-600 focus:bg-white'
                    }`}
                  />
                </div>
                <p className="text-[9px] text-slate-400 uppercase tracking-tighter ml-1">
                  Please provide a direct link to your LinkedIn profile, Behance portfolio, or Google Drive CV.
                </p>
                {errors.portfolioLink && (
                  <p id="career-portfolio-error" className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
                    <AlertCircle className="w-3 h-3 shrink-0" /> {errors.portfolioLink}
                  </p>
                )}
              </div>

              <div className="pt-4">
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-slate-900 text-white py-4 font-bold rounded-sm hover:bg-amber-600 transition-all uppercase tracking-widest text-sm shadow-lg shadow-slate-900/10 flex items-center justify-center gap-2 focus:outline-none focus:ring-2 focus:ring-amber-500 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Submitting Application...
                    </>
                  ) : (
                    t('applyNow')
                  )}
                </button>
              </div>
            </>
          )}
        </form>
      </div>
    </div>
  );
}
