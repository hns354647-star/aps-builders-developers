import React from 'react';
import { Project } from '../data/projects';
import { MapPin, Calendar, HardHat, DollarSign, Building2, CheckCircle2 } from 'lucide-react';

interface ProjectPrintSummaryProps {
  project: Project;
}

export default function ProjectPrintSummary({ project }: ProjectPrintSummaryProps) {
  const currentDate = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <div className="hidden print:block p-10 bg-white text-slate-900 font-sans min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-start border-b-2 border-slate-900 pb-8 mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter uppercase mb-1">APS Architecture Pvt Ltd.</h1>
          <p className="text-xs text-slate-500 font-bold tracking-widest uppercase">Premium Engineering & Construction Excellence</p>
        </div>
        <div className="text-right">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Document Generated</p>
          <p className="text-sm font-mono font-bold">{currentDate}</p>
        </div>
      </div>

      {/* Project Identity */}
      <div className="grid grid-cols-3 gap-8 mb-12">
        <div className="col-span-2">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">{project.title}</h2>
          <p className="text-slate-600 leading-relaxed mb-6">{project.description}</p>
          
          <div className="flex flex-wrap gap-6">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-amber-600" />
              <div>
                <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest leading-none">Location</p>
                <p className="text-xs font-bold">{project.location}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-amber-600" />
              <div>
                <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest leading-none">Project Type</p>
                <p className="text-xs font-bold">{project.type}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-amber-600" />
              <div>
                <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest leading-none">Status</p>
                <p className="text-xs font-bold transition-colors">{project.status}</p>
              </div>
            </div>
          </div>
        </div>
        <div className="border border-slate-100 rounded-sm overflow-hidden h-48">
          <img 
            src={project.image} 
            alt={project.title} 
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Detailed Breakdown Section */}
      <div className="grid grid-cols-2 gap-12">
        {/* Timeline Table */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <Calendar className="w-4 h-4 text-amber-600" />
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-widest">Execution Timeline</h3>
          </div>
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="py-2 text-[9px] font-bold text-slate-400 uppercase">Phase</th>
                <th className="py-2 text-[9px] font-bold text-slate-400 uppercase">Schedule</th>
                <th className="py-2 text-[9px] font-bold text-slate-400 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="text-xs">
              <tr className="border-b border-slate-50">
                <td className="py-3 font-bold">Concept & Design</td>
                <td className="py-3 text-slate-500">Q1 2024</td>
                <td className="py-3 text-emerald-600 font-bold">Completed</td>
              </tr>
              <tr className="border-b border-slate-50">
                <td className="py-3 font-bold">Structural Work</td>
                <td className="py-3 text-slate-500">Q2-Q3 2024</td>
                <td className="py-3 text-amber-600 font-bold">In Progress</td>
              </tr>
              <tr className="border-b border-slate-50">
                <td className="py-3 font-bold">Finishing & MEP</td>
                <td className="py-3 text-slate-500">Q4 2024</td>
                <td className="py-3 text-slate-400 font-bold">Scheduled</td>
              </tr>
            </tbody>
          </table>
          <div className="bg-slate-50 p-4 rounded-sm border border-slate-100">
             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Estimated Handover</p>
             <p className="text-sm font-bold text-slate-900">{project.estimatedCompletion || 'Q1 2025'}</p>
          </div>
        </div>

        {/* Cost Breakdown Table */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <DollarSign className="w-4 h-4 text-amber-600" />
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-widest">Estimated Cost Breakdown</h3>
          </div>
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="py-2 text-[9px] font-bold text-slate-400 uppercase">Category</th>
                <th className="py-2 text-[9px] font-bold text-slate-400 uppercase">Allocation</th>
                <th className="py-2 text-[10px] font-bold text-slate-400 uppercase text-right">Weight</th>
              </tr>
            </thead>
            <tbody className="text-xs font-mono">
              <tr className="border-b border-slate-50">
                <td className="py-3 font-bold text-slate-900">Standard Materials</td>
                <td className="py-3 text-slate-500">Steel, Concrete, Masonry</td>
                <td className="py-3 text-right font-bold">45%</td>
              </tr>
              <tr className="border-b border-slate-50">
                <td className="py-3 font-bold text-slate-900">Labor & Supervision</td>
                <td className="py-3 text-slate-500">Technical Teams, Artisans</td>
                <td className="py-3 text-right font-bold">25%</td>
              </tr>
              <tr className="border-b border-slate-50">
                <td className="py-3 font-bold text-slate-900">Interior & MEP</td>
                <td className="py-3 text-slate-500">Electrical, Plumbing, Flooring</td>
                <td className="py-3 text-right font-bold">20%</td>
              </tr>
              <tr className="border-b border-slate-50">
                <td className="py-3 font-bold text-slate-900">Arch/Eng Fees</td>
                <td className="py-3 text-slate-500">Consultancy & Permits</td>
                <td className="py-3 text-right font-bold">10%</td>
              </tr>
            </tbody>
          </table>
          <div className="bg-amber-600 p-4 rounded-sm">
             <p className="text-[10px] font-bold text-amber-100 uppercase tracking-widest mb-1">Project Valuation Index</p>
             <div className="flex items-end justify-between">
                <p className="text-xl font-bold text-white tracking-widest">PREMIUM GRADE</p>
                <div className="flex gap-1 mb-1">
                   {[1,2,3,4,5].map(i => (
                     <div key={i} className="w-1.5 h-3 bg-white/20 rounded-full overflow-hidden">
                        <div className={`w-full h-full bg-white ${i <= 4 ? 'opacity-100' : 'opacity-0'}`} />
                     </div>
                   ))}
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* Footer / Contact */}
      <div className="mt-auto pt-12 border-t border-slate-200 grid grid-cols-3 gap-8">
        <div>
          <h4 className="text-[10px] font-bold text-slate-900 uppercase tracking-widest mb-2">Corporate Office</h4>
          <p className="text-[10px] text-slate-500 leading-relaxed font-medium">
            APS Architecture Pvt Ltd.<br />
            Opposite KV, Nedumudy,<br />
            Alappuzha, Kerala - 688503
          </p>
        </div>
        <div>
          <h4 className="text-[10px] font-bold text-slate-900 uppercase tracking-widest mb-2">Connect</h4>
          <p className="text-[10px] text-slate-500 leading-relaxed font-medium font-mono">
            +91 79076 56700<br />
            design@apsarch.com<br />
            www.apsarch.com
          </p>
        </div>
        <div className="flex flex-col items-end justify-end">
           <div className="w-24 h-24 border border-slate-100 p-2 bg-white flex items-center justify-center mb-2">
              {/* Mock QR Code Seal */}
              <div className="w-full h-full bg-slate-50 border border-dotted border-slate-200 flex flex-col items-center justify-center p-2 text-center">
                 <div className="w-10 h-10 border-2 border-slate-900 relative mb-1">
                    <div className="absolute top-1 left-1 w-2 h-2 bg-slate-900" />
                    <div className="absolute top-1 right-1 w-2 h-2 bg-slate-900" />
                    <div className="absolute bottom-1 left-1 w-2 h-2 bg-slate-900" />
                 </div>
                 <span className="text-[6px] font-bold uppercase tracking-widest text-slate-400 leading-none">Scannable Authenticity Seal</span>
              </div>
           </div>
           <p className="text-[8px] font-bold text-slate-300 uppercase tracking-widest">© 2026 APS ARCHITECTURE PVT LTD</p>
        </div>
      </div>
    </div>
  );
}
