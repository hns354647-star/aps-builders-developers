import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Send, Bot, ChevronRight, Maximize2, MinusSquare } from 'lucide-react';
import { Project } from '../data/projects';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AIChatWidgetProps {
  currentProject?: Project | null;
}

export default function AIChatWidget({ currentProject }: AIChatWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: "Welcome to APS Builders! How can we assist you with your architectural or construction project today?",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [smartRepliesEnabled, setSmartRepliesEnabled] = useState(true);

  const lastProjectIdRef = useRef<string | null>(null);

  useEffect(() => {
    if (isOpen && currentProject) {
      if (currentProject.id !== lastProjectIdRef.current) {
        lastProjectIdRef.current = currentProject.id;
        
        // Append a tailored welcoming message regarding the active project details
        const projectContextMessage = `I see you are viewing our "${currentProject.title}" (${currentProject.type}) project in ${currentProject.location}. 

We have this listed as currently ${currentProject.status.toLowerCase()}. Would you like to check structural blueprints, look at estimation guides, verify Vastu details, or schedule an in-person site visit?`;

        setMessages(prev => [
          ...prev,
          {
            role: 'assistant',
            content: projectContextMessage,
            timestamp: new Date()
          }
        ]);
      }
    } else if (!currentProject) {
      lastProjectIdRef.current = null;
    }
  }, [isOpen, currentProject]);

  const defaultSmartInquiries = [
    { label: 'View current projects', icon: '🏗️', text: "Hi APS Team, I'm interested in viewing your latest projects. Could you share some recent residential or commercial case studies?" },
    { label: 'Book an appointment', icon: '📅', text: "Hi, I'd like to schedule an appointment with an architect to discuss my upcoming construction project." },
    { label: 'Get cost estimate', icon: '💰', text: "Hello, I am looking for a preliminary cost estimate for a new building project. Can you help me with the pricing details?" },
    { label: 'Vastu Consultation', icon: '🧘', text: "Hi APS, I'm interested in a Vastu consultation for my property. How can I get started?" },
    { label: 'Check Site Status', icon: '🏠', text: "Hi, I'd like to get a progress update on one of your existing construction sites." }
  ];

  const projectSmartInquiries = currentProject ? [
    { 
      label: `Inquire: ${currentProject.title}`, 
      icon: '🏢', 
      text: `Hi APS, I'm exploring your project "${currentProject.title}" in ${currentProject.location}. I would like to get more technical detail models, cost estimates, or specific layout plans.` 
    },
    { 
      label: 'Book Site Visit', 
      icon: '📍', 
      text: `Hi APS Team, I'd like to schedule a walk-through or live site visit for the project "${currentProject.title}" in ${currentProject.location}.` 
    },
    { 
      label: 'Vastu Compliance', 
      icon: '🧘', 
      text: `Hello, is "${currentProject.title}" developed according to Vastu rules? I'd love more Vastu details regarding it.` 
    },
    { 
      label: 'Request Quotation', 
      icon: '📊', 
      text: `Hello APS Team, could you provide pricing quotes or structural material details for the project "${currentProject.title}"?` 
    }
  ] : defaultSmartInquiries;

  const smartInquiries = currentProject ? projectSmartInquiries : defaultSmartInquiries;

  const handleWhatsAppRedirect = (customText?: string) => {
    const message = customText || input || "Hi APS Team, I'd like to inquire about your construction and architectural services in Alappuzha.";
    const link = `https://wa.me/917907656700?text=${encodeURIComponent(message)}`;
    window.open(link, '_blank');
  };

  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  return (
    <div className="fixed bottom-6 left-6 z-[9999] flex flex-col items-start gap-4">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9, transformOrigin: 'bottom left' }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              height: isMinimized ? '80px' : '550px',
              width: '380px'
            }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="bg-slate-900 p-4 flex items-center justify-between text-white">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-amber-600 rounded-full flex items-center justify-center">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-bold tracking-tight">APS Concierge</h3>
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                    <span className="text-[10px] text-slate-400 font-medium uppercase tracking-widest">
                      WhatsApp Support
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setIsMinimized(!isMinimized)}
                  className="p-1.5 hover:bg-white/10 rounded-lg transition-colors"
                >
                  {isMinimized ? <Maximize2 className="w-4 h-4" /> : <MinusSquare className="w-4 h-4" />}
                </button>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {!isMinimized && (
              <>
                {/* Messages Area */}
                <div 
                  ref={scrollRef}
                  className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50"
                >
                  {messages.map((msg, idx) => (
                    <div 
                      key={idx}
                      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[85%] p-3.5 rounded-2xl text-sm leading-relaxed ${
                        msg.role === 'user' 
                          ? 'bg-slate-900 text-white rounded-tr-none shadow-md' 
                          : 'bg-white text-slate-700 border border-slate-100 rounded-tl-none shadow-sm'
                      }`}>
                        {msg.content}
                        <div className={`text-[10px] mt-2 opacity-60 flex items-center gap-1 ${
                          msg.role === 'user' ? 'justify-end' : 'justify-start'
                        }`}>
                          {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          {msg.role === 'assistant' && ' • Verified'}
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {/* Smart Reply Chips */}
                  {smartRepliesEnabled && (
                    <div className="pt-2 flex flex-wrap gap-2">
                      {smartInquiries.map((action) => (
                        <button
                          key={action.label}
                          onClick={() => handleWhatsAppRedirect(action.text)}
                          className="px-3 py-2 bg-white border border-slate-200 rounded-full text-[10px] font-bold text-slate-600 hover:border-emerald-600 hover:text-emerald-600 transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
                        >
                          <span>{action.icon}</span>
                          {action.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <button 
                  onClick={() => handleWhatsAppRedirect()}
                  className="bg-emerald-50 px-4 py-2 border-y border-emerald-100 flex items-center justify-between group hover:bg-emerald-100 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-[10px] font-bold text-emerald-900 uppercase tracking-widest">Connect with our team on WhatsApp</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-emerald-400 group-hover:translate-x-1 transition-transform" />
                </button>

                {/* Input Area */}
                <div className="p-4 bg-white">
                  <div className="relative flex items-center gap-2">
                    <div className="relative flex-1">
                      <input 
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleWhatsAppRedirect()}
                        placeholder="Type your question..."
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 pr-12 text-sm focus:outline-none focus:border-emerald-600 focus:bg-white transition-all placeholder:text-slate-400"
                      />
                    </div>
                    <button 
                      onClick={() => handleWhatsAppRedirect()}
                      disabled={!input.trim()}
                      className="p-3 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 disabled:opacity-50 transition-all shadow-lg active:scale-95"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </div>
                  <p className="text-[9px] text-slate-400 mt-3 text-center uppercase tracking-widest font-bold">
                    Official WhatsApp Support • 24/7 Response
                  </p>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col gap-3">
        <motion.button
          whileHover={{ scale: 1.1, rotate: 5 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsOpen(!isOpen)}
          className={`w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all ${
            isOpen ? 'bg-slate-900 rotate-90' : 'bg-amber-600'
          } group`}
        >
          {isOpen ? (
            <X className="w-6 h-6 text-white" />
          ) : (
            <div className="relative">
               <MessageCircle className="w-7 h-7 text-white" />
               <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 border-2 border-white rounded-full" />
            </div>
          )}
        </motion.button>
      </div>
    </div>
  );
}
