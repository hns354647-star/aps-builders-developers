import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageCircle, 
  ChevronRight, 
  ArrowLeft, 
  Home, 
  Building2, 
  Paintbrush, 
  Maximize, 
  Clock, 
  Zap, 
  Calendar,
  Send,
  CheckCircle2
} from 'lucide-react';

type Step = 'service' | 'area' | 'urgency' | 'complete' | 'chat';

export default function WhatsAppLeadQualifier() {
  const [smartRepliesEnabled, setSmartRepliesEnabled] = useState(() => {
    const saved = localStorage.getItem('aps_smart_replies');
    return saved === null ? true : saved === 'true';
  });

  const [chatInput, setChatInput] = useState('');

  useEffect(() => {
    localStorage.setItem('aps_smart_replies', String(smartRepliesEnabled));
    window.dispatchEvent(new Event('smart-replies-changed'));
  }, [smartRepliesEnabled]);

  const smartInquiries = [
    { label: 'View current projects', icon: '🏗️', text: "Hi APS Team, I'm interested in viewing your latest residential and commercial projects. Could you share some recent case studies?" },
    { label: 'Book an appointment', icon: '📅', text: "Hi, I'd like to schedule an appointment with an architect to discuss my upcoming construction project." },
    { label: 'Get cost estimate', icon: '💰', text: "Hello, I am looking for a preliminary cost estimate for a new building project. Can you help me with the pricing details?" },
    { label: 'Vastu Consultation', icon: '🧘', text: "Hi APS, I'm interested in a Vastu consultation for my home/office space. How can I get started?" },
    { label: 'Check Site Status', icon: '🏗️', text: "Hi, I'm an existing client and would like to get a progress update on my construction site." }
  ];

  const handleWhatsAppRedirect = (customText?: string) => {
    const message = customText || chatInput || "Hi APS Team, I'd like to inquire about your construction and architectural services in Alappuzha.";
    const link = `https://wa.me/917907656700?text=${encodeURIComponent(message)}`;
    window.open(link, '_blank');
  };

  return (
    <div className="bg-white border border-slate-100 rounded-sm overflow-hidden shadow-sm">
      <div className="bg-slate-900 p-4 text-white flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageCircle className="w-4 h-4 text-emerald-400" />
          <h4 className="text-[10px] font-bold uppercase tracking-widest">WhatsApp Direct Connect</h4>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Smart Reply</span>
          <button 
            onClick={() => setSmartRepliesEnabled(!smartRepliesEnabled)}
            className={`w-8 h-4 rounded-full relative transition-colors ${smartRepliesEnabled ? 'bg-emerald-500' : 'bg-slate-700'}`}
          >
            <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all ${smartRepliesEnabled ? 'translate-x-4' : 'translate-x-0.5'}`} />
          </button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-slate-900">How can we help you today?</h3>
          <p className="text-[10px] text-slate-500 font-medium">Select a quick inquiry or type your message below.</p>
        </div>

        {/* Dynamic Smart Reply Chips Area */}
        {smartRepliesEnabled && (
          <div className="grid grid-cols-1 gap-2 animate-in fade-in slide-in-from-top-1">
            {smartInquiries.map((inquiry) => (
              <button
                key={inquiry.label}
                onClick={() => handleWhatsAppRedirect(inquiry.text)}
                className="flex items-center justify-between p-3 bg-slate-50 border border-slate-100 rounded-sm hover:border-emerald-500 hover:bg-emerald-50 transition-all group active:scale-[0.98] text-left"
              >
                <div className="flex items-center gap-3">
                  <span className="text-sm">{inquiry.icon}</span>
                  <span className="text-[11px] font-bold text-slate-700 group-hover:text-emerald-700">{inquiry.label}</span>
                </div>
                <Zap className="w-3 h-3 text-emerald-500 opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>
            ))}
          </div>
        )}

        <div className="pt-4 border-t border-slate-100">
          <div className="space-y-3">
            <div className="relative">
              <textarea 
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Type your custom question here..."
                rows={3}
                className="w-full bg-slate-50 border border-slate-100 rounded-sm px-3 py-2 text-xs focus:outline-none focus:border-emerald-500 transition-all resize-none"
              />
              <div className="absolute bottom-2 right-2 pointer-events-none">
                <Send className="w-3 h-3 text-slate-300" />
              </div>
            </div>
            
            <button 
              onClick={() => handleWhatsAppRedirect()}
              className="w-full bg-emerald-600 text-white py-3.5 rounded-sm font-bold text-[10px] uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg flex items-center justify-center gap-2 active:scale-[0.98]"
            >
              Start WhatsApp Session
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>
          
          <p className="text-[9px] text-slate-400 mt-4 text-center font-medium leading-relaxed">
            Clicking will redirect you to WhatsApp. <br/>
            Availability: <span className="text-emerald-600 font-bold">24/7 Response Support</span>
          </p>
        </div>
      </div>
    </div>
  );
}
