import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Zap, 
  Droplets, 
  Maximize, 
  Map, 
  Home, 
  Scale, 
  X, 
  Layers, 
  Activity, 
  FileCheck, 
  CheckCircle,
  HelpCircle,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PROJECTS, Project } from '../data/projects';

interface ProjectStructuralSpecsProps {
  project?: Project;
  onExpand?: () => void;
}

// Deterministic generator to provide highly realistic and varied structural specs for any project
export function getProjectSpecs(project: Project) {
  const isResidential = project.type?.toLowerCase() === 'residential';
  const isCommercial = project.type?.toLowerCase() === 'commercial' || project.title?.toLowerCase().includes('tower') || project.title?.toLowerCase().includes('plaza');
  const isInstitutional = project.type?.toLowerCase() === 'institutional' || project.type?.toLowerCase() === 'infrastructure';
  
  const costInCr = (project.cost || 25000000) / 10000000;
  
  // 1. Structural Type
  let structuralType = "RCC Framed Structure";
  if (isCommercial) {
    structuralType = "Steel-Concrete Composite Core";
  } else if (project.id === 'p2') {
    structuralType = "Engineered Timber Post & Beam";
  } else if (isInstitutional) {
    structuralType = "Precast Concrete Wall Panel System";
  } else if (costInCr > 5) {
    structuralType = "Post-Tensioned Flat Slab RCC";
  }

  // 2. Seismic Zone
  let seismicZone = "Zone III (High Ductility Detailing)";
  if (isCommercial || costInCr > 10) {
    seismicZone = "Zone IV (Active Dampers Integrated)";
  } else if (project.id === 'crystal-point') {
    seismicZone = "Zone III Resistant (Coastal Anchors)";
  }

  // 3. Solar Integration
  let solarIntegration = "5kW Grid-Tied PV System";
  if (project.id === 'p2') {
    solarIntegration = "12kW Off-Grid Smart Micro-Grid";
  } else if (isCommercial || costInCr > 8) {
    solarIntegration = "45kW Bi-directional Net-Metered Array";
  } else if (costInCr > 3) {
    solarIntegration = "10kW Hybrid Storage System";
  } else if (project.status === 'Planning') {
    solarIntegration = "Solar Conduit & Panel Inverter Ready";
  }

  // 4. Rainwater Harvesting
  let rainwaterPlan = "8,000L Domestic Rainwater Sump";
  if (isCommercial) {
    rainwaterPlan = "45,000L Underground Retention Tank";
  } else if (costInCr > 4) {
    rainwaterPlan = "15,000L Multi-stage Filtered Cistern";
  } else if (isInstitutional) {
    rainwaterPlan = "25,000L Dedicated Aquifer Well";
  }

  // 5. Total Lot Size
  let lotSize = "12.5 Cents";
  if (project.id === 'p1') lotSize = "18.0 Cents";
  else if (project.id === 'p2') lotSize = "15.5 Cents";
  else if (project.id === 'p3') lotSize = "45.0 Cents";
  else if (project.id === 'p4') lotSize = "32.0 Cents";
  else if (project.id === 'p5') lotSize = "22.5 Cents";
  else if (project.id === 'p6') lotSize = "88.0 Cents";
  else if (isCommercial) lotSize = "65.0 Cents";
  else if (isInstitutional) lotSize = "110.0 Cents";

  // 6. Built Area
  let builtArea = "3,200 Sq.Ft";
  if (project.id === 'p1') builtArea = "3,500 Sq.Ft";
  else if (project.id === 'p2') builtArea = "2,400 Sq.Ft";
  else if (project.id === 'p3') builtArea = "6,800 Sq.Ft";
  else if (project.id === 'p4') builtArea = "28,000 Sq.Ft";
  else if (project.id === 'p5') builtArea = "4,500 Sq.Ft";
  else if (project.id === 'p6') builtArea = "185,000 Sq.Ft";
  else if (isCommercial) builtArea = "42,000 Sq.Ft";
  else if (isInstitutional) builtArea = "15,000 Sq.Ft";

  // 7. Foundation Design
  let foundation = "Isolated Footing with Plinth Beam";
  if (isCommercial || costInCr > 15) {
    foundation = "Friction Pile Foundation with Cap Slab";
  } else if (project.id === 'crystal-point') {
    foundation = "Sub-sea Helical Piles & Marine Grade Raft";
  } else if (costInCr > 4) {
    foundation = "Continuous Reinforced Raft Slab";
  }

  // 8. Concrete Grade
  let concreteGrade = "M25 Reinforcement Grade";
  if (isCommercial || costInCr > 10) {
    concreteGrade = "M40 High-Performance Mix";
  } else if (costInCr > 3) {
    concreteGrade = "M30 High-Strength Premium Mix";
  }

  // 9. Steel Reinforcement
  let steelGrade = "Fe500 TMT Anti-Corrosive Bars";
  if (isCommercial || costInCr > 8) {
    steelGrade = "Fe550D High-Ductility Treated Bars";
  } else if (project.id === 'crystal-point') {
    steelGrade = "Epoxy-Coated Fe500D Marine Steel";
  }

  // 10. Green Building Rating
  let greenRating = "3-Star GRIHA Certified";
  if (project.id === 'p2') {
    greenRating = "5-Star GRIHA (Net Zero Passive)";
  } else if (isCommercial || costInCr > 5) {
    greenRating = "LEED Gold Certified";
  }

  return {
    structuralType,
    seismicZone,
    solarIntegration,
    rainwaterPlan,
    lotSize,
    builtArea,
    foundation,
    concreteGrade,
    steelGrade,
    greenRating,
  };
}

export default function ProjectStructuralSpecs({ project, onExpand }: ProjectStructuralSpecsProps) {
  // Use currently active project, fallback to first project if undefined
  const activeProject = project || PROJECTS[0];
  const activeSpecs = getProjectSpecs(activeProject);

  // Comparison State
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [projectAId, setProjectAId] = useState(activeProject.id);
  const [projectBId, setProjectBId] = useState(
    PROJECTS.find(p => p.id !== activeProject.id)?.id || PROJECTS[0].id
  );

  const projectA = PROJECTS.find(p => p.id === projectAId) || activeProject;
  const projectB = PROJECTS.find(p => p.id === projectBId) || PROJECTS[0];

  const specsA = getProjectSpecs(projectA);
  const specsB = getProjectSpecs(projectB);

  const displaySpecs = [
    { label: 'Structural Type', value: activeSpecs.structuralType, icon: <Home className="w-3.5 h-3.5" /> },
    { label: 'Seismic Zone', value: activeSpecs.seismicZone, icon: <ShieldCheck className="w-3.5 h-3.5" /> },
    { label: 'Solar Integration', value: activeSpecs.solarIntegration, icon: <Zap className="w-3.5 h-3.5" /> },
    { label: 'Rainwater Plan', value: activeSpecs.rainwaterPlan, icon: <Droplets className="w-3.5 h-3.5" /> },
    { label: 'Total Lot Size', value: activeSpecs.lotSize, icon: <Map className="w-3.5 h-3.5" /> },
    { label: 'Built Area', value: activeSpecs.builtArea, icon: <Maximize className="w-3.5 h-3.5" /> },
  ];

  // Open comparator, pre-filling project A with the current selection
  const handleOpenComparison = () => {
    setProjectAId(activeProject.id);
    const fallbackB = PROJECTS.find(p => p.id !== activeProject.id);
    if (fallbackB) {
      setProjectBId(fallbackB.id);
    }
    setIsCompareOpen(true);
  };

  return (
    <div className="bg-slate-900 border border-slate-800/80 p-5 rounded-xl space-y-5 shadow-xl relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute -top-12 -right-12 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-amber-500 animate-pulse" />
          <h4 className="text-[10px] font-bold text-slate-200 uppercase tracking-widest">Structural Architecture</h4>
        </div>
        <span className="text-[9px] font-mono font-bold bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/15">
          {activeProject.type}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-x-4 gap-y-4">
        {displaySpecs.map((spec, idx) => (
          <motion.div 
            key={spec.label}
            initial={{ opacity: 0, y: 5 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.04, duration: 0.3 }}
            className="p-3 bg-slate-950/50 rounded-lg border border-slate-800/40 hover:border-slate-800 transition-colors group space-y-1"
          >
            <div className="flex items-center gap-1.5 text-slate-500 group-hover:text-amber-500 transition-colors">
              {spec.icon}
              <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400">{spec.label}</span>
            </div>
            <p className="text-[10.5px] font-bold text-slate-200 uppercase font-mono tracking-wide line-clamp-1">
              {spec.value}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2">
        {onExpand && (
          <button 
            onClick={onExpand}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700 hover:border-amber-500/50 text-[10px] font-extrabold uppercase tracking-widest rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg hover:scale-[1.01] active:scale-95 cursor-pointer"
          >
            <Maximize className="w-3.5 h-3.5" /> Expand Full Specs
          </button>
        )}
        <button 
          onClick={handleOpenComparison}
          className={`${onExpand ? 'w-full' : 'w-full'} py-2.5 bg-amber-500 hover:bg-amber-400 text-black text-[10px] font-extrabold uppercase tracking-widest rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg hover:scale-[1.01] active:scale-95 cursor-pointer`}
        >
          <Scale className="w-3.5 h-3.5" /> Compare Specifications
        </button>
      </div>

      {/* Side-by-Side Comparison Modal */}
      <AnimatePresence>
        {isCompareOpen && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-[90] overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col my-8"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-amber-500/10 rounded-lg border border-amber-500/20 text-amber-500">
                    <Scale className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-base text-slate-100 uppercase tracking-wider">
                      Structural Specs Comparator
                    </h3>
                    <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                      Analyze structural load, materials & sustainability index side-by-side
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsCompareOpen(false)}
                  className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded-lg border border-slate-800 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Selection Column Header */}
              <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950/20 border-b border-slate-850">
                {/* Project A selector */}
                <div className="space-y-1.5">
                  <label className="text-[9px] font-bold text-amber-500 uppercase tracking-widest block">Project A (Primary)</label>
                  <select 
                    value={projectAId}
                    onChange={(e) => setProjectAId(e.target.value)}
                    className="w-full bg-slate-950 text-xs text-slate-200 px-3 py-2 rounded-lg border border-slate-800 focus:border-amber-500 outline-none transition-all"
                  >
                    {PROJECTS.map(p => (
                      <option key={p.id} value={p.id}>{p.title} ({p.location})</option>
                    ))}
                  </select>
                </div>

                {/* Project B selector */}
                <div className="space-y-1.5">
                  <label className="text-[9px] font-bold text-indigo-400 uppercase tracking-widest block">Project B (Comparative)</label>
                  <select 
                    value={projectBId}
                    onChange={(e) => setProjectBId(e.target.value)}
                    className="w-full bg-slate-950 text-xs text-slate-200 px-3 py-2 rounded-lg border border-slate-800 focus:border-indigo-500 outline-none transition-all"
                  >
                    {PROJECTS.map(p => (
                      <option key={p.id} value={p.id}>{p.title} ({p.location})</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Side-by-Side Table Area */}
              <div className="p-5 overflow-x-auto max-h-[50vh] overflow-y-auto custom-scrollbar">
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead>
                    <tr className="border-b border-slate-800 text-[9.5px] uppercase font-bold text-slate-400 tracking-wider">
                      <th className="py-2.5 pb-3">Structural Metric</th>
                      <th className="py-2.5 pb-3 text-amber-500 bg-amber-500/5 px-4 rounded-t-lg">{projectA.title}</th>
                      <th className="py-2.5 pb-3 text-indigo-400 bg-indigo-500/5 px-4 rounded-t-lg">{projectB.title}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850 text-xs">
                    {/* Basic specs rows */}
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Project Location</td>
                      <td className="py-3 px-4 font-medium text-slate-200 bg-amber-500/2">{projectA.location || "N/A"}</td>
                      <td className="py-3 px-4 font-medium text-slate-200 bg-indigo-500/2">{projectB.location || "N/A"}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Property Class</td>
                      <td className="py-3 px-4 font-medium text-slate-200 bg-amber-500/2">{projectA.type || "N/A"}</td>
                      <td className="py-3 px-4 font-medium text-slate-200 bg-indigo-500/2">{projectB.type || "N/A"}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Completion Year</td>
                      <td className="py-3 px-4 font-medium text-slate-200 bg-amber-500/2">{projectA.year || "In Progress"}</td>
                      <td className="py-3 px-4 font-medium text-slate-200 bg-indigo-500/2">{projectB.year || "In Progress"}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Estimated Cost</td>
                      <td className="py-3 px-4 font-bold text-amber-400 bg-amber-500/2 font-mono">
                        {projectA.cost ? `₹${(projectA.cost / 10000000).toFixed(2)} Crore` : "Consultation Required"}
                      </td>
                      <td className="py-3 px-4 font-bold text-indigo-400 bg-indigo-500/2 font-mono">
                        {projectB.cost ? `₹${(projectB.cost / 10000000).toFixed(2)} Crore` : "Consultation Required"}
                      </td>
                    </tr>
                    
                    {/* Structural technical rows */}
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Structural System</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-amber-500/2">{specsA.structuralType}</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-indigo-500/2">{specsB.structuralType}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Foundation Design</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-amber-500/2">{specsA.foundation}</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-indigo-500/2">{specsB.foundation}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Seismic Safety Code</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-amber-500/2">{specsA.seismicZone}</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-indigo-500/2">{specsB.seismicZone}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Concrete Grade Rating</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-amber-500/2">{specsA.concreteGrade}</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-indigo-500/2">{specsB.concreteGrade}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Steel Reinforcement</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-amber-500/2">{specsA.steelGrade}</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-indigo-500/2">{specsB.steelGrade}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Lot Size (Cents)</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-amber-500/2">{specsA.lotSize}</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-indigo-500/2">{specsB.lotSize}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Built Area</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-amber-500/2">{specsA.builtArea}</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-indigo-500/2">{specsB.builtArea}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Solar Integration</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-amber-500/2">{specsA.solarIntegration}</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-indigo-500/2">{specsB.solarIntegration}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Rainwater Sump Capacity</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-amber-500/2">{specsA.rainwaterPlan}</td>
                      <td className="py-3 px-4 font-mono text-slate-200 bg-indigo-500/2">{specsB.rainwaterPlan}</td>
                    </tr>
                    <tr className="hover:bg-slate-850/20 transition-colors">
                      <td className="py-3 font-semibold text-slate-400 text-[11px] uppercase tracking-wider">Green Building Certification</td>
                      <td className="py-3 px-4 font-mono text-emerald-400 bg-amber-500/2">{specsA.greenRating}</td>
                      <td className="py-3 px-4 font-mono text-emerald-400 bg-indigo-500/2">{specsB.greenRating}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Analytical Comparison Insight Summary */}
              <div className="p-5 bg-slate-950/60 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-start gap-3 max-w-xl">
                  <div className="p-1.5 bg-amber-500/10 text-amber-400 rounded-lg border border-amber-500/15 shrink-0 mt-0.5">
                    <Sparkles className="w-4 h-4 animate-pulse" />
                  </div>
                  <div>
                    <h5 className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">Structural Comparison Report</h5>
                    <p className="text-[10.5px] text-slate-400 leading-relaxed mt-1">
                      {projectA.type === projectB.type ? (
                        `Both configurations are optimized for ${projectA.type} load matrices. ${projectA.title} delivers specialized structural advantages on a ${specsA.lotSize} footprint, while ${projectB.title} exhibits a highly ductile reinforcement rating with ${specsB.steelGrade}.`
                      ) : (
                        `This compares an active ${projectA.type} structure with an eco-centric ${projectB.type} layout. ${projectA.title} utilizes a robust ${specsA.structuralType} core framework, contrasted with ${projectB.title}'s tailored ${specsB.structuralType} layout configuration.`
                      )}
                    </p>
                  </div>
                </div>

                <button 
                  onClick={() => {
                    alert(`Exporting comparison details for [${projectA.title}] and [${projectB.title}] into CAD specifications spreadsheet...`);
                  }}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-[9.5px] font-bold uppercase tracking-wider rounded-lg border border-slate-700 transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5"
                >
                  <FileCheck className="w-3.5 h-3.5 text-emerald-400" /> Export CAD Data
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
