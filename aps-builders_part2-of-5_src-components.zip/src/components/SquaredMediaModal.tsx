import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  ArrowLeft,
  Calendar,
  Clock,
  CheckCircle2,
  ExternalLink,
  Sparkles,
  User,
  Mail,
  FileText
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

export interface SquaredMediaModalProps {
  isOpen: boolean;
  onClose: () => void;
  whatsappNumber?: string;
  founderName?: string;
  founderRole?: string;
  founderPhoto?: string;
}

type ModalView = 'choose' | 'cal' | 'done';

export const SquaredMediaModal: React.FC<SquaredMediaModalProps> = ({
  isOpen,
  onClose,
  whatsappNumber = '7907656700',
  founderName = 'Wouter',
  founderRole = 'Oprichter Squared',
  founderPhoto = '/team/wouter.webp'
}) => {
  const { lang } = useLanguage();
  const [view, setView] = useState<ModalView>('choose');

  // Calendar booking state
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('11:00');
  const [clientName, setClientName] = useState<string>('');
  const [clientEmail, setClientEmail] = useState<string>('');
  const [projectNote, setProjectNote] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Generate the next 7 business days for scheduling
  const availableDates = React.useMemo(() => {
    const dates = [];
    const today = new Date();
    let current = new Date(today);
    current.setDate(current.getDate() + 1); // start tomorrow

    while (dates.length < 7) {
      const day = current.getDay();
      // Skip weekends (0 = Sunday, 6 = Saturday)
      if (day !== 0 && day !== 6) {
        const dateStr = current.toISOString().split('T')[0];
        const dayLabel = current.toLocaleDateString(lang === 'nl' ? 'nl-NL' : 'en-US', {
          weekday: 'short',
          day: 'numeric',
          month: 'short'
        });
        dates.push({ dateStr, dayLabel });
      }
      current.setDate(current.getDate() + 1);
    }
    return dates;
  }, [lang]);

  // Set default selected date once dates are computed
  React.useEffect(() => {
    if (availableDates.length > 0 && !selectedDate) {
      setSelectedDate(availableDates[0].dateStr);
    }
  }, [availableDates, selectedDate]);

  // Reset to initial choose view whenever the modal opens
  React.useEffect(() => {
    if (isOpen) {
      setView('choose');
      setIsSubmitting(false);
    }
  }, [isOpen]);

  const timeSlots = ['09:30', '11:00', '13:30', '15:00', '16:30'];

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim() || !clientEmail.trim()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setView('done');
    }, 600);
  };

  // WhatsApp click handler with prefilled text
  const cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
  const waPrefill = encodeURIComponent(
    lang === 'nl'
      ? `Hallo ${founderName}, ik wil graag even sparren over een website/platform project via Squared!`
      : `Hi ${founderName}, I would love to connect about a new web/creative project via Squared!`
  );
  const whatsappUrl = `https://wa.me/${cleanNumber.length === 10 ? '91' + cleanNumber : cleanNumber}?text=${waPrefill}`;

  const t = {
    nl: {
      eyebrow: 'Even sparren?',
      title: `Plan een call met ${founderName}`,
      intro: 'Stuur een appje of prik direct een moment in de agenda. Binnen een werkdag reactie.',
      appButton: `App ${founderName}`,
      planButton: 'Plan direct een call',
      note: 'WhatsApp opent met een voorgevuld bericht, jij drukt zelf op verzenden.',
      back: 'Terug',
      calTitle: 'Kies een datum & tijd // 30 min kennismaking',
      pickDate: '1. Selecteer een werkdag',
      pickTime: '2. Selecteer een tijdstip',
      yourDetails: '3. Jouw gegevens',
      namePlaceholder: 'Je naam (bijv. Sophie van Dijk)',
      emailPlaceholder: 'je@bedrijf.nl',
      notesPlaceholder: 'Waar wil je over sparren? (bijv. nieuwe 3D website, ticketsysteem, video)',
      confirmBooking: 'Bevestig afspraak →',
      submitting: 'Bezig met inplannen...',
      bookedEyebrow: 'Afspraak ingepland',
      bookedTitle: 'Tot snel!',
      bookedIntro: 'We hebben de uitnodiging en Google Meet link naar je inbox gestuurd. We kijken uit naar het gesprek!',
      dateLabel: 'Datum & Tijd',
      withLabel: 'Met',
      close: 'Sluiten'
    },
    en: {
      eyebrow: 'Quick chat?',
      title: `Schedule a call with ${founderName}`,
      intro: 'Send a quick WhatsApp or pick a slot directly in the calendar. Reply within one business day.',
      appButton: `WhatsApp ${founderName}`,
      planButton: 'Schedule a call directly',
      note: 'WhatsApp opens with a prefilled message, you press send yourself.',
      back: 'Back',
      calTitle: 'Pick a date & time // 30 min intro call',
      pickDate: '1. Select a business day',
      pickTime: '2. Select a time slot',
      yourDetails: '3. Your details',
      namePlaceholder: 'Your name (e.g. Alex Miller)',
      emailPlaceholder: 'alex@company.com',
      notesPlaceholder: 'What would you like to discuss? (e.g. 3D interactive site, retainer, video)',
      confirmBooking: 'Confirm Meeting →',
      submitting: 'Scheduling meeting...',
      bookedEyebrow: 'Meeting Scheduled',
      bookedTitle: 'See you soon!',
      bookedIntro: 'We sent the calendar invite and Google Meet link to your inbox. Looking forward to speaking with you!',
      dateLabel: 'Date & Time',
      withLabel: 'With',
      close: 'Close'
    }
  }[lang];

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          data-lenis-prevent=""
          role="dialog"
          aria-modal="true"
          aria-labelledby="sq-plancall-title"
          className="fixed inset-0 z-[150] flex items-center justify-center p-3 sm:p-6"
        >
          {/* Backdrop with Blur matching squared-media.nl */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#080807]/80 backdrop-blur-md"
          />

          {/* Modal Card: sq-plancall__card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 18 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 18 }}
            transition={{ type: 'spring', damping: 28, stiffness: 320 }}
            className="relative w-full max-w-[960px] max-h-[calc(100dvh-28px)] rounded-[28px] sm:rounded-[32px] overflow-hidden bg-[#141815] text-[#f2f5f1] border border-white/15 shadow-[0_30px_90px_rgba(0,0,0,0.65)] flex flex-col z-10"
          >
            {/* Top Right Close Button (sq-plancall__close) */}
            <button
              type="button"
              onClick={onClose}
              aria-label={t.close}
              className="absolute top-4 right-4 z-30 w-10 h-10 rounded-full border border-white/20 bg-[#1e2620]/80 backdrop-blur-md text-white flex items-center justify-center hover:bg-white hover:text-black hover:scale-105 transition-all duration-200 cursor-pointer shadow-md"
            >
              <X className="w-4 h-4" />
            </button>

            {/* VIEW 1: CHOOSE VIEW (sq-plancall__choose) */}
            {view === 'choose' && (
              <div className="grid grid-cols-1 md:grid-cols-12 min-h-[460px] max-h-[calc(100dvh-28px)] overflow-y-auto">
                {/* Left Figure (sq-plancall__figure) */}
                <figure className="md:col-span-5 relative bg-[#0b0e0c] min-h-[260px] md:min-h-full overflow-hidden m-0">
                  <img
                    src={founderPhoto}
                    alt={founderName}
                    loading="lazy"
                    decoding="async"
                    onError={(e) => {
                      // Fallback image if local asset fails
                      (e.target as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80';
                    }}
                    className="w-full h-full object-cover object-top absolute inset-0"
                  />

                  {/* Caption overlay */}
                  <figcaption className="absolute bottom-0 inset-x-0 p-5 bg-gradient-to-t from-[#0d0d0c] via-[#0d0d0c]/80 to-transparent z-10 flex flex-col gap-0.5 font-mono text-xs uppercase tracking-wider">
                    <strong className="text-xl font-bold font-sans tracking-tight text-white normal-case">
                      {founderName}
                    </strong>
                    <span className="text-stone-300 text-[11px] opacity-80">{founderRole}</span>
                  </figcaption>
                </figure>

                {/* Right Body (sq-plancall__body) */}
                <div className="md:col-span-7 p-6 sm:p-12 flex flex-col justify-center gap-5">
                  {/* Eyebrow with Flame Glowing Dot */}
                  <div className="inline-flex items-center gap-2.5 text-[11px] font-mono uppercase tracking-[0.2em] text-white/70">
                    <span
                      aria-hidden="true"
                      className="w-2.5 h-2.5 rounded-full bg-[#ff4500] shadow-[0_0_18px_#ff4500]"
                    />
                    <span>{t.eyebrow}</span>
                  </div>

                  {/* Bold Display Title */}
                  <h2
                    id="sq-plancall-title"
                    className="text-3xl sm:text-5xl font-black uppercase tracking-tight leading-[0.95] text-white font-sans"
                  >
                    {t.title}
                  </h2>

                  {/* Intro */}
                  <p className="text-stone-300 text-sm sm:text-base leading-relaxed max-w-md font-sans">
                    {t.intro}
                  </p>

                  {/* Actions (Buttons) */}
                  <div className="flex flex-wrap items-center gap-3 pt-2">
                    {/* Primary Button: WhatsApp App Wouter */}
                    <a
                      href={whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group relative inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-full bg-[#ff6a1a] hover:bg-[#ff7b33] text-white font-bold text-sm tracking-wide shadow-lg shadow-[#ff6a1a]/30 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
                    >
                      {/* WhatsApp Icon */}
                      <svg
                        viewBox="0 0 24 24"
                        width="18"
                        height="18"
                        fill="currentColor"
                        aria-hidden="true"
                      >
                        <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38c1.45.79 3.08 1.21 4.79 1.21 5.46 0 9.91-4.45 9.91-9.91S17.5 2 12.04 2Zm0 18.15c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.25-8.24 4.54 0 8.24 3.7 8.24 8.24s-3.7 8.24-8.24 8.24Zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.78.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.23.25-.87.85-.87 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.75 2.67 4.23 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.14-1.18-.06-.1-.22-.16-.47-.28Z" />
                      </svg>
                      <span>{t.appButton}</span>
                    </a>

                    {/* Secondary Button: Plan direct een call */}
                    <button
                      type="button"
                      onClick={() => setView('cal')}
                      className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 text-white font-semibold text-sm tracking-wide transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
                    >
                      <Calendar className="w-4 h-4 text-[#ff6a1a]" />
                      <span>{t.planButton}</span>
                    </button>
                  </div>

                  {/* Footnote */}
                  <p className="text-[11px] font-mono text-stone-400 tracking-wide mt-2">
                    {t.note}
                  </p>
                </div>
              </div>
            )}

            {/* VIEW 2: CALENDAR VIEW (sq-plancall__cal) */}
            {view === 'cal' && (
              <div className="flex flex-col max-h-[calc(100dvh-28px)] overflow-y-auto">
                {/* Header (sq-plancall__cal-head) */}
                <div className="flex items-center gap-4 px-6 py-4 border-b border-white/10 bg-[#101412]">
                  <button
                    type="button"
                    onClick={() => setView('choose')}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border border-white/20 bg-white/5 hover:bg-white hover:text-black text-xs font-semibold text-white transition-all cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>{t.back}</span>
                  </button>
                  <span
                    id="sq-plancall-title"
                    className="text-xs font-mono uppercase tracking-[0.18em] text-white/70"
                  >
                    {t.calTitle}
                  </span>
                </div>

                {/* Cal Body / Booking Form */}
                <form onSubmit={handleBookingSubmit} className="p-6 sm:p-10 space-y-6">
                  {/* Step 1: Business Days */}
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-stone-300 mb-3">
                      {t.pickDate}
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
                      {availableDates.map((item) => {
                        const isSelected = selectedDate === item.dateStr;
                        return (
                          <button
                            key={item.dateStr}
                            type="button"
                            onClick={() => setSelectedDate(item.dateStr)}
                            className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-[#ff6a1a] text-white border-[#ff6a1a] shadow-md shadow-[#ff6a1a]/30'
                                : 'bg-[#18211b] border-white/10 text-stone-300 hover:border-white/30'
                            }`}
                          >
                            <span className="block text-xs font-semibold capitalize font-sans">
                              {item.dayLabel}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Step 2: Time Slots */}
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-stone-300 mb-3">
                      {t.pickTime}
                    </label>
                    <div className="flex flex-wrap gap-2.5">
                      {timeSlots.map((slot) => {
                        const isSelected = selectedTime === slot;
                        return (
                          <button
                            key={slot}
                            type="button"
                            onClick={() => setSelectedTime(slot)}
                            className={`px-4 py-2 rounded-lg border text-xs font-mono transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-white text-black border-white font-bold shadow-md'
                                : 'bg-[#18211b] border-white/10 text-stone-300 hover:border-white/30'
                            }`}
                          >
                            {slot}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Step 3: Contact Inputs */}
                  <div className="space-y-4 pt-2 border-t border-white/10">
                    <label className="block text-xs font-mono uppercase tracking-wider text-stone-300">
                      {t.yourDetails}
                    </label>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="relative">
                        <User className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type="text"
                          required
                          value={clientName}
                          onChange={(e) => setClientName(e.target.value)}
                          placeholder={t.namePlaceholder}
                          className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0e120f] border border-white/15 text-white text-sm placeholder:text-stone-500 focus:outline-none focus:border-[#ff6a1a]"
                        />
                      </div>

                      <div className="relative">
                        <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type="email"
                          required
                          value={clientEmail}
                          onChange={(e) => setClientEmail(e.target.value)}
                          placeholder={t.emailPlaceholder}
                          className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0e120f] border border-white/15 text-white text-sm placeholder:text-stone-500 focus:outline-none focus:border-[#ff6a1a]"
                        />
                      </div>
                    </div>

                    <div className="relative">
                      <FileText className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5 pointer-events-none" />
                      <textarea
                        rows={2}
                        value={projectNote}
                        onChange={(e) => setProjectNote(e.target.value)}
                        placeholder={t.notesPlaceholder}
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0e120f] border border-white/15 text-white text-sm placeholder:text-stone-500 focus:outline-none focus:border-[#ff6a1a] resize-none"
                      />
                    </div>
                  </div>

                  {/* Submit CTA */}
                  <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/10">
                    <a
                      href="https://cal.com/wouter-mur-ye8yri/30min"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs text-stone-400 hover:text-white transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Of open direct in Cal.com</span>
                    </a>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="px-7 py-3 rounded-full bg-[#ff6a1a] hover:bg-[#ff7b33] text-white font-bold text-sm tracking-wide shadow-lg shadow-[#ff6a1a]/30 hover:scale-105 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? t.submitting : t.confirmBooking}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* VIEW 3: DONE CONFIRMATION (sq-plancall__done) */}
            {view === 'done' && (
              <div className="p-8 sm:p-14 text-center flex flex-col items-center justify-center gap-6 min-h-[420px]">
                <div className="w-16 h-16 rounded-full bg-[#ff6a1a]/20 border border-[#ff6a1a]/40 flex items-center justify-center text-[#ff6a1a] shadow-lg shadow-[#ff6a1a]/20">
                  <CheckCircle2 className="w-8 h-8" />
                </div>

                <div className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-[#ff6a1a]">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{t.bookedEyebrow}</span>
                </div>

                <h2
                  id="sq-plancall-title"
                  className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-sans"
                >
                  {t.bookedTitle}
                </h2>

                <p className="text-stone-300 text-sm sm:text-base max-w-md leading-relaxed font-sans">
                  {t.bookedIntro}
                </p>

                {/* Appointment Card */}
                <div className="w-full max-w-md p-4 rounded-2xl bg-[#0d120f] border border-white/15 text-left text-xs font-mono space-y-2">
                  <div className="flex justify-between border-b border-white/10 pb-2">
                    <span className="text-stone-400">{t.withLabel}:</span>
                    <span className="text-white font-bold">{founderName} (Squared)</span>
                  </div>
                  <div className="flex justify-between border-b border-white/10 pb-2">
                    <span className="text-stone-400">{t.dateLabel}:</span>
                    <span className="text-[#ff6a1a] font-bold">
                      {selectedDate} om {selectedTime} CET
                    </span>
                  </div>
                  <div className="flex justify-between pt-1">
                    <span className="text-stone-400">Locatie:</span>
                    <span className="text-white">Google Meet (Link verzonden)</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onClose}
                  className="px-8 py-3 rounded-full bg-white hover:bg-stone-200 text-black font-bold text-sm tracking-wide transition-all hover:scale-105 active:scale-95 cursor-pointer shadow-lg"
                >
                  {t.close}
                </button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default SquaredMediaModal;
