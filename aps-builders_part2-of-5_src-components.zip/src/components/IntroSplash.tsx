import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, 
  Sun, 
  Moon, 
  Compass, 
  Layers, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  Eye, 
  Check, 
  Sliders, 
  Square,
  Sparkles,
  Info
} from 'lucide-react';
import { KineticText } from '@/registry/magicui/kinetic-text';

interface IntroSplashProps {
  onComplete: () => void;
}

type TimeOfDay = 'morning' | 'noon' | 'dusk' | 'midnight';

interface RoomDetails {
  id: string;
  name: string;
  category: string;
  videoUrl: string;
  dimensions: string;
  code: string;
  description: string;
  materials: string[];
  specs: { label: string; value: string }[];
}

const ROOMS_DATA: RoomDetails[] = [
  {
    id: 'gallery',
    name: 'The Kitchen',
    category: 'Concept Studio',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-apartment-kitchen-interior-41555-large.mp4',
    dimensions: '6.4m x 4.8m',
    code: 'SEC_K10',
    description: 'A bespoke culinary workspace combining brutalist marble structures with natural walnut cabinetry. Features integrated smart controls and ambient cove lighting.',
    materials: ['Invisible Gray Marble', 'Stained Walnut', 'Fluted Glass', 'Brushed Brass'],
    specs: [
      { label: 'Ceiling Height', value: '3.4m' },
      { label: 'Ventilation', value: 'Airflow 1200 CFM' },
      { label: 'Lighting System', value: 'DALI 3-Zone Dimming' },
      { label: 'Acoustic Rating', value: 'NRC 0.45' }
    ]
  },
  {
    id: 'inside',
    name: 'Living Area',
    category: 'Architectural Showcase',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-luxurious-living-room-with-modern-furniture-41558-large.mp4',
    dimensions: '8.2m x 6.5m',
    code: 'SEC_L22',
    description: 'An expansive open-concept salon built for modern entertainment and relaxation. Promotes an organic connection with the landscape through floor-to-ceiling panoramic glass panels.',
    materials: ['Microcement Flooring', 'Polished Concrete', 'Travertine Accents', 'Anodized Aluminum'],
    specs: [
      { label: 'Ceiling Height', value: '3.6m' },
      { label: 'Thermal Glazing', value: 'Double Low-E Argon' },
      { label: 'Luminous Flux', value: '3200 Lumens (Max)' },
      { label: 'Sound Isolation', value: 'STC 52' }
    ]
  },
  {
    id: 'exterior',
    name: 'Master Bedroom',
    category: 'Private Quarters',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-cozy-bedroom-with-warm-lighting-41557-large.mp4',
    dimensions: '5.8m x 5.2m',
    code: 'SEC_B40',
    description: 'A sanctuary designed with warm oak textures and dynamic fabric ceiling details. Features optimized solar geometry to invite subtle, indirect morning light.',
    materials: ['Smoked Oak Planks', 'Bouclé Wall Cladding', 'Bronze Details', 'Linen Textiles'],
    specs: [
      { label: 'Ceiling Height', value: '3.0m' },
      { label: 'HVAC Venting', value: 'Linear Slot Diffusers' },
      { label: 'Acoustic Fabric', value: 'SoundAbsorber Class A' },
      { label: 'Solar Analysis', value: 'Southeastern Aspect' }
    ]
  },
  {
    id: 'contact',
    name: 'The Suite',
    category: 'Bespoke Details',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-modern-minimalist-bathroom-interior-41556-large.mp4',
    dimensions: '4.8m x 4.0m',
    code: 'SEC_S05',
    description: 'A minimalist hydrotherapy suite. Highlighted by a freestanding monolithic stone tub, dual cantilevered stone vanities, and a sensory wet room under a linear skylight.',
    materials: ['Bianco Lasa Stone', 'Satin Nickel Fixtures', 'Terrazzo Tiles', 'Frosted Privacy Panels'],
    specs: [
      { label: 'Ceiling Height', value: '3.2m' },
      { label: 'Drainage Flow', value: 'High-Volume Linear Drain' },
      { label: 'Skylight Area', value: '1.8m x 0.8m' },
      { label: 'Underfloor Heat', value: 'Hydronic Radiant 24°C' }
    ]
  }
];

export default function IntroSplash({ onComplete }: IntroSplashProps) {
  const [activeRoomId, setActiveRoomId] = useState<string>('gallery');
  const [sliderValue, setSliderValue] = useState<number>(50); // 0 = full video, 100 = full blueprint
  const [timeOfDay, setTimeOfDay] = useState<TimeOfDay>('noon');
  const [wireframeOverlay, setWireframeOverlay] = useState<boolean>(true);
  const [isAudioActive, setIsAudioActive] = useState<boolean>(false);
  const [isEntering, setIsEntering] = useState<boolean>(false);

  // 3D Viewport Tilt values
  const [viewportTilt, setViewportTilt] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const viewportRef = useRef<HTMLDivElement>(null);
  
  // Audio Synthesizer refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const oscillatorsRef = useRef<any[]>([]);
  const filterNodeRef = useRef<BiquadFilterNode | null>(null);
  const mainGainNodeRef = useRef<GainNode | null>(null);

  const activeRoom = ROOMS_DATA.find(r => r.id === activeRoomId) || ROOMS_DATA[0];

  // Web Audio Ambient Drone Implementation
  const startSynthesizer = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;

      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      // Master Gain
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0, ctx.currentTime);
      masterGain.connect(ctx.destination);
      mainGainNodeRef.current = masterGain;

      // Smooth volume ramp
      masterGain.gain.linearRampToValueAtTime(0.2, ctx.currentTime + 1.5);

      // Low-pass Filter to make the synth deep and warm
      const lowpass = ctx.createBiquadFilter();
      lowpass.type = 'lowpass';
      lowpass.frequency.setValueAtTime(280, ctx.currentTime);
      lowpass.Q.setValueAtTime(1.5, ctx.currentTime);
      lowpass.connect(masterGain);
      filterNodeRef.current = lowpass;

      // Base oscillators to synthesize a luxury ambient space hum
      const frequencies = [55, 110, 165, 220]; // A1, A2, E3, A3 (Harmonic Series)
      const oscTypes: OscillatorType[] = ['sawtooth', 'triangle', 'sine', 'sine'];
      const gains = [0.4, 0.5, 0.3, 0.2];

      const oscs = frequencies.map((freq, index) => {
        const osc = ctx.createOscillator();
        const oscGain = ctx.createGain();

        osc.type = oscTypes[index];
        osc.frequency.setValueAtTime(freq, ctx.currentTime);

        // Add slow detune modulation to simulate a luxury cinematic ambient synth
        osc.detune.setValueAtTime((Math.random() - 0.5) * 15, ctx.currentTime);

        oscGain.gain.setValueAtTime(gains[index], ctx.currentTime);
        osc.connect(oscGain);
        oscGain.connect(lowpass);
        osc.start();

        // LFO (Low Frequency Oscillator) to modulate volume of each voice slowly
        const lfo = ctx.createOscillator();
        const lfoGain = ctx.createGain();
        lfo.frequency.setValueAtTime(0.08 + index * 0.03, ctx.currentTime);
        lfoGain.gain.setValueAtTime(0.15, ctx.currentTime);
        
        lfo.connect(lfoGain);
        lfoGain.connect(oscGain.gain);
        lfo.start();

        return { osc, lfo, oscGain };
      });

      oscillatorsRef.current = oscs;
    } catch (err) {
      console.warn('Audio synthesis failed to start:', err);
    }
  };

  const stopSynthesizer = () => {
    const masterGain = mainGainNodeRef.current;
    const ctx = audioContextRef.current;
    
    if (masterGain && ctx) {
      // Smooth fadeout
      masterGain.gain.cancelScheduledValues(ctx.currentTime);
      masterGain.gain.setValueAtTime(masterGain.gain.value, ctx.currentTime);
      masterGain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 1.0);

      setTimeout(() => {
        try {
          oscillatorsRef.current.forEach(({ osc, lfo }) => {
            osc.stop();
            lfo.stop();
          });
          ctx.close();
        } catch (e) {}
        audioContextRef.current = null;
        oscillatorsRef.current = [];
        mainGainNodeRef.current = null;
        filterNodeRef.current = null;
      }, 1100);
    }
  };

  const toggleAudio = () => {
    if (isAudioActive) {
      stopSynthesizer();
      setIsAudioActive(false);
    } else {
      startSynthesizer();
      setIsAudioActive(true);
    }
  };

  useEffect(() => {
    return () => {
      // Cleanup synth on unmount
      if (audioContextRef.current) {
        try {
          oscillatorsRef.current.forEach(({ osc, lfo }) => {
            osc.stop();
            lfo.stop();
          });
          audioContextRef.current.close();
        } catch (e) {}
      }
    };
  }, []);

  // Handle Mouse Move for 3D Viewport Tilt
  const handleViewportMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!viewportRef.current) return;
    const rect = viewportRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const normalizedX = (x / rect.width) - 0.5;
    const normalizedY = (y / rect.height) - 0.5;

    setViewportTilt({
      x: normalizedY * -6, // Tilt up/down
      y: normalizedX * 6,  // Tilt left/right
    });
  };

  const handleViewportMouseLeave = () => {
    setViewportTilt({ x: 0, y: 0 });
  };

  // Daylight filter resolver
  const getLightingFilter = () => {
    switch (timeOfDay) {
      case 'morning':
        return 'brightness-[0.9] contrast-[1.05] sepia-[0.15] saturate-[1.1] hue-rotate-[12deg]';
      case 'noon':
        return 'brightness-[1.15] contrast-[1.02] saturate-[1.1]';
      case 'dusk':
        return 'brightness-[0.78] contrast-[1.12] sepia-[0.35] saturate-[1.3] hue-rotate-[-10deg]';
      case 'midnight':
        return 'brightness-[0.42] contrast-[1.25] saturate-[0.6] hue-rotate-[-35deg]';
      default:
        return 'brightness-[1.15] contrast-[1.02] saturate-[1.1]';
    }
  };

  // Handle Proceed Animation
  const handleProceed = () => {
    setIsEntering(true);
    stopSynthesizer();
    // Match the animation duration before completing
    setTimeout(() => {
      onComplete();
    }, 1000);
  };

  return (
    <div 
      id="intro-splash-root" 
      className={`fixed inset-0 z-[200] bg-[#09090b] font-sans text-white overflow-hidden flex flex-col md:flex-row transition-all duration-1000 ${
        isEntering ? 'opacity-0 scale-105 pointer-events-none blur-[15px]' : 'opacity-100'
      }`}
    >
      
      {/* BACKGROUND SCI-FI VECTOR RADIAL GLOWS */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] w-[60%] h-[60%] rounded-full bg-amber-600/5 blur-[120px]" />
        <div className="absolute bottom-[-15%] left-[-15%] w-[70%] h-[70%] rounded-full bg-blue-500/5 blur-[150px]" />
        <div className="absolute top-[30%] left-[20%] w-[350px] h-[350px] rounded-full bg-emerald-500/3 blur-[100px]" />
        {/* Animated matrix dots pattern */}
        <div className="absolute inset-0 bg-[radial-gradient(rgba(255,255,255,0.015)_1px,transparent_1px)] [background-size:24px_24px] opacity-70" />
      </div>

      {/* LEFT SIDEBAR: GLASS CONTROL PANEL & SPECS */}
      <div className="w-full md:w-[350px] lg:w-[420px] bg-black/45 border-b md:border-b-0 md:border-r border-white/[0.06] backdrop-blur-xl relative z-20 flex flex-col justify-between shrink-0 h-1/3 md:h-full overflow-y-auto">
        
        {/* LOGO AND SUB-BRANDING */}
        <div className="p-5 lg:p-8 border-b border-white/[0.04]">
          <div className="flex items-center justify-between">
            <div className="flex flex-col items-start select-none">
              <p className="text-[9px] text-amber-500 tracking-[0.25em] font-medium uppercase font-sans mb-1.5">Interactive Walkthrough</p>
              <div className="flex items-center gap-2 flex-wrap">
                <KineticText 
                  text="APS BUILDERS & DEVELOPERS" 
                  className="text-base lg:text-lg text-white font-display font-black tracking-wider uppercase" 
                />
                <span className="text-[10px] bg-white/[0.05] border border-white/[0.08] text-white/50 px-2 py-0.5 rounded-md font-mono tracking-normal font-normal self-center">v2.4</span>
              </div>
            </div>
            
            {/* Audio Synthesis Pill */}
            <button
              onClick={toggleAudio}
              className={`p-2.5 rounded-full border transition-all duration-300 relative ${
                isAudioActive 
                  ? 'bg-amber-500/10 border-amber-500 text-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.2)]' 
                  : 'bg-white/[0.02] border-white/10 text-white/40 hover:text-white/80 hover:border-white/20'
              }`}
              title={isAudioActive ? "Mute Ambient Synth" : "Enable Ambient Synth"}
            >
              {isAudioActive ? <Volume2 className="w-4 h-4 animate-pulse" /> : <VolumeX className="w-4 h-4" />}
              {isAudioActive && (
                <span className="absolute -top-1 -right-1 flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                </span>
              )}
            </button>
          </div>
        </div>

        {/* COMPACT ROOM SELECTOR CARDS */}
        <div className="px-5 lg:px-8 py-4 lg:py-6 flex flex-col gap-2">
          <p className="text-[10px] text-white/40 tracking-wider font-mono uppercase mb-1">System Viewports</p>
          <div className="grid grid-cols-2 md:grid-cols-1 gap-2">
            {ROOMS_DATA.map((room) => {
              const isActive = room.id === activeRoomId;
              return (
                <button
                  key={room.id}
                  onClick={() => setActiveRoomId(room.id)}
                  className={`group text-left p-3.5 rounded-xl border transition-all duration-500 flex flex-col justify-between relative overflow-hidden ${
                    isActive 
                      ? 'bg-gradient-to-br from-white/[0.06] to-transparent border-amber-500/60 shadow-[inset_0_1px_1px_rgba(255,255,255,0.05),0_8px_20px_rgba(0,0,0,0.3)]' 
                      : 'bg-white/[0.01] border-white/[0.04] hover:bg-white/[0.03] hover:border-white/[0.08]'
                  }`}
                >
                  {/* Active highlight glow strip */}
                  {isActive && (
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-amber-500" />
                  )}

                  <div className="flex items-center justify-between mb-1 relative z-10">
                    <span className="text-[10px] font-mono text-white/40 group-hover:text-amber-500/70 transition-colors">{room.code}</span>
                    <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded-md ${
                      isActive ? 'bg-amber-500/20 text-amber-300' : 'bg-white/[0.04] text-white/40'
                    }`}>
                      {room.dimensions}
                    </span>
                  </div>

                  <div className="relative z-10">
                    <p className="text-[10px] text-white/50 tracking-wide font-sans">{room.category}</p>
                    <p className="font-display font-semibold text-sm tracking-wide text-white group-hover:translate-x-1 transition-transform duration-300">{room.name}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* SPECIFICATIONS & ACCENT INFO */}
        <div className="p-5 lg:p-8 bg-black/20 border-t border-white/[0.04] mt-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeRoom.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
              className="space-y-4"
            >
              {/* Description */}
              <div>
                <p className="text-[10px] text-white/40 tracking-wider font-mono uppercase mb-1 flex items-center gap-1">
                  <Info className="w-3 h-3 text-amber-500/80" /> Description
                </p>
                <p className="text-xs text-white/70 leading-relaxed font-sans">{activeRoom.description}</p>
              </div>

              {/* Specs Grid */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                {activeRoom.specs.map((spec, i) => (
                  <div key={i} className="border-l border-white/10 pl-2.5">
                    <p className="text-[9px] text-white/40 uppercase tracking-wider font-mono">{spec.label}</p>
                    <p className="text-xs font-semibold text-white/90">{spec.value}</p>
                  </div>
                ))}
              </div>

              {/* Key Materials */}
              <div className="pt-1">
                <p className="text-[9px] text-white/40 tracking-wider font-mono uppercase mb-1.5">Primary Materials</p>
                <div className="flex flex-wrap gap-1">
                  {activeRoom.materials.map((mat, i) => (
                    <span 
                      key={i} 
                      className="text-[9px] bg-white/[0.03] border border-white/[0.06] text-white/60 px-2 py-0.5 rounded-full font-sans tracking-wide"
                    >
                      {mat}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* RIGHT PANEL: MAIN 3D INTERACTIVE VIEWPORT HUD */}
      <div className="flex-1 relative flex flex-col justify-between h-2/3 md:h-full p-4 lg:p-6 z-10">
        
        {/* TOP STATUS BAR HUD */}
        <div className="flex items-center justify-between relative z-30">
          {/* Active room indicator tag */}
          <div className="bg-black/40 border border-white/[0.06] rounded-xl px-4 py-2 backdrop-blur-md flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            <div className="text-left">
              <p className="text-[9px] text-white/40 font-mono tracking-widest uppercase">HUD System Lock</p>
              <h3 className="font-display font-medium text-xs text-white uppercase tracking-wider">{activeRoom.name}</h3>
            </div>
          </div>

          {/* Quick Stats Widget */}
          <div className="hidden sm:flex items-center gap-4 bg-black/40 border border-white/[0.06] rounded-xl px-4 py-2 backdrop-blur-md">
            <div className="text-right">
              <p className="text-[8px] text-white/40 font-mono uppercase">Render Engine</p>
              <p className="text-[10px] font-mono text-emerald-400 font-semibold uppercase">WebGPU Hybrid</p>
            </div>
            <div className="h-6 w-px bg-white/10" />
            <div className="text-right">
              <p className="text-[8px] text-white/40 font-mono uppercase">Grid Mesh</p>
              <p className="text-[10px] font-mono text-white/70 font-semibold">{wireframeOverlay ? "ACTIVE" : "BYPASS"}</p>
            </div>
          </div>
        </div>

        {/* 3D FLOATING VIEWPORT STAGE */}
        <div className="absolute inset-0 flex items-center justify-center p-6 lg:p-12">
          <div 
            ref={viewportRef}
            onMouseMove={handleViewportMouseMove}
            onMouseLeave={handleViewportMouseLeave}
            className="w-full max-w-[850px] aspect-video rounded-2xl border border-white/[0.08] shadow-[0_25px_60px_rgba(0,0,0,0.6)] relative overflow-hidden bg-black transition-all duration-300 ease-out cursor-col-resize select-none"
            style={{
              transform: `perspective(1200px) rotateX(${viewportTilt.x}deg) rotateY(${viewportTilt.y}deg) scale(1.02)`,
              transformStyle: 'preserve-3d',
            }}
          >
            {/* HOLOGRAPHIC SCANNING GRID OVERLAY */}
            <AnimatePresence>
              {wireframeOverlay && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.18 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 pointer-events-none z-10 bg-[linear-gradient(to_right,#3b82f6_1px,transparent_1px),linear-gradient(to_bottom,#3b82f6_1px,transparent_1px)] [background-size:16px_16px] mix-blend-screen"
                >
                  {/* Holographic scanner light line */}
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-blue-400 to-transparent shadow-[0_0_15px_rgba(59,130,246,0.6)] animate-[shimmer_3s_infinite_linear]" 
                    style={{
                      animationName: 'scanline',
                      animationDuration: '4s',
                      animationIterationCount: 'infinite',
                      animationTimingFunction: 'linear'
                    }}
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {/* BASE LAYER (0% slider): DETAILED AR BLUEPRINT WIREFRAME */}
            <div className="absolute inset-0 z-0 bg-[#0e0e11] flex items-center justify-center p-8 select-none">
              <div className="w-full h-full relative opacity-80 flex flex-col justify-between">
                
                {/* Tech coordinates around grid */}
                <div className="absolute top-2 left-2 text-[8px] font-mono text-blue-400/40">LAT: 9.9312° N | LON: 76.2673° E</div>
                <div className="absolute top-2 right-2 text-[8px] font-mono text-blue-400/40">SYS_RENDER_0284X</div>
                <div className="absolute bottom-2 left-2 text-[8px] font-mono text-blue-400/40">SCALE: 1:50 | AUTOCAD v24.2</div>
                <div className="absolute bottom-2 right-2 text-[8px] font-mono text-blue-400/40">EPS: OMNI_GRID</div>

                {/* Vector Blueprint Graphics */}
                <div className="absolute inset-0 flex items-center justify-center p-6">
                  {/* Procedurally generated beautiful SVG blueprints */}
                  <svg className="w-[85%] h-[85%] text-blue-500/30" viewBox="0 0 400 240" fill="none" stroke="currentColor" strokeWidth="0.8">
                    {/* Architectural grids */}
                    <path d="M 0,20 L 400,20 M 0,60 L 400,60 M 0,100 L 400,100 M 0,140 L 400,140 M 0,180 L 400,180 M 0,220 L 400,220" strokeDasharray="3,3" stroke="currentColor" opacity="0.4" />
                    <path d="M 40,0 L 40,240 M 80,0 L 80,240 M 120,0 L 120,240 M 160,0 L 160,240 M 200,0 L 200,240 M 240,0 L 240,240 M 280,0 L 280,240 M 320,0 L 320,240 M 360,0 L 360,240" strokeDasharray="3,3" stroke="currentColor" opacity="0.4" />

                    {/* Room Specific Outlines */}
                    {activeRoomId === 'gallery' && (
                      <g>
                        {/* Kitchen Counters and Island */}
                        <rect x="30" y="30" width="340" height="30" />
                        <rect x="100" y="100" width="200" height="60" rx="4" />
                        <circle cx="50" cy="45" r="8" /> {/* Sink */}
                        <circle cx="150" cy="130" r="4" /> {/* Stools */}
                        <circle cx="200" cy="130" r="4" />
                        <circle cx="250" cy="130" r="4" />
                        <rect x="300" y="30" width="50" height="25" fill="none" strokeDasharray="2,2" /> {/* Cabinet */}
                        {/* Dimensional annotation lines */}
                        <line x1="30" y1="200" x2="370" y2="200" />
                        <line x1="30" y1="195" x2="30" y2="205" />
                        <line x1="370" y1="195" x2="370" y2="205" />
                        <text x="200" y="195" fill="currentColor" fontSize="6" fontFamily="monospace" textAnchor="middle">W_SPAN: 6.40m</text>
                      </g>
                    )}

                    {activeRoomId === 'inside' && (
                      <g>
                        {/* Living Room Sectional couch */}
                        <path d="M 50,60 L 250,60 L 250,150 L 210,150 L 210,95 L 50,95 Z" />
                        {/* Coffee table */}
                        <ellipse cx="140" cy="125" rx="35" ry="15" />
                        {/* TV Console unit */}
                        <rect x="320" y="40" width="20" height="150" />
                        <line x1="330" y1="50" x2="330" y2="180" strokeWidth="2" /> {/* Glass screen */}
                        <circle cx="80" cy="170" r="10" /> {/* Accent Chair */}
                        {/* Dimensional line */}
                        <line x1="320" y1="210" x2="50" y2="210" />
                        <line x1="320" y1="205" x2="320" y2="215" />
                        <line x1="50" y1="205" x2="50" y2="215" />
                        <text x="185" y="205" fill="currentColor" fontSize="6" fontFamily="monospace" textAnchor="middle">W_SPAN: 8.20m</text>
                      </g>
                    )}

                    {activeRoomId === 'exterior' && (
                      <g>
                        {/* Bedroom Layout */}
                        <rect x="120" y="40" width="160" height="120" rx="2" /> {/* Bed Frame */}
                        <rect x="140" y="30" width="120" height="20" /> {/* Headboard */}
                        <rect x="85" y="45" width="30" height="30" /> {/* Nightstands */}
                        <rect x="285" y="45" width="30" height="30" />
                        <path d="M 50,140 L 90,140 L 90,180 L 50,180 Z" /> {/* Wardrobe */}
                        <circle cx="340" cy="150" r="14" /> {/* Lounge chair */}
                        {/* Door swing arc */}
                        <path d="M 30,210 A 30,30 0 0,0 60,180" strokeDasharray="3,3" />
                        <line x1="30" y1="210" x2="30" y2="180" />
                        {/* Dimensions */}
                        <line x1="120" y1="185" x2="280" y2="185" />
                        <line x1="120" y1="180" x2="120" y2="190" />
                        <line x1="280" y1="180" x2="280" y2="190" />
                        <text x="200" y="180" fill="currentColor" fontSize="6" fontFamily="monospace" textAnchor="middle">BED_SPAN: 3.20m</text>
                      </g>
                    )}

                    {activeRoomId === 'contact' && (
                      <g>
                        {/* Bathroom Suite layout */}
                        <rect x="150" y="140" width="100" height="50" rx="25" /> {/* Monolithic Tub */}
                        <line x1="150" y1="165" x2="250" y2="165" opacity="0.3" />
                        {/* Double sink vanity */}
                        <rect x="40" y="50" width="320" height="35" />
                        <ellipse cx="100" cy="67" rx="15" ry="8" />
                        <ellipse cx="300" cy="67" rx="15" ry="8" />
                        {/* Glass shower stall */}
                        <rect x="40" y="120" width="75" height="75" />
                        <circle cx="77" cy="157" r="2" /> {/* Overhead rain nozzle */}
                        {/* Compass rose symbol */}
                        <circle cx="350" cy="160" r="12" />
                        <line x1="350" y1="145" x2="350" y2="175" />
                        <line x1="335" y1="160" x2="365" y2="160" />
                      </g>
                    )}
                  </svg>
                </div>
              </div>
            </div>

            {/* VIDEO RENDER LAYER (Clipped overlay controlled by swipe slider) */}
            <div 
              className="absolute inset-0 z-20 pointer-events-none"
              style={{
                clipPath: `polygon(0 0, ${sliderValue}% 0, ${sliderValue}% 100%, 0 100%)`,
                transition: 'none'
              }}
            >
              <video 
                key={`${activeRoom.id}-${timeOfDay}`}
                className={`w-full h-full object-cover select-none pointer-events-none transition-all duration-1000 ${getLightingFilter()}`} 
                autoPlay 
                loop 
                muted 
                playsInline
              >
                <source src={activeRoom.videoUrl} type="video/mp4" />
              </video>

              {/* Grid scanning glow effect at the border of video */}
              <div 
                className="absolute top-0 bottom-0 w-1 bg-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.8),0_0_4px_rgba(255,255,255,0.9)] z-30"
                style={{ left: `${sliderValue}%` }}
              />
            </div>

            {/* INTERACTIVE DRAG HANDLE AND SLIDER OVERLAY */}
            <div className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none">
              {/* Draggable divider lines */}
              <div 
                className="absolute top-0 bottom-0 w-[2px] bg-white/40 shadow-[0_0_8px_rgba(255,255,255,0.4)] transition-none flex items-center justify-center pointer-events-auto"
                style={{ left: `${sliderValue}%` }}
              >
                {/* Drag pill handle */}
                <div className="w-9 h-9 rounded-full bg-black/90 border border-white/20 hover:border-amber-400/80 text-white/90 hover:text-amber-400 shadow-[0_6px_20px_rgba(0,0,0,0.5),inset_0_1px_2px_rgba(255,255,255,0.1)] flex items-center justify-center transition-colors cursor-col-resize select-none">
                  <Sliders className="w-3.5 h-3.5 rotate-90" />
                </div>
              </div>

              {/* Hidden HTML range slider layer mapped perfectly over viewport */}
              <input 
                type="range" 
                min="0" 
                max="100" 
                value={sliderValue}
                onChange={(e) => setSliderValue(parseInt(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-col-resize pointer-events-auto z-40"
              />
            </div>

            {/* WATERMARK SPEC OVERLAYS */}
            <div className="absolute bottom-4 left-4 z-40 bg-black/50 border border-white/10 px-3 py-1.5 rounded-lg backdrop-blur-sm pointer-events-none">
              <div className="flex items-center gap-2 text-[10px] font-mono text-white/80">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                <span>3D RENDER : WIREFRAME INTEGRATION</span>
                <span className="text-white/35">|</span>
                <span className="text-amber-400 font-bold">{sliderValue}% Blueprint</span>
              </div>
            </div>

            {/* Perspective compass HUD element inside viewport */}
            <div className="absolute top-4 right-4 z-40 bg-black/50 border border-white/10 p-2.5 rounded-xl backdrop-blur-sm pointer-events-none hidden sm:block">
              <Compass className="w-5 h-5 text-amber-500/80 animate-[spin_24s_linear_infinite]" />
            </div>
          </div>
        </div>

        {/* BOTTOM HUD MODULE: SOLAR ANALYSIS & MESH CONTROL */}
        <div className="bg-black/40 border border-white/[0.06] rounded-2xl p-4 lg:p-5 backdrop-blur-md relative z-30 flex flex-col md:flex-row items-center justify-between gap-4 mt-auto">
          
          {/* SOLAR ANALYSIS DIAL (Time of day simulator) */}
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="text-left shrink-0">
              <p className="text-[8px] text-white/40 font-mono tracking-wider uppercase mb-1.5">Solar Analysis Simulator</p>
              <div className="flex items-center gap-1">
                {(['morning', 'noon', 'dusk', 'midnight'] as TimeOfDay[]).map((time) => (
                  <button
                    key={time}
                    onClick={() => setTimeOfDay(time)}
                    className={`px-3 py-1.5 rounded-lg text-[9px] font-mono border tracking-wider transition-all uppercase flex items-center gap-1.5 ${
                      timeOfDay === time 
                        ? 'bg-amber-500/10 border-amber-500/50 text-amber-400 shadow-[0_2px_10px_rgba(245,158,11,0.1)]' 
                        : 'bg-white/[0.02] border-white/[0.05] text-white/50 hover:text-white/90 hover:border-white/10'
                    }`}
                  >
                    {time === 'morning' && <Sun className="w-3 h-3 text-orange-400" />}
                    {time === 'noon' && <Sun className="w-3 h-3 text-amber-400" />}
                    {time === 'dusk' && <Sun className="w-3 h-3 text-red-400" />}
                    {time === 'midnight' && <Moon className="w-3 h-3 text-blue-400" />}
                    {time}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* HOLOGRAPHIC MESH TOGGLE */}
          <div className="flex items-center gap-3 w-full md:w-auto md:justify-end">
            <button
              onClick={() => setWireframeOverlay(!wireframeOverlay)}
              className={`px-4 py-2.5 rounded-xl border text-[10px] font-mono tracking-wider transition-all uppercase flex items-center gap-2 w-full md:w-auto justify-center ${
                wireframeOverlay 
                  ? 'bg-blue-500/10 border-blue-500/40 text-blue-400 shadow-[0_2px_10px_rgba(59,130,246,0.1)]' 
                  : 'bg-white/[0.02] border-white/[0.05] text-white/40 hover:text-white/80 hover:border-white/10'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Mesh Scan {wireframeOverlay ? "ON" : "OFF"}</span>
            </button>

            {/* ACTION PROCEED BUTTON */}
            <button
              onClick={handleProceed}
              className="bg-amber-500 hover:bg-amber-600 active:scale-[0.98] transition-all text-black font-semibold text-xs tracking-[0.15em] px-6 py-2.5 rounded-xl uppercase flex items-center gap-2 shadow-[0_4px_20px_rgba(245,158,11,0.3)] w-full md:w-auto justify-center shrink-0"
            >
              <span>Initialize Experience</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>

      {/* Embedded CSS scanline animations and layout patches */}
      <style>{`
        @keyframes scanline {
          0% { top: -2%; }
          50% { top: 102%; }
          100% { top: -2%; }
        }
      `}</style>
    </div>
  );
}
