import React from 'react';
import { motion } from 'motion/react';
import { Coffee, Map, Compass, PenTool, Layout, HardHat, Key } from 'lucide-react';

const STEPS = [
  {
    icon: Coffee,
    title: "Consultation",
    desc: "We discuss your vision, requirements, and budgetary expectations over coffee.",
    color: "bg-amber-100 text-amber-600"
  },
  {
    icon: Map,
    title: "Site Survey",
    desc: "Rigorous analysis of the terrain and legal requirements for optimal placement.",
    color: "bg-blue-100 text-blue-600"
  },
  {
    icon: Compass,
    title: "GPS Surveying System",
    desc: "Satellite-guided coordinate mapping and high-precision geographic alignments.",
    color: "bg-indigo-100 text-indigo-600"
  },
  {
    icon: PenTool,
    title: "Architectural Planning",
    desc: "Drafting detailed blueprints and 3D renderings to bring ideas to life.",
    color: "bg-purple-100 text-purple-600"
  },
  {
    icon: Layout,
    title: "Design Approval",
    desc: "Collaborative review of plans and material selection for final go-ahead.",
    color: "bg-orange-100 text-orange-600"
  },
  {
    icon: HardHat,
    title: "Active Construction",
    desc: "Our engineers and craftsmen execute the build with precision and safety.",
    color: "bg-slate-100 text-slate-900"
  },
  {
    icon: Key,
    title: "Project Handover",
    desc: "Final walkthrough and handing over the keys to your brand new asset.",
    color: "bg-emerald-100 text-emerald-600"
  }
];

export default function ProcessRoadmap() {
  return (
    <section className="py-32 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-24 max-w-2xl mx-auto space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          >
            <h2 className="text-amber-600 font-bold tracking-widest uppercase text-sm">Transparency</h2>
            <h3 className="font-display text-4xl lg:text-5xl font-bold text-slate-900">How We Build</h3>
          </motion.div>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="text-slate-500 leading-relaxed"
          >
            Our structured 7-step process ensures transparency, efficiency, and exceptional quality from start to finish.
          </motion.p>
        </div>

        <div className="relative">
          {/* Animated Connecting Line (Desktop) */}
          <div className="hidden lg:block absolute top-8 left-[7%] right-[7%] h-0.5 bg-slate-100 -translate-y-1/2">
            <motion.div 
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
              className="h-full bg-gradient-to-r from-amber-500 via-amber-600 to-emerald-500 origin-left"
            />
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-7 gap-8 relative z-10">
            {STEPS.map((step, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 35, scale: 0.9 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ 
                  delay: idx * 0.12, 
                  duration: 0.6,
                  ease: [0.16, 1, 0.3, 1]
                }}
                className="group flex flex-col items-center text-center space-y-6"
              >
                <div className={`w-16 h-16 ${step.color} rounded-full flex items-center justify-center shadow-lg transition-transform duration-500 group-hover:scale-110 relative ring-4 ring-white`}>
                  <step.icon className="w-6 h-6 transition-transform group-hover:rotate-6" />
                  <motion.div 
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.12 + 0.3, type: "spring", stiffness: 300, damping: 20 }}
                    className="absolute -top-2 -right-2 w-6 h-6 bg-slate-900 text-white rounded-full flex items-center justify-center text-[10px] font-bold shadow-md"
                  >
                    {idx + 1}
                  </motion.div>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-display font-bold text-slate-900 uppercase tracking-tight text-sm group-hover:text-amber-600 transition-colors">{step.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed max-w-[200px] mx-auto">
                    {step.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
