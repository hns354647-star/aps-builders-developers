import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { ShieldCheck } from 'lucide-react';

export const CookieBanner: React.FC = () => {
  const { t } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('archidomo_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('archidomo_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('archidomo_cookie_consent', 'declined');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-6 left-6 right-6 md:left-auto md:right-8 md:max-w-md z-50 bg-[#111111]/95 text-[#F5F3EF] backdrop-blur-md border border-white/10 p-5 shadow-2xl rounded-xs">
      <div className="flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-stone-400 shrink-0 mt-0.5" />
        <div className="space-y-3">
          <p className="text-xs text-stone-300 leading-relaxed font-sans">
            {t.cookie.message}
          </p>
          <div className="flex items-center gap-3">
            <button
              onClick={handleAccept}
              className="px-4 py-1.5 bg-[#F5F3EF] text-[#111111] text-[11px] uppercase tracking-wider font-semibold hover:bg-white transition-colors"
            >
              {t.cookie.accept}
            </button>
            <button
              onClick={handleDecline}
              className="text-[11px] uppercase tracking-wider text-stone-400 hover:text-white transition-colors underline underline-offset-4"
            >
              {t.cookie.decline}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;
