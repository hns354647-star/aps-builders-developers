import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Compass, DoorOpen, Home, Star, ArrowRight, ShieldCheck, Info } from 'lucide-react';

import doorEast from "../assets/images/vastu_door_east_1780813328926.png";
import doorNorth from "../assets/images/vastu_door_north_1780813345048.png";
import homeBrahmasthan from "../assets/images/vastu_home_brahmasthan_1780813360455.png";
import homeExterior from "../assets/images/vastu_home_exterior_1780813375422.png";

type VastuCategory = 'Doors' | 'Architecture';

const VASTU_INSIGHTS = {
  Doors: [
    {
      direction: "East",
      image: doorEast,
      title: "The Source of Energy",
      desc: "East-facing doors are considered highly auspicious, bringing in the first rays of the morning sun and prosperity.",
      tips: ["Avoid placing a bathroom near the entrance", "Use solid teak wood for strength", "Ensure the entrance is well-lit"]
    },
    {
      direction: "North",
      image: doorNorth,
      title: "Wealth & Prosperity",
      desc: "North-facing entrances are associated with Kuber, the god of wealth, ideal for business professionals and growth.",
      tips: ["Keep the entrance clutter-free", "Use lighter colors for the door", "Incorporate silver accents if possible"]
    }
  ],
  Architecture: [
    {
      direction: "Center",
      image: homeBrahmasthan,
      title: "The Heart (Brahmasthan)",
      desc: "The central part of the home should be open or hollow to allow free flow of cosmic energy and light.",
      tips: ["Ideal for a courtyard or high ceiling", "Keep this area free from heavy furniture", "Use natural stones for flooring"]
    },
    {
      direction: "Overall",
      image: homeExterior,
      title: "Harmonious Exterior",
      desc: "A balanced architecture ensures that energy (Prana) stays within the home, providing peace to inhabitants.",
      tips: ["Place heavy structures in the South-West", "Keep North-East open and light", "Balconies should ideally face East"]
    }
  ]
};

export default function VastuConsultant() {
  const [activeCategory, setActiveCategory] = useState<VastuCategory>('Doors');
  const [selectedIndex, setSelectedIndex] = useState(0);

  const currentItem = VASTU_INSIGHTS[activeCategory][selectedIndex];

  return (
    <section className="py-32 bg-slate-900 text-white overflow-hidden relative">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-600 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600 rounded-full blur-[120px]" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row gap-20">
          {/* Left Content */}
          <div className="lg:w-1/2 space-y-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <div className="inline-flex items-center gap-2 bg-amber-600/20 text-amber-500 px-4 py-2 rounded-full border border-amber-600/30">
                <Compass className="w-4 h-4 animate-spin-slow" />
                <span className="text-[10px] font-bold uppercase tracking-[0.2em]">Vastu AI Consultant</span>
              </div>
              <h2 className="font-display text-5xl lg:text-6xl font-bold leading-tight">
                Architectural <br />
                <span className="text-amber-600">Harmony</span> by Design
              </h2>
              <p className="text-slate-400 text-lg leading-relaxed max-w-xl">
                Our Vastu-integrated AI helps you visualize the perfect balance between ancient wisdom and modern aesthetics. Explore compliant designs for doors and layouts.
              </p>
            </motion.div>

            <div className="flex gap-4">
              {(['Doors', 'Architecture'] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => {
                    setActiveCategory(cat);
                    setSelectedIndex(0);
                  }}
                  className={`flex items-center gap-3 px-8 py-4 rounded-sm font-bold text-xs uppercase tracking-widest transition-all border ${
                    activeCategory === cat 
                      ? 'bg-amber-600 border-amber-600 text-white shadow-xl shadow-amber-600/20' 
                      : 'border-slate-800 text-slate-500 hover:border-slate-700 hover:text-slate-300'
                  }`}
                >
                  {cat === 'Doors' ? <DoorOpen className="w-4 h-4" /> : <Home className="w-4 h-4" />}
                  {cat}
                </button>
              ))}
            </div>

            <div className="space-y-8 pt-8 border-t border-slate-800">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentItem.direction}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center text-amber-600 font-bold">
                      {currentItem.direction.charAt(0)}
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-white">{currentItem.title}</h4>
                      <p className="text-amber-600 text-xs font-bold uppercase tracking-widest">{currentItem.direction} Direction</p>
                    </div>
                  </div>
                  
                  <p className="text-slate-400 text-sm leading-relaxed">
                    {currentItem.desc}
                  </p>

                  <div className="grid gap-3">
                    {currentItem.tips.map((tip, i) => (
                      <div key={i} className="flex items-center gap-3 text-xs text-slate-300">
                        <Star className="w-3 h-3 text-amber-600 fill-amber-600" />
                        {tip}
                      </div>
                    ))}
                  </div>
                </motion.div>
              </AnimatePresence>

              <div className="flex gap-2">
                {VASTU_INSIGHTS[activeCategory].map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedIndex(i)}
                    className={`h-1 transition-all rounded-full ${
                      selectedIndex === i ? 'w-12 bg-amber-600' : 'w-4 bg-slate-800'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Right Visuals */}
          <div className="lg:w-1/2 relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentItem.image}
                initial={{ opacity: 0, scale: 1.1 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.7 }}
                className="relative aspect-[4/5] lg:aspect-auto lg:h-full rounded-sm overflow-hidden"
              >
                <img 
                  src={currentItem.image} 
                  alt={currentItem.title} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-60" />
                
                {/* Floating Info Cards */}
                <div className="absolute bottom-6 left-6 right-6 p-6 bg-white/10 backdrop-blur-md border border-white/10 rounded-sm">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-[10px] font-bold text-amber-500 uppercase tracking-widest">AI Visualization</p>
                      <p className="text-sm font-bold text-white">Vastu Compliant Template v2.4</p>
                    </div>
                    <Info className="w-5 h-5 text-amber-600" />
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
            
            {/* Background Texture */}
            <div className="absolute -top-10 -right-10 w-40 h-40 border border-amber-600/20 rounded-full" />
            <div className="absolute -bottom-10 -left-10 w-40 h-40 border border-blue-600/20 rounded-full" />
          </div>
        </div>
      </div>
    </section>
  );
}
