import React, { useState, useEffect, useCallback } from 'react';
import { Mic, Volume2, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Project } from '../data/projects';
import ListeningWaveform from './ListeningWaveform';

interface VoiceGuidedTourProps {
  project: Project;
}

export default function VoiceGuidedTour({ project }: VoiceGuidedTourProps) {
  const [isListening, setIsListening] = useState(false);
  const [status, setStatus] = useState<'idle' | 'listening' | 'speaking' | 'error'>('idle');
  const [transcript, setTranscript] = useState('');

  const speak = useCallback((text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95;
    utterance.pitch = 1;
    
    utterance.onstart = () => {
      setStatus('speaking');
    };
    
    utterance.onend = () => {
      setStatus('idle');
    };

    window.speechSynthesis.speak(utterance);
  }, []);

  const handleTourCommand = useCallback(() => {
    const highlights = [
      `The ${project.title} showcases a sophisticated ${project.type} architecture characteristic of our premium standards.`,
      `Located in ${project.location}, this structure integrates modern materials with functional design principles.`,
      project.description ? project.description : "This project emphasizes structural integrity and aesthetic harmony through meticulously planned layouts.",
      `Its current status is ${project.status}, reflecting our dedication to quality and timely delivery.`
    ].join(' ');

    speak(highlights);
  }, [project, speak]);

  const toggleListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    if (isListening) {
      setIsListening(false);
      setStatus('idle');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
      setStatus('listening');
      setTranscript('');
    };

    recognition.onresult = (event: any) => {
      if (!event.results || !event.results[0] || !event.results[0][0]) return;
      
      const command = event.results[0][0].transcript.toLowerCase();
      setTranscript(command);
      
      if (command.includes('tell me about') || command.includes('architecture') || command.includes('tour')) {
        handleTourCommand();
      } else {
        // Just stop if not understood
        setIsListening(false);
        setStatus('idle');
      }
    };

    recognition.onerror = () => {
      setIsListening(false);
      setStatus('error');
    };

    recognition.onend = () => {
      setIsListening(false);
      // If we're not speaking, we go back to idle
      if (status !== 'speaking') {
        setStatus('idle');
      }
    };

    recognition.start();
  };

  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  return (
    <div className="flex flex-col gap-4 p-5 bg-slate-50/50 rounded-2xl border border-slate-100 mt-8 overflow-hidden backdrop-blur-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={`p-2.5 rounded-xl transition-all duration-300 ${
            status === 'listening' ? 'bg-red-500 text-white animate-pulse' : 
            status === 'speaking' ? 'bg-amber-500 text-white' : 
            'bg-slate-200 text-slate-600'
          }`}>
            {status === 'speaking' ? <Volume2 className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              Voice Architecture Tour
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            </h4>
            <div className="flex items-center gap-2">
              <p className="text-[11px] text-slate-500 font-medium">
                {status === 'listening' ? 'Listening...' : status === 'speaking' ? 'Narrating tour...' : "Try: 'Tell me about this project's architecture'"}
              </p>
              {status === 'listening' && (
                <ListeningWaveform color="bg-red-500 animate-pulse" barCount={5} height="h-4" />
              )}
            </div>
          </div>
        </div>
        
        <button
          onClick={toggleListening}
          className={`px-5 py-2.5 rounded-xl text-[11px] font-bold transition-all duration-300 shadow-sm ${
            isListening 
              ? 'bg-red-500 text-white hover:bg-red-600' 
              : status === 'speaking' ? 'bg-amber-500 text-white' : 'bg-slate-900 text-white hover:bg-slate-800'
          }`}
        >
          {isListening ? 'Stop' : status === 'speaking' ? 'Narrating...' : 'Start Voice Assistant'}
        </button>
      </div>

      <AnimatePresence>
        {transcript && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="text-[10px] font-mono text-slate-500 bg-white/80 p-3 rounded-lg border border-slate-100 flex items-center gap-2"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
            Detected: "{transcript}"
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
