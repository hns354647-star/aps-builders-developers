import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { HERO_SLIDES } from '../data/mockSanityData';
import { buildSanityImageUrl } from '../lib/sanityClient';
import { ArrowRight, ChevronLeft, ChevronRight, Pause, Play } from 'lucide-react';

export const HeroCarousel: React.FC = () => {
  const { locale, navigateTo, t } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % HERO_SLIDES.length);
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
  }, []);

  // Autoplay crossfade every 6.5s
  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        nextSlide();
      }, 6500);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isPlaying, nextSlide]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') nextSlide();
      if (e.key === 'ArrowLeft') prevSlide();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide]);

  const currentSlide = HERO_SLIDES[currentIndex];
  const prefix = locale === 'en' ? '/en' : '';

  return (
    <section
      className="relative w-full h-screen min-h-[700px] overflow-hidden bg-[#111111] text-white flex flex-col justify-end"
      aria-label="Carousel de présentations architecturales"
      onMouseEnter={() => setIsPlaying(false)}
      onMouseLeave={() => setIsPlaying(true)}
    >
      {/* Background Slides with Crossfade and Subtle Slow Zoom */}
      <AnimatePresence initial={false} mode="sync">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-0 w-full h-full"
        >
          {/* Subtle slow zoom animation */}
          <motion.div
            initial={{ scale: 1.04 }}
            animate={{ scale: 1.0 }}
            transition={{ duration: 7, ease: 'easeOut' }}
            className="w-full h-full relative"
          >
            <img
              src={buildSanityImageUrl(currentSlide.url, {
                width: currentSlide.isFinalWideCrop ? 1920 : 2200,
                height: currentSlide.isFinalWideCrop ? 940 : undefined,
                quality: 85,
                auto: 'format',
              })}
              alt={currentSlide.alt}
              className={`w-full h-full object-cover ${
                currentSlide.isFinalWideCrop ? 'object-center' : 'object-center'
              }`}
            />
          </motion.div>

          {/* Gradients to ensure text legibility while keeping photo luminous */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-black/30 pointer-events-none" />
          <div className="absolute inset-0 bg-radial from-transparent via-transparent to-black/40 pointer-events-none" />
        </motion.div>
      </AnimatePresence>

      {/* Hero Content Overlay */}
      <div className="relative z-20 max-w-7xl mx-auto px-6 sm:px-8 md:px-12 pb-16 sm:pb-24 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end">
          {/* Left Block: H1 and Tagline */}
          <div className="lg:col-span-8 space-y-6">
            {/* Slide Metadata Indicator */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              key={`meta-${currentIndex}`}
              transition={{ duration: 0.6 }}
              className="flex items-center gap-3 text-xs tracking-[0.25em] uppercase text-stone-300 font-sans"
            >
              <span className="font-semibold text-white">
                {String(currentIndex + 1).padStart(2, '0')} / {String(HERO_SLIDES.length).padStart(2, '0')}
              </span>
              <span className="opacity-40">·</span>
              <span>{currentSlide.title}</span>
              <span className="opacity-40">·</span>
              <span className="text-stone-400">{currentSlide.location}</span>
              {currentSlide.isFinalWideCrop && (
                <span className="text-[10px] border border-white/30 px-1.5 py-0.5 tracking-widest text-amber-200">
                  1920×940
                </span>
              )}
            </motion.div>

            {/* H1 Main Heading */}
            <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl xl:text-7xl font-light tracking-tight leading-[1.08] text-white max-w-4xl">
              {t.hero.h1}
            </h1>

            {/* Tagline */}
            <p className="text-base sm:text-lg text-stone-200 font-sans font-light max-w-2xl leading-relaxed tracking-wide opacity-90">
              {t.hero.tagline}
            </p>
          </div>

          {/* Right Block: Carousel Controls & Navigation */}
          <div className="lg:col-span-4 flex flex-col lg:items-end justify-between gap-6">
            {/* Quick Action Button to Featured Projects */}
            <button
              onClick={() => navigateTo(`${prefix}/realisations/`)}
              className="inline-flex items-center gap-3 text-xs uppercase tracking-[0.22em] text-white hover:text-stone-300 transition-colors group border-b border-white/40 pb-1.5 self-start lg:self-end"
            >
              <span>{t.projectIndex.allProjectsCta}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
            </button>

            {/* Next Image & Navigation Bar */}
            <div className="flex items-center gap-4 bg-black/40 backdrop-blur-md border border-white/10 px-4 py-2.5 rounded-xs">
              <button
                onClick={prevSlide}
                aria-label={t.hero.previousImage}
                className="p-1 hover:text-stone-300 transition-colors focus:outline-none"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              {/* Progress Dots */}
              <div className="flex items-center gap-1.5 px-2">
                {HERO_SLIDES.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentIndex(idx)}
                    aria-label={`Aller à la photo ${idx + 1}`}
                    className={`h-1 transition-all duration-300 rounded-full ${
                      idx === currentIndex ? 'w-6 bg-white' : 'w-2 bg-white/30 hover:bg-white/60'
                    }`}
                  />
                ))}
              </div>

              {/* Next Control */}
              <button
                onClick={nextSlide}
                aria-label={t.hero.nextImage}
                className="flex items-center gap-2 text-xs uppercase tracking-[0.18em] font-medium hover:text-stone-300 transition-colors pl-2 border-l border-white/20 focus:outline-none"
              >
                <span>{t.hero.nextImage}</span>
                <ChevronRight className="w-4 h-4" />
              </button>

              {/* Autoplay Pause/Play toggle */}
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                aria-label={isPlaying ? "Mettre en pause l'autoplay" : "Lancer l'autoplay"}
                className="text-white/60 hover:text-white transition-colors pl-1"
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroCarousel;
