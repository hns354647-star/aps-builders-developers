import React, { useState, useRef } from 'react';
import { motion, useInView, HTMLMotionProps } from 'motion/react';
import { Building2, ImageOff, RefreshCw } from 'lucide-react';
import Skeleton from './Skeleton';

interface LazyImageProps extends HTMLMotionProps<"img"> {
  src: string;
  alt: string;
  className?: string;
  containerClassName?: string;
  showSkeleton?: boolean;
  aspectRatio?: string;
}

export default function LazyImage({ 
  src, 
  alt, 
  className = "", 
  containerClassName = "",
  showSkeleton = true,
  aspectRatio,
  ...props 
}: LazyImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [retryKey, setRetryKey] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "250px" });

  const handleRetry = (e: React.MouseEvent) => {
    e.stopPropagation();
    setHasError(false);
    setIsLoaded(false);
    setRetryKey(prev => prev + 1);
  };

  return (
    <div 
      ref={ref} 
      style={aspectRatio ? { aspectRatio } : undefined}
      className={`relative overflow-hidden bg-slate-100 ${containerClassName || 'w-full h-full'}`}
    >
      {/* High-Fidelity Blueprint Architectural Skeleton Loader */}
      {showSkeleton && !isLoaded && !hasError && (
        <Skeleton 
          className="absolute inset-0 z-0" 
          variant="blueprint" 
          icon={Building2} 
        />
      )}

      {/* Error Fallback State */}
      {hasError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-100 p-4 text-center z-10 select-none">
          <div className="w-10 h-10 rounded-full bg-slate-200/80 flex items-center justify-center text-slate-400 mb-2">
            <ImageOff className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-slate-700 line-clamp-1">{alt}</span>
          <span className="text-[10px] text-slate-400 uppercase tracking-wider mb-2">Image preview unavailable</span>
          <button
            onClick={handleRetry}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider bg-slate-800 hover:bg-amber-600 text-white rounded-sm transition-colors shadow-xs"
          >
            <RefreshCw className="w-3 h-3" /> Retry
          </button>
        </div>
      )}

      {/* Actual Lazy-Loaded Image */}
      {isInView && !hasError && (
        <motion.img
          key={retryKey}
          src={src}
          alt={alt}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ 
            opacity: isLoaded ? 1 : 0,
            scale: isLoaded ? 1 : 1.05,
            filter: isLoaded ? "blur(0px)" : "blur(8px)",
          }}
          transition={{ 
            opacity: { duration: 0.6, ease: "easeOut" },
            scale: { duration: 0.8, ease: [0.16, 1, 0.3, 1] },
            filter: { duration: 0.5 },
            ...props.transition as any
          }}
          onLoad={(e) => {
            setIsLoaded(true);
            if (props.onLoad) props.onLoad(e as any);
          }}
          onError={() => {
            setHasError(true);
            setIsLoaded(false);
          }}
          className={`w-full h-full object-cover select-none relative z-[1] transition-transform duration-700 ${className}`}
          referrerPolicy="no-referrer"
          {...props}
        />
      )}
      
      {/* Ambient Vignette Overlay */}
      <div className="absolute inset-0 bg-slate-900/5 pointer-events-none z-[2]" />
    </div>
  );
}
