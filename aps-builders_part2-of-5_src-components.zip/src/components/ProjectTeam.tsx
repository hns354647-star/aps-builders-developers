import React from 'react';
import { motion } from 'motion/react';
import { Users, Award, Linkedin, Mail } from 'lucide-react';

interface TeamMember {
  name: string;
  role: string;
  specialty: string;
}

interface ProjectTeamProps {
  onInquiry?: (member: TeamMember) => void;
}

const team: TeamMember[] = [
  { name: 'Ar. Rahul Vasudev', role: 'Chief Resident Architect', specialty: 'Tropical Modernism' },
  { name: 'Eng. Sneha Nair', role: 'Structural Consultant', specialty: 'Sustainable Concrete' },
  { name: 'Karthik Menon', role: 'Project Manager', specialty: 'Lean Construction' },
];

export default function ProjectTeam({ onInquiry }: ProjectTeamProps) {
  return (
    <div className="bg-slate-50 p-6 rounded-sm border border-slate-100 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-amber-600" />
          <h4 className="text-[10px] font-bold text-slate-900 uppercase tracking-widest">The Expert Team</h4>
        </div>
        <Award className="w-3 h-3 text-amber-600" />
      </div>

      <div className="space-y-4">
        {team.map((member, idx) => (
          <motion.div 
            key={member.name}
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="flex items-center justify-between p-3 bg-white rounded-sm border border-slate-200/50 shadow-sm group hover:border-amber-200 transition-colors"
          >
            <div className="flex-1">
              <h5 className="text-[10px] font-bold text-slate-900 uppercase tracking-tight group-hover:text-amber-600 transition-colors">
                {member.name}
              </h5>
              <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">
                {member.role} • <span className="text-slate-500 italic">{member.specialty}</span>
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <button 
                onClick={() => onInquiry?.(member)}
                className="px-3 py-1.5 bg-slate-50 hover:bg-amber-600 text-[8px] font-bold uppercase tracking-widest text-salte-600 hover:text-white rounded-sm border border-slate-100 transition-all active:scale-95"
              >
                Consult
              </button>
              <div className="flex items-center gap-2 border-l border-slate-100 pl-3">
                <Linkedin className="w-3 h-3 text-slate-300 hover:text-amber-600 cursor-pointer transition-colors" />
                <Mail className="w-3 h-3 text-slate-300 hover:text-amber-600 cursor-pointer transition-colors" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
      
      <p className="text-[8px] text-slate-400 text-center uppercase tracking-widest leading-relaxed px-4">
        Collaboration between registered IIA Architects and certified Structural Engineers.
      </p>
    </div>
  );
}
