import React, { useState, useEffect } from 'react';
import { Bell, BellRing, Check, Info, Loader2, Send, ShieldAlert, Smartphone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  requestNotificationPermission, 
  getNotificationPermission, 
  sendMilestoneNotification,
  getSubscribedProjectIds 
} from '../lib/notificationService';

interface SiteUpdateSubscriptionProps {
  projectId?: string;
  projectTitle?: string;
}

export default function SiteUpdateSubscription({
  projectId = 'crystal-point',
  projectTitle = 'Premier Project'
}: SiteUpdateSubscriptionProps) {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [loading, setLoading] = useState(false);
  const [permission, setPermission] = useState<string>('default');
  const [lastNotificationDetails, setLastNotificationDetails] = useState<{ title: string; body: string } | null>(null);

  useEffect(() => {
    setPermission(getNotificationPermission());
    const ids = getSubscribedProjectIds();
    setIsSubscribed(ids.includes(projectId));
  }, [projectId]);

  const toggleSubscription = async () => {
    setLoading(true);

    if (!isSubscribed) {
      const perm = await requestNotificationPermission();
      setPermission(perm);

      // Trigger Web Push Notification via Service Worker
      await sendMilestoneNotification({
        projectId,
        projectTitle,
        milestone: 'Subscribed to Push Alerts',
        date: new Date().toLocaleDateString()
      });

      setLastNotificationDetails({
        title: `Push Alerts Enabled: ${projectTitle}`,
        body: 'Your device is registered with the Service Worker to receive instant construction stage updates.'
      });

      setIsSubscribed(true);
      setShowNotification(true);
      setLoading(false);
      setTimeout(() => setShowNotification(false), 5000);
    } else {
      setIsSubscribed(false);
      setShowNotification(false);
      setLoading(false);
    }
  };

  const handleTestPush = async () => {
    await sendMilestoneNotification({
      projectId,
      projectTitle,
      milestone: 'Foundation Pouring & Curing Verified',
      date: new Date().toLocaleDateString()
    });

    setLastNotificationDetails({
      title: `🚨 Milestone Hit: ${projectTitle}`,
      body: 'Stage Update: "Foundation Pouring & Curing Verified" has been certified on-site!'
    });
    setShowNotification(true);
    setTimeout(() => setShowNotification(false), 5000);
  };

  return (
    <div className="relative">
      <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-lg ${isSubscribed ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'}`}>
               {isSubscribed ? <BellRing className="w-4 h-4 animate-bounce" /> : <Bell className="w-4 h-4" />}
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Service Worker Push Alerts
              </h4>
              <p className="text-[10px] text-slate-500 font-mono">
                Status: <strong className="uppercase text-amber-600">{permission}</strong>
              </p>
            </div>
          </div>
          
          <button 
            onClick={toggleSubscription}
            disabled={loading}
            className={`relative w-11 h-6 rounded-full transition-colors duration-300 ${
              isSubscribed ? 'bg-amber-600' : 'bg-slate-300'
            }`}
            id="site-update-sub-toggle"
          >
            <motion.div 
              animate={{ x: isSubscribed ? 22 : 2 }}
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
              className="absolute left-0 top-1 w-4 h-4 bg-white rounded-full shadow flex items-center justify-center"
            >
              {loading && <Loader2 className="w-2.5 h-2.5 animate-spin text-amber-600" />}
              {!loading && isSubscribed && <Check className="w-2.5 h-2.5 text-amber-600" />}
            </motion.div>
          </button>
        </div>

        <p className="text-[11px] text-slate-600 leading-relaxed">
          Enable background push notifications to receive real-time alerts on your device whenever this project completes a construction milestone.
        </p>

        {isSubscribed && (
          <div className="space-y-2 pt-1 border-t border-slate-100">
            <div className="flex items-start gap-2 bg-emerald-50 p-2 rounded border border-emerald-200">
               <Info className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
               <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider leading-tight">
                 Subscribed to milestone push broadcasts
               </span>
            </div>

            <button
              onClick={handleTestPush}
              className="w-full py-1.5 px-3 bg-slate-900 hover:bg-slate-800 text-white text-[10px] font-bold uppercase tracking-wider rounded flex items-center justify-center gap-1.5 transition-colors"
            >
              <Send className="w-3 h-3 text-amber-400" />
              <span>Test Service Worker Push Alert</span>
            </button>
          </div>
        )}
      </div>

      {/* Real-time In-App Push Toast */}
      <AnimatePresence>
        {showNotification && lastNotificationDetails && (
          <motion.div 
            initial={{ opacity: 0, x: 200, scale: 0.85 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 200, scale: 0.85 }}
            className="fixed bottom-6 right-6 z-[1000] max-w-[340px] bg-slate-950 text-white rounded-xl shadow-2xl p-4 border border-amber-500/30 overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-amber-500 animate-pulse" />
            <div className="flex gap-3">
               <div className="w-10 h-10 bg-amber-500/20 rounded-xl flex items-center justify-center flex-shrink-0 border border-amber-500/30">
                  <BellRing className="w-5 h-5 text-amber-400" />
               </div>
               <div>
                  <div className="flex items-center justify-between gap-2 mb-0.5">
                    <span className="text-[9px] font-mono uppercase text-amber-400 font-bold">Service Worker Alert</span>
                    <span className="text-[8px] text-slate-400">Just now</span>
                  </div>
                  <h5 className="text-xs font-bold text-white mb-1">{lastNotificationDetails.title}</h5>
                  <p className="text-[11px] text-slate-300 leading-normal">{lastNotificationDetails.body}</p>
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
