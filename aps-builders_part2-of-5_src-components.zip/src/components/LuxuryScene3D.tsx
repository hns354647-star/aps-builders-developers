import React, { useRef, useState, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, ContactShadows, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { 
  Sparkles, 
  Rotate3d, 
  Eye, 
  Sun, 
  Moon, 
  Layers, 
  Maximize2, 
  Minimize2, 
  Compass, 
  Info,
  CheckCircle2,
  X
} from 'lucide-react';

export type ModelType = 'tower' | 'villa' | 'penthouse';
export type ShadingMode = 'golden' | 'cyber' | 'blueprint' | 'studio';

interface HotspotData {
  id: string;
  name: string;
  level: string;
  description: string;
  pos: [number, number, number];
}

const TOWER_HOTSPOTS: HotspotData[] = [
  {
    id: 't-crown',
    name: 'Helipad & Celestial Lounge',
    level: 'Level 48 · 185m',
    description: 'Private cantilever sky deck with panoramic Arabian Sea views and dedicated helipad.',
    pos: [0, 3.4, 0]
  },
  {
    id: 't-pool',
    name: 'Cantilever Glass Infinity Pool',
    level: 'Level 34 · 130m',
    description: 'Suspended acrylic glass plunge pool with zero-edge water spillover.',
    pos: [1.2, 1.2, 0.8]
  },
  {
    id: 't-garden',
    name: 'Biophilic Sky Gardens',
    level: 'Level 20 · 76m',
    description: 'Double-height hanging botanical gardens with native Kerala flora and micro-climate control.',
    pos: [-1.1, -0.2, 0.8]
  },
  {
    id: 't-atrium',
    name: 'Grand Italian Travertine Atrium',
    level: 'Ground Level',
    description: '14-meter vaulted lobby with private high-speed elevators and concierge gallery.',
    pos: [0, -2.2, 1.2]
  }
];

const VILLA_HOTSPOTS: HotspotData[] = [
  {
    id: 'v-water',
    name: 'Private Lagoon Waterfront Deck',
    level: 'Ground Deck',
    description: 'Marine-grade teak boardwalk with direct yacht berthing and Vembanad Lake frontage.',
    pos: [1.4, -0.4, 1.2]
  },
  {
    id: 'v-suite',
    name: 'Cantilever Master Glass Suite',
    level: 'First Floor',
    description: 'Triple-glazed acoustic glass pavilion with motorized timber shading louvers.',
    pos: [0.6, 1.0, 0.2]
  },
  {
    id: 'v-courtyard',
    name: 'Rainwater Reflection Courtyard',
    level: 'Central Atrium',
    description: 'Traditional Kerala Nalukettu-inspired open-to-sky courtyard with reflection basin.',
    pos: [-0.9, 0.2, -0.2]
  }
];

const PENTHOUSE_HOTSPOTS: HotspotData[] = [
  {
    id: 'p-dome',
    name: 'Stargazing Solarium Geodesic Dome',
    level: 'Upper Solarium',
    description: 'Acoustic smart-glass dome with 360-degree skyline visibility and automated tinting.',
    pos: [-0.8, 1.4, 0]
  },
  {
    id: 'p-plunge',
    name: 'Sky Plunge Pool & Sun Terrace',
    level: 'Crown Deck',
    description: 'Heated infinity plunge pool surrounded by volcanic stone sunbeds.',
    pos: [0.8, 0.4, 0]
  },
  {
    id: 'p-rings',
    name: 'Kinetic Gold Architectural Halo',
    level: 'Apex Feature',
    description: 'Signature 24k brushed gold kinetic architectural ring with integrated night illumination.',
    pos: [0, 1.8, 0]
  }
];

// Interactive 3D Hotspot Pin Mesh
function HotspotMarker({
  hotspot,
  isActive,
  onClick,
  shadingMode
}: {
  hotspot: HotspotData;
  isActive: boolean;
  onClick: () => void;
  shadingMode: ShadingMode;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const ringRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (meshRef.current) {
      const scale = isActive ? 1.4 + Math.sin(t * 5) * 0.15 : 1 + Math.sin(t * 3) * 0.1;
      meshRef.current.scale.set(scale, scale, scale);
    }
    if (ringRef.current) {
      ringRef.current.rotation.z = t * 2;
      const s = 1 + Math.sin(t * 2) * 0.25;
      ringRef.current.scale.set(s, s, s);
    }
  });

  const pinColor = shadingMode === 'blueprint' 
    ? '#06b6d4' 
    : shadingMode === 'cyber' 
    ? '#38bdf8' 
    : '#f59e0b';

  return (
    <group position={hotspot.pos} onClick={(e) => { e.stopPropagation(); onClick(); }}>
      {/* Outer Pulse Ring */}
      <mesh ref={ringRef} rotation={[Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.18, 0.24, 32]} />
        <meshBasicMaterial 
          color={pinColor} 
          side={THREE.DoubleSide} 
          transparent 
          opacity={isActive ? 0.9 : 0.5} 
        />
      </mesh>

      {/* Core Glowing Sphere */}
      <mesh ref={meshRef}>
        <sphereGeometry args={[0.12, 16, 16]} />
        <meshStandardMaterial
          color={isActive ? '#ffffff' : pinColor}
          emissive={pinColor}
          emissiveIntensity={isActive ? 1.8 : 0.8}
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>
    </group>
  );
}

// 🏢 3D THE ZENITH SKY SPIRE (High-Tech Parametric Glass Tower)
function ZenithTowerModel({
  exploded,
  shadingMode,
  activeHotspot,
  onSelectHotspot
}: {
  exploded: boolean;
  shadingMode: ShadingMode;
  activeHotspot: HotspotData | null;
  onSelectHotspot: (h: HotspotData) => void;
}) {
  const groupRef = useRef<THREE.Group>(null);
  const crownRef = useRef<THREE.Mesh>(null);
  const haloRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (groupRef.current && !exploded) {
      groupRef.current.rotation.y = t * 0.12;
    }
    if (crownRef.current) {
      crownRef.current.rotation.y = -t * 0.3;
    }
    if (haloRef.current) {
      haloRef.current.rotation.x = Math.sin(t * 0.5) * 0.2;
      haloRef.current.rotation.y = t * 0.4;
    }
  });

  const floors = useMemo(() => {
    const list = [];
    for (let i = 0; i < 11; i++) {
      list.push({
        idx: i,
        baseY: (i - 5) * 0.55,
        scale: 1 - i * 0.038,
        rot: (i * Math.PI) / 14,
      });
    }
    return list;
  }, []);

  const isWireframe = shadingMode === 'blueprint';
  const isCyber = shadingMode === 'cyber';
  const isStudio = shadingMode === 'studio';

  const coreColor = isWireframe ? '#0891b2' : isCyber ? '#030712' : isStudio ? '#f8fafc' : '#0f172a';
  const edgeColor = isWireframe ? '#06b6d4' : isCyber ? '#38bdf8' : isStudio ? '#d4af37' : '#f59e0b';
  const glassColor = isWireframe ? '#22d3ee' : isCyber ? '#0284c7' : isStudio ? '#e2e8f0' : '#38bdf8';

  return (
    <group ref={groupRef} position={[0, -0.2, 0]}>
      {/* Central Structural Core */}
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[0.5, 0.7, 6.2, 12]} />
        <meshPhysicalMaterial
          color={coreColor}
          roughness={isWireframe ? 0.9 : 0.15}
          metalness={isWireframe ? 0 : 0.9}
          transmission={isWireframe ? 0 : 0.5}
          wireframe={isWireframe}
        />
      </mesh>

      {/* Floating Floor Slabs with Exploded Axonometric Interpolation */}
      {floors.map((floor) => {
        const explodeOffset = exploded ? (floor.idx - 5) * 0.45 : 0;
        const currentY = floor.baseY + explodeOffset;

        return (
          <group 
            key={floor.idx} 
            position={[0, currentY, 0]} 
            rotation={[0, floor.rot, 0]} 
            scale={floor.scale}
          >
            {/* Main Concrete/Ceramic Slab */}
            <mesh>
              <boxGeometry args={[2.3, 0.07, 2.3]} />
              <meshStandardMaterial
                color={coreColor}
                metalness={isStudio ? 0.2 : 0.8}
                roughness={0.25}
                wireframe={isWireframe}
              />
            </mesh>

            {/* Glowing Architectural Edge Band */}
            <mesh position={[0, 0.035, 0]}>
              <boxGeometry args={[2.32, 0.02, 2.32]} />
              <meshStandardMaterial
                color={edgeColor}
                emissive={edgeColor}
                emissiveIntensity={isCyber ? 1.5 : isWireframe ? 1.2 : 0.4}
                metalness={1}
                roughness={0.1}
              />
            </mesh>

            {/* Cantilever Sky Balconies & Terraces */}
            {floor.idx % 2 === 0 && (
              <mesh position={[0.75, 0.12, 0.75]}>
                <boxGeometry args={[0.95, 0.16, 0.95]} />
                <meshPhysicalMaterial
                  color={glassColor}
                  transmission={isWireframe ? 0 : 0.8}
                  transparent
                  opacity={0.8}
                  roughness={0.05}
                  wireframe={isWireframe}
                />
              </mesh>
            )}

            {/* Glass Guardrails */}
            {!isWireframe && (
              <mesh position={[0, 0.12, 1.15]}>
                <boxGeometry args={[2.25, 0.16, 0.02]} />
                <meshPhysicalMaterial
                  color="#ffffff"
                  transmission={0.9}
                  roughness={0.02}
                  transparent
                  opacity={0.7}
                />
              </mesh>
            )}
          </group>
        );
      })}

      {/* Apex Celestial Spire & Helipad */}
      <group position={[0, exploded ? 5.2 : 3.4, 0]}>
        <mesh ref={crownRef}>
          <octahedronGeometry args={[0.5, 0]} />
          <meshStandardMaterial
            color={edgeColor}
            emissive={edgeColor}
            emissiveIntensity={0.8}
            metalness={1}
            roughness={0.1}
            wireframe={isWireframe}
          />
        </mesh>

        {/* Halo Beacon Ring */}
        <mesh ref={haloRef} rotation={[Math.PI / 4, 0, 0]}>
          <torusGeometry args={[0.85, 0.03, 16, 48]} />
          <meshStandardMaterial
            color={edgeColor}
            emissive={edgeColor}
            emissiveIntensity={1.2}
            metalness={1}
          />
        </mesh>
      </group>

      {/* 3D Hotspots on Tower */}
      {TOWER_HOTSPOTS.map((hotspot) => (
        <HotspotMarker
          key={hotspot.id}
          hotspot={hotspot}
          isActive={activeHotspot?.id === hotspot.id}
          onClick={() => onSelectHotspot(hotspot)}
          shadingMode={shadingMode}
        />
      ))}
    </group>
  );
}

// 🏖️ 3D VEMBANAD SOVEREIGN VILLA (Tropical Modern Waterfront Pavilion)
function VembanadVillaModel({
  exploded,
  shadingMode,
  activeHotspot,
  onSelectHotspot
}: {
  exploded: boolean;
  shadingMode: ShadingMode;
  activeHotspot: HotspotData | null;
  onSelectHotspot: (h: HotspotData) => void;
}) {
  const groupRef = useRef<THREE.Group>(null);
  const waterRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (groupRef.current && !exploded) {
      groupRef.current.rotation.y = Math.sin(t * 0.25) * 0.2 + (t * 0.06);
    }
    if (waterRef.current) {
      const mat = waterRef.current.material as THREE.MeshStandardMaterial;
      if (mat) {
        mat.roughness = 0.05 + Math.sin(t * 2) * 0.02;
      }
    }
  });

  const isWireframe = shadingMode === 'blueprint';
  const isCyber = shadingMode === 'cyber';
  const isStudio = shadingMode === 'studio';

  const stoneColor = isWireframe ? '#0e7490' : isCyber ? '#111827' : isStudio ? '#e2e8f0' : '#1e2230';
  const woodColor = isWireframe ? '#06b6d4' : isCyber ? '#1e293b' : isStudio ? '#d4af37' : '#92400e';
  const waterColor = isWireframe ? '#22d3ee' : isCyber ? '#0284c7' : '#0284c7';

  const roofY = exploded ? 2.6 : 1.35;
  const upperY = exploded ? 1.8 : 1.1;

  return (
    <group ref={groupRef} position={[0, -0.4, 0]}>
      {/* Stone Foundation Plinth */}
      <mesh position={[0, -0.25, 0]}>
        <boxGeometry args={[4.2, 0.35, 3.4]} />
        <meshStandardMaterial 
          color={stoneColor} 
          roughness={0.7} 
          metalness={0.2} 
          wireframe={isWireframe} 
        />
      </mesh>

      {/* Waterfront Wooden Deck */}
      <mesh position={[0.9, -0.04, 0.7]}>
        <boxGeometry args={[2.4, 0.08, 1.8]} />
        <meshStandardMaterial 
          color={woodColor} 
          roughness={0.6} 
          metalness={0.1}
          wireframe={isWireframe} 
        />
      </mesh>

      {/* Infinity Reflection Basin */}
      <mesh ref={waterRef} position={[1.0, -0.01, 1.55]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[2.0, 1.0]} />
        <meshStandardMaterial
          color={waterColor}
          metalness={0.9}
          roughness={0.05}
          wireframe={isWireframe}
        />
      </mesh>

      {/* Ground Glass Pavilion */}
      <mesh position={[-0.9, 0.5, -0.2]}>
        <boxGeometry args={[1.8, 1.15, 2.0]} />
        <meshStandardMaterial 
          color={stoneColor} 
          roughness={0.2} 
          metalness={0.7} 
          wireframe={isWireframe} 
        />
      </mesh>

      {/* Double Height Glass Wall */}
      <mesh position={[-0.9, 0.5, 0.82]}>
        <planeGeometry args={[1.7, 1.05]} />
        <meshPhysicalMaterial
          color="#93c5fd"
          transmission={isWireframe ? 0 : 0.85}
          transparent
          opacity={0.85}
          roughness={0.04}
          wireframe={isWireframe}
        />
      </mesh>

      {/* Second Floor Cantilever Master Suite (Elevates in Exploded Mode) */}
      <group position={[0.4, upperY, -0.2]}>
        <mesh>
          <boxGeometry args={[2.4, 0.95, 1.8]} />
          <meshStandardMaterial 
            color={stoneColor} 
            roughness={0.3} 
            metalness={0.6} 
            wireframe={isWireframe} 
          />
        </mesh>

        {/* Architectural Teak Louvers */}
        {!isWireframe && (
          <group position={[0, 0, 0.92]}>
            {[-0.8, -0.4, 0, 0.4, 0.8].map((x, i) => (
              <mesh key={i} position={[x, 0, 0]}>
                <boxGeometry args={[0.05, 0.85, 0.08]} />
                <meshStandardMaterial color={woodColor} roughness={0.4} />
              </mesh>
            ))}
          </group>
        )}
      </group>

      {/* Modern Kerala Sloped Overhanging Canopy Roof */}
      <group position={[-0.9, roofY, -0.2]}>
        <mesh rotation={[0, 0, 0]}>
          <coneGeometry args={[1.6, 0.6, 4]} />
          <meshStandardMaterial 
            color={woodColor} 
            roughness={0.5} 
            wireframe={isWireframe} 
          />
        </mesh>
      </group>

      {/* 3D Hotspots on Villa */}
      {VILLA_HOTSPOTS.map((hotspot) => (
        <HotspotMarker
          key={hotspot.id}
          hotspot={hotspot}
          isActive={activeHotspot?.id === hotspot.id}
          onClick={() => onSelectHotspot(hotspot)}
          shadingMode={shadingMode}
        />
      ))}
    </group>
  );
}

// 👑 3D THE CROWN SKY PENTHOUSE & SOLARIUM
function CrownPenthouseModel({
  exploded,
  shadingMode,
  activeHotspot,
  onSelectHotspot
}: {
  exploded: boolean;
  shadingMode: ShadingMode;
  activeHotspot: HotspotData | null;
  onSelectHotspot: (h: HotspotData) => void;
}) {
  const groupRef = useRef<THREE.Group>(null);
  const ringRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (groupRef.current && !exploded) {
      groupRef.current.rotation.y = t * 0.15;
    }
    if (ringRef.current) {
      ringRef.current.rotation.x = t * 0.2;
      ringRef.current.rotation.z = Math.sin(t * 0.4) * 0.3;
    }
  });

  const isWireframe = shadingMode === 'blueprint';
  const isCyber = shadingMode === 'cyber';
  const isStudio = shadingMode === 'studio';

  const baseColor = isWireframe ? '#0369a1' : isCyber ? '#030712' : isStudio ? '#f1f5f9' : '#111827';
  const goldColor = isWireframe ? '#38bdf8' : isCyber ? '#0284c7' : '#f59e0b';
  const domeY = exploded ? 2.4 : 1.4;

  return (
    <group ref={groupRef} position={[0, -0.2, 0]}>
      {/* Sky Terrace Circular Platform */}
      <mesh position={[0, -0.3, 0]}>
        <cylinderGeometry args={[2.5, 2.5, 0.25, 32]} />
        <meshStandardMaterial 
          color={baseColor} 
          roughness={0.3} 
          metalness={0.8} 
          wireframe={isWireframe} 
        />
      </mesh>

      {/* 24k Gold Trim Ring */}
      <mesh position={[0, -0.16, 0]}>
        <torusGeometry args={[2.52, 0.04, 16, 64]} />
        <meshStandardMaterial 
          color={goldColor} 
          metalness={1} 
          roughness={0.1} 
        />
      </mesh>

      {/* Cantilever Circular Glass Plunge Pool */}
      <mesh position={[0.85, 0.35, 0]}>
        <cylinderGeometry args={[0.95, 0.95, 0.65, 24]} />
        <meshPhysicalMaterial
          color="#0284c7"
          transmission={isWireframe ? 0 : 0.85}
          roughness={0.03}
          transparent
          opacity={0.85}
          wireframe={isWireframe}
        />
      </mesh>

      {/* Architectural Duplex Living Pavilion */}
      <mesh position={[-0.8, 0.65, 0]}>
        <boxGeometry args={[1.7, 1.45, 1.7]} />
        <meshStandardMaterial 
          color={baseColor} 
          metalness={0.8} 
          roughness={0.2} 
          wireframe={isWireframe} 
        />
      </mesh>

      {/* Stargazing Geodesic Glass Dome (Elevates in Exploded Mode) */}
      <mesh position={[-0.8, domeY, 0]}>
        <sphereGeometry args={[0.8, 24, 24, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshPhysicalMaterial
          color={goldColor}
          transmission={isWireframe ? 0 : 0.9}
          roughness={0.02}
          reflectivity={1}
          clearcoat={1}
          wireframe={isWireframe}
        />
      </mesh>

      {/* Kinetic Golden Rings of Saturn Halo */}
      <mesh ref={ringRef} position={[0, exploded ? 3.0 : 1.9, 0]}>
        <torusGeometry args={[1.2, 0.04, 16, 48]} />
        <meshStandardMaterial 
          color={goldColor} 
          emissive={goldColor}
          emissiveIntensity={0.6}
          metalness={1} 
          roughness={0.1} 
        />
      </mesh>

      {/* Floating Geometric Apex Crystal */}
      <Float speed={2} rotationIntensity={1} floatIntensity={1.2}>
        <mesh position={[0, exploded ? 3.6 : 2.5, 0]}>
          <icosahedronGeometry args={[0.3, 0]} />
          <meshStandardMaterial 
            color={goldColor} 
            metalness={1} 
            roughness={0.15} 
            wireframe={isWireframe}
          />
        </mesh>
      </Float>

      {/* 3D Hotspots on Penthouse */}
      {PENTHOUSE_HOTSPOTS.map((hotspot) => (
        <HotspotMarker
          key={hotspot.id}
          hotspot={hotspot}
          isActive={activeHotspot?.id === hotspot.id}
          onClick={() => onSelectHotspot(hotspot)}
          shadingMode={shadingMode}
        />
      ))}
    </group>
  );
}

// 🌌 Ambient Luxury Particle Atmosphere
function SceneAtmosphere({ shadingMode }: { shadingMode: ShadingMode }) {
  const pointsRef = useRef<THREE.Points>(null);
  const count = 90;

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 10;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 8;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 8;
    }
    return pos;
  }, []);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (pointsRef.current) {
      pointsRef.current.rotation.y = t * 0.04;
      pointsRef.current.rotation.x = Math.sin(t * 0.03) * 0.08;
    }
  });

  const pColor = shadingMode === 'blueprint' 
    ? '#06b6d4' 
    : shadingMode === 'cyber' 
    ? '#38bdf8' 
    : '#fde047';

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.06}
        color={pColor}
        transparent
        opacity={0.65}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

// 📐 Grid Floor for Blueprint Mode
function BlueprintGrid() {
  return (
    <gridHelper 
      args={[14, 28, '#0891b2', '#164e63']} 
      position={[0, -2.1, 0]} 
    />
  );
}

// MAIN EXPORT: Next-Gen 3D Interactive Template
export default function LuxuryScene3D({
  modelType: initialModel = 'tower',
  interactive = true,
  className = 'w-full h-full min-h-[440px]'
}: {
  modelType?: ModelType;
  interactive?: boolean;
  className?: string;
}) {
  const [modelType, setModelType] = useState<ModelType>(initialModel);
  const [shadingMode, setShadingMode] = useState<ShadingMode>('golden');
  const [exploded, setExploded] = useState(false);
  const [autoRotate, setAutoRotate] = useState(true);
  const [activeHotspot, setActiveHotspot] = useState<HotspotData | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen();
      }
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
      setIsFullscreen(false);
    }
  };

  return (
    <div 
      ref={containerRef}
      className={`relative rounded-3xl overflow-hidden border border-[#c5a059]/30 bg-[#07090e] shadow-2xl transition-all ${className} ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none h-screen' : ''
      }`}
    >
      {/* 🌟 TOP 3D CONTROLLER DOCK */}
      <div className="absolute top-4 left-4 right-4 z-20 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
        {/* Model Switcher Pills */}
        <div className="flex items-center gap-1.5 p-1.5 rounded-full bg-[#0a0d14]/85 backdrop-blur-xl border border-[#c5a059]/30 shadow-lg pointer-events-auto">
          <button
            onClick={() => { setModelType('tower'); setActiveHotspot(null); }}
            className={`px-3.5 py-1.5 rounded-full text-xs font-serif uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer ${
              modelType === 'tower'
                ? 'bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-stone-950 font-bold shadow-md shadow-[#d4af37]/30'
                : 'text-stone-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <span>Zenith Spire</span>
          </button>

          <button
            onClick={() => { setModelType('villa'); setActiveHotspot(null); }}
            className={`px-3.5 py-1.5 rounded-full text-xs font-serif uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer ${
              modelType === 'villa'
                ? 'bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-stone-950 font-bold shadow-md shadow-[#d4af37]/30'
                : 'text-stone-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <span>Waterfront Villa</span>
          </button>

          <button
            onClick={() => { setModelType('penthouse'); setActiveHotspot(null); }}
            className={`px-3.5 py-1.5 rounded-full text-xs font-serif uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer ${
              modelType === 'penthouse'
                ? 'bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-stone-950 font-bold shadow-md shadow-[#d4af37]/30'
                : 'text-stone-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <span>Crown Solarium</span>
          </button>
        </div>

        {/* Shading & View Presets */}
        <div className="flex items-center gap-1.5 p-1.5 rounded-full bg-[#0a0d14]/85 backdrop-blur-xl border border-[#c5a059]/30 shadow-lg pointer-events-auto">
          {/* Golden Hour */}
          <button
            onClick={() => setShadingMode('golden')}
            className={`p-2 rounded-full text-xs transition-all cursor-pointer ${
              shadingMode === 'golden' ? 'bg-[#d4af37] text-stone-950 shadow-md' : 'text-stone-400 hover:text-white'
            }`}
            title="Golden Hour / Sunset Lighting"
          >
            <Sun className="w-3.5 h-3.5" />
          </button>

          {/* Midnight Cyber */}
          <button
            onClick={() => setShadingMode('cyber')}
            className={`p-2 rounded-full text-xs transition-all cursor-pointer ${
              shadingMode === 'cyber' ? 'bg-sky-500 text-stone-950 shadow-md' : 'text-stone-400 hover:text-white'
            }`}
            title="Midnight Cyber-Onyx Lighting"
          >
            <Moon className="w-3.5 h-3.5" />
          </button>

          {/* Blueprint X-Ray */}
          <button
            onClick={() => setShadingMode('blueprint')}
            className={`p-2 rounded-full text-xs transition-all cursor-pointer ${
              shadingMode === 'blueprint' ? 'bg-cyan-500 text-stone-950 shadow-md' : 'text-stone-400 hover:text-white'
            }`}
            title="Holographic Blueprint Wireframe"
          >
            <Layers className="w-3.5 h-3.5" />
          </button>

          {/* Studio White Clay */}
          <button
            onClick={() => setShadingMode('studio')}
            className={`p-2 rounded-full text-xs transition-all cursor-pointer ${
              shadingMode === 'studio' ? 'bg-stone-100 text-stone-950 shadow-md' : 'text-stone-400 hover:text-white'
            }`}
            title="Studio White Clay & Gold"
          >
            <Sparkles className="w-3.5 h-3.5" />
          </button>

          <div className="w-px h-4 bg-stone-700 mx-0.5" />

          {/* Exploded Mode */}
          <button
            onClick={() => setExploded(!exploded)}
            className={`px-2.5 py-1 rounded-full text-[11px] font-serif uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer ${
              exploded ? 'bg-amber-400/20 text-amber-300 border border-amber-400/50' : 'text-stone-400 hover:text-white'
            }`}
            title="Toggle Exploded Axonometric Architecture"
          >
            <span>{exploded ? 'Collapsed' : 'Explode 3D'}</span>
          </button>

          {/* Auto Rotate */}
          <button
            onClick={() => setAutoRotate(!autoRotate)}
            className={`p-2 rounded-full text-xs transition-all cursor-pointer ${
              autoRotate ? 'text-amber-400' : 'text-stone-500 hover:text-stone-300'
            }`}
            title="Toggle Auto Orbit"
          >
            <Rotate3d className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin' : ''}`} style={{ animationDuration: '8s' }} />
          </button>

          {/* Fullscreen */}
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-full text-xs text-stone-400 hover:text-white transition-all cursor-pointer"
            title="Toggle Fullscreen 3D Viewport"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* 🧭 BOTTOM ARCHITECTURAL HUD METRICS */}
      <div className="absolute bottom-4 left-4 right-4 z-20 flex flex-wrap items-end justify-between gap-3 pointer-events-none">
        {/* Model Spec Badge */}
        <div className="p-3 rounded-2xl bg-[#0a0d14]/85 backdrop-blur-xl border border-[#c5a059]/25 shadow-xl max-w-sm pointer-events-auto">
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-[#d4af37]">
              APS-MODEL // {modelType.toUpperCase()}
            </span>
          </div>
          <p className="text-xs text-stone-200 font-serif font-light">
            {modelType === 'tower' && 'Marine Drive Glass Pinnacle · 48 Luxury Floors · Opening March 2027'}
            {modelType === 'villa' && 'Kumarakom Sovereign Waterfront Sanctuary · Private Yacht Jetty'}
            {modelType === 'penthouse' && 'Panampilly Nagar Crown Sky Solarium · Double Height Glass Dome'}
          </p>
          <div className="flex items-center gap-3 mt-2 text-[10px] text-stone-400 font-mono">
            <span>AZIMUTH: 42.8°</span>
            <span>·</span>
            <span>ELEV: +14.2°</span>
            <span>·</span>
            <span className="text-amber-300">CLICK PINS TO INSPECT</span>
          </div>
        </div>

        {/* Hotspot Floating Detail Glass Card (if selected) */}
        {activeHotspot && (
          <div className="p-4 rounded-2xl bg-[#0c101a]/95 backdrop-blur-2xl border border-amber-400/50 shadow-2xl max-w-sm pointer-events-auto animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex items-start justify-between gap-2 mb-1.5">
              <div className="flex items-center gap-1.5 text-[#f3e5ab]">
                <Info className="w-4 h-4 text-amber-400" />
                <h4 className="font-serif font-bold text-sm tracking-wide text-white">
                  {activeHotspot.name}
                </h4>
              </div>
              <button 
                onClick={() => setActiveHotspot(null)}
                className="text-stone-400 hover:text-white cursor-pointer p-0.5"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="text-[11px] font-mono text-amber-300/80 mb-1.5 uppercase">
              {activeHotspot.level}
            </div>
            <p className="text-xs text-stone-300 font-serif leading-relaxed">
              {activeHotspot.description}
            </p>
          </div>
        )}
      </div>

      {/* 🎨 3D WEBGL CANVAS */}
      <Canvas
        camera={{ position: [0, 1.6, 6.5], fov: 45 }}
        gl={{ antialias: true, alpha: true }}
      >
        {/* Dynamic Lighting per Shading Mode */}
        {shadingMode === 'golden' && (
          <>
            <ambientLight intensity={0.9} />
            <directionalLight position={[7, 9, 6]} intensity={1.8} color="#fed7aa" />
            <directionalLight position={[-7, -2, -5]} intensity={0.6} color="#93c5fd" />
            <pointLight position={[0, 2, 3]} intensity={1.5} color="#fbbf24" />
          </>
        )}

        {shadingMode === 'cyber' && (
          <>
            <ambientLight intensity={0.5} />
            <directionalLight position={[6, 8, 5]} intensity={1.2} color="#38bdf8" />
            <directionalLight position={[-6, -4, -4]} intensity={1.0} color="#a855f7" />
            <pointLight position={[0, 3, 2]} intensity={2.0} color="#38bdf8" />
          </>
        )}

        {shadingMode === 'blueprint' && (
          <>
            <ambientLight intensity={1.2} />
            <directionalLight position={[5, 10, 5]} intensity={1.5} color="#22d3ee" />
            <BlueprintGrid />
          </>
        )}

        {shadingMode === 'studio' && (
          <>
            <ambientLight intensity={1.4} />
            <directionalLight position={[8, 12, 6]} intensity={2.0} color="#ffffff" />
            <directionalLight position={[-8, 6, -6]} intensity={1.0} color="#fef08a" />
          </>
        )}

        <SceneAtmosphere shadingMode={shadingMode} />

        <Float speed={exploded ? 0 : 1.2} rotationIntensity={exploded ? 0 : 0.15} floatIntensity={exploded ? 0 : 0.3}>
          {modelType === 'tower' && (
            <ZenithTowerModel 
              exploded={exploded} 
              shadingMode={shadingMode}
              activeHotspot={activeHotspot}
              onSelectHotspot={(h) => setActiveHotspot(h)}
            />
          )}
          {modelType === 'villa' && (
            <VembanadVillaModel 
              exploded={exploded} 
              shadingMode={shadingMode}
              activeHotspot={activeHotspot}
              onSelectHotspot={(h) => setActiveHotspot(h)}
            />
          )}
          {modelType === 'penthouse' && (
            <CrownPenthouseModel 
              exploded={exploded} 
              shadingMode={shadingMode}
              activeHotspot={activeHotspot}
              onSelectHotspot={(h) => setActiveHotspot(h)}
            />
          )}
        </Float>

        <ContactShadows
          position={[0, -2.1, 0]}
          opacity={0.6}
          scale={12}
          blur={2.5}
          far={4.5}
          color={shadingMode === 'blueprint' ? '#0891b2' : shadingMode === 'cyber' ? '#0369a1' : '#d4af37'}
        />

        {interactive && (
          <OrbitControls
            enableZoom={true}
            enablePan={false}
            autoRotate={autoRotate && !activeHotspot}
            autoRotateSpeed={0.9}
            maxPolarAngle={Math.PI / 2 + 0.1}
            minPolarAngle={Math.PI / 5}
            minDistance={4}
            maxDistance={11}
          />
        )}
      </Canvas>
    </div>
  );
}
