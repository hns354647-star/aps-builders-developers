import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, X, Send, Bot } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

interface MascotChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MascotChatModal: React.FC<MascotChatModalProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();
  const [messages, setMessages] = useState<Array<{ sender: 'bo' | 'user'; text: string }>>([]);
  const [inputValue, setInputValue] = useState('');

  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{ sender: 'bo', text: t.mascotChat.initialMessage }]);
    }
  }, [t]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const userText = inputValue;
    setMessages((prev) => [...prev, { sender: 'user', text: userText }]);
    setInputValue('');

    // Responsive mascot reply
    setTimeout(() => {
      const lower = userText.toLowerCase();
      let reply = "Ik vind dat een uitstekende vraag! Onze studio combineert Next.js 14, Three.js shaders en vloeibare GSAP animaties. Wil je een vrijblijvende call inplannen met Lars of Emma?";
      
      if (lower.includes('prijs') || lower.includes('kosten') || lower.includes('tarief') || lower.includes('price') || lower.includes('pricing') || lower.includes('cost')) {
        reply = "Onze tarieven zijn transparant: een Sprint Partnership kost € 4.850 per 2 weken, of kies voor onze Studio Retainer van € 8.950 per maand met onbeperkte aanvragen!";
      } else if (lower.includes('tech') || lower.includes('stack') || lower.includes('three') || lower.includes('webgl') || lower.includes('r3f')) {
        reply = "We draaien op Next.js 14 App Router, React Three Fiber, Three.js, GSAP ScrollTrigger en Lenis. Alles geoptimaliseerd voor 60FPS op mobiel en desktop!";
      } else if (lower.includes('wie') || lower.includes('who') || lower.includes('bo') || lower.includes('mascot')) {
        reply = "Ik ben Bo! Een vriendelijke betonnen kubus met een oranje sjaal. Ik zwaai naar bezoekers en bewaak onze 60 frames per seconde.";
      }

      setMessages((prev) => [...prev, { sender: 'bo', text: reply }]);
    }, 600);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md"
        >
          <motion.div
            initial={{ scale: 0.92, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.92, y: 20 }}
            className="bg-[#151c17] border border-white/20 rounded-3xl max-w-md w-full overflow-hidden shadow-2xl text-white flex flex-col h-[520px]"
          >
            {/* Header */}
            <div className="p-4 px-6 bg-white/5 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#ff6a1a] flex items-center justify-center text-white shadow-md">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-white flex items-center gap-2">
                    <span>{t.mascotChat.title}</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  </h4>
                  <p className="text-[10px] text-stone-400 font-mono">
                    {t.mascotChat.status}
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-full hover:bg-white/10 text-stone-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Messages Body */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs leading-relaxed">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[82%] p-3.5 rounded-2xl ${
                      m.sender === 'user'
                        ? 'bg-[#ff6a1a] text-white rounded-br-none'
                        : 'bg-white/10 text-stone-200 border border-white/10 rounded-bl-none'
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              ))}
            </div>

            {/* Input Bar */}
            <form onSubmit={handleSend} className="p-3 border-t border-white/10 bg-white/5 flex items-center gap-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder={t.mascotChat.placeholder}
                className="flex-1 bg-black/40 border border-white/15 rounded-xl px-4 py-2.5 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-[#ff6a1a]"
              />
              <button
                type="submit"
                className="p-2.5 rounded-xl bg-[#ff6a1a] hover:bg-[#ff7e36] text-white transition-colors cursor-pointer shadow-md"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
