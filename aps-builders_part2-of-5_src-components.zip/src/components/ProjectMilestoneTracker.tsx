import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Check, 
  Clock, 
  Calendar, 
  ChevronRight, 
  ShieldCheck, 
  Bell, 
  BellRing, 
  Sparkles, 
  Send, 
  CheckCircle2, 
  Volume2, 
  AlertCircle 
} from 'lucide-react';
import { ProjectMilestone } from '../data/projects';
import { 
  isProjectSubscribed, 
  toggleProjectSubscription, 
  sendMilestoneNotification, 
  requestNotificationPermission,
  getNotificationPermission 
} from '../lib/notificationService';

interface ProjectMilestoneTrackerProps {
  milestones: ProjectMilestone[];
  projectId?: string;
  projectTitle?: string;
  projectImage?: string;
}

export default function ProjectMilestoneTracker({ 
  milestones: initialMilestones, 
  projectId = 'general', 
  projectTitle = 'Premier Project',
  projectImage
}: ProjectMilestoneTrackerProps) {
  const [milestones, setMilestones] = useState<ProjectMilestone[]>(initialMilestones || []);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);
  const [lastAlertMessage, setLastAlertMessage] = useState<string | null>(null);
  const [permissionState, setPermissionState] = useState<string>('default');

  useEffect(() => {
    setMilestones(initialMilestones);
  }, [initialMilestones]);

  useEffect(() => {
    setIsSubscribed(isProjectSubscribed(projectId));
    setPermissionState(getNotificationPermission());

    const handleSubChange = (e: any) => {
      if (e.detail?.projectId === projectId) {
        setIsSubscribed(e.detail.isSubscribed);
      }
    };
    window.addEventListener('aps-subscription-changed', handleSubChange);
    return () => window.removeEventListener('aps-subscription-changed', handleSubChange);
  }, [projectId]);

  if (!milestones || milestones.length === 0) return null;

  const completedCount = milestones.filter(m => m.status === 'Completed').length;
  const progressPercent = (completedCount / milestones.length) * 100;

  // Toggle Push Alerts for this specific project
  const handleToggleSubscription = async () => {
    if (!isSubscribed) {
      const perm = await requestNotificationPermission();
      setPermissionState(perm);
      const subscribed = toggleProjectSubscription(projectId);
      setIsSubscribed(subscribed);

      if (subscribed) {
        // Send a welcome alert via service worker
        sendMilestoneNotification({
          projectId,
          projectTitle,
          milestone: 'Push Alerts Activated',
          image: projectImage,
          date: new Date().toLocaleDateString()
        });
        setLastAlertMessage(`Subscribed to live push alerts for ${projectTitle}`);
        setTimeout(() => setLastAlertMessage(null), 4000);
      }
    } else {
      const subscribed = toggleProjectSubscription(projectId);
      setIsSubscribed(subscribed);
      setLastAlertMessage(`Unsubscribed from alerts for ${projectTitle}`);
      setTimeout(() => setLastAlertMessage(null), 3000);
    }
  };

  // Simulate advancing to the next milestone and firing an actual Service Worker Push Notification
  const handleSimulateNextMilestone = async () => {
    setIsSimulating(true);

    // Find the first milestone that is In Progress or Pending
    const nextIdx = milestones.findIndex(m => m.status === 'In Progress' || m.status === 'Pending');
    const targetIdx = nextIdx !== -1 ? nextIdx : milestones.length - 1;
    const targetMilestone = milestones[targetIdx];

    const updatedMilestones = [...milestones];
    updatedMilestones[targetIdx] = {
      ...targetMilestone,
      status: 'Completed',
      date: `Completed ${new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`
    };

    // If there is a next one, mark it as In Progress
    if (targetIdx + 1 < updatedMilestones.length) {
      updatedMilestones[targetIdx + 1] = {
        ...updatedMilestones[targetIdx + 1],
        status: 'In Progress'
      };
    }

    setMilestones(updatedMilestones);

    // Trigger Service Worker Web Push Notification!
    await sendMilestoneNotification({
      projectId,
      projectTitle,
      milestone: targetMilestone.label,
      image: projectImage,
      date: new Date().toLocaleDateString()
    });

    setLastAlertMessage(`🎉 Push Notification Sent: "${targetMilestone.label}" marked complete!`);
    setTimeout(() => {
      setIsSimulating(false);
      setTimeout(() => setLastAlertMessage(null), 4000);
    }, 800);
  };

  return (
    <div className="space-y-6">
      {/* Header with Execution Roadmap & Push Alerts Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-3.5 rounded-lg border border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5 text-amber-600" />
            <h4 className="text-[11px] font-bold text-slate-900 uppercase tracking-widest">
              Execution Roadmap & Milestone Alerts
            </h4>
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">
            Real-time stage tracking with native service worker push notifications.
          </p>
        </div>

        {/* Subscription Toggle */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleToggleSubscription}
            className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-sm ${
              isSubscribed
                ? 'bg-amber-600 text-white shadow-amber-600/20'
                : 'bg-white text-slate-700 border border-slate-200 hover:border-amber-500 hover:text-amber-600'
            }`}
            id={`toggle-sub-${projectId}`}
          >
            {isSubscribed ? (
              <>
                <BellRing className="w-3 h-3 text-white animate-bounce" />
                <span>Alerts On</span>
              </>
            ) : (
              <>
                <Bell className="w-3 h-3 text-slate-400" />
                <span>Subscribe Alerts</span>
              </>
            )}
          </button>

          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest bg-white border border-slate-200 px-2.5 py-1 rounded-full">
            {completedCount} / {milestones.length} Done
          </span>
        </div>
      </div>

      {/* Subscription feedback banner */}
      <AnimatePresence>
        {lastAlertMessage && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="flex items-center gap-2 bg-amber-50 border border-amber-200 text-amber-900 text-xs px-3.5 py-2.5 rounded-lg font-medium shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-amber-600 shrink-0 animate-spin-slow" />
            <span className="flex-1">{lastAlertMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Visual Progress Bar */}
      <div className="space-y-2">
        <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200/60">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progressPercent}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="h-full bg-gradient-to-r from-amber-500 to-amber-600 rounded-full relative"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer" />
          </motion.div>
        </div>
        <div className="flex justify-between text-[9px] font-bold text-slate-400 uppercase tracking-widest">
          <span>Vision & Planning</span>
          <span className="text-amber-600 font-extrabold">Active Structural Build</span>
          <span>Final Handover</span>
        </div>
      </div>

      {/* Milestone List */}
      <div className="relative pt-2 overflow-hidden">
        {/* Animated Connection Line */}
        <motion.div 
          initial={{ scaleY: 0, originY: 0 }}
          animate={{ scaleY: 1 }}
          transition={{ duration: 0.7, ease: "easeInOut" }}
          className="absolute left-[11px] top-6 bottom-6 w-[2px] bg-slate-200" 
        />

        {/* Staggered Items Container */}
        <motion.div 
          className="space-y-5 relative"
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.12,
                delayChildren: 0.1
              }
            }
          }}
        >
          {milestones.map((milestone, idx) => {
            const isCompleted = milestone.status === 'Completed';
            const isProgress = milestone.status === 'In Progress';

            return (
              <motion.div 
                key={idx}
                variants={{
                  hidden: { 
                    opacity: 0, 
                    x: -24, 
                    y: 8,
                    scale: 0.95
                  },
                  visible: { 
                    opacity: 1, 
                    x: 0, 
                    y: 0,
                    scale: 1,
                    transition: {
                      type: "spring",
                      stiffness: 280,
                      damping: 24,
                      mass: 0.8
                    }
                  }
                }}
                className="flex items-start gap-4 group"
              >
                {/* Dot with spring entry & pulse effect */}
                <div className="relative z-10">
                  <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ 
                      type: "spring", 
                      stiffness: 350, 
                      damping: 20, 
                      delay: 0.12 + idx * 0.12 
                    }}
                    className={`w-[24px] h-[24px] rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                      isCompleted ? "bg-amber-600 border-amber-600 text-white shadow-sm" : 
                      isProgress ? "bg-white border-amber-600 text-amber-600 shadow-[0_0_12px_rgba(217,119,6,0.3)]" : 
                      "bg-white border-slate-200 text-slate-300"
                    }`}
                  >
                    {isCompleted ? (
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    ) : isProgress ? (
                      <Clock className="w-3.5 h-3.5 animate-pulse" />
                    ) : (
                      <span className="text-[10px] font-bold">{idx + 1}</span>
                    )}
                  </motion.div>
                </div>

                {/* Content */}
                <div className="flex-1 pb-1">
                  <div className="flex justify-between items-start mb-1">
                    <div className="space-y-0.5">
                      <h5 className={`text-xs font-bold uppercase tracking-wide leading-none ${
                        isCompleted ? "text-slate-900" : isProgress ? "text-amber-600 font-extrabold" : "text-slate-400"
                      }`}>
                        {milestone.label}
                      </h5>
                      <div className="flex items-center gap-1.5 text-slate-400">
                         <Calendar className="w-2.5 h-2.5" />
                         <span className="text-[9px] font-medium tracking-tight">Est. {milestone.date}</span>
                      </div>
                    </div>
                    
                    <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                      isCompleted ? "bg-green-50 text-green-700 border-green-200" : 
                      isProgress ? "bg-amber-50 text-amber-700 border-amber-200 shadow-sm" : 
                      "bg-slate-50 text-slate-400 border-slate-100"
                    }`}>
                      {milestone.status}
                    </span>
                  </div>
                  
                  {isProgress && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0, scale: 0.98 }}
                      animate={{ opacity: 1, height: 'auto', scale: 1 }}
                      transition={{ duration: 0.3, delay: 0.2 + idx * 0.1 }}
                      className="mt-2 bg-amber-500/10 border-l-2 border-amber-500 p-2.5 rounded-r text-[11px] text-slate-700 space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-amber-700 text-[10px] uppercase tracking-wider">
                          Active Construction Milestone
                        </span>
                        <span className="text-[9px] font-mono text-amber-800 bg-amber-200/60 px-1.5 py-0.2 rounded font-bold">
                          Live Inspection Stage
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-600 leading-relaxed italic">
                        Structural and finishing crews are currently active at the site. Subscribed users receive instant Service Worker push alerts upon completion.
                      </p>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>

      {/* Push Notification Milestone Simulator Tool */}
      <div className="bg-slate-900 text-white p-4 rounded-xl border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-amber-400">
              Service Worker Push Dispatcher
            </span>
          </div>
          <span className="text-[9px] font-mono text-slate-400">
            Permission: <strong className="text-white uppercase">{permissionState}</strong>
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Test the service worker push pipeline. Clicking below advances the next project milestone and dispatches a background push notification to your device.
        </p>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          <button
            onClick={handleSimulateNextMilestone}
            disabled={isSimulating}
            className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg uppercase tracking-wider transition-colors flex items-center gap-2 shadow-lg disabled:opacity-50"
            id="test-push-notification-btn"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{isSimulating ? 'Dispatching Push Alert...' : 'Simulate Next Milestone Alert'}</span>
          </button>

          <button
            onClick={() => {
              sendMilestoneNotification({
                projectId,
                projectTitle,
                milestone: 'Roof Slab Reinforcement Complete',
                image: projectImage,
                date: new Date().toLocaleDateString()
              });
              setLastAlertMessage(`Dispatched test push alert for "${projectTitle}"`);
              setTimeout(() => setLastAlertMessage(null), 3000);
            }}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs rounded-lg font-medium transition-colors flex items-center gap-1.5"
          >
            <BellRing className="w-3.5 h-3.5 text-amber-400" />
            <span>Send Test Push Ping</span>
          </button>
        </div>
      </div>

      {/* QA Verification Banner */}
      <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 flex items-center justify-between group">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm border border-slate-100">
            <ShieldCheck className="w-4 h-4 text-amber-600" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-900 uppercase tracking-widest">
              Quality Assurance & Handover Guarantee
            </p>
            <p className="text-[9px] text-slate-500 font-medium">
              Every milestone is verified on-site by registered structural engineers before push broadcast.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
