import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Building2, 
  Compass, 
  ShieldCheck, 
  Sliders, 
  Maximize2, 
  FastForward,
  Play,
  RotateCw,
  Layers,
  ChevronRight
} from 'lucide-react';
import { KineticText } from '@/registry/magicui/kinetic-text';

interface MovingSystemIntroProps {
  onComplete: () => void;
}

export default function MovingSystemIntro({ onComplete }: MovingSystemIntroProps) {
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);
  const [isAudioActive, setIsAudioActive] = useState<boolean>(false);
  const [isEntering, setIsEntering] = useState<boolean>(false);
  const [tilt, setTilt] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [wireframeActive, setWireframeActive] = useState<boolean>(true);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(12);
  const [autoProgress, setAutoProgress] = useState<boolean>(true);

  const containerRef = useRef<HTMLDivElement>(null);
  
  // Audio synthesizer refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const oscillatorsRef = useRef<any[]>([]);
  const mainGainNodeRef = useRef<GainNode | null>(null);

  // Auto progression countdown
  useEffect(() => {
    if (!autoProgress || isEntering) return;
    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleEnter();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [autoProgress, isEntering]);

  // Web Audio Ambient Synthesizer
  const startSynthesizer = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;

      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0, ctx.currentTime);
      masterGain.connect(ctx.destination);
      mainGainNodeRef.current = masterGain;

      masterGain.gain.linearRampToValueAtTime(0.18, ctx.currentTime + 1.2);

      const lowpass = ctx.createBiquadFilter();
      lowpass.type = 'lowpass';
      lowpass.frequency.setValueAtTime(320, ctx.currentTime);
      lowpass.Q.setValueAtTime(1.8, ctx.currentTime);
      lowpass.connect(masterGain);

      const frequencies = [65.41, 130.81, 196.00, 261.63]; // C2, C3, G3, C4
      const oscTypes: OscillatorType[] = ['sawtooth', 'triangle', 'sine', 'sine'];

      const oscs = frequencies.map((freq, index) => {
        const osc = ctx.createOscillator();
        const oscGain = ctx.createGain();

        osc.type = oscTypes[index];
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        osc.detune.setValueAtTime((Math.random() - 0.5) * 12, ctx.currentTime);

        oscGain.gain.setValueAtTime(0.35 - index * 0.05, ctx.currentTime);
        osc.connect(oscGain);
        oscGain.connect(lowpass);
        osc.start();

        const lfo = ctx.createOscillator();
        const lfoGain = ctx.createGain();
        lfo.frequency.setValueAtTime(0.1 + index * 0.04, ctx.currentTime);
        lfoGain.gain.setValueAtTime(0.12, ctx.currentTime);
        lfo.connect(lfoGain);
        lfoGain.connect(oscGain.gain);
        lfo.start();

        return { osc, lfo };
      });

      oscillatorsRef.current = oscs;
    } catch (err) {
      console.warn('Synth failed:', err);
    }
  };

  const stopSynthesizer = () => {
    const masterGain = mainGainNodeRef.current;
    const ctx = audioContextRef.current;
    if (masterGain && ctx) {
      masterGain.gain.cancelScheduledValues(ctx.currentTime);
      masterGain.gain.setValueAtTime(masterGain.gain.value, ctx.currentTime);
      masterGain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.8);

      setTimeout(() => {
        try {
          oscillatorsRef.current.forEach(({ osc, lfo }) => {
            osc.stop();
            lfo.stop();
          });
          ctx.close();
        } catch (e) {}
        audioContextRef.current = null;
        oscillatorsRef.current = [];
        mainGainNodeRef.current = null;
      }, 900);
    }
  };

  const toggleAudio = () => {
    if (isAudioActive) {
      stopSynthesizer();
      setIsAudioActive(false);
    } else {
      startSynthesizer();
      setIsAudioActive(true);
    }
  };

  useEffect(() => {
    return () => {
      if (audioContextRef.current) {
        try {
          oscillatorsRef.current.forEach(({ osc, lfo }) => {
            osc.stop();
            lfo.stop();
          });
          audioContextRef.current.close();
        } catch (e) {}
      }
    };
  }, []);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ x: y * -8, y: x * 8 });
  };

  const handleEnter = () => {
    setIsEntering(true);
    stopSynthesizer();
    setTimeout(() => {
      onComplete();
    }, 900);
  };

  const phrases = [
    "APS BUILDERS & DEVELOPERS • ARCHITECTURAL EXCELLENCE • LUXURY RESIDENCES • COMMERCIAL SPACES • KERALA • SINCE 2012 • ",
    "APS BUILDERS & DEVELOPERS • MASTER CRAFTSMANSHIP • SUSTAINABLE ECO-VILLAS • ENGINEERING PRECISION • 100+ LANDMARKS • ",
    "APS BUILDERS & DEVELOPERS • CRAFTING STRUCTURES THAT LAST • VASTU COMPLIANT • PREMIER BUILDERS • INNOVATIVE DESIGN • ",
    "APS BUILDERS & DEVELOPERS • TURNKEY EXECUTION • 3D BIM MODELING • PREMIUM INTERIORS • KERALA HERITAGE • "
  ];

  return (
    <div 
      ref={containerRef}
      onMouseMove={handleMouseMove}
      id="moving-system-intro-root"
      className={`fixed inset-0 z-[200] bg-[#07090e] text-white overflow-hidden flex flex-col justify-between select-none transition-all duration-1000 ${
        isEntering ? 'opacity-0 scale-110 blur-xl pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* BACKGROUND MOVING KINETIC SYSTEM */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0 flex flex-col justify-between py-6">
        
        {/* Stream 1: Top Right-to-Left Fast */}
        <div className="relative w-full opacity-20 -rotate-3 transform scale-110 origin-left">
          <motion.div
            className="flex whitespace-nowrap font-display font-black text-4xl sm:text-6xl md:text-7xl tracking-wider text-transparent"
            style={{
              WebkitTextStroke: '1px rgba(255, 255, 255, 0.45)',
            }}
            animate={{ x: [0, -1600] }}
            transition={{
              repeat: Infinity,
              repeatType: 'loop',
              duration: 32 / speedMultiplier,
              ease: 'linear'
            }}
          >
            <span className="mr-8 inline-block">{phrases[0]}</span>
            <span className="mr-8 inline-block">{phrases[0]}</span>
            <span className="mr-8 inline-block">{phrases[0]}</span>
          </motion.div>
        </div>

        {/* Stream 2: Upper Mid Left-to-Right */}
        <div className="relative w-full opacity-25 rotate-2 transform scale-110">
          <motion.div
            className="flex whitespace-nowrap font-display font-black text-5xl sm:text-7xl md:text-9xl tracking-tight"
            style={{
              WebkitTextStroke: '1.5px rgba(245, 158, 11, 0.5)',
              color: 'transparent'
            }}
            animate={{ x: [-1800, 0] }}
            transition={{
              repeat: Infinity,
              repeatType: 'loop',
              duration: 38 / speedMultiplier,
              ease: 'linear'
            }}
          >
            <span className="mr-12 inline-block flex items-center gap-6">
              <span className="text-amber-500/40">★</span> {phrases[1]}
            </span>
            <span className="mr-12 inline-block flex items-center gap-6">
              <span className="text-amber-500/40">★</span> {phrases[1]}
            </span>
          </motion.div>
        </div>

        {/* Stream 3: Center Massive Kinetic Hero Layer */}
        <div className="relative w-full opacity-30 -rotate-1 transform scale-105">
          <motion.div
            className="flex whitespace-nowrap font-display font-black text-6xl sm:text-8xl md:text-[10rem] tracking-tighter"
            style={{
              WebkitTextStroke: '2px rgba(255, 255, 255, 0.3)',
              color: 'transparent',
              textShadow: '0 0 30px rgba(217, 119, 6, 0.15)'
            }}
            animate={{ x: [0, -2200] }}
            transition={{
              repeat: Infinity,
              repeatType: 'loop',
              duration: 44 / speedMultiplier,
              ease: 'linear'
            }}
          >
            <span className="mr-16 inline-block">{phrases[2]}</span>
            <span className="mr-16 inline-block">{phrases[2]}</span>
          </motion.div>
        </div>

        {/* Stream 4: Lower Mid Left-to-Right */}
        <div className="relative w-full opacity-20 rotate-3 transform scale-110">
          <motion.div
            className="flex whitespace-nowrap font-display font-extrabold text-4xl sm:text-6xl md:text-8xl tracking-widest text-amber-500/30"
            animate={{ x: [-1600, 0] }}
            transition={{
              repeat: Infinity,
              repeatType: 'loop',
              duration: 34 / speedMultiplier,
              ease: 'linear'
            }}
          >
            <span className="mr-10 inline-block">{phrases[3]}</span>
            <span className="mr-10 inline-block">{phrases[3]}</span>
          </motion.div>
        </div>

        {/* Stream 5: Bottom Continuous Ticker Ribbon */}
        <div className="relative w-full opacity-15 -rotate-2 transform scale-105">
          <motion.div
            className="flex whitespace-nowrap font-display font-bold text-3xl sm:text-5xl md:text-6xl tracking-wider text-white/30"
            animate={{ x: [0, -1400] }}
            transition={{
              repeat: Infinity,
              repeatType: 'loop',
              duration: 28 / speedMultiplier,
              ease: 'linear'
            }}
          >
            <span className="mr-8 inline-block">{phrases[0]}</span>
            <span className="mr-8 inline-block">{phrases[0]}</span>
          </motion.div>
        </div>
      </div>

      {/* AMBIENT RADIAL LIGHTING & LASER GRID */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-amber-600/10 rounded-full blur-[140px]" />
        <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[160px]" />
        
        {wireframeActive && (
          <div className="absolute inset-0 bg-[radial-gradient(rgba(255,255,255,0.03)_1px,transparent_1px)] [background-size:32px_32px] opacity-80" />
        )}
      </div>

      {/* TOP HEADER STATUS & CONTROLS BAR */}
      <header className="relative z-30 p-6 sm:p-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/40 text-amber-400 flex items-center justify-center shadow-[0_0_20px_rgba(245,158,11,0.2)]">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black tracking-[0.25em] text-white uppercase">APS BUILDERS</span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">SYS_v3.0</span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono tracking-wider">KINETIC ARCHITECTURAL SYSTEM</p>
          </div>
        </div>

        {/* Action Controls Cluster */}
        <div className="flex items-center gap-2 sm:gap-4">
          {/* Speed Multiplier Pill */}
          <div className="hidden sm:flex items-center gap-1.5 bg-black/60 border border-white/10 rounded-full px-3 py-1.5 text-[10px] font-mono backdrop-blur-md">
            <span className="text-slate-400 flex items-center gap-1">
              <FastForward className="w-3 h-3 text-amber-400" /> Velocity:
            </span>
            {[1, 2, 3].map((spd) => (
              <button
                key={spd}
                onClick={() => setSpeedMultiplier(spd)}
                className={`px-2 py-0.5 rounded-full transition-all ${
                  speedMultiplier === spd 
                    ? 'bg-amber-500 text-black font-bold shadow-sm' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {spd}x
              </button>
            ))}
          </div>

          {/* Grid Toggle */}
          <button
            onClick={() => setWireframeActive(!wireframeActive)}
            className={`p-2.5 rounded-full border transition-all ${
              wireframeActive 
                ? 'bg-blue-500/10 border-blue-500/40 text-blue-400 shadow-[0_0_12px_rgba(59,130,246,0.2)]' 
                : 'bg-white/5 border-white/10 text-white/40 hover:text-white'
            }`}
            title="Toggle Blueprint Grid"
          >
            <Layers className="w-4 h-4" />
          </button>

          {/* Audio Synthesizer */}
          <button
            onClick={toggleAudio}
            className={`p-2.5 rounded-full border transition-all ${
              isAudioActive 
                ? 'bg-amber-500/10 border-amber-500 text-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.25)]' 
                : 'bg-white/5 border-white/10 text-white/40 hover:text-white'
            }`}
            title={isAudioActive ? "Mute Ambient Synth" : "Activate Ambient Soundscape"}
          >
            {isAudioActive ? <Volume2 className="w-4 h-4 animate-pulse" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Quick Skip Button */}
          <button
            onClick={handleEnter}
            className="px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 border border-white/15 text-xs font-mono tracking-wider uppercase transition-all flex items-center gap-1.5 text-white/80 hover:text-white"
          >
            <span>Skip</span>
            <span className="text-amber-400 font-bold font-mono">({secondsRemaining}s)</span>
          </button>
        </div>
      </header>

      {/* CENTRAL 3D INTERACTIVE PORTAL CARD */}
      <main className="relative z-20 flex-1 flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          style={{
            transform: `perspective(1000px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
            transformStyle: 'preserve-3d',
          }}
          className="w-full max-w-2xl bg-black/60 border border-white/15 rounded-3xl p-8 sm:p-12 backdrop-blur-2xl shadow-[0_25px_70px_rgba(0,0,0,0.8),inset_0_1px_1px_rgba(255,255,255,0.15)] relative overflow-hidden text-center"
        >
          {/* Animated Gold Edge Shimmer */}
          <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-amber-500 to-transparent animate-pulse" />

          {/* Sub-tag */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-[11px] font-mono tracking-widest uppercase mb-6">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <span>KERALA&apos;S PREMIER CONSTRUCTION ARCHITECTURE</span>
          </div>

          {/* Dynamic Brand Kinetic Headline */}
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-display font-black tracking-tight text-white uppercase mb-4 leading-tight">
            APS BUILDERS <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500">
              &amp; DEVELOPERS
            </span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-base max-w-lg mx-auto mb-8 font-light leading-relaxed">
            Crafting enduring landmarks, luxury residences, and commercial marvels across Kerala with engineering precision &amp; master craftsmanship.
          </p>

          {/* Key Metrics Strip */}
          <div className="grid grid-cols-3 gap-4 border-y border-white/10 py-4 mb-8 bg-white/[0.02] rounded-xl">
            <div>
              <div className="text-xl sm:text-2xl font-black font-display text-amber-400">100+</div>
              <div className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Delivered Projects</div>
            </div>
            <div className="border-x border-white/10">
              <div className="text-xl sm:text-2xl font-black font-display text-white">15+</div>
              <div className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Years of Trust</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-black font-display text-amber-400">100%</div>
              <div className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Vastu Compliant</div>
            </div>
          </div>

          {/* Primary CTA Enter Experience */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={handleEnter}
              id="enter-experience-btn"
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-slate-950 font-black text-sm uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 shadow-[0_0_30px_rgba(245,158,11,0.4)] group"
            >
              <span>EXPLORE ARCHITECTURE</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
            </button>

            <button
              onClick={() => {
                setAutoProgress(!autoProgress);
              }}
              className="px-5 py-3.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono uppercase text-slate-300 transition-all"
            >
              {autoProgress ? "Pause Auto-Enter" : "Resume Timer"}
            </button>
          </div>
        </motion.div>
      </main>

      {/* FOOTER LIVE SYSTEM TELEMETRY */}
      <footer className="relative z-30 p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono text-slate-400 gap-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-emerald-300 font-medium">MOVING ENGINE ONLINE</span>
          </div>
          <span>•</span>
          <span>LAT 9.9312° N / LON 76.2673° E</span>
        </div>

        <div className="flex items-center gap-6">
          <span>KERALA, INDIA</span>
          <span>•</span>
          <span className="text-amber-400 font-bold">APS DEVELOPERS © {new Date().getFullYear()}</span>
        </div>
      </footer>
    </div>
  );
}
