import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  HardHat,
  Compass,
  FileCheck2,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  Layers,
  Ruler,
  ShieldCheck,
  Building2,
  Home,
  DraftingCompass,
  Hammer,
  BadgePercent,
  Cpu,
  ChevronRight,
  PhoneCall
} from 'lucide-react';
import TiltCard3D from './TiltCard3D';

export interface ServiceItem {
  id: string;
  category: 'construction' | 'architecture' | 'consulting';
  categoryLabel: string;
  title: string;
  subtitle: string;
  badge: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  keyDeliverables: string[];
  metrics: { label: string; value: string }[];
  accentColor: string;
}

const SERVICES_DATA: ServiceItem[] = [
  // 1. GENERAL & LUXURY CONSTRUCTION
  {
    id: 'turnkey-construction',
    category: 'construction',
    categoryLabel: 'General & Coastal Construction',
    title: 'Turnkey Luxury Construction',
    subtitle: 'End-to-End Civil & Structural Execution',
    badge: 'Core Competency',
    icon: HardHat,
    description:
      'Turnkey residential and commercial construction engineered specifically for Alappuzha’s delicate backwater and coastal terrain. We manage deep-pile foundations, marine-grade reinforced concrete, seismic framing, and master craftsmanship from ground-breaking to key handover.',
    keyDeliverables: [
      'Cast-in-situ bored pile foundation & soil stabilization',
      'M-80 grade coastal marine concrete with anti-salt additives',
      'Full Bill of Quantities (BOQ) with zero hidden cost escalations',
      'Dedicated on-site Project Director & real-time digital milestone tracking'
    ],
    metrics: [
      { label: 'Structural Warranty', value: '25 Years' },
      { label: 'On-Time Delivery Rate', value: '98.4%' }
    ],
    accentColor: '#d4af37'
  },
  {
    id: 'coastal-waterfront-engineering',
    category: 'construction',
    categoryLabel: 'General & Coastal Construction',
    title: 'Backwater & Waterfront Civil Engineering',
    subtitle: 'Geotechnical Soil Armor & Marine Berths',
    badge: 'Specialized Engineering',
    icon: Hammer,
    description:
      'Specialized civil engineering for lakefront estates, private boat berths, and canal-front structures along Vembanad Lake and Punnamada waterways. Incorporates geo-textile filtration, hydrostatic drainage, and cantilevered infinity deck engineering.',
    keyDeliverables: [
      'Riprap stone revetments & shoreline erosion prevention',
      'Submersible piling for private yacht & motorboat docks',
      'Acoustic-dampened cantilevered plunge pool structural slabs',
      'Hydrostatic waterproof tanking for basements and ground terraces'
    ],
    metrics: [
      { label: 'Tidal Fluctuation Tolerance', value: '+2.4m Safe' },
      { label: 'Foundation Integrity', value: '100% Tested' }
    ],
    accentColor: '#38bdf8'
  },

  // 2. ARCHITECTURAL & INTERIOR DESIGN
  {
    id: 'bespoke-architectural-design',
    category: 'architecture',
    categoryLabel: 'Architectural & Interior Design',
    title: 'Bespoke Tropical Modern Architecture',
    subtitle: 'Kerala Vernacular Fused with Contemporary Glass',
    badge: 'Award-Winning',
    icon: DraftingCompass,
    description:
      'Harmonizing timeless Kerala heritage (Nalukettu courtyards, Machakam carved timber louvers, sloping clay tile overhangs) with modern bioclimatic floorplans, floor-to-ceiling glass expanses, and microclimate ventilation.',
    keyDeliverables: [
      'Full 3D photorealistic visualization & virtual spatial walkthroughs',
      'Passive solar shading & natural cross-ventilation flow calculations',
      'Complete structural, electrical, plumbing (MEP) schematics',
      'Custom joinery detailing using seasoned Nilambur teak and walnut'
    ],
    metrics: [
      { label: 'Thermal Cooling Reduction', value: 'Up to 32%' },
      { label: 'Custom Layout Precision', value: '100% Bespoke' }
    ],
    accentColor: '#f59e0b'
  },
  {
    id: 'curated-luxury-interiors',
    category: 'architecture',
    categoryLabel: 'Architectural & Interior Design',
    title: 'Luxury Interior Architecture & Styling',
    subtitle: 'Haute Finishes, Imported Marbles & Concealed Automation',
    badge: 'High Distinction',
    icon: Layers,
    description:
      'Complete interior architecture from bookmatched Italian Calacatta Oro marble installations to concealed multi-zone VRF HVAC systems, acoustic timber paneling, and discreet Lutron/DALI lighting automation.',
    keyDeliverables: [
      'Satin-honed Italian marble bookmatching & local stone inlay',
      'Concealed architectural linear diffusers & silent air purification',
      'DALI / KNX smart-home automation for lighting, climate, & security',
      'Custom artisan furniture curation & heritage copper-brass artifacts'
    ],
    metrics: [
      { label: 'Acoustic Isolation Rating', value: 'STC 56+' },
      { label: 'Craftsman Quality Rating', value: 'Master Class' }
    ],
    accentColor: '#ec4899'
  },

  // 3. CONSULTING, VASTU & ADVISORY
  {
    id: 'traditional-vastu-consulting',
    category: 'consulting',
    categoryLabel: 'Advisory & Technical Consulting',
    title: 'Classical Vastu Shastra & Thachu Shastra',
    subtitle: 'Cosmic Orientation & Energy Grid Alignment',
    badge: 'Ancient Wisdom',
    icon: Compass,
    description:
      'Authentic Kerala Thachu Shastra and Vastu consultations integrated harmoniously into modern floor plans. We align Brahmasthan central courtyards, directional door orientations, kitchen fire quadrants (Agni), and water features without compromising luxury.',
    keyDeliverables: [
      'Mathematical Brahmasthan grid mapping & cardinal alignment audit',
      'Site energy line surveying and directional gradient corrections',
      'Zero-demolition energetic balancing recommendations',
      'Aayadi Shadvarga dimensional formula calculation for prosperity'
    ],
    metrics: [
      { label: 'Vastu Conformance', value: '100% Certified' },
      { label: 'Floorplan Integration', value: 'Seamless' }
    ],
    accentColor: '#10b981'
  },
  {
    id: 'statutory-approvals-project-management',
    category: 'consulting',
    categoryLabel: 'Advisory & Technical Consulting',
    title: 'Statutory Approvals & Project Advisory',
    subtitle: 'Municipal Sanctions, CRZ Clearances & BOQ Audits',
    badge: 'Turnkey Governance',
    icon: FileCheck2,
    description:
      'Navigating Coastal Regulation Zone (CRZ) clearances, municipal building sanctions, fire safety approvals, and environmental compliance across Alappuzha. Includes independent cost auditing and quality assurance inspections.',
    keyDeliverables: [
      'Fast-track Alappuzha Municipality & Grama Panchayath building permits',
      'Coastal Regulation Zone (CRZ-III & CRZ-II) environmental compliance',
      'Independent quantity surveying & contractor audit verification',
      'Post-handover Annual Maintenance Contracts (AMC) and facility governance'
    ],
    metrics: [
      { label: 'Statutory Approval Speed', value: '3x Faster' },
      { label: 'Audit Variance Tolerance', value: 'Zero Overrun' }
    ],
    accentColor: '#8b5cf6'
  }
];

export default function ServicesSection() {
  const [activeTab, setActiveTab] = useState<'all' | 'construction' | 'architecture' | 'consulting'>('all');
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);

  const filteredServices =
    activeTab === 'all'
      ? SERVICES_DATA
      : SERVICES_DATA.filter((s) => s.category === activeTab);

  const scrollToQuote = () => {
    const el = document.getElementById('request-quote-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="our-services-section" className="w-full max-w-6xl mx-auto px-6 mb-28 scroll-mt-24">
      {/* SECTION HEADER */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
        <div>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/35 text-[11px] font-serif uppercase tracking-[0.25em] text-[#f3e5ab] font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Comprehensive Architectural & Construction Solutions</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight">
            Our Core Services
          </h2>
          <p className="text-xs sm:text-sm text-stone-300 font-serif font-light max-w-xl mt-2 leading-relaxed">
            From precision civil execution and coastal waterfront engineering to bespoke tropical modernism and traditional Vastu consultations — discover what we build for Alappuzha.
          </p>
        </div>

        {/* CATEGORY FILTER TABS */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-[#090b13] border border-white/10 self-start md:self-auto overflow-x-auto max-w-full">
          {[
            { id: 'all', label: 'All Offerings' },
            { id: 'construction', label: 'Construction' },
            { id: 'architecture', label: 'Architectural Design' },
            { id: 'consulting', label: 'Consulting & Vastu' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-serif transition-all whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-stone-950 font-bold shadow-md shadow-[#d4af37]/20'
                  : 'text-stone-300 hover:text-white hover:bg-white/5'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* SERVICES GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredServices.map((service) => {
          const IconComponent = service.icon;
          return (
            <TiltCard3D key={service.id} maxTilt={8} glare={true} className="rounded-3xl h-full">
              <div className="bg-gradient-to-b from-[#101322] via-[#0c0e17] to-[#080a11] border border-[#c5a059]/30 hover:border-[#d4af37] rounded-3xl p-6 sm:p-7 shadow-xl h-full flex flex-col justify-between transition-all duration-300 relative group overflow-hidden">
                {/* Background Watermark Glow */}
                <div
                  className="absolute -top-12 -right-12 w-36 h-36 rounded-full blur-3xl opacity-15 pointer-events-none group-hover:opacity-30 transition-opacity"
                  style={{ backgroundColor: service.accentColor }}
                />

                <div>
                  {/* Top Header Badge & Descriptive Icon */}
                  <div className="flex items-center justify-between mb-5">
                    <div className="w-13 h-13 rounded-2xl bg-[#080911] border border-white/10 group-hover:border-[#d4af37]/60 flex items-center justify-center transition-all duration-300 shadow-inner">
                      <IconComponent className="w-6 h-6 text-[#d4af37] group-hover:scale-110 transition-transform" />
                    </div>
                    <span className="px-3 py-1 rounded-full text-[10px] font-serif uppercase tracking-widest bg-[#d4af37]/15 text-[#f3e5ab] border border-[#d4af37]/35 font-semibold">
                      {service.badge}
                    </span>
                  </div>

                  <span className="text-[11px] font-serif uppercase tracking-wider text-[#d4af37] font-semibold block mb-1">
                    {service.categoryLabel}
                  </span>

                  <h3 className="text-xl font-serif font-bold text-white group-hover:text-[#f3e5ab] transition-colors leading-snug mb-1">
                    {service.title}
                  </h3>

                  <p className="text-xs text-[#f3e5ab]/80 font-serif mb-4">
                    {service.subtitle}
                  </p>

                  <p className="text-xs text-stone-300 font-serif font-light leading-relaxed mb-6">
                    {service.description}
                  </p>

                  {/* Key Deliverables Bullet Points */}
                  <div className="space-y-2 mb-6 pt-4 border-t border-white/5">
                    <div className="text-[10px] font-serif uppercase tracking-wider text-stone-400 font-semibold mb-2">
                      Key Capabilities:
                    </div>
                    {service.keyDeliverables.map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-stone-300 font-serif font-light">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#d4af37] shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bottom Metric Tags & Action */}
                <div className="pt-4 border-t border-white/10">
                  <div className="grid grid-cols-2 gap-2 mb-4">
                    {service.metrics.map((m, idx) => (
                      <div key={idx} className="p-2.5 rounded-xl bg-[#06080f] border border-white/5">
                        <span className="text-[9px] font-serif uppercase text-stone-400 block mb-0.5">
                          {m.label}
                        </span>
                        <span className="text-xs font-serif font-bold text-[#f3e5ab]">
                          {m.value}
                        </span>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={() => {
                      setSelectedService(service);
                    }}
                    className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-[#d4af37] hover:text-stone-950 text-stone-200 border border-white/10 hover:border-[#d4af37] text-xs font-serif font-semibold tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm group-hover:shadow-md"
                  >
                    <span>View Technical Scope</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </TiltCard3D>
          );
        })}
      </div>

      {/* DETAILED SERVICE SCOPE MODAL */}
      <AnimatePresence>
        {selectedService && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.94, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.94, opacity: 0, y: 20 }}
              className="bg-[#0e121e] border border-[#c5a059]/50 rounded-3xl max-w-xl w-full overflow-hidden shadow-2xl relative p-6 sm:p-8"
            >
              {/* Top Close Button */}
              <button
                onClick={() => setSelectedService(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/60 text-stone-300 hover:text-white border border-white/10 cursor-pointer"
              >
                ✕
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-[#080911] border border-[#d4af37]/60 flex items-center justify-center text-[#d4af37]">
                  <selectedService.icon className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-serif uppercase tracking-widest text-[#d4af37] font-semibold block">
                    {selectedService.categoryLabel}
                  </span>
                  <h3 className="text-xl font-serif font-bold text-white">
                    {selectedService.title}
                  </h3>
                </div>
              </div>

              <p className="text-xs text-stone-300 font-serif leading-relaxed mb-6 font-light">
                {selectedService.description}
              </p>

              <div className="mb-6">
                <h4 className="text-xs font-serif uppercase tracking-wider text-[#d4af37] font-semibold mb-3">
                  Scope of Execution & Standards:
                </h4>
                <div className="space-y-2">
                  {selectedService.keyDeliverables.map((d, i) => (
                    <div key={i} className="p-3 rounded-xl bg-[#070911] border border-white/5 flex items-start gap-2.5 text-xs text-stone-200 font-serif">
                      <CheckCircle2 className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                      <span>{d}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-6">
                {selectedService.metrics.map((m, i) => (
                  <div key={i} className="p-3 rounded-xl bg-[#070911] border border-[#c5a059]/25 text-center">
                    <span className="text-[10px] font-serif uppercase text-stone-400 block mb-0.5">
                      {m.label}
                    </span>
                    <span className="text-sm font-serif font-bold text-[#f3e5ab]">
                      {m.value}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-3 pt-4 border-t border-white/10">
                <button
                  onClick={() => {
                    setSelectedService(null);
                    scrollToQuote();
                  }}
                  className="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-stone-950 font-serif font-bold text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer text-center"
                >
                  Request Estimation for This Service
                </button>
                <a
                  href={`https://wa.me/917907656700?text=Hello%20APS%20Builders%2C%20I%20would%20like%20to%20consult%20regarding%20${encodeURIComponent(selectedService.title)}%20in%20Alappuzha.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-3.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-serif font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-1.5"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Inquire</span>
                </a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
