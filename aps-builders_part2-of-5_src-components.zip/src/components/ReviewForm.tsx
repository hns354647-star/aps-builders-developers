import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, Send, X, CheckCircle, Loader2, Quote } from 'lucide-react';

interface ReviewFormProps {
  onClose: () => void;
  onSubmit: (review: { name: string; role: string; text: string; rating: number }) => void;
}

export default function ReviewForm({ onClose, onSubmit }: ReviewFormProps) {
  const [step, setStep] = useState<'rating' | 'feedback' | 'success'>('rating');
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [text, setText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate submission
    setTimeout(() => {
      onSubmit({ name, role, text, rating });
      setStep('success');
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[120] flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="w-full max-w-lg bg-white rounded-sm shadow-2xl overflow-hidden flex flex-col relative"
      >
        {/* Header */}
        <div className="p-8 border-b border-slate-100 flex items-center justify-between">
          <div className="space-y-1">
            <h2 className="font-display text-2xl font-bold text-slate-900">Submit Your Review</h2>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Share your experience with APS Builders</p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-50 rounded-full transition-colors text-slate-400 hover:text-slate-900"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-8">
          <AnimatePresence mode="wait">
            {step === 'rating' && (
              <motion.div
                key="rating"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="text-center space-y-4 py-8">
                  <h3 className="text-sm font-bold text-slate-700 uppercase tracking-widest">How would you rate our craftsmanship?</h3>
                  <div className="flex justify-center gap-3">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onMouseEnter={() => setHoveredRating(star)}
                        onMouseLeave={() => setHoveredRating(0)}
                        onClick={() => setRating(star)}
                        className="transition-transform active:scale-95"
                      >
                        <Star 
                          className={`w-10 h-10 transition-colors ${
                            (hoveredRating || rating) >= star 
                              ? 'text-amber-600 fill-amber-600' 
                              : 'text-slate-200'
                          }`} 
                        />
                      </button>
                    ))}
                  </div>
                  {rating > 0 && (
                    <p className="text-xs font-bold text-amber-600 uppercase tracking-widest animate-pulse">
                      {rating === 5 ? 'Excellent!' : rating === 4 ? 'Very Good' : rating === 3 ? 'Good' : 'Thank you'}
                    </p>
                  )}
                </div>
                <button
                  disabled={rating === 0}
                  onClick={() => setStep('feedback')}
                  className="w-full py-4 bg-slate-900 text-white font-bold uppercase tracking-widest text-xs hover:bg-amber-600 transition-all disabled:opacity-50"
                >
                  Continue to Feedback
                </button>
              </motion.div>
            )}

            {step === 'feedback' && (
              <motion.form
                key="feedback"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onSubmit={handleSubmit}
                className="space-y-6"
              >
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Full Name</label>
                    <input 
                      required
                      type="text" 
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. John Doe"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-100 focus:border-amber-600 focus:bg-white outline-none transition-all rounded-sm text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Project Role</label>
                    <input 
                      required
                      type="text" 
                      value={role}
                      onChange={(e) => setRole(e.target.value)}
                      placeholder="e.g. Homeowner"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-100 focus:border-amber-600 focus:bg-white outline-none transition-all rounded-sm text-sm"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Share your experience</label>
                  <textarea 
                    required
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    rows={4}
                    placeholder="Tell us about the project quality, team, and delivery..."
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-100 focus:border-amber-600 focus:bg-white outline-none transition-all rounded-sm text-sm resize-none"
                  />
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep('rating')}
                    className="flex-1 py-4 border border-slate-200 text-slate-500 font-bold uppercase tracking-widest text-xs hover:bg-slate-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-[2] py-4 bg-slate-900 text-white font-bold uppercase tracking-widest text-xs hover:bg-amber-600 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    Submit Project Review
                  </button>
                </div>
              </motion.form>
            )}

            {step === 'success' && (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12 space-y-6"
              >
                <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle className="w-10 h-10 text-green-600" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-display font-bold text-slate-900">Review Submitted!</h3>
                  <p className="text-slate-500 text-sm max-w-xs mx-auto">
                    Thank you for your valuable feedback. Your review helps us maintain our standards of excellence.
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="px-8 py-3 bg-slate-900 text-white font-bold uppercase tracking-widest text-[10px] hover:bg-amber-600 transition-all mt-4"
                >
                  Return to Site
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Decorative Quote */}
        {step !== 'success' && (
           <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center gap-3 opacity-60">
              <Quote className="w-4 h-4 text-amber-600" />
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest italic">
                "Precision. Transparency. Quality." - APS Core Values
              </p>
           </div>
        )}
      </motion.div>
    </motion.div>
  );
}
