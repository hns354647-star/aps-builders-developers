import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Clock, Calendar, Hammer, Paintbrush, Key } from 'lucide-react';

interface Milestone {
  phase: string;
  duration: string;
  status: 'completed' | 'in-progress' | 'upcoming';
  icon: React.ReactNode;
}

const milestones: Milestone[] = [
  { phase: 'Design & Planning', duration: '2 Months', status: 'completed', icon: <Paintbrush className="w-3 h-3" /> },
  { phase: 'Foundation & Plinth', duration: '1.5 Months', status: 'completed', icon: <Calendar className="w-3 h-3" /> },
  { phase: 'Super Structure', duration: '4 Months', status: 'completed', icon: <Hammer className="w-3 h-3" /> },
  { phase: 'MEP & Finishing', duration: '3 Months', status: 'completed', icon: <CheckCircle2 className="w-3 h-3" /> },
  { phase: 'Handover', duration: 'Final Phase', status: 'completed', icon: <Key className="w-3 h-3" /> },
];

import ProjectTimelineChart from './ProjectTimelineChart';

export default function ProjectTimeline() {
  return (
    <div className="bg-white p-6 rounded-sm border border-slate-100 space-y-6">
      <div className="flex items-center gap-2">
        <Clock className="w-4 h-4 text-amber-600" />
        <h4 className="text-[10px] font-bold text-slate-900 uppercase tracking-widest">Project Journey</h4>
      </div>

      {/* D3 Visualization */}
      <div className="p-4 bg-slate-50 border border-slate-100 rounded-sm mb-6">
        <ProjectTimelineChart />
      </div>

      <div className="space-y-0 relative">
        {/* Progress Line */}
        <div className="absolute left-[13px] top-2 bottom-2 w-px bg-slate-100" />

        {milestones.map((m, idx) => (
          <motion.div 
            key={m.phase}
            initial={{ opacity: 0, x: -10 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="flex gap-4 pb-6 last:pb-0 relative"
          >
            <div className={`relative z-10 w-7 h-7 rounded-full flex items-center justify-center border-2 transition-colors ${
              m.status === 'completed' ? 'bg-amber-600 border-amber-600 text-white' : 'bg-white border-slate-200 text-slate-400'
            }`}>
              {m.icon}
            </div>
            
            <div className="flex-1 pt-1">
              <div className="flex items-center justify-between">
                <h5 className="text-[10px] font-bold text-slate-900 uppercase tracking-tight">{m.phase}</h5>
                <span className="text-[8px] font-bold text-slate-400 uppercase font-mono">{m.duration}</span>
              </div>
              <p className="text-[9px] text-slate-500 mt-0.5 italic">Phase execution validated by site engineers.</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
