import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

export const Loader: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const { t } = useLanguage();
  const [count, setCount] = useState(0);
  const [isDone, setIsDone] = useState(false);

  useEffect(() => {
    // Smooth 0 to 100 counter over ~1.6 seconds
    const interval = setInterval(() => {
      setCount((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setIsDone(true);
            setTimeout(onComplete, 600);
          }, 200);
          return 100;
        }
        // Accelerating curve
        const step = Math.max(1, Math.floor((100 - prev) * 0.15));
        return Math.min(100, prev + step);
      });
    }, 40);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <AnimatePresence>
      {!isDone && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: 'easeInOut' }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#cfdccb] text-[#141a3a] select-none"
        >
          {/* Studio Brand Mark */}
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-[#ff6a1a] flex items-center justify-center font-black text-white text-lg shadow-lg shadow-[#ff6a1a]/30">
              //
            </div>
            <span className="font-extrabold text-xl tracking-widest uppercase">
              STUDIO MONOLITH
            </span>
          </div>

          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-[#334237] mb-8">
            {t.loader.welcome} MONOLITH // AMSTERDAM
          </p>

          {/* Large Expressive Percentage Counter */}
          <div className="text-7xl sm:text-9xl font-black tracking-tighter text-[#141a3a] mb-8 font-mono">
            {count.toString().padStart(3, '0')}%
          </div>

          {/* Minimal Loading Bar */}
          <div className="w-64 h-1.5 rounded-full bg-[#b8c9b3] overflow-hidden mb-4">
            <motion.div
              className="h-full bg-[#ff6a1a]"
              style={{ width: `${count}%` }}
              transition={{ ease: 'linear' }}
            />
          </div>

          <div className="flex items-center gap-2 text-xs text-[#4d5e52] font-medium">
            <Sparkles className="w-3.5 h-3.5 text-[#ff6a1a] animate-pulse" />
            <span>{t.loader.subtitle}</span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
