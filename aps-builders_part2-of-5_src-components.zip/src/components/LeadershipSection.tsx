import React from 'react';
import { motion } from 'motion/react';
import { LEADERSHIP, TeamMember } from '../data/team';
import LazyImage from './LazyImage';
import { Linkedin, Mail } from 'lucide-react';

const MemberCard = ({ member }: { member: TeamMember }) => {
  return (
    <motion.div 
      className="relative group h-[400px] bg-slate-900 overflow-hidden rounded-sm border border-white/5 shadow-xl"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ 
        duration: 0.8, 
        ease: "anticipate"
      }}
    >
      {/* Background Image */}
      <div className="absolute inset-0 grayscale group-hover:grayscale-0 transition-all duration-700 scale-105 group-hover:scale-100">
        <LazyImage 
          src={member.image} 
          alt={member.name} 
          className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity"
        />
      </div>

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />

      {/* Default View: Name & Role */}
      <div className="absolute inset-x-0 bottom-0 p-8 transform group-hover:translate-y-[-10px] transition-transform duration-700 ease-out">
        <h4 className="text-white font-display text-2xl font-bold tracking-tight mb-1">{member.name}</h4>
        <div className="flex items-center gap-2">
          <motion.div 
            initial={{ width: 0 }}
            whileInView={{ width: 16 }}
            className="h-px bg-amber-600" 
          />
          <p className="text-amber-500 text-[10px] font-bold uppercase tracking-widest">{member.role}</p>
        </div>
      </div>

      {/* Hover View: Bio & Socials */}
      <div className="absolute inset-0 bg-slate-950/95 p-10 flex flex-col justify-center opacity-0 group-hover:opacity-100 transition-all duration-700 ease-out translate-y-4 group-hover:translate-y-0 backdrop-blur-md">
        <h4 className="text-white font-display text-xl font-bold mb-4">{member.name}</h4>
        <p className="text-slate-400 text-sm leading-relaxed mb-8">
          {member.bio}
        </p>
        
        <div className="flex items-center gap-4">
          <button className="p-2 bg-white/5 hover:bg-amber-600 text-white rounded-full transition-colors border border-white/10 group/btn">
            <Linkedin className="w-4 h-4 group-hover/btn:scale-110 transition-transform" />
          </button>
          <button className="p-2 bg-white/5 hover:bg-amber-600 text-white rounded-full transition-colors border border-white/10 group/btn">
            <Mail className="w-4 h-4 group-hover/btn:scale-110 transition-transform" />
          </button>
          <span className="text-[10px] font-bold text-amber-600 uppercase tracking-widest ml-auto">Biography</span>
        </div>
      </div>

      {/* Decorative Border */}
      <div className="absolute inset-0 border-[10px] border-amber-600/0 group-hover:border-amber-600/10 transition-all duration-500 pointer-events-none" />
    </motion.div>
  );
};

export default function LeadershipSection() {
  return (
    <section className="py-24 bg-slate-950">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-px bg-amber-600" />
              <span className="text-amber-500 text-[10px] font-bold uppercase tracking-[0.3em]">Our Leadership</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-display font-bold text-white tracking-tight leading-tight">
              A collective of <span className="text-white/40">experts</span> shaping tomorrow.
            </h2>
          </div>
          <div className="md:text-right">
            <p className="text-slate-500 text-sm max-w-xs md:ml-auto uppercase tracking-widest line-clamp-3">
              Founded on the principles of integrity, innovation, and architectural excellence.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {LEADERSHIP.map((member) => (
            <MemberCard key={member.id} member={member} />
          ))}
        </div>
      </div>
    </section>
  );
}
