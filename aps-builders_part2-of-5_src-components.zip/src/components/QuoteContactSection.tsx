import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText,
  Building2,
  Mail,
  User,
  Phone,
  MapPin,
  Coins,
  Send,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Compass,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  MessageCircle,
  RotateCcw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { quoteRequestSchema, QuoteRequestFormData, validateField } from '../schemas/validationSchemas';
import TiltCard3D from './TiltCard3D';

const PROJECT_TYPE_OPTIONS = [
  {
    id: 'waterfront-villa',
    label: 'Waterfront Estate / Sovereign Villa',
    subtitle: 'Vembanad Lakefront / Alappuzha Backwaters residences',
    startingBudget: '₹4.5 Cr+'
  },
  {
    id: 'sky-suite-tower',
    label: 'Alappuzha Beach Horizon Suite',
    subtitle: 'Coastal panoramic apartments & sunset decks on Beach Road',
    startingBudget: '₹2.8 Cr+'
  },
  {
    id: 'crown-penthouse',
    label: 'The Punnamada Crown Penthouse',
    subtitle: 'Duplex waterway sky villas with private plunge pools',
    startingBudget: '₹5.5 Cr+'
  },
  {
    id: 'commercial-plaza',
    label: 'Commercial & Institutional Landmark',
    subtitle: 'Grade-A office, retail, wellness, or mixed-use in Alappuzha',
    startingBudget: '₹8.0 Cr+'
  },
  {
    id: 'bespoke-residence',
    label: 'Bespoke Private Architectural Residence',
    subtitle: 'Custom single-family architectural design across Alappuzha',
    startingBudget: '₹2.0 Cr+'
  },
  {
    id: 'hospitality-retreat',
    label: 'Ayurvedic Retreat / Eco-Boutique Resort',
    subtitle: 'Eco-conscious heritage backwater hospitality enclaves',
    startingBudget: '₹10.0 Cr+'
  },
  {
    id: 'architectural-advisory',
    label: 'Pre-Construction Advisory & Masterplanning',
    subtitle: 'Feasibility, Vastu alignment, site zoning & structural design',
    startingBudget: 'Custom'
  }
];

const BUDGET_TIERS = [
  '₹1.5 Cr – ₹3.0 Cr',
  '₹3.0 Cr – ₹6.0 Cr',
  '₹6.0 Cr – ₹12.0 Cr',
  '₹12.0 Cr – ₹25.0 Cr',
  '₹25.0 Cr+ (Institutional / Ultra-Luxury)',
  'Undisclosed / Require Feasibility Study'
];

interface FormErrors {
  name?: string;
  email?: string;
  phone?: string;
  projectType?: string;
  location?: string;
  estimatedBudget?: string;
  projectScope?: string;
}

export default function QuoteContactSection() {
  const [formData, setFormData] = useState<QuoteRequestFormData>({
    name: '',
    email: '',
    phone: '',
    projectType: '',
    estimatedBudget: '',
    location: '',
    projectScope: ''
  });

  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [quoteReference, setQuoteReference] = useState<string | null>(null);
  const [submittedData, setSubmittedData] = useState<QuoteRequestFormData | null>(null);

  const handleFieldChange = (field: keyof QuoteRequestFormData, value: string) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);

    if (touched[field]) {
      const fieldError = validateField(quoteRequestSchema, field, value);
      setErrors((prev) => ({
        ...prev,
        [field]: fieldError || undefined
      }));
    }
  };

  const handleFieldBlur = (field: keyof QuoteRequestFormData) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
    const fieldError = validateField(quoteRequestSchema, field, formData[field]);
    setErrors((prev) => ({
      ...prev,
      [field]: fieldError || undefined
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Mark all required fields as touched
    setTouched({
      name: true,
      email: true,
      phone: true,
      projectType: true
    });

    const validationResult = quoteRequestSchema.safeParse(formData);

    if (!validationResult.success) {
      const issueMap: FormErrors = {};
      validationResult.error.issues.forEach((issue) => {
        const key = issue.path[0] as keyof FormErrors;
        if (!issueMap[key]) {
          issueMap[key] = issue.message;
        }
      });
      setErrors(issueMap);
      return;
    }

    setErrors({});
    setIsSubmitting(true);

    setTimeout(() => {
      const refCode = `APS-EST-${Math.floor(100000 + Math.random() * 900000)}`;
      setQuoteReference(refCode);
      setSubmittedData({ ...formData });
      setIsSubmitting(false);

      try {
        confetti({
          particleCount: 90,
          spread: 85,
          origin: { y: 0.65 },
          colors: ['#d4af37', '#f3e5ab', '#c5a059', '#10b981', '#ffffff']
        });
      } catch {
        // Fallback
      }
    }, 700);
  };

  const handleResetForm = () => {
    setQuoteReference(null);
    setSubmittedData(null);
    setFormData({
      name: '',
      email: '',
      phone: '',
      projectType: '',
      estimatedBudget: '',
      location: '',
      projectScope: ''
    });
    setTouched({});
    setErrors({});
  };

  return (
    <section id="request-quote-section" className="w-full max-w-6xl mx-auto px-6 mb-28 scroll-mt-24">
      {/* Editorial Header */}
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/35 text-[11px] font-serif uppercase tracking-[0.25em] text-[#f3e5ab] font-semibold mb-3">
          <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Architectural Estimations & Client Advisory</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight mb-3">
          Request a Bespoke Architectural Quote
        </h2>
        <p className="text-sm sm:text-base text-stone-300 max-w-2xl mx-auto font-serif font-light leading-relaxed">
          Partner with Alappuzha&apos;s preeminent architectural construction firm. Submit your project requirements to receive a detailed cost appraisal, timeline schedule, and technical feasibility dossier from our Principal Estimators.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* LEFT COLUMN: Firm Standards & Trust Metrics (4 Cols) */}
        <div className="lg:col-span-4 space-y-4">
          <TiltCard3D maxTilt={10} glare={true} className="rounded-2xl">
            <div className="p-6 rounded-2xl bg-gradient-to-b from-[#101422] to-[#0a0d16] border border-[#c5a059]/30 shadow-xl">
              <div className="w-12 h-12 rounded-xl bg-[#d4af37]/15 border border-[#d4af37]/40 flex items-center justify-center text-[#d4af37] mb-4">
                <Building2 className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-serif font-bold text-white mb-1.5">
                Transparent Itemized Estimations
              </h3>
              <p className="text-xs text-stone-300 leading-relaxed font-serif font-light mb-4">
                Every quote includes BOQ (Bill of Quantities), structural steel benchmarks, grade-80 concrete formulations, and certified Nilambur teak joinery specs.
              </p>
              <div className="pt-3 border-t border-white/5 space-y-2 text-xs font-serif text-stone-300">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>Zero hidden variation clauses</span>
                </div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>Guaranteed handover milestone penalties</span>
                </div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>Turnkey Vastu & bioclimatic integration</span>
                </div>
              </div>
            </div>
          </TiltCard3D>

          {/* Quick Contact Concierge Card */}
          <div className="p-5 rounded-2xl bg-[#090b12] border border-white/10 text-xs font-serif">
            <div className="text-[10px] uppercase tracking-wider text-[#d4af37] font-bold mb-1">
              Direct Technical Line
            </div>
            <h4 className="text-sm font-bold text-white mb-2">
              Prefer an Immediate Walkthrough?
            </h4>
            <p className="text-stone-400 font-light leading-relaxed mb-4">
              Connect directly with our Principal Project Directors across our Alappuzha backwater, beachfront, and town corridors.
            </p>
            <div className="flex flex-col gap-2">
              <a
                href="tel:7907656700"
                className="flex items-center justify-between p-2.5 rounded-xl bg-white/5 hover:bg-[#d4af37]/15 border border-[#c5a059]/30 text-stone-200 hover:text-white transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>+91 79076 56700</span>
                </span>
                <span className="text-[10px] text-stone-400">Head Office</span>
              </a>
              <a
                href="https://wa.me/917907656700?text=Hello%20APS%20Builders%2C%20I%20would%20like%20to%20request%20an%20architectural%20quote."
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-500/40 text-emerald-300 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WhatsApp Concierge</span>
                </span>
                <span className="text-[10px] text-emerald-400">Live 9am–8pm</span>
              </a>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: The Interactive Quote Form or Success Dossier (8 Cols) */}
        <div className="lg:col-span-8">
          <TiltCard3D maxTilt={6} glare={false} className="rounded-3xl">
            <div className="bg-gradient-to-b from-[#111422] to-[#090b12] border border-[#c5a059]/40 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
              
              {/* Gold Top Hairline Horizon */}
              <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#d4af37] to-transparent" />

              {!quoteReference ? (
                <form onSubmit={handleSubmit} noValidate className="space-y-6">
                  <div className="flex items-center justify-between pb-4 border-b border-[#c5a059]/20">
                    <div>
                      <h3 className="text-xl font-serif font-bold text-white">
                        Project Appraisal Application
                      </h3>
                      <p className="text-xs text-stone-400 font-serif">
                        All mandatory fields marked with an asterisk (*). Strictly confidential.
                      </p>
                    </div>
                    <FileText className="w-6 h-6 text-[#d4af37] opacity-80" />
                  </div>

                  {/* Row 1: Name and Email */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Full Name */}
                    <div>
                      <label className="flex items-center justify-between text-xs font-serif uppercase tracking-wider text-stone-300 mb-1.5 font-semibold">
                        <span className="flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-[#d4af37]" />
                          Full Name *
                        </span>
                        {errors.name && (
                          <span className="text-rose-400 text-[10px] lowercase font-sans">
                            {errors.name}
                          </span>
                        )}
                      </label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => handleFieldChange('name', e.target.value)}
                        onBlur={() => handleFieldBlur('name')}
                        placeholder="e.g. Adv. Rajesh Kurup"
                        className={`w-full px-4 py-3 rounded-xl bg-[#070911] border text-sm text-white placeholder-stone-600 focus:outline-none transition-all font-serif ${
                          errors.name
                            ? 'border-rose-500/80 focus:border-rose-400 ring-1 ring-rose-500/30'
                            : touched.name && !errors.name
                            ? 'border-emerald-500/60 focus:border-emerald-400'
                            : 'border-[#c5a059]/30 focus:border-[#d4af37]'
                        }`}
                      />
                    </div>

                    {/* Email Address */}
                    <div>
                      <label className="flex items-center justify-between text-xs font-serif uppercase tracking-wider text-stone-300 mb-1.5 font-semibold">
                        <span className="flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-[#d4af37]" />
                          Email Address *
                        </span>
                        {errors.email && (
                          <span className="text-rose-400 text-[10px] lowercase font-sans">
                            {errors.email}
                          </span>
                        )}
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleFieldChange('email', e.target.value)}
                        onBlur={() => handleFieldBlur('email')}
                        placeholder="rajesh@example.com"
                        className={`w-full px-4 py-3 rounded-xl bg-[#070911] border text-sm text-white placeholder-stone-600 focus:outline-none transition-all font-serif ${
                          errors.email
                            ? 'border-rose-500/80 focus:border-rose-400 ring-1 ring-rose-500/30'
                            : touched.email && !errors.email
                            ? 'border-emerald-500/60 focus:border-emerald-400'
                            : 'border-[#c5a059]/30 focus:border-[#d4af37]'
                        }`}
                      />
                    </div>
                  </div>

                  {/* Row 2: Phone and Location */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Phone Number */}
                    <div>
                      <label className="flex items-center justify-between text-xs font-serif uppercase tracking-wider text-stone-300 mb-1.5 font-semibold">
                        <span className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-[#d4af37]" />
                          Contact / WhatsApp *
                        </span>
                        {errors.phone && (
                          <span className="text-rose-400 text-[10px] lowercase font-sans">
                            {errors.phone}
                          </span>
                        )}
                      </label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleFieldChange('phone', e.target.value)}
                        onBlur={() => handleFieldBlur('phone')}
                        placeholder="+91 98470 12345"
                        className={`w-full px-4 py-3 rounded-xl bg-[#070911] border text-sm text-white placeholder-stone-600 focus:outline-none transition-all font-serif ${
                          errors.phone
                            ? 'border-rose-500/80 focus:border-rose-400 ring-1 ring-rose-500/30'
                            : touched.phone && !errors.phone
                            ? 'border-emerald-500/60 focus:border-emerald-400'
                            : 'border-[#c5a059]/30 focus:border-[#d4af37]'
                        }`}
                      />
                    </div>

                    {/* Site Location */}
                    <div>
                      <label className="flex items-center justify-between text-xs font-serif uppercase tracking-wider text-stone-300 mb-1.5 font-semibold">
                        <span className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-[#d4af37]" />
                          Site Location (Optional)
                        </span>
                      </label>
                      <input
                        type="text"
                        value={formData.location || ''}
                        onChange={(e) => handleFieldChange('location', e.target.value)}
                        placeholder="e.g. Punnamada, Beach Road Alappuzha, Cullen Road, Kainakary"
                        className="w-full px-4 py-3 rounded-xl bg-[#070911] border border-[#c5a059]/30 focus:border-[#d4af37] text-sm text-white placeholder-stone-600 focus:outline-none transition-all font-serif"
                      />
                    </div>
                  </div>

                  {/* Project Type Selection (MANDATORY WITH VALIDATION) */}
                  <div>
                    <label className="flex items-center justify-between text-xs font-serif uppercase tracking-wider text-stone-300 mb-2 font-semibold">
                      <span className="flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-[#d4af37]" />
                        Project Category *
                      </span>
                      {errors.projectType && (
                        <span className="text-rose-400 text-[10px] lowercase font-sans">
                          {errors.projectType}
                        </span>
                      )}
                    </label>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {PROJECT_TYPE_OPTIONS.map((opt) => {
                        const isSelected = formData.projectType === opt.id;
                        return (
                          <button
                            type="button"
                            key={opt.id}
                            onClick={() => handleFieldChange('projectType', opt.id)}
                            className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                              isSelected
                                ? 'bg-[#d4af37]/15 border-[#d4af37] ring-1 ring-[#d4af37]/60 shadow-md'
                                : 'bg-[#080a12] border-white/10 hover:border-[#c5a059]/40 hover:bg-white/5'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <span className="text-xs font-serif font-bold text-white leading-snug">
                                {opt.label}
                              </span>
                              {isSelected && (
                                <CheckCircle2 className="w-4 h-4 text-[#d4af37] shrink-0" />
                              )}
                            </div>
                            <span className="text-[11px] text-stone-400 font-serif line-clamp-1 block mb-1">
                              {opt.subtitle}
                            </span>
                            <span className="text-[10px] font-serif text-[#f3e5ab] font-semibold">
                              Starting from: {opt.startingBudget}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Estimated Budget Tier */}
                  <div>
                    <label className="flex items-center justify-between text-xs font-serif uppercase tracking-wider text-stone-300 mb-1.5 font-semibold">
                      <span className="flex items-center gap-1.5">
                        <Coins className="w-3.5 h-3.5 text-[#d4af37]" />
                        Target Investment Tier
                      </span>
                    </label>
                    <select
                      value={formData.estimatedBudget || ''}
                      onChange={(e) => handleFieldChange('estimatedBudget', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-[#070911] border border-[#c5a059]/30 text-white text-sm focus:outline-none focus:border-[#d4af37] transition-all font-serif"
                    >
                      <option value="">Select target investment bracket (optional)</option>
                      {BUDGET_TIERS.map((tier) => (
                        <option key={tier} value={tier}>
                          {tier}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Project Scope & Specifications Notes */}
                  <div>
                    <label className="flex items-center justify-between text-xs font-serif uppercase tracking-wider text-stone-300 mb-1.5 font-semibold">
                      <span className="flex items-center gap-1.5">
                        <Compass className="w-3.5 h-3.5 text-[#d4af37]" />
                        Project Scope & Architectural Requirements
                      </span>
                      <span className="text-[10px] text-stone-500">Max 1200 characters</span>
                    </label>
                    <textarea
                      rows={4}
                      value={formData.projectScope || ''}
                      onChange={(e) => handleFieldChange('projectScope', e.target.value)}
                      placeholder="Share details regarding plot area, number of floors, custom teak woodwork, swimming pool specifications, or handover timeline..."
                      className="w-full px-4 py-3 rounded-xl bg-[#070911] border border-[#c5a059]/30 text-white placeholder-stone-600 text-sm focus:outline-none focus:border-[#d4af37] transition-all font-serif resize-none"
                    />
                  </div>

                  {/* Submission Action */}
                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#f3e5ab] to-[#c5a059] hover:from-[#f3e5ab] hover:to-[#d4af37] text-stone-950 font-serif font-bold text-xs uppercase tracking-[0.2em] shadow-xl shadow-[#d4af37]/25 transition-all flex items-center justify-center gap-2 cursor-pointer hover:scale-105 active:scale-95 disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <span>Compiling Estimation Request...</span>
                      ) : (
                        <>
                          <Send className="w-4 h-4 text-stone-950" />
                          <span>Submit Quote Request</span>
                        </>
                      )}
                    </button>

                    <div className="flex items-center gap-2 text-xs font-serif text-stone-400">
                      <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
                      <span>Non-binding formal estimation dossier</span>
                    </div>
                  </div>
                </form>
              ) : (
                /* SUCCESS STATE: ELEVATED QUOTE DOSSIER */
                <motion.div
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-4"
                >
                  <div className="w-16 h-16 rounded-full bg-[#d4af37]/20 border border-[#d4af37]/50 text-[#d4af37] flex items-center justify-center mx-auto mb-4 shadow-inner">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>

                  <span className="text-[11px] font-serif uppercase tracking-[0.3em] text-[#d4af37] font-bold">
                    Official Appraisal Dossier Initialized
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white mt-1 mb-2">
                    Estimation Request Received
                  </h3>
                  <p className="text-sm text-stone-300 max-w-lg mx-auto font-serif font-light leading-relaxed mb-6">
                    Thank you, <strong className="text-white">{submittedData?.name}</strong>. Our Principal Project Estimators will synthesize a tailored technical dossier and reach out to your contact details.
                  </p>

                  {/* Reference Certificate Box */}
                  <div className="max-w-md mx-auto p-5 rounded-2xl bg-[#070912] border border-[#c5a059]/40 mb-6 text-left">
                    <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/5">
                      <div>
                        <span className="text-[10px] text-stone-400 font-serif uppercase block">
                          Quotation Reference Code
                        </span>
                        <span className="text-lg font-serif font-bold text-[#f3e5ab] tracking-wider">
                          {quoteReference}
                        </span>
                      </div>
                      <span className="px-3 py-1 rounded-full bg-[#d4af37]/15 text-[#f3e5ab] text-[10px] font-serif uppercase tracking-wider font-semibold border border-[#d4af37]/35">
                        Priority Queue
                      </span>
                    </div>

                    <div className="space-y-1.5 text-xs font-serif">
                      <div className="flex justify-between text-stone-300">
                        <span className="text-stone-400">Client Contact:</span>
                        <span>{submittedData?.phone}</span>
                      </div>
                      <div className="flex justify-between text-stone-300">
                        <span className="text-stone-400">Target Email:</span>
                        <span>{submittedData?.email}</span>
                      </div>
                      <div className="flex justify-between text-stone-300">
                        <span className="text-stone-400">Project Type:</span>
                        <span className="text-[#f3e5ab] font-semibold capitalize">
                          {PROJECT_TYPE_OPTIONS.find((p) => p.id === submittedData?.projectType)?.label}
                        </span>
                      </div>
                      {submittedData?.estimatedBudget && (
                        <div className="flex justify-between text-stone-300">
                          <span className="text-stone-400">Target Budget:</span>
                          <span>{submittedData.estimatedBudget}</span>
                        </div>
                      )}
                      {submittedData?.location && (
                        <div className="flex justify-between text-stone-300">
                          <span className="text-stone-400">Site Location:</span>
                          <span>{submittedData.location}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions: WhatsApp Forwarding or New Quote */}
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                    <a
                      href={`https://wa.me/917907656700?text=Hello%20APS%20Builders%2C%20I%20have%20submitted%20a%20Quote%20Request%20(Ref%3A%20${quoteReference})%20for%20${encodeURIComponent(
                        submittedData?.name || ''
                      )}%20regarding%20${encodeURIComponent(
                        PROJECT_TYPE_OPTIONS.find((p) => p.id === submittedData?.projectType)?.label || ''
                      )}.%20Please%20expedite%20my%20estimation.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-serif font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-800/25"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Forward to Estimator on WhatsApp</span>
                    </a>

                    <button
                      onClick={handleResetForm}
                      className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/15 border border-[#c5a059]/40 text-stone-200 text-xs font-serif font-semibold uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-[#d4af37]" />
                      <span>Submit Another Inquiry</span>
                    </button>
                  </div>
                </motion.div>
              )}
            </div>
          </TiltCard3D>
        </div>
      </div>
    </section>
  );
}
