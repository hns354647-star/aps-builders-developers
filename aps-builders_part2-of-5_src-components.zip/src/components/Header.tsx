import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { Instagram, Linkedin, Menu, X, ArrowUpRight } from 'lucide-react';

export const Header: React.FC = () => {
  const { locale, toggleLocale, currentPath, navigateTo, t } = useLanguage();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on resize to desktop
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Prevent background scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMobileMenuOpen]);

  const prefix = locale === 'en' ? '/en' : '';

  const navLinks = [
    { label: t.nav.agency, path: `${prefix}/agence/` },
    { label: t.nav.projects, path: `${prefix}/realisations/` },
    { label: t.nav.immersion, path: `${prefix}/lieu/` },
    { label: t.nav.contact, path: `${prefix}/contact/` },
  ];

  const newsLink = { label: t.nav.news, path: `${prefix}/actualites/` };

  const handleNavClick = (path: string) => {
    setIsMobileMenuOpen(false);
    navigateTo(path);
  };

  const isHome = currentPath === '/' || currentPath === '/en' || currentPath === '/en/';

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#F5F3EF]/95 backdrop-blur-md border-b border-[#111111]/8 py-4 shadow-xs text-[#111111]'
            : isHome
            ? 'bg-gradient-to-b from-black/60 via-black/25 to-transparent py-6 text-white'
            : 'bg-[#F5F3EF]/90 backdrop-blur-sm border-b border-[#111111]/5 py-6 text-[#111111]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12 flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => handleNavClick(prefix ? '/en/' : '/')}
            className="group text-left focus:outline-none focus-visible:ring-1 focus-visible:ring-current"
            aria-label="Archidomo - Accueil"
          >
            <span className="font-serif text-2xl sm:text-3xl tracking-[0.18em] uppercase font-light transition-opacity duration-300 group-hover:opacity-70">
              Archidomo
            </span>
            <span className="block text-[9px] tracking-[0.25em] uppercase text-stone-muted opacity-80 -mt-1 font-sans">
              Annecy · Genève · Cannes
            </span>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8 text-[13px] tracking-[0.14em] uppercase font-medium">
            <div className="flex items-center gap-7">
              {navLinks.map((item) => {
                const isActive = currentPath.startsWith(item.path);
                return (
                  <button
                    key={item.path}
                    onClick={() => handleNavClick(item.path)}
                    className={`editorial-link transition-colors duration-300 focus:outline-none ${
                      isActive
                        ? 'opacity-100 font-semibold underline underline-offset-8 decoration-1'
                        : 'opacity-75 hover:opacity-100'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </div>

            {/* Separator for News */}
            <div className="w-[1px] h-4 bg-current opacity-25" aria-hidden="true" />

            {/* News Link (Separated visually) */}
            <button
              onClick={() => handleNavClick(newsLink.path)}
              className={`editorial-link text-[12px] tracking-[0.18em] transition-colors duration-300 opacity-70 hover:opacity-100 ${
                currentPath.startsWith(newsLink.path) ? 'opacity-100 font-semibold' : ''
              }`}
            >
              {newsLink.label}
            </button>

            {/* Social Links */}
            <div className="flex items-center gap-4 text-current opacity-60 ml-2">
              <a
                href="https://www.instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram Archidomo"
                className="hover:opacity-100 transition-opacity"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn Archidomo"
                className="hover:opacity-100 transition-opacity"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            </div>

            {/* Language Switcher */}
            <div className="flex items-center text-[11px] tracking-[0.2em] font-semibold border-l border-current/20 pl-6 ml-2">
              <button
                onClick={() => locale !== 'fr' && toggleLocale()}
                className={`transition-opacity ${locale === 'fr' ? 'opacity-100 underline underline-offset-4 decoration-1 font-bold' : 'opacity-40 hover:opacity-80'}`}
                aria-label="Version française"
              >
                FR
              </button>
              <span className="mx-1.5 opacity-40">/</span>
              <button
                onClick={() => locale !== 'en' && toggleLocale()}
                className={`transition-opacity ${locale === 'en' ? 'opacity-100 underline underline-offset-4 decoration-1 font-bold' : 'opacity-40 hover:opacity-80'}`}
                aria-label="English version"
              >
                EN
              </button>
            </div>
          </nav>

          {/* Mobile Right Controls: Language & Hamburger */}
          <div className="flex items-center gap-4 lg:hidden">
            {/* Quick Language Toggle */}
            <button
              onClick={toggleLocale}
              className="text-[11px] tracking-[0.2em] font-semibold px-2 py-1 uppercase opacity-80 hover:opacity-100 border border-current/20 rounded-xs"
              aria-label="Changer de langue"
            >
              {locale === 'fr' ? 'EN' : 'FR'}
            </button>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 -mr-2 text-current focus:outline-none"
              aria-label={isMobileMenuOpen ? t.nav.close : t.nav.menu}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Full-Screen Mobile Overlay Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-0 z-40 bg-[#111111] text-[#F5F3EF] flex flex-col justify-between p-8 sm:p-12 pt-28 overflow-y-auto lg:hidden"
          >
            <div className="space-y-6 sm:space-y-8">
              <span className="block text-[11px] tracking-[0.25em] text-[#8E8880] uppercase">
                Menu de navigation
              </span>

              <nav className="flex flex-col gap-5 sm:gap-6">
                {navLinks.map((item, idx) => (
                  <motion.button
                    key={item.path}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.05 * idx, duration: 0.3 }}
                    onClick={() => handleNavClick(item.path)}
                    className="text-left font-serif text-3xl sm:text-4xl hover:text-stone-300 transition-colors flex items-center justify-between group"
                  >
                    <span>{item.label}</span>
                    <ArrowUpRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </motion.button>
                ))}

                {/* News Link in Mobile Menu */}
                <motion.button
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.25, duration: 0.3 }}
                  onClick={() => handleNavClick(newsLink.path)}
                  className="text-left font-sans text-lg tracking-[0.18em] uppercase text-stone-400 hover:text-white pt-4 border-t border-white/10"
                >
                  {newsLink.label} &amp; Journal
                </motion.button>
              </nav>
            </div>

            {/* Mobile Menu Footer Info */}
            <div className="pt-8 border-t border-white/10 space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-[0.2em] text-[#8E8880]">
                  Langue / Language
                </span>
                <div className="flex items-center gap-3 text-sm font-semibold tracking-wider">
                  <button
                    onClick={() => toggleLocale()}
                    className={`px-3 py-1 text-xs border border-white/20 uppercase ${
                      locale === 'fr' ? 'bg-white text-black' : 'text-white'
                    }`}
                  >
                    Français
                  </button>
                  <button
                    onClick={() => toggleLocale()}
                    className={`px-3 py-1 text-xs border border-white/20 uppercase ${
                      locale === 'en' ? 'bg-white text-black' : 'text-white'
                    }`}
                  >
                    English
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-stone-400">
                <div className="flex gap-6">
                  <a
                    href="https://www.instagram.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-white transition-colors"
                  >
                    Instagram
                  </a>
                  <a
                    href="https://www.linkedin.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-white transition-colors"
                  >
                    LinkedIn
                  </a>
                </div>
                <span>Talloires · Courchevel · Cannes</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Header;
