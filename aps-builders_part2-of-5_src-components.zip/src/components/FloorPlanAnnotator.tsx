import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, MessageSquare, X, Send, Info } from 'lucide-react';

interface Annotation {
  id: string;
  x: number; // percentage
  y: number; // percentage
  question: string;
}

interface FloorPlanAnnotatorProps {
  planTitle: string;
  planUrl: string;
}

export default function FloorPlanAnnotator({ planTitle, planUrl }: FloorPlanAnnotatorProps) {
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [activePin, setActivePin] = useState<Annotation | null>(null);
  const [newPinPos, setNewPinPos] = useState<{ x: number, y: number } | null>(null);
  const [inquiryText, setInquiryText] = useState('');
  const imgRef = useRef<HTMLImageElement>(null);

  const handleImageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!imgRef.current) return;
    
    const rect = imgRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    setNewPinPos({ x, y });
    setInquiryText('');
    setActivePin(null);
  };

  const saveAnnotation = () => {
    if (!newPinPos || !inquiryText.trim()) return;

    const newAnnotation: Annotation = {
      id: Math.random().toString(36).substr(2, 9),
      x: newPinPos.x,
      y: newPinPos.y,
      question: inquiryText
    };

    setAnnotations([...annotations, newAnnotation]);
    setNewPinPos(null);
    setInquiryText('');
  };

  return (
    <div className="bg-slate-950 p-6 rounded-sm border border-white/5 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-amber-500" />
          <h4 className="text-[10px] font-bold text-white uppercase tracking-widest">Interactive Plan Annotator</h4>
        </div>
        <div className="flex items-center gap-2">
           <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">{planTitle}</span>
           <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
        </div>
      </div>

      <div className="relative group cursor-crosshair overflow-hidden rounded-sm border border-white/10" onClick={handleImageClick}>
        <img 
          ref={imgRef}
          src={planUrl} 
          alt={planTitle}
          className="w-full h-auto grayscale hover:grayscale-0 transition-all duration-700 opacity-60 hover:opacity-100"
        />
        
        {/* Helper Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none bg-slate-950/20">
           <div className="bg-black/60 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10 flex items-center gap-2">
              <Info className="w-3 h-3 text-amber-500" />
              <span className="text-[8px] font-bold text-white uppercase tracking-widest">Click anywhere to drop a priority pin</span>
           </div>
        </div>

        {/* Existing Pins */}
        {annotations.map((anno) => (
          <button
            key={anno.id}
            onClick={(e) => {
               e.stopPropagation();
               setActivePin(anno);
               setNewPinPos(null);
            }}
            className="absolute -translate-x-1/2 -translate-y-1/2 z-20"
            style={{ left: `${anno.x}%`, top: `${anno.y}%` }}
          >
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              whileHover={{ scale: 1.2 }}
              className="relative"
            >
              <div className="absolute inset-0 bg-amber-500 blur-md rounded-full opacity-50 animate-pulse" />
              <div className="relative bg-amber-500 text-white p-1 rounded-full shadow-xl">
                 <MessageSquare className="w-3 h-3" />
              </div>
            </motion.div>
          </button>
        ))}

        {/* New Pin Preview */}
        {newPinPos && (
          <div 
            className="absolute -translate-x-1/2 -translate-y-1/2 z-30"
            style={{ left: `${newPinPos.x}%`, top: `${newPinPos.y}%` }}
          >
            <div className="bg-amber-600 text-white p-1.5 rounded-full shadow-2xl relative">
               <div className="absolute inset-0 bg-amber-600 animate-ping rounded-full opacity-40" />
               <MapPin className="w-4 h-4 relative z-10" />
            </div>
          </div>
        )}
      </div>

      <AnimatePresence mode="wait">
        {newPinPos && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="bg-white/5 border border-amber-500/30 p-4 rounded-sm"
          >
            <div className="flex items-start justify-between mb-3 text-amber-500">
               <span className="text-[10px] font-bold uppercase tracking-widest">New Priority Question</span>
               <button onClick={() => setNewPinPos(null)}>
                 <X className="w-3 h-3" />
               </button>
            </div>
            <textarea 
              autoFocus
              value={inquiryText}
              onChange={(e) => setInquiryText(e.target.value)}
              placeholder="Ask about materials, dimensions, or structural logic here..."
              className="w-full bg-slate-900 border border-white/10 rounded-sm p-3 text-xs text-white focus:border-amber-600 outline-none resize-none mb-3"
              rows={3}
            />
            <button 
              onClick={saveAnnotation}
              disabled={!inquiryText.trim()}
              className="w-full py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-[9px] font-bold uppercase tracking-widest rounded-sm flex items-center justify-center gap-2 transition-all"
            >
              Drop Pin & Inquiry
              <Send className="w-3 h-3" />
            </button>
          </motion.div>
        )}

        {activePin && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="bg-white border text-slate-900 p-4 rounded-sm"
          >
            <div className="flex items-start justify-between mb-3">
               <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Archived Inquiry</span>
               <button onClick={() => setActivePin(null)}>
                 <X className="w-3 h-3 text-slate-400" />
               </button>
            </div>
            <p className="text-xs font-medium leading-relaxed italic mb-4">"{activePin.question}"</p>
            <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
               <div className="w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center">
                  <span className="text-[8px] font-bold text-amber-700">A</span>
               </div>
               <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest italic">Awaiting technical review from Site Head</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="pt-2 text-center">
        <p className="text-[7px] text-slate-600 uppercase tracking-widest font-bold font-mono">
          Pinned queries are directly synced with the Lead Architect's tablet.
        </p>
      </div>
    </div>
  );
}
