import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Compass, Layout, DoorOpen, Palette, Wand2, ShieldCheck, Download, Share2, Info, Loader2, History, Mountain, Trees, Building2, Waves, Trash2, ArrowRight, ChevronRight } from 'lucide-react';

// Import assets
import doorEast from "../assets/images/vastu_door_east_1780813328926.png";
import doorNorth from "../assets/images/vastu_door_north_1780813345048.png";
import doorSouth from "../assets/images/vastu_door_south_1780813770045.png";
import doorWest from "../assets/images/vastu_door_west_1780813787291.png";
import interiorModern from "../assets/images/vastu_home_brahmasthan_1780813360455.png";
import interiorTraditional from "../assets/images/vastu_interior_traditional_1780813803200.png";
import exteriorBalanced from "../assets/images/vastu_home_exterior_1780813375422.png";
import exteriorMinimalist from "../assets/images/vastu_exterior_minimalist_1780813816159.png";

type Category = 'Doors' | 'Interiors' | 'Houses' | 'Exteriors';
type Style = 'Modern' | 'Traditional';
type Direction = 'East' | 'North' | 'South' | 'West';

const OPTIONS = {
  Doors: {
    directions: ['East', 'North', 'South', 'West'],
    styles: ['Modern', 'Traditional']
  },
  Interiors: {
    styles: ['Modern', 'Traditional']
  },
  Houses: {
    styles: ['Modern', 'Traditional']
  },
  Exteriors: {
    styles: ['Modern', 'Traditional']
  }
};

const IMAGE_MAP: Record<string, string> = {
  'Doors-East': doorEast,
  'Doors-North': doorNorth,
  'Doors-South': doorSouth,
  'Doors-West': doorWest,
  'Interiors-Modern': interiorModern,
  'Interiors-Traditional': interiorTraditional,
  'Houses-Modern': exteriorMinimalist,
  'Houses-Traditional': exteriorBalanced,
  'Exteriors-Modern': exteriorMinimalist,
  'Exteriors-Traditional': exteriorBalanced,
};

export default function AICustomizer() {
  const [category, setCategory] = useState<Category>('Doors');
  const [style, setStyle] = useState<string>('Modern');
  const [direction, setDirection] = useState<string>('East');
  const [customPrompt, setCustomPrompt] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentImage, setCurrentImage] = useState(doorEast);
  const [activePrompt, setActivePrompt] = useState<string>('');
  const [showResult, setShowResult] = useState(true);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [generationNotice, setGenerationNotice] = useState<string | null>(null);
  const [history, setHistory] = useState<{url: string, prompt: string, timestamp: number}[]>([]);

  // Advanced Controls
  const [selectedMaterial, setSelectedMaterial] = useState<string>('Teak Wood');
  const [selectedLighting, setSelectedLighting] = useState<string>('Golden Hour');
  const [architecturalStyle, setArchitecturalStyle] = useState<string>('Minimalist');
  const [environment, setEnvironment] = useState<string>('Urban');

  const [showAdvanced, setShowAdvanced] = useState(false);

  const MATERIALS = ['Teak Wood', 'Polished Marble', 'Reinforced Glass', 'Antique Brass', 'Black Granite'];
  const LIGHTING = ['Golden Hour', 'Moonlit Dusk', 'High Noon Sharp', 'Soft Ambient'];
  const ARCH_STYLES = ['Minimalist', 'Brutalism', 'Neo-Classical', 'Futuristic', 'Industrial'];
  const ENVIRONMENTS = [
    { name: 'Urban', icon: <Building2 className="w-3 h-3" /> },
    { name: 'Mountain', icon: <Mountain className="w-3 h-3" /> },
    { name: 'Coastal', icon: <Waves className="w-3 h-3" /> },
    { name: 'Forest', icon: <Trees className="w-3 h-3" /> }
  ];

  useEffect(() => {
    const saved = localStorage.getItem('aps_design_history');
    if (saved) setHistory(JSON.parse(saved));
  }, []);

  const saveToHistory = (url: string, p: string) => {
    const newItem = { url, prompt: p, timestamp: Date.now() };
    const updated = [newItem, ...history].slice(0, 6);
    setHistory(updated);
    localStorage.setItem('aps_design_history', JSON.stringify(updated));
  };

  const handleGenerate = async () => {
    if (isGenerating) return;
    
    setIsGenerating(true);
    setShowResult(false);
    setGenerationError(null);
    setGenerationNotice(null);
    
    const enhancedPrompt = `${customPrompt}. Architectural Style: ${architecturalStyle}. Setting: ${environment}. Use ${selectedMaterial} details. Captured in ${selectedLighting} lighting.`;
    setActivePrompt(enhancedPrompt);
    
    try {
      const response = await fetch("/api/generate-design", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          prompt: enhancedPrompt,
          category,
          style: architecturalStyle,
          direction,
          selectedMaterial,
          selectedLighting
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.details || data.error || "Failed to generate design");
      }

      if (data.isFallback) {
        setGenerationNotice(data.details);
        applyFallback();
      } else {
        setCurrentImage(data.imageUrl);
        saveToHistory(data.imageUrl, enhancedPrompt);
      }
      
      setIsGenerating(false);
      setShowResult(true);
    } catch (error: any) {
      console.error("Design Generation Error:", error);
      setGenerationError(error.message);
      applyFallback();
      setIsGenerating(false);
      setShowResult(true);
    }
  };

  const applyFallback = () => {
    let key = "";
    if (category === 'Doors') {
      key = `${category}-${direction}`;
    } else {
      key = `${category}-${style}`;
    }
    const fallbackUrl = IMAGE_MAP[key] || doorEast;
    setCurrentImage(fallbackUrl);
  };

  return (
    <section className="py-24 bg-slate-950 overflow-hidden relative" id="ai-customizer">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-amber-500/5 to-transparent pointer-events-none" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row gap-16 items-start">
          
          {/* Controls Panel */}
          <div className="lg:w-2/5 space-y-10 lg:sticky lg:top-24">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 text-amber-500 font-bold uppercase text-[10px] tracking-[0.3em] bg-amber-500/10 px-4 py-1.5 rounded-full border border-amber-500/20">
                <Sparkles className="w-3 h-3" /> ARCHITECTURAL VISION ENGINE
              </div>
              <h2 className="text-4xl font-display font-bold text-white tracking-tight leading-tight">
                Your Prompt<span className="text-amber-500">,</span> <br />
                Our Architecture.
              </h2>
              <p className="text-slate-400 text-sm leading-relaxed font-light">
                Describe your dream home in natural language. Our AI translates your words into high-fidelity architectural visualizations instantly.
              </p>
            </div>

            <div className="space-y-8">
              {/* Primary Prompt Input */}
              <div className="space-y-4">
                <div className="p-1 pb-1 bg-gradient-to-br from-amber-500/20 to-transparent rounded-sm">
                  <div className="bg-slate-900 border border-white/5 rounded-sm p-4 space-y-4 shadow-2xl">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block flex items-center gap-2">
                       <Wand2 className="w-3.5 h-3.5 text-amber-500" /> Enter Your Vision
                    </label>
                    <textarea
                      value={customPrompt}
                      onChange={(e) => setCustomPrompt(e.target.value)}
                      placeholder="e.g., A minimalist black glass villa perched on a misty cliffside with warm interior lighting and a wrap-around infinity pool..."
                      className="w-full h-40 p-0 text-base bg-transparent border-none focus:ring-0 resize-none placeholder:text-slate-700 text-white font-light leading-relaxed outline-none"
                    />
                    
                    <div className="flex items-center justify-between pt-2 border-t border-white/5">
                      <div className="flex gap-2">
                        {['Modern', 'Kerala', 'Brutalist'].map(tag => (
                          <button 
                            key={tag}
                            onClick={() => setCustomPrompt(prev => prev ? `${prev}, ${tag} style` : `${tag} style house`)}
                            className="text-[9px] font-bold text-slate-500 hover:text-amber-500 uppercase tracking-tighter transition-colors"
                          >
                            #{tag}
                          </button>
                        ))}
                      </div>
                      <button
                        onClick={handleGenerate}
                        disabled={isGenerating || !customPrompt.trim()}
                        className="bg-amber-500 text-slate-950 p-2.5 rounded-sm hover:bg-amber-400 transition-all shadow-lg shadow-amber-500/10 disabled:opacity-50 disabled:grayscale"
                      >
                        <ArrowRight className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Advanced Controls */}
              <div className="space-y-6 pt-4 border-t border-white/5">
                <button 
                  className="w-full flex items-center justify-between text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] hover:text-white transition-colors"
                  onClick={() => setShowAdvanced(!showAdvanced)}
                >
                  Refine Parameters <ChevronRight className={`w-4 h-4 transition-transform ${showAdvanced ? 'rotate-90' : ''}`} />
                </button>

                <AnimatePresence>
                  {showAdvanced && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden space-y-6"
                    >
                      {/* Material Selection */}
                      <div className="space-y-3">
                        <label className="text-[9px] font-bold text-slate-600 uppercase tracking-widest block">Primary Material</label>
                        <div className="flex flex-wrap gap-2">
                          {MATERIALS.map(m => (
                            <button
                              key={m}
                              onClick={() => setSelectedMaterial(m)}
                              className={`px-3 py-1.5 rounded-sm text-[10px] font-medium transition-all ${
                                selectedMaterial === m ? 'bg-amber-600 text-white' : 'bg-white/5 text-slate-500 hover:bg-white/10'
                              }`}
                            >
                              {m}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Architecture Style */}
                      <div className="space-y-3">
                        <label className="text-[9px] font-bold text-slate-600 uppercase tracking-widest block">Design Philosophy</label>
                        <div className="flex flex-wrap gap-2">
                          {ARCH_STYLES.map(s => (
                            <button
                              key={s}
                              onClick={() => setArchitecturalStyle(s)}
                              className={`px-3 py-1.5 rounded-sm text-[10px] font-medium transition-all ${
                                architecturalStyle === s ? 'bg-amber-600 text-white' : 'bg-white/5 text-slate-500 hover:bg-white/10'
                              }`}
                            >
                              {s}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Lighting */}
                      <div className="space-y-3">
                        <label className="text-[9px] font-bold text-slate-600 uppercase tracking-widest block">Ambiance</label>
                        <div className="flex flex-wrap gap-2">
                          {LIGHTING.map(l => (
                            <button
                              key={l}
                              onClick={() => setSelectedLighting(l)}
                              className={`px-3 py-1.5 rounded-sm text-[10px] font-medium transition-all ${
                                selectedLighting === l ? 'bg-amber-600 text-white' : 'bg-white/5 text-slate-500 hover:bg-white/10'
                              }`}
                            >
                              {l}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Environment */}
                      <div className="space-y-3">
                        <label className="text-[9px] font-bold text-slate-600 uppercase tracking-widest block">Site Terrain</label>
                        <div className="grid grid-cols-2 gap-2">
                          {ENVIRONMENTS.map(env => (
                            <button
                              key={env.name}
                              onClick={() => setEnvironment(env.name)}
                              className={`flex items-center gap-2 px-4 py-2.5 rounded-sm text-[10px] font-medium transition-all ${
                                environment === env.name ? 'bg-amber-600 text-white' : 'bg-white/5 text-slate-500 hover:bg-white/10'
                              }`}
                            >
                              {env.icon} {env.name}
                            </button>
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Quick Inspiration */}
              <div className="space-y-4">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Quick Inspiration</label>
                <div className="grid grid-cols-1 gap-2">
                  {[
                    "Tropical Nalukettu reimagined with glass and steel in Wayanad",
                    "Ultra-minimalist concrete studio in Kochi with vertical gardens",
                    "Luxury seaside mansion in Alappuzha with infinity pool and sunset view"
                  ].map((p, i) => (
                    <button
                      key={i}
                      onClick={() => setCustomPrompt(p)}
                      className="text-left p-4 bg-white/5 border border-white/5 rounded-sm hover:bg-white/10 hover:border-amber-500/30 transition-all group"
                    >
                      <p className="text-[11px] text-slate-400 group-hover:text-white transition-colors flex items-center justify-between">
                        "{p}"
                        <Sparkles className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Visualization Stage */}
          <div className="lg:w-3/5 flex flex-col gap-8 w-full">
            <div className="bg-slate-900 w-full rounded-sm border border-white/5 relative shadow-inner flex items-center justify-center overflow-hidden h-[600px] group">
              <AnimatePresence mode="wait">
                {isGenerating ? (
                <div className="flex flex-col items-center gap-8 z-20 pointer-events-none p-12 text-center">
                  <div className="relative">
                    <motion.div 
                      className="absolute inset-0 bg-amber-500/20 rounded-full blur-2xl"
                      animate={{ scale: [1, 2, 1], opacity: [0.3, 0.8, 0.3] }}
                      transition={{ duration: 2.5, repeat: Infinity }}
                    />
                    <Loader2 className="w-16 h-16 animate-spin text-amber-500 relative z-10" />
                  </div>
                  <div className="space-y-3">
                    <div className="text-[14px] font-bold text-white uppercase tracking-[0.5em] animate-pulse">
                      Neural Synthesis in Progress
                    </div>
                    <div className="text-[10px] font-medium text-slate-500 uppercase tracking-[0.3em]">
                      Decoding architectural motifs • Rendering materials
                    </div>
                  </div>
                </div>
                ) : showResult ? (
                  <motion.div
                    key={currentImage}
                    initial={{ opacity: 0, scale: 1.05 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
                    className="absolute inset-0"
                  >
                    <img 
                      src={currentImage} 
                      alt="AI Generated Design" 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent" />
                    
                    {/* UI Overlays on Image */}
                    <div className="absolute top-8 left-8 flex flex-col gap-3">
                       <motion.div 
                         initial={{ x: -20, opacity: 0 }}
                         animate={{ x: 0, opacity: 1 }}
                         transition={{ delay: 0.3 }}
                         className="flex items-center gap-3"
                       >
                         <span className="bg-amber-600 px-4 py-1.5 text-[10px] font-bold text-white uppercase tracking-[0.3em] rounded-sm shadow-xl">
                            Live Render
                         </span>
                         <span className="bg-slate-950/90 backdrop-blur-xl px-4 py-1.5 text-[10px] font-bold text-slate-400 border border-white/10 uppercase tracking-[0.3em] rounded-sm">
                            v3.1 Flash Image
                         </span>
                       </motion.div>
                       
                       {generationError && (
                         <motion.div 
                           initial={{ opacity: 0, y: -10 }}
                           animate={{ opacity: 1, y: 0 }}
                           className="bg-red-950/90 backdrop-blur-xl border border-red-500/50 p-6 rounded-sm max-w-sm shadow-2xl"
                         >
                           <p className="text-[10px] text-red-100 font-medium leading-relaxed">
                             <strong className="text-red-400 block mb-1.5 uppercase tracking-tighter">System Alert: Gen Error</strong>
                             {generationError}
                           </p>
                         </motion.div>
                       )}

                       {generationNotice && (
                         <motion.div 
                           initial={{ opacity: 0, y: -10 }}
                           animate={{ opacity: 1, y: 0 }}
                           className="bg-amber-950/90 backdrop-blur-xl border border-amber-500/50 p-6 rounded-sm max-w-sm shadow-2xl"
                         >
                           <p className="text-[10px] text-amber-100 font-medium leading-relaxed">
                             <strong className="text-amber-400 block mb-1.5 uppercase tracking-tighter">Optimized Fallback Active</strong>
                             {generationNotice}
                           </p>
                         </motion.div>
                       )}
                    </div>

                    <div className="absolute bottom-8 right-8 flex gap-3 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                      <button className="p-4 bg-white/10 backdrop-blur-xl border border-white/10 text-white hover:bg-amber-500 hover:text-slate-950 transition-all rounded-full shadow-2xl">
                        <Download className="w-5 h-5" />
                      </button>
                      <button className="p-4 bg-white/10 backdrop-blur-xl border border-white/10 text-white hover:bg-amber-500 hover:text-slate-950 transition-all rounded-full shadow-2xl">
                        <Share2 className="w-5 h-5" />
                      </button>
                    </div>

                    <motion.div 
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.6 }}
                      className="absolute bottom-8 left-8 right-8 p-8 max-w-2xl bg-slate-950/40 backdrop-blur-md border border-white/5 rounded-sm"
                    >
                       <div className="flex items-start gap-6">
                         <div className="w-12 h-12 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0 border border-amber-500/30">
                           <Sparkles className="w-6 h-6 text-amber-500" />
                         </div>
                         <div className="space-y-2">
                           <div className="flex items-center gap-3">
                             <p className="text-[11px] text-amber-500 font-bold uppercase tracking-widest">Architectural Commentary</p>
                             <div className="h-[1px] w-12 bg-amber-500/30" />
                           </div>
                           <p className="text-sm text-slate-200 leading-relaxed font-light italic">
                             {activePrompt ? (
                               <>
                                 "The generated visualization emphasizes <strong>structural harmony</strong> and <strong>material authenticity</strong> based on your prompt. The composition suggests a design that respects both modern minimalism and regional climate considerations."
                               </>
                             ) : (
                               "Visual engine standing by. Please provide a description of your desired architectural space to begin the synthesis process."
                             )}
                           </p>
                         </div>
                       </div>
                    </motion.div>
                  </motion.div>
                ) : null}
              </AnimatePresence>

              {/* Scanning Effect Overlay */}
              {isGenerating && (
                <motion.div 
                  className="absolute inset-x-0 h-1 bg-amber-600/50 shadow-[0_0_15px_rgba(217,119,6,0.5)] z-30"
                  animate={{ top: ['0%', '100%', '0%'] }}
                  transition={{ repeat: Infinity, duration: 2, ease: 'linear' }}
                />
              )}
            </div>
            
            {/* Visual Specs */}
            <div className="flex flex-wrap gap-3">
              {[
                { label: 'Latency', val: '~2.2s' },
                { label: 'Resolution', val: '4K Ultra-Res' },
                { label: 'AI Model', val: 'Gemini 3.1' },
                { label: 'Style', val: architecturalStyle }
              ].map((stat, i) => (
                <div key={i} className="flex-1 min-w-[140px] bg-slate-900 border border-white/5 p-4 rounded-sm">
                  <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest mb-1">{stat.label}</p>
                  <p className="text-xs text-white font-medium">{stat.val}</p>
                </div>
              ))}
            </div>

            {/* History Rail */}
            <div className="space-y-6 pt-4">
              <div className="flex items-center justify-between">
                <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.3em] flex items-center gap-2">
                   <History className="w-3.5 h-3.5" /> Recent Masterpieces
                </h3>
                {history.length > 0 && (
                  <button 
                    onClick={() => {
                      setHistory([]);
                      localStorage.removeItem('aps_design_history');
                    }}
                    className="text-[9px] text-slate-600 hover:text-red-400 transition-colors uppercase font-bold tracking-widest"
                  >
                    Clear History
                  </button>
                )}
              </div>

              <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
                {history.length === 0 ? (
                  <div className="w-full py-8 border border-white/5 border-dashed rounded-sm flex items-center justify-center">
                    <p className="text-[9px] text-slate-700 font-bold uppercase tracking-widest italic">No iterations found in local cache</p>
                  </div>
                ) : (
                  history.map((item, idx) => (
                    <motion.button
                      key={item.timestamp}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: idx * 0.1 }}
                      onClick={() => setCurrentImage(item.url)}
                      className={`group relative w-32 aspect-square shrink-0 rounded-sm overflow-hidden border-2 transition-all ${
                        currentImage === item.url ? 'border-amber-500' : 'border-white/5 grayscale hover:grayscale-0'
                      }`}
                    >
                      <img src={item.url} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-slate-950/40 group-hover:bg-transparent transition-colors" />
                    </motion.button>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
