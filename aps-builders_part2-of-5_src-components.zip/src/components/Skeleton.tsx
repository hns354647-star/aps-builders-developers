import React from 'react';
import { motion } from 'motion/react';
import { LucideIcon, Building2 } from 'lucide-react';

interface SkeletonProps {
  className?: string;
  icon?: LucideIcon;
  variant?: 'default' | 'blueprint' | 'card' | 'text' | 'badge';
  shimmerSpeed?: number;
}

export default function Skeleton({ 
  className = "", 
  icon: Icon = Building2,
  variant = 'default',
  shimmerSpeed = 1.6
}: SkeletonProps) {
  return (
    <div className={`relative bg-slate-100/90 overflow-hidden select-none ${className}`}>
      {/* Blueprint grid texture for architectural feel */}
      {variant === 'blueprint' && (
        <div 
          className="absolute inset-0 opacity-[0.35] bg-[radial-gradient(#94a3b8_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" 
          aria-hidden="true"
        />
      )}

      {/* Center Icon Watermark */}
      {Icon && (
        <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-300 pointer-events-none">
          <motion.div
            animate={{ 
              opacity: [0.35, 0.65, 0.35],
              scale: [0.98, 1.02, 0.98]
            }}
            transition={{ 
              duration: 2.2, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
            className="flex flex-col items-center gap-1.5"
          >
            <Icon className="w-10 h-10 stroke-[1.2px] text-slate-400/80" />
            <span className="text-[9px] font-mono uppercase tracking-widest text-slate-400/70 font-semibold">
              Loading Blueprint...
            </span>
          </motion.div>
        </div>
      )}

      {/* Shimmer Light Beam */}
      <motion.div 
        initial={{ x: "-150%" }}
        animate={{ x: "150%" }}
        transition={{ 
          repeat: Infinity, 
          duration: shimmerSpeed, 
          ease: "easeInOut",
        }}
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/75 to-transparent skew-x-12 pointer-events-none will-change-transform"
      />

      {/* Subtle corner drafting tick marks for architectural cards */}
      {variant === 'blueprint' && (
        <>
          <div className="absolute top-2 left-2 w-2 h-2 border-t border-l border-slate-300/80" />
          <div className="absolute top-2 right-2 w-2 h-2 border-t border-r border-slate-300/80" />
          <div className="absolute bottom-2 left-2 w-2 h-2 border-b border-l border-slate-300/80" />
          <div className="absolute bottom-2 right-2 w-2 h-2 border-b border-r border-slate-300/80" />
        </>
      )}
    </div>
  );
}
