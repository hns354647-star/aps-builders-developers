import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, Globe, ArrowUpRight, Sparkles, Code2, Film, Palette, Layers } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

interface NavProps {
  onOpenMascotChat: () => void;
  onOpenPlanModal?: () => void;
}

export const Nav: React.FC<NavProps> = ({ onOpenMascotChat, onOpenPlanModal }) => {
  const { lang, toggleLang, t } = useLanguage();
  const [megaMenuOpen, setMegaMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMegaMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Floating Pill Navigation Header */}
      <header className="fixed top-5 left-1/2 -translate-x-1/2 z-50 w-full max-w-5xl px-4 pointer-events-none">
        <nav
          className={`pointer-events-auto flex items-center justify-between px-5 py-3 rounded-full transition-all duration-300 ${
            scrolled
              ? 'bg-[#18201b]/85 backdrop-blur-xl border border-white/15 shadow-2xl text-white'
              : 'bg-[#2b362f]/70 backdrop-blur-lg border border-white/20 shadow-lg text-white'
          }`}
          aria-label="Main Navigation"
        >
          {/* Logo Mark */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="flex items-center gap-2 group cursor-pointer"
              aria-label="Studio Monolith Home"
            >
              <div className="w-8 h-8 rounded-lg bg-[#ff6a1a] flex items-center justify-center font-bold text-white text-sm shadow-md shadow-[#ff6a1a]/30 group-hover:scale-105 transition-transform">
                //
              </div>
              <span className="font-extrabold text-sm tracking-wider uppercase font-sans">
                MONOLITH
              </span>
            </button>
          </div>

          {/* Center Links with Mega-Menu Trigger */}
          <div className="hidden md:flex items-center gap-1 text-xs font-semibold uppercase tracking-wider">
            <button
              onClick={() => setMegaMenuOpen(!megaMenuOpen)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
              aria-expanded={megaMenuOpen}
            >
              <span>{t.nav.services}</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform ${megaMenuOpen ? 'rotate-180' : ''}`} />
            </button>
            <button
              onClick={() => scrollToSection('cases-section')}
              className="px-3 py-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            >
              {t.nav.cases}
            </button>
            <button
              onClick={() => scrollToSection('process-section')}
              className="px-3 py-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            >
              {t.nav.process}
            </button>
            <button
              onClick={() => scrollToSection('pricing-section')}
              className="px-3 py-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            >
              {t.nav.pricing}
            </button>
            <button
              onClick={() => scrollToSection('team-section')}
              className="px-3 py-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            >
              {t.nav.team}
            </button>
          </div>

          {/* Right Controls: Mascot Chat, Language Toggle & Primary CTA */}
          <div className="flex items-center gap-2.5">
            {/* Ask Mascot Quick Icon */}
            <button
              onClick={onOpenMascotChat}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-[#ff6a1a]/20 border border-white/15 hover:border-[#ff6a1a]/50 text-xs transition-colors cursor-pointer"
              title="Ask Mascot Bo"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#ff6a1a]" />
              <span className="font-medium text-[11px]">Bo AI</span>
            </button>

            {/* Language Switch Button */}
            <button
              onClick={toggleLang}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-full bg-white/10 hover:bg-white/20 transition-colors text-xs font-bold cursor-pointer"
              aria-label={`Switch language to ${lang === 'nl' ? 'English' : 'Dutch'}`}
            >
              <Globe className="w-3.5 h-3.5 text-stone-300" />
              <span>{lang.toUpperCase()}</span>
            </button>

            {/* Primary Magnetic CTA - Opens Squared Media Plan a Call Modal */}
            <button
              onClick={() => {
                if (onOpenPlanModal) {
                  onOpenPlanModal();
                } else {
                  scrollToSection('final-cta-section');
                }
              }}
              className="px-4 py-1.5 rounded-full bg-[#ff6a1a] hover:bg-[#ff7e36] text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-[#ff6a1a]/35 cursor-pointer hover:scale-105 active:scale-95"
            >
              {t.nav.bookCall}
            </button>
          </div>
        </nav>
      </header>

      {/* Interactive Mega-Menu Backdrop & Drawer */}
      <AnimatePresence>
        {megaMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.25 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-40 w-full max-w-4xl px-4 pointer-events-auto"
          >
            <div className="bg-[#121915]/95 backdrop-blur-2xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl text-white">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {/* Column 1: Services */}
                <div>
                  <h4 className="text-xs font-bold text-[#ff6a1a] uppercase tracking-widest mb-3 flex items-center gap-1.5">
                    <Palette className="w-3.5 h-3.5" />
                    <span>{t.nav.megaMenu.servicesTitle}</span>
                  </h4>
                  <ul className="space-y-2 text-xs font-medium text-stone-300">
                    <li
                      onClick={() => scrollToSection('services-section')}
                      className="hover:text-white cursor-pointer transition-colors"
                    >
                      UI/UX & Design Systems
                    </li>
                    <li
                      onClick={() => scrollToSection('services-section')}
                      className="hover:text-white cursor-pointer transition-colors"
                    >
                      WebGL & Three.js Architecture
                    </li>
                    <li
                      onClick={() => scrollToSection('services-section')}
                      className="hover:text-white cursor-pointer transition-colors"
                    >
                      3D Film & Commercial CGI
                    </li>
                    <li
                      onClick={() => scrollToSection('services-section')}
                      className="hover:text-white cursor-pointer transition-colors"
                    >
                      AI Workflow Integration
                    </li>
                  </ul>
                </div>

                {/* Column 2: Selected Work */}
                <div>
                  <h4 className="text-xs font-bold text-[#ff6a1a] uppercase tracking-widest mb-3 flex items-center gap-1.5">
                    <Code2 className="w-3.5 h-3.5" />
                    <span>{t.nav.megaMenu.workTitle}</span>
                  </h4>
                  <ul className="space-y-2 text-xs font-medium text-stone-300">
                    <li
                      onClick={() => scrollToSection('cases-section')}
                      className="hover:text-white cursor-pointer transition-colors"
                    >
                      Aura Spatial Audio
                    </li>
                    <li
                      onClick={() => scrollToSection('cases-section')}
                      className="hover:text-white cursor-pointer transition-colors"
                    >
                      Polaris EV Cockpit 3D
                    </li>
                    <li
                      onClick={() => scrollToSection('cases-section')}
                      className="hover:text-white cursor-pointer transition-colors"
                    >
                      Kinetics Brand Platform
                    </li>
                    <li
                      onClick={() => scrollToSection('cases-section')}
                      className="hover:text-white cursor-pointer transition-colors"
                    >
                      Vanguard Quantum Lab
                    </li>
                  </ul>
                </div>

                {/* Column 3: Tools & Pipeline */}
                <div>
                  <h4 className="text-xs font-bold text-[#ff6a1a] uppercase tracking-widest mb-3 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5" />
                    <span>{t.nav.megaMenu.toolsTitle}</span>
                  </h4>
                  <ul className="space-y-2 text-xs font-medium text-stone-300">
                    <li className="flex items-center gap-1.5">Next.js 14 App Router</li>
                    <li className="flex items-center gap-1.5">Three.js & R3F (Fiber)</li>
                    <li className="flex items-center gap-1.5">GSAP & ScrollTrigger</li>
                    <li className="flex items-center gap-1.5">Lenis Smooth Scroll</li>
                  </ul>
                </div>

                {/* Column 4: Featured Case Card */}
                <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-[#ff6a1a] uppercase tracking-widest block mb-1">
                      {t.nav.megaMenu.featuredCase}
                    </span>
                    <h5 className="font-bold text-sm text-white mb-1">
                      Aura Spatial Audio
                    </h5>
                    <p className="text-xs text-stone-300 font-light leading-relaxed">
                      {t.nav.megaMenu.featuredCaseDesc}
                    </p>
                  </div>
                  <button
                    onClick={() => scrollToSection('cases-section')}
                    className="mt-4 flex items-center gap-1 text-xs font-bold text-[#ff6a1a] hover:underline cursor-pointer"
                  >
                    <span>{t.nav.megaMenu.viewCase}</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
