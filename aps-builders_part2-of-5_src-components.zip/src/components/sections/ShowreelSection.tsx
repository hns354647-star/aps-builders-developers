import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Volume2, VolumeX, Play, Sparkles, Maximize2 } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

export const ShowreelSection: React.FC<{ scrollProgress: number }> = ({ scrollProgress }) => {
  const { t } = useLanguage();
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);

  // Calculate dynamic scale from card to wider presentation based on progress in showreel phase (~0.5 - 0.6)
  const reelProgress = Math.max(0, Math.min(1, (scrollProgress - 0.48) * 6.0));
  const cardScale = 0.9 + reelProgress * 0.12;

  return (
    <section className="relative py-28 px-4 sm:px-6 max-w-7xl mx-auto w-full z-10">
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-xs font-semibold text-[#18211b] tracking-wider uppercase mb-3 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-[#ff6a1a]" />
          <span>{t.showreel.badge}</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-black text-[#141a3a] tracking-tight font-sans">
          {t.showreel.title}
        </h2>
        <p className="text-xs sm:text-sm text-[#38493d] mt-2 font-medium">
          {t.showreel.caption}
        </p>
      </div>

      {/* Scrub-Driven Video / Cinematic Canvas Frame */}
      <motion.div
        style={{ scale: cardScale }}
        className="relative mx-auto rounded-[28px] overflow-hidden shadow-2xl border border-white/20 bg-[#0d1310] h-[340px] sm:h-[480px] lg:h-[560px] flex items-center justify-center group"
      >
        {/* Synthetic Photorealistic Showreel Canvas Visual */}
        <div className="absolute inset-0 bg-gradient-to-tr from-[#0a0f0d] via-[#1b251f] to-[#121c16] flex flex-col items-center justify-center p-8 text-center select-none">
          {/* Animated Ambient Ring */}
          <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border border-[#ff6a1a]/40 flex items-center justify-center relative mb-6 group-hover:scale-105 transition-transform">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#ff6a1a] flex items-center justify-center text-white shadow-2xl shadow-[#ff6a1a]/50">
              <Play className="w-6 h-6 sm:w-8 sm:h-8 fill-white translate-x-0.5" />
            </div>
            <div className="absolute inset-0 rounded-full border border-white/20 animate-ping opacity-30" />
          </div>

          <span className="text-xs font-bold uppercase tracking-[0.3em] text-[#ff6a1a] mb-2">
            STUDIO MONOLITH // CINEMATIC REEL
          </span>
          <h3 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight max-w-xl mb-3">
            Realtime 3D, Shaders & Kinetic Motion
          </h3>
          <p className="text-xs sm:text-sm text-stone-300 max-w-md font-light">
            Crafting tactile digital landmarks that elevate tech visionaries into category leaders.
          </p>

          {/* Scrub Indicator */}
          <div className="absolute bottom-5 left-6 right-6 flex items-center justify-between text-xs text-stone-400 font-mono">
            <span>SCRUB: {Math.round(reelProgress * 100)}%</span>
            <span className="text-[10px] uppercase tracking-wider text-stone-400 hidden sm:inline">
              {t.showreel.scrollExpand}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white text-[11px] transition-colors cursor-pointer"
              >
                {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-[#ff6a1a]" />}
                <span>{isMuted ? t.showreel.soundOff : t.showreel.soundOn}</span>
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  );
};
