import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, ArrowUpRight, Users, Briefcase } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

export const TeamSection: React.FC = () => {
  const { t } = useLanguage();

  const scrollToContact = () => {
    document.getElementById('final-cta-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="team-section" className="relative py-28 px-6 max-w-7xl mx-auto w-full z-10 scroll-mt-24">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-xs font-semibold text-[#18211b] tracking-wider uppercase mb-3 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-[#ff6a1a]" />
          <span>{t.team.badge}</span>
        </div>
        <h2 className="text-4xl sm:text-6xl font-black text-[#141a3a] tracking-tight leading-tight font-sans">
          {t.team.title}
        </h2>
        <p className="text-base sm:text-lg text-[#324538] mt-3 font-medium">
          {t.team.subtitle}
        </p>
      </div>

      {/* Member Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {t.team.members.map((member, idx) => (
          <div
            key={idx}
            className="bg-[#18211b]/85 backdrop-blur-2xl border border-white/20 hover:border-[#ff6a1a]/50 rounded-[28px] p-6 shadow-2xl text-white flex flex-col justify-between transition-all hover:scale-105 duration-300 group"
          >
            <div>
              {/* Stylized Avatar Placeholder */}
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center font-bold text-xl text-white mb-5 shadow-lg group-hover:scale-110 transition-transform"
                style={{ backgroundColor: member.avatarColor }}
              >
                {member.name[0]}
              </div>

              <h3 className="text-xl font-extrabold text-white mb-1 group-hover:text-[#ff8438] transition-colors">
                {member.name}
              </h3>
              <span className="text-xs font-bold text-[#ff6a1a] uppercase tracking-wider block mb-3">
                {member.role}
              </span>
              <p className="text-xs text-stone-300 font-light leading-relaxed">
                {member.specialty}
              </p>
            </div>

            <div className="pt-4 mt-6 border-t border-white/10 flex items-center justify-between text-[11px] text-stone-400 font-mono">
              <span>AMSTERDAM // AMS</span>
              <span className="text-emerald-400 font-bold">ACTIVE</span>
            </div>
          </div>
        ))}
      </div>

      {/* Hiring Banner */}
      <div className="bg-gradient-to-r from-[#213025] via-[#1a251e] to-[#213025] border border-white/20 rounded-[28px] p-8 sm:p-10 shadow-2xl text-white flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <span className="inline-block px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest bg-[#ff6a1a] text-white mb-3">
            {t.team.hiringBanner.tag}
          </span>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-white mb-2">
            {t.team.hiringBanner.title}
          </h3>
          <p className="text-xs sm:text-sm text-stone-300 font-light max-w-xl">
            {t.team.hiringBanner.desc}
          </p>
        </div>

        <button
          onClick={scrollToContact}
          className="px-6 py-4 rounded-full bg-white hover:bg-stone-200 text-[#141a3a] font-bold text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer flex items-center gap-2 whitespace-nowrap self-start md:self-auto"
        >
          <span>{t.team.hiringBanner.cta}</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>
    </section>
  );
};
