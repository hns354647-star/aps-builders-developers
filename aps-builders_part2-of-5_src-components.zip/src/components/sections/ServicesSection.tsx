import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, Play, Sparkles, Layers, Code2, Film, FileText, ArrowRight } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

type TabKey = 'design' | 'build' | 'film' | 'content';

export const ServicesSection: React.FC = () => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<TabKey>('design');

  const currentData = t.services.tabs[activeTab];

  const icons: Record<TabKey, React.ComponentType<{ className?: string }>> = {
    design: Layers,
    build: Code2,
    film: Film,
    content: FileText
  };

  const ActiveIcon = icons[activeTab];

  return (
    <section id="services-section" className="relative py-28 px-6 max-w-7xl mx-auto w-full z-10 scroll-mt-24">
      {/* Editorial Header */}
      <div className="mb-14 max-w-3xl">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-xs font-semibold text-[#18211b] tracking-wider uppercase mb-3 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-[#ff6a1a]" />
          <span>{t.services.badge}</span>
        </div>
        <h2 className="text-4xl sm:text-6xl font-black text-[#141a3a] tracking-tight leading-tight mb-4 font-sans">
          {t.services.title}
        </h2>
        <p className="text-base sm:text-lg text-[#324337] leading-relaxed font-medium">
          {t.services.subtitle}
        </p>
      </div>

      {/* Glass Showcase Card */}
      <div className="bg-[#18211b]/85 backdrop-blur-2xl border border-white/20 rounded-[28px] p-6 sm:p-10 shadow-2xl text-white">
        {/* Tab Navigation Controls */}
        <div className="flex flex-wrap items-center gap-2 mb-8 pb-6 border-b border-white/15">
          {(['design', 'build', 'film', 'content'] as TabKey[]).map((tabKey) => {
            const Icon = icons[tabKey];
            const isActive = activeTab === tabKey;
            return (
              <button
                key={tabKey}
                onClick={() => setActiveTab(tabKey)}
                className={`flex items-center gap-2 px-5 py-3 rounded-full text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#ff6a1a] text-white shadow-lg shadow-[#ff6a1a]/30 scale-105'
                    : 'bg-white/10 text-stone-300 hover:bg-white/15 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{t.services.tabs[tabKey].label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Stage */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center"
          >
            {/* Left Narrative */}
            <div className="lg:col-span-7 space-y-5">
              <span className="text-xs font-bold text-[#ff6a1a] uppercase tracking-widest block">
                {currentData.tag}
              </span>
              <h3 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight leading-snug">
                {currentData.heading}
              </h3>
              <p className="text-sm sm:text-base text-stone-300 font-light leading-relaxed">
                {currentData.desc}
              </p>

              {/* Bullet Points */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3">
                {currentData.bullets.map((bullet, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-stone-200">
                    <CheckCircle2 className="w-4 h-4 text-[#ff6a1a] shrink-0 mt-0.5" />
                    <span className="font-medium">{bullet}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4">
                <button
                  onClick={() => document.getElementById('pricing-section')?.scrollIntoView({ behavior: 'smooth' })}
                  className="inline-flex items-center gap-2 text-xs font-bold text-[#ff6a1a] hover:text-white uppercase tracking-wider transition-colors cursor-pointer group"
                >
                  <span>Bekijk tarieven voor {currentData.label}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>

            {/* Right Interactive Simulated 3D / Video Preview Stage */}
            <div className="lg:col-span-5 relative h-72 sm:h-80 rounded-2xl overflow-hidden bg-black/40 border border-white/10 group">
              {/* Dynamic canvas visualizer representation per tab */}
              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#202d25] to-[#0c120f]">
                <div className="w-16 h-16 rounded-2xl bg-[#ff6a1a]/20 border border-[#ff6a1a]/50 flex items-center justify-center text-[#ff6a1a] mb-4 shadow-lg group-hover:scale-110 transition-transform">
                  <ActiveIcon className="w-8 h-8" />
                </div>
                <span className="text-xs font-bold uppercase tracking-widest text-[#ff6a1a] mb-1">
                  Preview // {currentData.label}
                </span>
                <h4 className="text-lg font-bold text-white mb-2">
                  WebGL 60FPS Architecture
                </h4>
                <p className="text-xs text-stone-400 max-w-xs font-light">
                  Handcrafted responsive shaders, physics constraints, and zero-jank micro-interactions.
                </p>

                {/* Looping Ambient Simulation Pulse */}
                <div className="absolute bottom-3 left-4 flex items-center gap-2 text-[10px] text-emerald-400 font-mono">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>Realtime WebGL Stream</span>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
};
