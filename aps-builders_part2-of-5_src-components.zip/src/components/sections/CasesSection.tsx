import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUpRight, Sparkles, Tag, Calendar } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

export const CasesSection: React.FC = () => {
  const { t } = useLanguage();
  const [hoveredCase, setHoveredCase] = useState<string | null>(null);

  return (
    <section id="cases-section" className="relative py-28 px-6 max-w-7xl mx-auto w-full z-10 scroll-mt-24">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
        <div>
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-xs font-semibold text-[#18211b] tracking-wider uppercase mb-3 shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-[#ff6a1a]" />
            <span>{t.cases.badge}</span>
          </div>
          <h2 className="text-4xl sm:text-6xl font-black text-[#141a3a] tracking-tight font-sans">
            {t.cases.title}
          </h2>
          <p className="text-sm sm:text-base text-[#384a3e] mt-2 font-medium">
            {t.cases.subtitle}
          </p>
        </div>
      </div>

      {/* Case Studies Interactive List */}
      <div className="bg-[#18211b]/85 backdrop-blur-2xl border border-white/20 rounded-[28px] overflow-hidden shadow-2xl text-white divide-y divide-white/10">
        {t.cases.items.map((item, index) => {
          const isHovered = hoveredCase === item.id;
          return (
            <div
              key={item.id}
              onMouseEnter={() => setHoveredCase(item.id)}
              onMouseLeave={() => setHoveredCase(null)}
              className="p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:bg-white/5 transition-all group cursor-pointer relative"
            >
              {/* Left Identity */}
              <div className="flex items-center gap-5">
                <span className="font-mono text-xs font-bold text-stone-400">
                  {(index + 1).toString().padStart(2, '0')}
                </span>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#ff6a1a] block mb-1">
                    {item.client}
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-white group-hover:text-[#ff8438] transition-colors leading-tight">
                    {item.title}
                  </h3>
                  <span className="text-xs text-stone-300 font-light mt-0.5 block">
                    {item.category}
                  </span>
                </div>
              </div>

              {/* Tags & Year */}
              <div className="flex flex-wrap items-center gap-2 md:justify-end">
                {item.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 rounded-full text-[10px] font-medium uppercase tracking-wider bg-white/10 text-stone-300 border border-white/5"
                  >
                    {tag}
                  </span>
                ))}
                <span className="text-xs font-mono text-stone-400 ml-2">
                  {item.year}
                </span>

                <div className="w-10 h-10 rounded-full bg-white/5 group-hover:bg-[#ff6a1a] text-white flex items-center justify-center transition-all ml-2 group-hover:scale-110">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>

              {/* Floating Hover Preview Card (Simulated interactive visual teaser) */}
              <AnimatePresence>
                {isHovered && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9, x: 20 }}
                    animate={{ opacity: 1, scale: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.9, x: 20 }}
                    transition={{ duration: 0.2 }}
                    className="hidden lg:block absolute right-32 top-1/2 -translate-y-1/2 w-64 h-36 rounded-2xl overflow-hidden shadow-2xl border border-white/20 pointer-events-none z-30 bg-[#0d1310]"
                  >
                    <div
                      className="w-full h-full flex flex-col justify-end p-4 text-white"
                      style={{
                        background: `linear-gradient(135deg, ${item.accentColor}33, #090e0c)`
                      }}
                    >
                      <span className="text-[10px] font-bold uppercase tracking-wider text-white/80">
                        Live Preview // {item.year}
                      </span>
                      <h4 className="font-extrabold text-sm text-white">
                        {item.title}
                      </h4>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </section>
  );
};
