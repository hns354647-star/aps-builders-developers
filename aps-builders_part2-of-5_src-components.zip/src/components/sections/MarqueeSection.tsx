import React from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../../i18n/LanguageContext';

export const MarqueeSection: React.FC = () => {
  const { t } = useLanguage();
  const clients = t.marquee.clients;

  return (
    <section className="relative py-16 overflow-hidden select-none z-10">
      <div className="max-w-7xl mx-auto px-6 mb-6 text-center">
        <span className="text-[11px] font-bold text-[#44584b] uppercase tracking-[0.28em] font-sans">
          {t.marquee.title}
        </span>
      </div>

      {/* Row 1: Left to right ticker, pauses on hover */}
      <div className="flex overflow-hidden py-3 border-y border-white/20 bg-white/10 backdrop-blur-md group cursor-default">
        <motion.div
          className="flex whitespace-nowrap gap-12 text-sm sm:text-base font-extrabold uppercase tracking-widest text-[#18211b] group-hover:[animation-play-state:paused]"
          animate={{ x: [0, -1000] }}
          transition={{ repeat: Infinity, ease: 'linear', duration: 24 }}
        >
          {[...clients, ...clients, ...clients].map((client, i) => (
            <div key={i} className="flex items-center gap-12">
              <span className="hover:text-[#ff6a1a] transition-colors">{client}</span>
              <span className="text-[#ff6a1a] text-xs">//</span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Row 2: Right to left ticker */}
      <div className="flex overflow-hidden py-3 border-b border-white/15 bg-white/5 backdrop-blur-sm group mt-2">
        <motion.div
          className="flex whitespace-nowrap gap-12 text-xs sm:text-sm font-bold uppercase tracking-wider text-[#35483c] group-hover:[animation-play-state:paused]"
          animate={{ x: [-1000, 0] }}
          transition={{ repeat: Infinity, ease: 'linear', duration: 28 }}
        >
          {[...clients, ...clients, ...clients].reverse().map((client, i) => (
            <div key={i} className="flex items-center gap-12">
              <span className="hover:text-[#141a3a] transition-colors">{client}</span>
              <span className="text-stone-400 text-xs">•</span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};
