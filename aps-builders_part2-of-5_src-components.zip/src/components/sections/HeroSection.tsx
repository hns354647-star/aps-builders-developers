import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight, Clock, MessageSquare, Sparkles } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

interface HeroSectionProps {
  onOpenMascotChat: () => void;
  onOpenPlanModal?: () => void;
  scrollProgress: number;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenMascotChat,
  onOpenPlanModal,
  scrollProgress
}) => {
  const { t } = useLanguage();
  const [localTime, setLocalTime] = useState('');

  // Live Studio Clock (Amsterdam / Visitor timezone awareness)
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setLocalTime(
        now.toLocaleTimeString('nl-NL', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const scrollToCases = () => {
    document.getElementById('cases-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToContact = () => {
    document.getElementById('final-cta-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  // Word opacity and scale driven by scroll progress
  const wordScale = 1 + scrollProgress * 1.4;
  const wordOpacity = Math.max(0, 1 - scrollProgress * 3.5);

  return (
    <section className="relative min-h-screen flex flex-col justify-between pt-32 pb-16 px-6 max-w-7xl mx-auto w-full">
      {/* 1. Giant Brand Word Sitting BEHIND the Island (Z-Order: Word - Canvas - DOM Cards) */}
      <div
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none select-none z-[-1] whitespace-nowrap text-center"
        style={{
          transform: `translate(-50%, -50%) scale(${wordScale})`,
          opacity: wordOpacity
        }}
      >
        <span className="text-[18vw] font-black tracking-tighter text-[#1f2822]/20 font-sans leading-none block">
          MONOLITH
        </span>
      </div>

      {/* 2. Top Kicker & Live Clock Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 z-10">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-xs font-semibold text-[#18211b] tracking-wider uppercase shadow-sm"
        >
          <span className="w-2 h-2 rounded-full bg-[#ff6a1a] animate-pulse" />
          <span>{t.hero.badge}</span>
        </motion.div>

        {/* Live Studio Clock Badge */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#18201b]/80 backdrop-blur-md text-white text-xs font-mono border border-white/15 shadow-sm"
        >
          <Clock className="w-3.5 h-3.5 text-[#ff6a1a]" />
          <span className="text-stone-400">{t.hero.liveTime}:</span>
          <span className="font-bold text-white">{localTime || '12:00:00'} (AMS)</span>
        </motion.div>
      </div>

      {/* 3. Main Headline & Pitch Card */}
      <div className="my-auto py-12 max-w-3xl z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <h1 className="text-5xl sm:text-7xl lg:text-8xl font-black text-[#141a3a] tracking-tight leading-[0.98] mb-6 font-sans">
            {t.hero.title1} <br />
            <span className="text-[#ff6a1a] italic font-serif font-normal">
              {t.hero.title2}
            </span>
          </h1>

          <p className="text-base sm:text-xl text-[#313f36] leading-relaxed max-w-2xl font-medium mb-8">
            {t.hero.subtitle}
          </p>

          <div className="flex flex-wrap items-center gap-4">
            <button
              onClick={() => {
                if (onOpenPlanModal) {
                  onOpenPlanModal();
                } else {
                  scrollToContact();
                }
              }}
              className="px-8 py-4 rounded-full bg-[#ff6a1a] hover:bg-[#ff7e36] text-white font-bold text-xs uppercase tracking-widest shadow-xl shadow-[#ff6a1a]/30 transition-all hover:scale-105 active:scale-95 cursor-pointer flex items-center gap-2"
            >
              <span>{t.hero.bookCall}</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>

            <button
              onClick={scrollToCases}
              className="px-8 py-4 rounded-full bg-[#18201b]/80 hover:bg-[#18201b] text-white font-bold text-xs uppercase tracking-widest border border-white/20 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              {t.hero.viewWork}
            </button>

            {/* Quick Mascot Ask Button */}
            <button
              onClick={onOpenMascotChat}
              className="px-5 py-4 rounded-full bg-white/30 hover:bg-white/50 backdrop-blur-md text-[#18201b] font-bold text-xs uppercase tracking-wider border border-white/40 transition-all cursor-pointer flex items-center gap-2"
            >
              <MessageSquare className="w-3.5 h-3.5 text-[#ff6a1a]" />
              <span className="hidden sm:inline">{t.hero.askMascot}</span>
              <span className="sm:hidden">Ask Bo</span>
            </button>
          </div>
        </motion.div>
      </div>

      {/* 4. Bottom Scroll Hint */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="flex items-center justify-between text-xs font-semibold text-[#415347] tracking-widest uppercase z-10 border-t border-[#415347]/20 pt-4"
      >
        <span className="flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-[#ff6a1a]" />
          <span>Next.js 14 + WebGL + Three.js</span>
        </span>
        <span className="animate-bounce">↓ {t.hero.scrollHint}</span>
      </motion.div>
    </section>
  );
};
