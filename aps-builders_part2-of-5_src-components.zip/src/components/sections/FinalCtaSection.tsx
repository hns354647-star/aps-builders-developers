import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, ArrowUpRight, Mail, Phone, Calendar, Check, Send } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

interface FinalCtaSectionProps {
  onOpenPlanModal?: () => void;
}

export const FinalCtaSection: React.FC<FinalCtaSectionProps> = ({ onOpenPlanModal }) => {
  const { t } = useLanguage();
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setEmail('');
      setName('');
    }, 4000);
  };

  return (
    <section id="final-cta-section" className="relative py-32 px-6 max-w-7xl mx-auto w-full z-10 scroll-mt-24">
      <div className="bg-[#121915]/90 backdrop-blur-3xl border border-white/20 rounded-[32px] p-8 sm:p-16 shadow-2xl text-white text-center relative overflow-hidden">
        {/* Subtle Accent Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#ff6a1a]/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#ff6a1a]/20 border border-[#ff6a1a]/40 text-xs font-semibold text-[#ff6a1a] tracking-wider uppercase mb-4 shadow-sm">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.finalCta.badge}</span>
          </div>

          <h2 className="text-5xl sm:text-7xl lg:text-8xl font-black text-white tracking-tight leading-[0.95] mb-6 font-sans">
            {t.finalCta.title1} <br />
            <span className="text-[#ff6a1a] italic font-serif font-normal">
              {t.finalCta.title2}
            </span>
          </h2>

          <p className="text-base sm:text-xl text-stone-300 font-light leading-relaxed mb-10 max-w-2xl mx-auto">
            {t.finalCta.desc}
          </p>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-4 mb-12">
            <button
              type="button"
              onClick={() => {
                if (onOpenPlanModal) {
                  onOpenPlanModal();
                } else {
                  window.open('https://cal.com/wouter-mur-ye8yri/30min', '_blank');
                }
              }}
              className="px-8 py-4 rounded-full bg-[#ff6a1a] hover:bg-[#ff7e36] text-white font-extrabold text-xs uppercase tracking-widest shadow-xl shadow-[#ff6a1a]/40 transition-all hover:scale-105 active:scale-95 flex items-center gap-2 cursor-pointer"
            >
              <Calendar className="w-4 h-4" />
              <span>{t.finalCta.bookCall}</span>
            </button>

            <a
              href="mailto:hello@studiomonolith.com"
              className="px-8 py-4 rounded-full bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-widest border border-white/20 transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
            >
              <Mail className="w-4 h-4 text-[#ff6a1a]" />
              <span>{t.finalCta.sendEmail}</span>
            </a>
          </div>

          {/* Instant Inquiry Contact Form */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 sm:p-8 max-w-xl mx-auto">
            {!formSubmitted ? (
              <form onSubmit={handleSubmit} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    placeholder="Uw naam / Your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-[#ff6a1a]"
                  />
                  <input
                    type="email"
                    required
                    placeholder="Uw e-mailadres"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-[#ff6a1a]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-white hover:bg-stone-200 text-[#141a3a] font-extrabold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md"
                >
                  <Send className="w-3.5 h-3.5 text-[#ff6a1a]" />
                  <span>Verstuur directe aanvraag</span>
                </button>
              </form>
            ) : (
              <div className="py-4 text-center">
                <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-2">
                  <Check className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-sm text-white mb-1">
                  Aanvraag ontvangen!
                </h4>
                <p className="text-xs text-stone-300">
                  Lars of Emma reageert binnen 4 uur op werkdagen.
                </p>
              </div>
            )}
          </div>

          <p className="text-[11px] text-stone-400 font-mono mt-8">
            • {t.finalCta.availability} •
          </p>
        </div>
      </div>
    </section>
  );
};
