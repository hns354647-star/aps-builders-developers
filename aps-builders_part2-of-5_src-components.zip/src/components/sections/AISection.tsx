import React from 'react';
import { motion } from 'motion/react';
import { Cpu, Zap, Shield, Sparkles } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

export const AISection: React.FC = () => {
  const { t } = useLanguage();

  return (
    <section className="relative py-28 px-6 max-w-7xl mx-auto w-full z-10">
      <div className="bg-[#18211b]/85 backdrop-blur-2xl border border-white/20 rounded-[28px] p-8 sm:p-14 shadow-2xl text-white">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Main Statement */}
          <div className="lg:col-span-8 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#ff6a1a]/20 border border-[#ff6a1a]/40 text-xs font-semibold text-[#ff6a1a] tracking-wider uppercase shadow-sm">
              <Zap className="w-3.5 h-3.5" />
              <span>{t.ai.badge}</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight font-sans">
              {t.ai.title}
            </h2>

            <p className="text-xl sm:text-2xl font-serif text-[#ff8438] italic font-normal leading-snug">
              &ldquo;{t.ai.boldLine}&rdquo;
            </p>

            <p className="text-sm sm:text-base text-stone-300 font-light leading-relaxed max-w-2xl">
              {t.ai.desc}
            </p>
          </div>

          {/* Metric Badges Column */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-[#ff6a1a]/50 transition-colors">
              <div className="text-4xl font-black text-[#ff6a1a] mb-1 font-mono">
                {t.ai.stat1.value}
              </div>
              <div className="text-xs text-stone-300 font-medium">
                {t.ai.stat1.label}
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-[#ff6a1a]/50 transition-colors">
              <div className="text-4xl font-black text-white mb-1 font-mono">
                {t.ai.stat2.value}
              </div>
              <div className="text-xs text-stone-300 font-medium">
                {t.ai.stat2.label}
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-[#ff6a1a]/50 transition-colors">
              <div className="text-4xl font-black text-emerald-400 mb-1 font-mono">
                {t.ai.stat3.value}
              </div>
              <div className="text-xs text-stone-300 font-medium">
                {t.ai.stat3.label}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
