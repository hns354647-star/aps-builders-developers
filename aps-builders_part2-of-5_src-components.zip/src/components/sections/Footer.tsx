import React from 'react';
import { Globe, ArrowUp } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

export const Footer: React.FC = () => {
  const { lang, toggleLang, t } = useLanguage();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-[#0d1310] border-t border-white/10 text-stone-400 py-16 px-6 z-10">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#ff6a1a] flex items-center justify-center font-bold text-white text-xs">
                //
              </div>
              <span className="font-extrabold text-sm tracking-wider uppercase text-white font-sans">
                STUDIO MONOLITH
              </span>
            </div>
            <p className="text-xs text-stone-400 max-w-sm leading-relaxed">
              {t.footer.tagline}
            </p>
            <div className="text-[11px] font-mono text-stone-400 pt-2">
              Keizersgracht 482, 1016 GD Amsterdam • KvK: 84920194
            </div>
          </div>

          {/* Navigation Sitemap */}
          <div className="md:col-span-3 space-y-3">
            <h5 className="text-xs font-bold text-white uppercase tracking-widest">
              {t.footer.sitemapTitle}
            </h5>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => scrollToSection('services-section')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.nav.services}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('cases-section')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.nav.cases}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('process-section')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.nav.process}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('pricing-section')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.nav.pricing}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('team-section')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.nav.team}
                </button>
              </li>
            </ul>
          </div>

          {/* Socials & Language Toggle */}
          <div className="md:col-span-4 space-y-4">
            <h5 className="text-xs font-bold text-white uppercase tracking-widest">
              {t.footer.socialTitle}
            </h5>
            <div className="flex flex-wrap gap-2 text-xs">
              {['Twitter / X', 'LinkedIn', 'GitHub', 'Awwwards', 'Instagram'].map((s) => (
                <span
                  key={s}
                  className="px-3 py-1 rounded-full bg-white/5 border border-white/10 hover:border-[#ff6a1a] text-stone-300 hover:text-white cursor-pointer transition-colors"
                >
                  {s}
                </span>
              ))}
            </div>

            <div className="pt-2">
              <button
                onClick={toggleLang}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs font-semibold cursor-pointer transition-colors"
              >
                <Globe className="w-3.5 h-3.5 text-[#ff6a1a]" />
                <span>Taal / Language: {lang === 'nl' ? 'Nederlands' : 'English'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Rights & Back to Top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div>
            © {new Date().getFullYear()} STUDIO MONOLITH BV. {t.footer.copyright}
          </div>

          <div className="text-[11px] text-stone-400">
            {t.footer.rights}
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-stone-400 hover:text-[#ff6a1a] transition-colors cursor-pointer font-bold uppercase text-[11px]"
          >
            <span>Top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};
