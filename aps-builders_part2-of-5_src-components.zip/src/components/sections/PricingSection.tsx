import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, ChevronDown, Sparkles, ArrowRight, ShieldCheck, HelpCircle } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

interface PricingSectionProps {
  onOpenPlanModal?: () => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onOpenPlanModal }) => {
  const { t } = useLanguage();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const scrollToContact = () => {
    if (onOpenPlanModal) {
      onOpenPlanModal();
    } else {
      document.getElementById('final-cta-section')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="pricing-section" className="relative py-28 px-6 max-w-7xl mx-auto w-full z-10 scroll-mt-24">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-xs font-semibold text-[#18211b] tracking-wider uppercase mb-3 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-[#ff6a1a]" />
          <span>{t.pricing.badge}</span>
        </div>
        <h2 className="text-4xl sm:text-6xl font-black text-[#141a3a] tracking-tight leading-tight font-sans">
          {t.pricing.title}
        </h2>
        <p className="text-base sm:text-lg text-[#324538] mt-3 font-medium">
          {t.pricing.subtitle}
        </p>
      </div>

      {/* 3 Pricing Plan Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-20 items-stretch">
        {/* Plan 1: Sprint */}
        <div className="bg-[#18211b]/85 backdrop-blur-2xl border border-white/20 rounded-[28px] p-8 shadow-2xl text-white flex flex-col justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-[#ff6a1a] block mb-2">
              {t.pricing.plans.sprint.tag}
            </span>
            <h3 className="text-2xl font-extrabold text-white mb-2">
              {t.pricing.plans.sprint.name}
            </h3>
            <p className="text-xs text-stone-300 font-light mb-6">
              {t.pricing.plans.sprint.desc}
            </p>

            <div className="mb-8 pb-6 border-b border-white/10">
              <span className="text-4xl sm:text-5xl font-black text-white font-mono">
                {t.pricing.plans.sprint.price}
              </span>
              <span className="text-xs text-stone-400 block mt-1">
                {t.pricing.plans.sprint.period}
              </span>
            </div>

            <ul className="space-y-3 mb-8 text-xs text-stone-200">
              {t.pricing.plans.sprint.features.map((feat, idx) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#ff6a1a] shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </li>
              ))}
            </ul>
          </div>

          <button
            onClick={scrollToContact}
            className="w-full py-4 rounded-full bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-wider transition-all cursor-pointer border border-white/20"
          >
            {t.pricing.plans.sprint.cta}
          </button>
        </div>

        {/* Plan 2: Dedicated Retainer (Featured) */}
        <div className="bg-gradient-to-b from-[#243329] to-[#141d17] border-2 border-[#ff6a1a] rounded-[28px] p-8 shadow-2xl text-white flex flex-col justify-between relative transform lg:-translate-y-2">
          <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-[#ff6a1a] text-white text-[10px] font-extrabold uppercase tracking-widest shadow-md">
            {t.pricing.plans.dedicated.popular}
          </div>

          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-[#ff8438] block mb-2">
              {t.pricing.plans.dedicated.tag}
            </span>
            <h3 className="text-2xl font-extrabold text-white mb-2">
              {t.pricing.plans.dedicated.name}
            </h3>
            <p className="text-xs text-stone-300 font-light mb-6">
              {t.pricing.plans.dedicated.desc}
            </p>

            <div className="mb-8 pb-6 border-b border-white/15">
              <span className="text-4xl sm:text-5xl font-black text-white font-mono">
                {t.pricing.plans.dedicated.price}
              </span>
              <span className="text-xs text-stone-300 block mt-1">
                {t.pricing.plans.dedicated.period}
              </span>
            </div>

            <ul className="space-y-3 mb-8 text-xs text-stone-100">
              {t.pricing.plans.dedicated.features.map((feat, idx) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#ff6a1a] shrink-0 mt-0.5" />
                  <span className="font-medium">{feat}</span>
                </li>
              ))}
            </ul>
          </div>

          <button
            onClick={scrollToContact}
            className="w-full py-4 rounded-full bg-[#ff6a1a] hover:bg-[#ff7e36] text-white font-extrabold text-xs uppercase tracking-wider transition-all shadow-xl shadow-[#ff6a1a]/40 cursor-pointer hover:scale-105 active:scale-95"
          >
            {t.pricing.plans.dedicated.cta}
          </button>
        </div>

        {/* Plan 3: Custom Enterprise */}
        <div className="bg-[#18211b]/85 backdrop-blur-2xl border border-white/20 rounded-[28px] p-8 shadow-2xl text-white flex flex-col justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-[#ff6a1a] block mb-2">
              {t.pricing.plans.custom.tag}
            </span>
            <h3 className="text-2xl font-extrabold text-white mb-2">
              {t.pricing.plans.custom.name}
            </h3>
            <p className="text-xs text-stone-300 font-light mb-6">
              {t.pricing.plans.custom.desc}
            </p>

            <div className="mb-8 pb-6 border-b border-white/10">
              <span className="text-4xl sm:text-5xl font-black text-white font-mono">
                {t.pricing.plans.custom.price}
              </span>
              <span className="text-xs text-stone-400 block mt-1">
                {t.pricing.plans.custom.period}
              </span>
            </div>

            <ul className="space-y-3 mb-8 text-xs text-stone-200">
              {t.pricing.plans.custom.features.map((feat, idx) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#ff6a1a] shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </li>
              ))}
            </ul>
          </div>

          <button
            onClick={scrollToContact}
            className="w-full py-4 rounded-full bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-wider transition-all cursor-pointer border border-white/20"
          >
            {t.pricing.plans.custom.cta}
          </button>
        </div>
      </div>

      {/* Always Included Strip */}
      <div className="bg-white/15 backdrop-blur-xl border border-white/30 rounded-3xl p-6 sm:p-8 mb-20 shadow-lg text-[#18211b]">
        <h4 className="text-xs font-bold uppercase tracking-widest text-[#18211b] mb-4 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#ff6a1a]" />
          <span>{t.pricing.alwaysIncludedTitle}</span>
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {t.pricing.alwaysIncluded.map((item, idx) => (
            <div key={idx} className="flex items-center gap-2 text-xs font-semibold text-[#18211b]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#ff6a1a]" />
              <span>{item}</span>
            </div>
          ))}
        </div>
      </div>

      {/* "Do The Math" Comparison Block */}
      <div className="bg-[#18211b]/85 backdrop-blur-2xl border border-white/20 rounded-[28px] p-8 sm:p-12 shadow-2xl text-white mb-20">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold text-[#ff6a1a] uppercase tracking-widest block mb-1">
            Cost & Value Comparison
          </span>
          <h3 className="text-3xl sm:text-4xl font-extrabold text-white">
            {t.pricing.mathTitle}
          </h3>
          <p className="text-xs sm:text-sm text-stone-300 font-light mt-2">
            {t.pricing.mathDesc}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* In-House Cost Card */}
          <div className="p-6 rounded-2xl bg-white/5 border border-white/10">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-400 block mb-1">
              {t.pricing.mathComparison.inHouseTitle}
            </span>
            <div className="text-3xl font-black text-rose-400 font-mono mb-4">
              {t.pricing.mathComparison.inHouseCost}
            </div>
            <ul className="space-y-2 text-xs text-stone-300">
              {t.pricing.mathComparison.inHousePoints.map((pt, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-rose-400 font-bold">✕</span>
                  <span>{pt}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Studio Retainer Card */}
          <div className="p-6 rounded-2xl bg-[#ff6a1a]/15 border border-[#ff6a1a]/40">
            <span className="text-xs font-bold uppercase tracking-wider text-[#ff8438] block mb-1">
              {t.pricing.mathComparison.studioTitle}
            </span>
            <div className="text-3xl font-black text-emerald-400 font-mono mb-4">
              {t.pricing.mathComparison.studioCost}
            </div>
            <ul className="space-y-2 text-xs text-stone-100">
              {t.pricing.mathComparison.studioPoints.map((pt, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span>{pt}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Accordion FAQ */}
      <div className="max-w-3xl mx-auto">
        <h3 className="text-2xl sm:text-3xl font-black text-[#141a3a] text-center mb-8 font-sans">
          {t.pricing.faqTitle}
        </h3>
        <div className="space-y-3">
          {t.pricing.faqs.map((faq, idx) => (
            <div
              key={idx}
              className="bg-[#18211b]/85 backdrop-blur-xl border border-white/20 rounded-2xl overflow-hidden text-white"
            >
              <button
                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer font-bold text-sm"
              >
                <span>{faq.q}</span>
                <ChevronDown
                  className={`w-4 h-4 text-[#ff6a1a] transition-transform ${
                    openFaq === idx ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <AnimatePresence>
                {openFaq === idx && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="px-5 pb-5 text-xs text-stone-300 font-light leading-relaxed border-t border-white/10 pt-3"
                  >
                    {faq.a}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
