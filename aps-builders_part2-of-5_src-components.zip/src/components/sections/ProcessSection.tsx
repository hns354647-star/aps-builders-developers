import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, CheckCircle2, Clock, ArrowRight } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

export const ProcessSection: React.FC = () => {
  const { t } = useLanguage();

  return (
    <section id="process-section" className="relative py-28 px-6 max-w-7xl mx-auto w-full z-10 scroll-mt-24">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-xs font-semibold text-[#18211b] tracking-wider uppercase mb-3 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-[#ff6a1a]" />
          <span>{t.process.badge}</span>
        </div>
        <h2 className="text-4xl sm:text-6xl font-black text-[#141a3a] tracking-tight leading-tight font-sans">
          {t.process.title}
        </h2>
        <p className="text-base sm:text-lg text-[#324538] mt-3 font-medium">
          {t.process.subtitle}
        </p>
      </div>

      {/* 4 Sequenced Ticket Steps */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {t.process.steps.map((item, idx) => (
          <div
            key={idx}
            className="bg-[#18211b]/85 backdrop-blur-2xl border border-white/20 hover:border-[#ff6a1a]/50 rounded-[28px] p-7 shadow-2xl text-white flex flex-col justify-between transition-all hover:scale-105 duration-300 group"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-3xl font-black text-[#ff6a1a] font-mono">
                  {item.step}
                </span>
                <span className="flex items-center gap-1 text-[11px] font-mono text-stone-400 bg-white/5 px-2.5 py-1 rounded-full border border-white/10">
                  <Clock className="w-3 h-3 text-[#ff6a1a]" />
                  <span>{item.duration}</span>
                </span>
              </div>

              <h3 className="text-xl font-bold text-white mb-2 group-hover:text-[#ff8438] transition-colors">
                {item.title}
              </h3>

              <p className="text-xs text-stone-300 leading-relaxed font-light">
                {item.desc}
              </p>
            </div>

            <div className="pt-6 mt-6 border-t border-white/10 flex items-center justify-between text-xs text-stone-400">
              <span className="text-[10px] uppercase tracking-wider font-semibold">
                Milestone Guaranteed
              </span>
              <CheckCircle2 className="w-4 h-4 text-[#ff6a1a]" />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
