import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { Calculator, TrendingUp, Info } from 'lucide-react';

interface ProjectCostWidgetProps {
  projectType: string;
  projectName: string;
}

const COST_RATES: Record<string, { min: number, max: number }> = {
  'Residential': { min: 2200, max: 3500 },
  'Commercial': { min: 2800, max: 4800 },
  'Public': { min: 2000, max: 3200 },
  'Institutional': { min: 2100, max: 3300 },
  'default': { min: 2200, max: 3500 }
};

export default function ProjectCostWidget({ projectType, projectName }: ProjectCostWidgetProps) {
  const [sqft, setSqft] = useState<number>(1500);
  
  const rates = useMemo(() => COST_RATES[projectType] || COST_RATES.default, [projectType]);

  const estimate = useMemo(() => {
    return {
      min: sqft * rates.min,
      max: sqft * rates.max
    };
  }, [sqft, rates]);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(val);
  };

  return (
    <div className="bg-slate-950 p-6 rounded-sm border border-white/5 space-y-6 relative overflow-hidden group">
      {/* Background Accent */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-amber-600/10 blur-3xl rounded-full -mr-16 -mt-16 group-hover:bg-amber-600/20 transition-colors duration-700" />
      
      <div className="flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2">
          <Calculator className="w-4 h-4 text-amber-500" />
          <h4 className="text-[10px] font-bold text-white uppercase tracking-widest">Instant Estimate</h4>
        </div>
        <div className="group relative">
          <Info className="w-3 h-3 text-slate-600 cursor-help" />
          <div className="absolute bottom-full right-0 mb-2 w-48 p-2 bg-white text-[8px] text-slate-900 rounded-sm opacity-0 group-hover:opacity-100 transition-all pointer-events-none z-50 shadow-xl border border-slate-100">
            Approximate range based on current {projectType} market rates. Final quote may vary based on exact specifications.
          </div>
        </div>
      </div>

      <div className="space-y-4 relative z-10">
        <div className="flex justify-between items-end">
          <label htmlFor="cost-widget-build-area" className="text-[9px] font-bold text-slate-400 uppercase tracking-widest font-mono">Build Area (Sq.Ft)</label>
          <motion.span 
            key={sqft}
            initial={{ scale: 1.1, color: '#f59e0b' }}
            animate={{ scale: 1, color: '#f59e0b' }}
            className="text-xl font-mono font-bold"
          >
            {sqft.toLocaleString()}
          </motion.span>
        </div>
        
        <input 
          id="cost-widget-build-area"
          type="range"
          min="500"
          max="10000"
          step="100"
          value={sqft}
          aria-label={`Build Area in square feet for ${projectName}`}
          aria-valuemin={500}
          aria-valuemax={10000}
          aria-valuenow={sqft}
          aria-valuetext={`${sqft.toLocaleString()} square feet`}
          onChange={(e) => setSqft(parseInt(e.target.value))}
          className="w-full h-1.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-amber-600 hover:accent-amber-500 transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
        />
        
        <div className="flex justify-between text-[8px] font-bold text-slate-600 uppercase tracking-tighter font-mono" aria-hidden="true">
          <span>500</span>
          <span>5000</span>
          <span>10,000</span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-2 pt-2 relative z-10">
        <motion.div 
          key={sqft}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 border border-white/10 p-4 rounded-sm"
        >
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-3 h-3 text-amber-500" />
            <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Projected Investment</span>
          </div>
          
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1">
              <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mb-1">Base Plan</p>
              <p className="text-sm font-bold text-white font-mono">{formatCurrency(estimate.min)}</p>
            </div>
            
            <div className="w-px h-8 bg-white/10" />
            
            <div className="flex-1 text-right">
              <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mb-1">Premium Plan</p>
              <p className="text-sm font-bold text-amber-500 font-mono">{formatCurrency(estimate.max)}</p>
            </div>
          </div>
        </motion.div>
      </div>

      <div className="pt-2">
        <button className="w-full py-2 bg-amber-600/10 hover:bg-amber-600 text-amber-500 hover:text-white border border-amber-600/20 text-[8px] font-bold uppercase tracking-[0.2em] transition-all rounded-sm">
          Request Detailed Quote
        </button>
      </div>

      <p className="text-[7px] text-slate-600 italic leading-tight text-center relative z-10 uppercase tracking-widest">
        *Estimates based on current {projectType} material costs in Kerala.
      </p>
    </div>
  );
}
