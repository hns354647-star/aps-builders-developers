import React, { useMemo } from 'react';
import * as THREE from 'three';

export const Atmosphere: React.FC<{ progress: number }> = ({ progress }) => {
  // Low-poly drifting clouds
  const cloudPositions = useMemo(() => [
    { pos: [-6, 6.5, -4], scale: 1.6 },
    { pos: [7, 7.2, 5], scale: 2.1 },
    { pos: [-8, 8.0, 7], scale: 1.8 },
    { pos: [5, 6.0, -8], scale: 1.4 }
  ], []);

  // Starfield for night sky (fades in as progress > 0.65)
  const starCount = 350;
  const starPositions = useMemo(() => {
    const arr = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const radius = 35 + Math.random() * 25;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 1.8 - 0.9);
      arr[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      arr[i * 3 + 1] = Math.abs(radius * Math.cos(phi)) + 4; // keep above horizon
      arr[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
    }
    return arr;
  }, [starCount]);

  // Night opacity factor
  const starOpacity = Math.max(0, Math.min(1, (progress - 0.6) * 2.8));

  return (
    <group>
      {/* Drifting Clouds */}
      {cloudPositions.map((c, i) => (
        <group key={i} position={c.pos as [number, number, number]} scale={c.scale}>
          <mesh castShadow position={[0, 0, 0]}>
            <sphereGeometry args={[0.9, 7, 7]} />
            <meshStandardMaterial color="#ffffff" roughness={0.9} flatShading />
          </mesh>
          <mesh castShadow position={[0.7, -0.1, 0.2]}>
            <sphereGeometry args={[0.7, 7, 7]} />
            <meshStandardMaterial color="#ffffff" roughness={0.9} flatShading />
          </mesh>
          <mesh castShadow position={[-0.7, -0.15, -0.1]}>
            <sphereGeometry args={[0.65, 7, 7]} />
            <meshStandardMaterial color="#ffffff" roughness={0.9} flatShading />
          </mesh>
        </group>
      ))}

      {/* Night Stars */}
      {starOpacity > 0.01 && (
        <points>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              args={[starPositions, 3]}
            />
          </bufferGeometry>
          <pointsMaterial
            size={0.28}
            color="#ffffff"
            transparent
            opacity={starOpacity}
            sizeAttenuation
          />
        </points>
      )}
    </group>
  );
};
