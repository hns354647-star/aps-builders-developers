import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Island } from './Island';
import { Mascot } from './Mascot';
import { Water } from './Water';
import { OrbitingCubes } from './OrbitingCubes';
import { Atmosphere } from './Atmosphere';
import { CameraRig } from './CameraRig';
import { LightingAndFog } from './LightingAndFog';

interface SceneProps {
  progress: number;
  mousePos: { x: number; y: number };
  introComplete: boolean;
  prefersReducedMotion?: boolean;
}

export const Scene: React.FC<SceneProps> = ({
  progress,
  mousePos,
  introComplete,
  prefersReducedMotion = false
}) => {
  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      <Canvas
        shadows
        dpr={[1, 2]} // Clamped DPR up to 2 for crisp retina rendering with performance ceiling
        camera={{ position: [0, 4.2, 11], fov: 45, near: 0.1, far: 80 }}
        gl={{
          antialias: true,
          alpha: false,
          powerPreference: 'high-performance'
        }}
      >
        <Suspense fallback={null}>
          <LightingAndFog progress={progress} />
          
          <CameraRig
            progress={progress}
            mousePos={mousePos}
            prefersReducedMotion={prefersReducedMotion}
          />

          {/* Group animated during initial loader rise intro */}
          <group position={[0, introComplete ? 0 : -3.5, 0]}>
            <Island progress={progress} />
            <Mascot progress={progress} isWaving={progress < 0.15 || progress > 0.8} />
            <Water progress={progress} />
            <OrbitingCubes progress={progress} />
            <Atmosphere progress={progress} />
          </group>
        </Suspense>
      </Canvas>
    </div>
  );
};
