import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

// Seeded pseudorandom generator for deterministic low-poly tree and rock distribution
function seededRandom(seed: number) {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

export const Island: React.FC<{ progress: number }> = ({ progress }) => {
  const islandRef = useRef<THREE.Group>(null);
  const monolithRef = useRef<THREE.Group>(null);

  // Generate deterministic low-poly trees on island surface
  const treePositions = useMemo(() => {
    const trees = [];
    const count = 14;
    for (let i = 0; i < count; i++) {
      const angle = seededRandom(i * 12.3) * Math.PI * 2;
      const radius = 1.2 + seededRandom(i * 34.5) * 2.8;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      // avoid placing on center where monolith sits
      if (Math.abs(x) < 0.9 && Math.abs(z) < 0.9) continue;
      const scale = 0.6 + seededRandom(i * 78.9) * 0.7;
      const rotationY = seededRandom(i * 90.1) * Math.PI * 2;
      trees.push({ x, z, scale, rotationY, key: i });
    }
    return trees;
  }, []);

  // Generate small decorative rock clusters on grass
  const rocks = useMemo(() => {
    const arr = [];
    for (let i = 0; i < 9; i++) {
      const angle = seededRandom(i * 55.5) * Math.PI * 2;
      const radius = 2.2 + seededRandom(i * 11.1) * 2.1;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      arr.push({ x, z, scale: 0.18 + seededRandom(i * 77) * 0.28, key: i });
    }
    return arr;
  }, []);

  useFrame((_, delta) => {
    if (islandRef.current) {
      // Base gentle idle oscillation + continuous rotation driven by scroll progress
      islandRef.current.rotation.y = progress * Math.PI * 2.2 + Math.sin(Date.now() * 0.0006) * 0.05;
      islandRef.current.position.y = Math.sin(Date.now() * 0.0012) * 0.06;
    }

    if (monolithRef.current) {
      // Subtle hovering energy reaction
      monolithRef.current.position.y = 0.02 * Math.sin(Date.now() * 0.002);
    }
  });

  return (
    <group ref={islandRef} position={[0, 0, 0]}>
      {/* 1. Flat-shaded grass top plateau */}
      <mesh position={[0, 0, 0]} receiveShadow castShadow>
        <cylinderGeometry args={[4.4, 4.0, 0.7, 10]} />
        <meshStandardMaterial
          color="#92b28c" // morning sage grass
          roughness={0.85}
          metalness={0.05}
          flatShading
        />
      </mesh>

      {/* 2. Earth bedrock inverted cone below water line */}
      <mesh position={[0, -2.1, 0]} receiveShadow castShadow>
        <cylinderGeometry args={[4.0, 0.4, 3.6, 9]} />
        <meshStandardMaterial
          color="#423a32" // rich subterranean earth
          roughness={0.95}
          metalness={0.0}
          flatShading
        />
      </mesh>

      {/* 3. Sand shoreline rim at lake level */}
      <mesh position={[0, -0.25, 0]} receiveShadow>
        <cylinderGeometry args={[4.65, 4.25, 0.35, 10]} />
        <meshStandardMaterial
          color="#cfc29f"
          roughness={0.9}
          flatShading
        />
      </mesh>

      {/* 4. Concrete Monoliths forming "//" Agency Logo mark */}
      <group ref={monolithRef} position={[0, 0.35, 0]}>
        {/* First leaning concrete slab */}
        <mesh
          position={[-0.45, 1.25, 0]}
          rotation={[0.05, 0.15, -0.28]}
          castShadow
          receiveShadow
        >
          <boxGeometry args={[0.32, 2.7, 0.45]} />
          <meshStandardMaterial
            color="#8c918f"
            roughness={0.7}
            metalness={0.15}
            flatShading
          />
        </mesh>

        {/* Second leaning concrete slab parallel to first */}
        <mesh
          position={[0.45, 1.25, 0]}
          rotation={[0.05, 0.15, -0.28]}
          castShadow
          receiveShadow
        >
          <boxGeometry args={[0.32, 2.7, 0.45]} />
          <meshStandardMaterial
            color="#a2a7a4"
            roughness={0.65}
            metalness={0.15}
            flatShading
          />
        </mesh>

        {/* Accent Orange studio detail on base of slab */}
        <mesh position={[-0.43, 0.2, 0.24]} rotation={[0, 0.15, -0.28]}>
          <boxGeometry args={[0.34, 0.12, 0.04]} />
          <meshBasicMaterial color="#ff6a1a" />
        </mesh>
      </group>

      {/* 5. Low-poly stylized trees */}
      {treePositions.map((t) => (
        <group key={t.key} position={[t.x, 0.35, t.z]} scale={t.scale} rotation={[0, t.rotationY, 0]}>
          {/* Wood trunk */}
          <mesh position={[0, 0.45, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[0.08, 0.14, 0.9, 5]} />
            <meshStandardMaterial color="#543d2b" roughness={0.9} flatShading />
          </mesh>
          {/* Lower foliage cone */}
          <mesh position={[0, 1.1, 0]} castShadow receiveShadow>
            <coneGeometry args={[0.75, 1.1, 5]} />
            <meshStandardMaterial color="#4d7047" roughness={0.8} flatShading />
          </mesh>
          {/* Upper foliage cone */}
          <mesh position={[0, 1.65, 0]} castShadow receiveShadow>
            <coneGeometry args={[0.55, 0.9, 5]} />
            <meshStandardMaterial color="#668e5e" roughness={0.8} flatShading />
          </mesh>
        </group>
      ))}

      {/* 6. Low-poly scattered boulders */}
      {rocks.map((r) => (
        <mesh
          key={r.key}
          position={[r.x, 0.35, r.z]}
          scale={[r.scale, r.scale * 0.7, r.scale]}
          rotation={[r.x, r.z, 0]}
          castShadow
          receiveShadow
        >
          <dodecahedronGeometry args={[1, 0]} />
          <meshStandardMaterial color="#7a807d" roughness={0.9} flatShading />
        </mesh>
      ))}

      {/* 7. Small Wooden Dock stretching into lake */}
      <group position={[0, 0.05, 4.3]} rotation={[0, 0, 0]}>
        <mesh position={[0, 0, 0.5]} receiveShadow castShadow>
          <boxGeometry args={[1.1, 0.12, 1.4]} />
          <meshStandardMaterial color="#6e5038" roughness={0.85} flatShading />
        </mesh>
        <mesh position={[-0.45, -0.4, 1.1]} castShadow>
          <cylinderGeometry args={[0.05, 0.05, 0.8, 6]} />
          <meshStandardMaterial color="#422f20" roughness={0.9} />
        </mesh>
        <mesh position={[0.45, -0.4, 1.1]} castShadow>
          <cylinderGeometry args={[0.05, 0.05, 0.8, 6]} />
          <meshStandardMaterial color="#422f20" roughness={0.9} />
        </mesh>
      </group>
    </group>
  );
};
