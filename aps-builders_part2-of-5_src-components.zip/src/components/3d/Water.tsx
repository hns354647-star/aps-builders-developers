import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export const Water: React.FC<{ progress: number }> = ({ progress }) => {
  const meshRef = useRef<THREE.Mesh>(null);

  // Generate subdivided plane geometry for procedural wave vertex displacements
  const geometry = useMemo(() => {
    return new THREE.PlaneGeometry(64, 64, 48, 48);
  }, []);

  // Save original positions to oscillate relative to baseline
  const originalPositions = useMemo(() => {
    return geometry.attributes.position.array.slice();
  }, [geometry]);

  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    const t = clock.getElapsedTime() * 1.4;
    const positions = meshRef.current.geometry.attributes.position;
    const posArr = positions.array as Float32Array;
    const origArr = originalPositions as Float32Array;

    for (let i = 0; i < posArr.length; i += 3) {
      const u = origArr[i];
      const v = origArr[i + 1];

      // Two overlapping sine wave harmonics for gentle, organic water rippling
      const wave1 = Math.sin(u * 0.25 + t) * Math.cos(v * 0.25 + t * 0.8) * 0.14;
      const wave2 = Math.sin(u * 0.5 - t * 0.6) * 0.06;

      posArr[i + 2] = origArr[i + 2] + wave1 + wave2;
    }

    positions.needsUpdate = true;
    meshRef.current.geometry.computeVertexNormals();
  });

  // Color transitions through day: morning soft teal -> golden reflections -> deep night navy
  const waterColor = useMemo(() => {
    if (progress < 0.35) return '#5b8285'; // morning sage teal
    if (progress < 0.7) return '#3a6976'; // golden hour lake
    return '#0b1329'; // deep night indigo
  }, [progress]);

  return (
    <mesh
      ref={meshRef}
      geometry={geometry}
      rotation={[-Math.PI / 2, 0, 0]}
      position={[0, -0.3, 0]}
      receiveShadow
    >
      <meshStandardMaterial
        color={waterColor}
        roughness={0.15}
        metalness={0.35}
        transparent
        opacity={0.88}
        flatShading
      />
    </mesh>
  );
};
