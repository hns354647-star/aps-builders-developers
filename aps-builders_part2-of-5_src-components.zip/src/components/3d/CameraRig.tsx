import React, { useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface CameraRigProps {
  progress: number;
  mousePos: { x: number; y: number };
  prefersReducedMotion?: boolean;
}

export const CameraRig: React.FC<CameraRigProps> = ({
  progress,
  mousePos,
  prefersReducedMotion = false
}) => {
  const { camera } = useThree();

  // Closed/smooth CatmullRomCurve3 spline path around the island world
  // 1. Hero: [0, 4.2, 11] (centered, wide view)
  // 2. Client marquee: orbit slightly right and tilt down [3.5, 3.8, 9.5]
  // 3. Services: top-down view [0.5, 9.5, 3.5]
  // 4. AI section: medium distance with orbiting cubes clustered [-3.2, 4.0, 8.2]
  // 5. Showreel: sweeping cinematic side angle [6.8, 3.5, 5.2]
  // 6. Cases: dramatic low angle looking up at monoliths [-4.5, 1.8, 7.0]
  // 7. Process: following mascot path [1.2, 2.6, 6.2]
  // 8. Pricing: elevated overview with mascot waving [0, 4.5, 9.0]
  // 9. Team: balanced mid-shot [3.0, 3.2, 7.8]
  // 10. Final CTA: close-up on mascot and illuminated monoliths [0, 2.1, 5.0]
  const curve = useMemo(() => {
    return new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 4.2, 11.0),    // 0.0 Hero
      new THREE.Vector3(3.2, 3.8, 9.6),   // 0.15 Marquee
      new THREE.Vector3(1.2, 9.2, 4.2),   // 0.30 Services (Top-down view)
      new THREE.Vector3(-3.5, 4.2, 8.4),  // 0.42 AI cluster
      new THREE.Vector3(6.5, 3.2, 5.5),   // 0.54 Showreel
      new THREE.Vector3(-4.2, 1.8, 7.2),  // 0.65 Cases (Low angle)
      new THREE.Vector3(1.0, 2.6, 6.4),   // 0.76 Process
      new THREE.Vector3(0, 4.2, 8.8),     // 0.86 Pricing
      new THREE.Vector3(2.8, 3.0, 7.2),   // 0.93 Team
      new THREE.Vector3(0, 2.1, 5.0)      // 1.0 Final CTA (Close to mascot)
    ]);
  }, []);

  // Target lookAt trajectory
  const targetLookAtCurve = useMemo(() => {
    return new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 1.2, 0),      // Hero looks at monolith center
      new THREE.Vector3(0, 0.8, 0),      // Marquee
      new THREE.Vector3(0, 0, 0),        // Services looks straight at island center
      new THREE.Vector3(0, 1.4, 0),      // AI looks at monolith
      new THREE.Vector3(0, 1.2, 0),      // Showreel
      new THREE.Vector3(0, 2.0, 0),      // Cases looks upwards
      new THREE.Vector3(0, 0.8, 2.8),    // Process looks at mascot
      new THREE.Vector3(0, 1.2, 0),      // Pricing
      new THREE.Vector3(0, 1.0, 0),      // Team
      new THREE.Vector3(0, 1.2, 3.2)     // Final CTA lands close to mascot
    ]);
  }, []);

  const currentCamPos = useMemo(() => new THREE.Vector3(), []);
  const currentLookAt = useMemo(() => new THREE.Vector3(), []);

  useFrame(() => {
    if (prefersReducedMotion) {
      // Static comfortable framing if user prefers reduced motion
      camera.position.set(0, 4.0, 10.5);
      camera.lookAt(0, 1.2, 0);
      return;
    }

    const clampedProgress = Math.max(0, Math.min(1, progress));
    
    // Evaluate point on CatmullRom spline
    const targetPos = curve.getPointAt(clampedProgress);
    const targetLook = targetLookAtCurve.getPointAt(clampedProgress);

    // Apply gentle mouse parallax offset
    const parallaxX = mousePos.x * 0.45;
    const parallaxY = -mousePos.y * 0.35;

    targetPos.x += parallaxX;
    targetPos.y += parallaxY;

    // Smooth lerp for buttery movement
    currentCamPos.lerp(targetPos, 0.08);
    currentLookAt.lerp(targetLook, 0.08);

    camera.position.copy(currentCamPos);
    camera.lookAt(currentLookAt);
  });

  return null;
};
