import React, { useMemo } from 'react';
import * as THREE from 'three';

interface LightingProps {
  progress: number;
}

export const LightingAndFog: React.FC<LightingProps> = ({ progress }) => {
  // Lighting and fog interpolate across 3 distinct diurnal phases:
  // Phase 1 (0.0 - 0.4): Morning Sage / fresh architectural studio daylight
  // Phase 2 (0.4 - 0.75): Golden Hour / amber warmth and long cast shadows
  // Phase 3 (0.75 - 1.0): Night Navy / deep stars, moon glow and glowing accent monoliths

  const { sunColor, sunIntensity, hemiColor, groundColor, fogColor, sunPosition } = useMemo(() => {
    let sunCol = new THREE.Color('#fff7e6');
    let sunInt = 1.8;
    let hemiCol = new THREE.Color('#dce7d8');
    let groundCol = new THREE.Color('#6d806a');
    let fogCol = '#cfdccb'; // Sage background token
    let sunPos: [number, number, number] = [12, 16, 10];

    if (progress < 0.4) {
      // Morning Sage
      const t = progress / 0.4;
      sunCol = new THREE.Color('#fffbf0');
      sunInt = 1.7 + t * 0.2;
      hemiCol = new THREE.Color('#cfdccb').lerp(new THREE.Color('#dbe7d7'), t);
      groundCol = new THREE.Color('#6d826a');
      fogCol = '#cfdccb';
      sunPos = [10 + t * 2, 14 + t * 2, 8 + t * 2];
    } else if (progress < 0.75) {
      // Golden Hour
      const t = (progress - 0.4) / 0.35;
      sunCol = new THREE.Color('#fffbf0').lerp(new THREE.Color('#ff9a3c'), t);
      sunInt = 1.9 - t * 0.4;
      hemiCol = new THREE.Color('#dbe7d7').lerp(new THREE.Color('#ffc187'), t);
      groundCol = new THREE.Color('#6d826a').lerp(new THREE.Color('#4d3a2b'), t);
      fogCol = '#e2be9b';
      sunPos = [12 - t * 6, 16 - t * 10, 10 - t * 4];
    } else {
      // Night Navy
      const t = (progress - 0.75) / 0.25;
      sunCol = new THREE.Color('#ff9a3c').lerp(new THREE.Color('#7899db'), t);
      sunInt = 1.5 - t * 0.9;
      hemiCol = new THREE.Color('#ffc187').lerp(new THREE.Color('#141a3a'), t);
      groundCol = new THREE.Color('#4d3a2b').lerp(new THREE.Color('#080d1e'), t);
      fogCol = '#141a3a'; // Night navy token
      sunPos = [6 - t * 12, 6 - t * 2, 6 - t * 6];
    }

    return {
      sunColor: sunCol,
      sunIntensity: sunInt,
      hemiColor: hemiCol,
      groundColor: groundCol,
      fogColor: fogCol,
      sunPosition: sunPos
    };
  }, [progress]);

  return (
    <>
      <fog attach="fog" args={[fogColor, 12, 38]} />
      <color attach="background" args={[fogColor]} />

      {/* Atmospheric Hemisphere Ambient Light */}
      <hemisphereLight
        args={[hemiColor, groundColor, 0.9]}
      />

      {/* Primary Directional Sun with crisp architectural shadows */}
      <directionalLight
        position={sunPosition}
        intensity={sunIntensity}
        color={sunColor}
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-camera-near={0.5}
        shadow-camera-far={45}
        shadow-camera-left={-8}
        shadow-camera-right={8}
        shadow-camera-top={8}
        shadow-camera-bottom={-8}
        shadow-bias={-0.0004}
      />

      {/* Subtle Mascot Fill Light */}
      <pointLight
        position={[0, 2.5, 4.5]}
        intensity={progress > 0.75 ? 0.8 : 0.4}
        color={progress > 0.75 ? '#ff8438' : '#ffffff'}
        distance={7}
      />
    </>
  );
};
