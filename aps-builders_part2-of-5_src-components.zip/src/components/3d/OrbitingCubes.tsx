import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface OrbitingCubesProps {
  progress: number;
}

export const OrbitingCubes: React.FC<OrbitingCubesProps> = ({ progress }) => {
  const count = 36;
  const instancedMeshRef = useRef<THREE.InstancedMesh>(null);
  const tempObject = useMemo(() => new THREE.Object3D(), []);

  // Pre-calculate randomized orbital parameters for each cube
  const cubeData = useMemo(() => {
    const data = [];
    for (let i = 0; i < count; i++) {
      const radius = 5.5 + (i % 6) * 1.4;
      const speed = 0.2 + (i % 5) * 0.12;
      const initialAngle = (i / count) * Math.PI * 2;
      const yOffset = -0.5 + (i % 7) * 0.7;
      const scale = 0.12 + ((i * 13) % 10) * 0.025;
      const tiltAngle = ((i % 4) - 2) * 0.3;
      data.push({ radius, speed, initialAngle, yOffset, scale, tiltAngle });
    }
    return data;
  }, [count]);

  useFrame(({ clock }) => {
    if (!instancedMeshRef.current) return;
    const time = clock.getElapsedTime();

    // In AI section (progress ~0.45), cubes cluster and move toward the camera
    const aiClusterExpansion = Math.sin(Math.PI * Math.max(0, Math.min(1, (progress - 0.35) * 4.0)));

    cubeData.forEach((cube, i) => {
      const currentAngle = cube.initialAngle + time * cube.speed * 0.6;
      const r = cube.radius - aiClusterExpansion * 2.2;
      const x = Math.cos(currentAngle) * r;
      const z = Math.sin(currentAngle) * r;
      const y = cube.yOffset + Math.sin(time * 1.5 + i) * 0.35 + aiClusterExpansion * 0.8;

      tempObject.position.set(x, y, z);
      tempObject.rotation.x = time * 0.8 + i;
      tempObject.rotation.y = time * 0.6 + i * 0.5;
      tempObject.rotation.z = cube.tiltAngle;

      const dynamicScale = cube.scale * (1 + aiClusterExpansion * 0.4);
      tempObject.scale.set(dynamicScale, dynamicScale, dynamicScale);

      tempObject.updateMatrix();
      instancedMeshRef.current?.setMatrixAt(i, tempObject.matrix);
    });

    instancedMeshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh
      ref={instancedMeshRef}
      args={[undefined, undefined, count]}
      castShadow
      receiveShadow
    >
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial
        color="#ffffff"
        roughness={0.4}
        metalness={0.2}
      />
    </instancedMesh>
  );
};
