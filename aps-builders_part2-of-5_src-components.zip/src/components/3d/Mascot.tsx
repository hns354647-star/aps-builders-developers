import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface MascotProps {
  progress: number;
  isWaving?: boolean;
}

export const Mascot: React.FC<MascotProps> = ({ progress, isWaving = true }) => {
  const mascotGroup = useRef<THREE.Group>(null);
  const headGroup = useRef<THREE.Group>(null);
  const rightArm = useRef<THREE.Group>(null);
  const leftArm = useRef<THREE.Group>(null);
  const scarfTail = useRef<THREE.Mesh>(null);

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();

    if (mascotGroup.current) {
      // Idle breathing bounce
      mascotGroup.current.position.y = 0.42 + Math.sin(t * 2.2) * 0.04;
      
      // Face toward general camera position with soft interpolation
      mascotGroup.current.rotation.y = Math.sin(t * 0.8) * 0.12 - 0.1;

      // React to scroll: during ticket workflow / final section, mascot rotates slightly
      if (progress > 0.65 && progress < 0.85) {
        mascotGroup.current.rotation.y += Math.sin(t * 4.0) * 0.15;
      }
    }

    if (headGroup.current) {
      // Inquisitive head tilt
      headGroup.current.rotation.z = Math.sin(t * 1.5) * 0.05;
      headGroup.current.rotation.x = Math.sin(t * 1.8) * 0.03;
    }

    if (rightArm.current) {
      // Natural expressive waving gesture
      const waveSpeed = isWaving ? 6.5 : 2.0;
      rightArm.current.rotation.z = -0.5 - Math.sin(t * waveSpeed) * 0.45;
      rightArm.current.rotation.x = Math.sin(t * 3.0) * 0.15;
    }

    if (leftArm.current) {
      leftArm.current.rotation.z = 0.2 + Math.sin(t * 1.8) * 0.08;
    }

    if (scarfTail.current) {
      // Wind blowing scarf
      scarfTail.current.rotation.z = -0.2 + Math.sin(t * 3.5) * 0.2;
      scarfTail.current.rotation.y = Math.cos(t * 2.8) * 0.15;
    }
  });

  return (
    <group ref={mascotGroup} position={[0, 0.42, 3.4]} scale={0.75}>
      {/* Concrete Cube Head */}
      <group ref={headGroup} position={[0, 1.45, 0]}>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[0.9, 0.9, 0.9]} />
          <meshStandardMaterial
            color="#cfd4d0" // architectural concrete
            roughness={0.75}
            metalness={0.1}
            flatShading
          />
        </mesh>

        {/* Mascot Face: Left Eye */}
        <mesh position={[-0.22, 0.05, 0.46]}>
          <cylinderGeometry args={[0.07, 0.07, 0.02, 16]} />
          <meshBasicMaterial color="#111827" />
        </mesh>
        {/* Eye highlight spark */}
        <mesh position={[-0.2, 0.07, 0.47]}>
          <planeGeometry args={[0.03, 0.03]} />
          <meshBasicMaterial color="#ffffff" />
        </mesh>

        {/* Mascot Face: Right Eye */}
        <mesh position={[0.22, 0.05, 0.46]}>
          <cylinderGeometry args={[0.07, 0.07, 0.02, 16]} />
          <meshBasicMaterial color="#111827" />
        </mesh>
        {/* Eye highlight spark */}
        <mesh position={[0.24, 0.07, 0.47]}>
          <planeGeometry args={[0.03, 0.03]} />
          <meshBasicMaterial color="#ffffff" />
        </mesh>

        {/* Minimal friendly smile */}
        <mesh position={[0, -0.16, 0.46]} rotation={[0, 0, Math.PI]}>
          <torusGeometry args={[0.1, 0.02, 8, 16, Math.PI * 0.8]} />
          <meshBasicMaterial color="#1f2937" />
        </mesh>

        {/* Top playful antenna with orange indicator ball */}
        <mesh position={[0, 0.55, 0]}>
          <cylinderGeometry args={[0.02, 0.02, 0.22, 6]} />
          <meshStandardMaterial color="#6b7280" />
        </mesh>
        <mesh position={[0, 0.7, 0]}>
          <sphereGeometry args={[0.07, 12, 12]} />
          <meshBasicMaterial color="#ff6a1a" />
        </mesh>
      </group>

      {/* Signature Accent Scarf */}
      <group position={[0, 0.95, 0]}>
        {/* Neck wrap */}
        <mesh castShadow>
          <torusGeometry args={[0.38, 0.12, 10, 24]} />
          <meshStandardMaterial
            color="#ff6a1a" // Brand accent orange
            roughness={0.65}
            metalness={0.0}
          />
        </mesh>
        {/* Scarf tail fluttering */}
        <mesh ref={scarfTail} position={[0.32, -0.3, 0.15]} rotation={[0, 0, -0.2]} castShadow>
          <boxGeometry args={[0.18, 0.55, 0.04]} />
          <meshStandardMaterial color="#ff6a1a" roughness={0.65} />
        </mesh>
      </group>

      {/* Concrete Torso Body */}
      <mesh position={[0, 0.5, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.75, 0.85, 0.65]} />
        <meshStandardMaterial
          color="#b0b5b2"
          roughness={0.8}
          metalness={0.1}
          flatShading
        />
      </mesh>

      {/* Subtle Chest Emblem (// studio mark) */}
      <mesh position={[-0.08, 0.55, 0.33]} rotation={[0, 0, -0.25]}>
        <boxGeometry args={[0.04, 0.22, 0.02]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>
      <mesh position={[0.08, 0.55, 0.33]} rotation={[0, 0, -0.25]}>
        <boxGeometry args={[0.04, 0.22, 0.02]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>

      {/* Animated Waving Right Arm */}
      <group ref={rightArm} position={[0.48, 0.75, 0]}>
        <mesh position={[0.25, 0.15, 0]} rotation={[0, 0, -0.6]} castShadow>
          <cylinderGeometry args={[0.09, 0.09, 0.55, 8]} />
          <meshStandardMaterial color="#9ea3a0" roughness={0.7} />
        </mesh>
        {/* Hand mitten */}
        <mesh position={[0.48, 0.35, 0]} castShadow>
          <sphereGeometry args={[0.13, 10, 10]} />
          <meshStandardMaterial color="#cfd4d0" roughness={0.75} />
        </mesh>
      </group>

      {/* Left Arm Resting at side */}
      <group ref={leftArm} position={[-0.48, 0.75, 0]}>
        <mesh position={[-0.1, -0.25, 0]} rotation={[0, 0, 0.1]} castShadow>
          <cylinderGeometry args={[0.09, 0.09, 0.55, 8]} />
          <meshStandardMaterial color="#9ea3a0" roughness={0.7} />
        </mesh>
        <mesh position={[-0.13, -0.55, 0]} castShadow>
          <sphereGeometry args={[0.12, 10, 10]} />
          <meshStandardMaterial color="#cfd4d0" roughness={0.75} />
        </mesh>
      </group>

      {/* Concrete Legs / Stand */}
      <mesh position={[-0.2, -0.15, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.24, 0.45, 0.32]} />
        <meshStandardMaterial color="#737976" roughness={0.85} flatShading />
      </mesh>
      <mesh position={[0.2, -0.15, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.24, 0.45, 0.32]} />
        <meshStandardMaterial color="#737976" roughness={0.85} flatShading />
      </mesh>
    </group>
  );
};
