import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, Variants } from 'motion/react';
import {
  Quote,
  Star,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Building2,
  MapPin,
  CheckCircle2,
  Sparkles,
  Pause,
  Play,
  PlusCircle,
  ThumbsUp,
  X,
  Send,
  MessageSquare,
  Check
} from 'lucide-react';
import TiltCard3D from './TiltCard3D';

export interface ClientReview {
  id: string;
  name: string;
  role: string;
  location: string;
  projectCompleted: string;
  projectCategory: string;
  year: string;
  quote: string;
  detailedFeedback: string;
  rating: number; // 1 to 5
  verifiedClient: boolean;
  avatarInitials: string;
  highlights: string[];
  helpfulCount?: number;
}

const INITIAL_REVIEWS: ClientReview[] = [
  {
    id: 'rev-1',
    name: 'Dr. Anand Menon',
    role: 'Senior Vascular Surgeon',
    location: 'Vembanad Backwaters, Alappuzha',
    projectCompleted: 'The Palm Crest Lakefront Villa',
    projectCategory: 'Waterfront Estate',
    year: 'Delivered 2024',
    quote: 'Executed our backwater villa with surgical precision. Zero variation in Nilambur teak joinery and delivered two weeks early.',
    detailedFeedback: 'Building along the Alappuzha lakefront requires deep geotechnical mastery. APS managed pile stabilization, deep soil anchors, and traditional timber ventilation with zero compromises. Their transparent weekly milestones gave our family absolute peace of mind.',
    rating: 5,
    verifiedClient: true,
    avatarInitials: 'AM',
    highlights: ['Vastu Compliant Orientations', 'Bioclimatic Airflow', 'Zero Hidden Cost Variations'],
    helpfulCount: 28
  },
  {
    id: 'rev-2',
    name: 'Brig. K. R. Nambiar (Retd.)',
    role: 'Former Chief Military Engineer',
    location: 'Beach Road, Alappuzha',
    projectCompleted: 'Coastal Horizon Heritage Residence',
    projectCategory: 'Bespoke Family Residence',
    year: 'Delivered 2023',
    quote: 'As an army engineer with unforgiving standards, APS surpassed every concrete compression benchmark for coastal Alappuzha construction.',
    detailedFeedback: 'Their itemized Bill of Quantities (BOQ) and weekly photographic lab reports are benchmark-setting. From M-80 grade coastal marine concrete testing to copper-shielded earthing, their structural integrity is unyielding.',
    rating: 5,
    verifiedClient: true,
    avatarInitials: 'KN',
    highlights: ['Grade-80 Coastal Concrete', 'Weekly BOQ Reports', 'Seismic & Wind-Resistant Framing'],
    helpfulCount: 42
  },
  {
    id: 'rev-3',
    name: 'Susan & George Mathew',
    role: 'NRI Tech Entrepreneurs (Dubai / Alappuzha)',
    location: 'Punnamada Finishing Point, Alappuzha',
    projectCompleted: 'Punnamada Waterway Sky Villa Duplex',
    projectCategory: 'Waterway Penthouse',
    year: 'Delivered 2025',
    quote: 'Managing a luxury duplex while residing overseas in Dubai seemed daunting until APS took complete turnkey ownership.',
    detailedFeedback: 'Acoustic triple-glazed floor-to-ceiling glass installations against Alappuzha monsoons have remained airtight and leak-proof. The private rooftop plunge pool was acoustically dampened so lower bedroom levels hear absolute stillness.',
    rating: 5,
    verifiedClient: true,
    avatarInitials: 'SM',
    highlights: ['Acoustic Triple Glazing', 'Overseas Digital Tracking', 'Cantilevered Plunge Pool'],
    helpfulCount: 35
  },
  {
    id: 'rev-4',
    name: 'C. V. Radhakrishnan',
    role: 'Managing Director, Horizon Retail Group',
    location: 'Alappuzha Town Commercial Hub',
    projectCompleted: 'Ayur Heritage Commercial Complex',
    projectCategory: 'Commercial Plaza',
    year: 'Delivered 2024',
    quote: 'Delivered our 42,000 sq.ft commercial plaza right on time, enabling 100% pre-leasing before grand inauguration.',
    detailedFeedback: 'APS Builders coordinated all fire-safety approvals, coastal regulatory clearances, and heavy-duty passenger elevators with flawless administrative precision. Their local facility management team remains on call 24/7.',
    rating: 5,
    verifiedClient: true,
    avatarInitials: 'CR',
    highlights: ['100% Pre-Leased Delivery', 'Turnkey Statutory Approvals', 'Post-Handover AMC'],
    helpfulCount: 19
  },
  {
    id: 'rev-5',
    name: 'Lakshmi & Dr. Jayadeep Varma',
    role: 'Heritage Architectural Historian & Neurologist',
    location: 'Kainakary Backwaters, Alappuzha',
    projectCompleted: 'Modern Nalukettu Courtyard Estate',
    projectCategory: 'Heritage Contemporary Fusion',
    year: 'Delivered 2023',
    quote: 'They respected traditional Alappuzha woodcraft heritage while seamlessly embedding concealed smart home automation.',
    detailedFeedback: 'Finding timber masters capable of carving authentic Machakam woodwork while simultaneously integrating concealed multi-zone VRF air conditioning was extraordinary. The central open courtyard channels heavy monsoon rain like poetry.',
    rating: 5,
    verifiedClient: true,
    avatarInitials: 'LV',
    highlights: ['Heritage Woodwork Restoration', 'Rainwater Harvesting', 'Concealed Smart Home Systems'],
    helpfulCount: 31
  },
  {
    id: 'rev-6',
    name: 'Mathew Koshy',
    role: 'Plantation Owner & Investor',
    location: 'Mararikulam Coastal Stretch, Alappuzha',
    projectCompleted: 'Marari Coastal Eco-Villa',
    projectCategory: 'Eco-Luxury Residence',
    year: 'Delivered 2024',
    quote: 'Flawless execution of solar microgrids and salt-air-resistant structural coatings along Mararikulam beach.',
    detailedFeedback: 'We wanted an eco-friendly sanctuary that could withstand coastal salinity without continuous upkeep. APS used specialized anti-corrosive fasteners, seasoned teakwood, and concealed rainwater harvesting tanks that perform impeccably.',
    rating: 5,
    verifiedClient: true,
    avatarInitials: 'MK',
    highlights: ['Anti-Corrosion Coastal Coatings', 'Solar Battery Microgrid', 'Permaculture Landscape'],
    helpfulCount: 16
  },
  {
    id: 'rev-7',
    name: 'Amina & Firoz Khan',
    role: 'Architectural Patrons & NRI Business Leaders',
    location: 'Pallathuruthy Waterways, Alappuzha',
    projectCompleted: 'Serene Waterway Pavilion Home',
    projectCategory: 'Bespoke Residence',
    year: 'Delivered 2025',
    quote: 'Their attention to foundation piling in marshy backwater ground saved us both time and immense construction stress.',
    detailedFeedback: 'We had heard horror stories about foundation settlements near the waterways with other contractors. APS conducted comprehensive subsoil test bores, presented three pile foundation options, and built a rock-solid foundation backed by structural guarantees.',
    rating: 5,
    verifiedClient: true,
    avatarInitials: 'AK',
    highlights: ['Bored Cast-in-Situ Piling', 'Vastu Waterway Balancing', 'Turnkey Interior Joinery'],
    helpfulCount: 22
  },
  {
    id: 'rev-8',
    name: 'Prof. P. Sankaran Nair',
    role: 'Retired Principal & Civil Engineer',
    location: 'Cullen Road, Alappuzha Town',
    projectCompleted: 'Nair Ancestral Home Modernization',
    projectCategory: 'Structural Restoration',
    year: 'Delivered 2023',
    quote: 'Superb balance of structural reinforcement without altering our 70-year-old heritage architecture in Alappuzha.',
    detailedFeedback: 'Retrofitting old laterite stone structures with RCC ring beams requires utmost care. The APS engineering crew was respectful of our family home, kept the site pristine, and finished within budget.',
    rating: 5,
    verifiedClient: true,
    avatarInitials: 'SN',
    highlights: ['Heritage Laterite Retrofitting', 'RCC Ring Beam Stiffening', 'On-Budget Handover'],
    helpfulCount: 14
  }
];

export default function TestimonialCarousel() {
  const [reviews, setReviews] = useState<ClientReview[]>(INITIAL_REVIEWS);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [direction, setDirection] = useState(1);
  const [filterRating, setFilterRating] = useState<number | 'all'>('all');
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);

  // New review form state
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState('');
  const [newLocation, setNewLocation] = useState('Alappuzha');
  const [newRating, setNewRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [newQuote, setNewQuote] = useState('');
  const [newDetailedFeedback, setNewDetailedFeedback] = useState('');
  const [newProject, setNewProject] = useState('Custom Residence in Alappuzha');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [reviewSubmittedSuccess, setReviewSubmittedSuccess] = useState(false);

  // Filter reviews
  const filteredReviews = filterRating === 'all'
    ? reviews
    : reviews.filter((r) => r.rating === filterRating);

  // Auto-play interval
  useEffect(() => {
    if (!isPlaying || filteredReviews.length <= 1) return;
    const timer = setInterval(() => {
      handleNext();
    }, 7500);
    return () => clearInterval(timer);
  }, [isPlaying, currentIndex, filteredReviews.length]);

  // Keep index in range
  useEffect(() => {
    if (currentIndex >= filteredReviews.length) {
      setCurrentIndex(0);
    }
  }, [filterRating, filteredReviews.length]);

  const handleNext = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % filteredReviews.length);
  };

  const handlePrev = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + filteredReviews.length) % filteredReviews.length);
  };

  const handleVoteHelpful = (id: string) => {
    setReviews((prev) =>
      prev.map((r) =>
        r.id === id ? { ...r, helpfulCount: (r.helpfulCount || 0) + 1 } : r
      )
    );
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newQuote.trim()) return;

    setIsSubmittingReview(true);
    setTimeout(() => {
      const initials = newName
        .split(' ')
        .map((n) => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2) || 'AP';

      const userReview: ClientReview = {
        id: `rev-${Date.now()}`,
        name: newName.trim(),
        role: newRole.trim() || 'Valued Client in Alappuzha',
        location: newLocation.trim() || 'Alappuzha, Kerala',
        projectCompleted: newProject.trim(),
        projectCategory: 'Client Commission',
        year: 'Submitted 2026',
        quote: newQuote.trim(),
        detailedFeedback: newDetailedFeedback.trim() || newQuote.trim(),
        rating: newRating,
        verifiedClient: true,
        avatarInitials: initials,
        highlights: ['Verified Client Review', 'Alappuzha Project', '5-Star Quality Benchmark'],
        helpfulCount: 1
      };

      setReviews([userReview, ...reviews]);
      setIsSubmittingReview(false);
      setReviewSubmittedSuccess(true);
      setTimeout(() => {
        setReviewSubmittedSuccess(false);
        setIsReviewModalOpen(false);
        setNewName('');
        setNewRole('');
        setNewQuote('');
        setNewDetailedFeedback('');
      }, 1600);
    }, 600);
  };

  const current = filteredReviews[currentIndex] || filteredReviews[0] || reviews[0];

  // Calculate overall metrics
  const totalReviewsCount = reviews.length;
  const averageRating = (
    reviews.reduce((acc, r) => acc + r.rating, 0) / totalReviewsCount
  ).toFixed(1);
  const fiveStarPercentage = Math.round(
    (reviews.filter((r) => r.rating === 5).length / totalReviewsCount) * 100
  );

  const slideVariants: Variants = {
    enter: (dir: number) => ({
      x: dir > 0 ? 35 : -35,
      opacity: 0,
      scale: 0.98
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
      transition: {
        x: { type: 'spring' as const, stiffness: 300, damping: 28 },
        opacity: { duration: 0.35 },
        scale: { duration: 0.35 }
      }
    },
    exit: (dir: number) => ({
      x: dir > 0 ? -35 : 35,
      opacity: 0,
      scale: 0.98,
      transition: {
        x: { type: 'spring' as const, stiffness: 300, damping: 28 },
        opacity: { duration: 0.25 }
      }
    })
  };

  return (
    <section id="client-testimonials-section" className="w-full max-w-6xl mx-auto px-6 mb-28 scroll-mt-24">
      {/* SECTION HEADER: Star Rating & Client Reviews */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10 pb-6 border-b border-[#c5a059]/20">
        <div>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/35 text-[11px] font-serif uppercase tracking-[0.25em] text-[#f3e5ab] font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Client Feedback & Star Ratings</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight mb-2">
            Client Reviews & Star Ratings
          </h2>

          <p className="text-xs sm:text-sm text-stone-300 font-serif font-light max-w-2xl leading-relaxed">
            Read verified reviews and star ratings from doctors, engineers, NRI homeowners, and commercial patrons who commissioned APS Builders across Alappuzha.
          </p>
        </div>

        {/* Aggregate Star Rating Pill & Action */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-[#0e121d] border border-[#c5a059]/35 shadow-lg">
            <div className="text-3xl font-serif font-bold text-[#f3e5ab] leading-none">
              {averageRating}
            </div>
            <div>
              <div className="flex items-center gap-1 text-[#d4af37] mb-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[#d4af37] text-[#d4af37]" />
                ))}
              </div>
              <div className="text-[11px] font-serif text-stone-400">
                Based on <strong className="text-white">{totalReviewsCount} Verified Reviews</strong> ({fiveStarPercentage}% 5-Star)
              </div>
            </div>
          </div>

          <button
            onClick={() => setIsReviewModalOpen(true)}
            className="px-5 py-3.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#c5a059] hover:from-[#f3e5ab] hover:to-[#d4af37] text-stone-950 font-serif font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 shadow-lg shadow-[#d4af37]/20 cursor-pointer hover:scale-105 active:scale-95"
          >
            <PlusCircle className="w-4 h-4 text-stone-950" />
            <span>Write a Review</span>
          </button>
        </div>
      </div>

      {/* FILTER & CAROUSEL CONTROLS BAR */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        {/* Star Rating Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <span className="text-xs font-serif uppercase tracking-wider text-stone-400 mr-1 shrink-0">
            Filter:
          </span>
          <button
            onClick={() => setFilterRating('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-serif transition-all cursor-pointer shrink-0 ${
              filterRating === 'all'
                ? 'bg-[#d4af37] text-stone-950 font-bold shadow-md'
                : 'bg-[#0b0e17] text-stone-300 border border-white/10 hover:border-[#c5a059]/40'
            }`}
          >
            All Reviews ({reviews.length})
          </button>
          <button
            onClick={() => setFilterRating(5)}
            className={`px-3 py-1.5 rounded-lg text-xs font-serif transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
              filterRating === 5
                ? 'bg-[#d4af37] text-stone-950 font-bold shadow-md'
                : 'bg-[#0b0e17] text-stone-300 border border-white/10 hover:border-[#c5a059]/40'
            }`}
          >
            <span>5 Stars</span>
            <Star className={`w-3 h-3 ${filterRating === 5 ? 'fill-stone-950 text-stone-950' : 'fill-[#d4af37] text-[#d4af37]'}`} />
            <span>({reviews.filter((r) => r.rating === 5).length})</span>
          </button>
        </div>

        {/* Carousel Prev/Next & Play/Pause */}
        <div className="flex items-center gap-2.5 self-end sm:self-auto">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-9 h-9 rounded-full border border-white/10 hover:border-[#d4af37]/60 bg-[#090b12] text-stone-300 hover:text-white flex items-center justify-center transition-all cursor-pointer shadow-sm"
            title={isPlaying ? 'Pause auto-rotation' : 'Play auto-rotation'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5 text-[#d4af37]" /> : <Play className="w-3.5 h-3.5 text-[#d4af37]" />}
          </button>
          <button
            onClick={handlePrev}
            className="w-9 h-9 rounded-full border border-white/10 hover:border-[#d4af37]/60 bg-[#090b12] text-stone-300 hover:text-white flex items-center justify-center transition-all cursor-pointer shadow-sm hover:scale-105 active:scale-95"
            title="Previous review"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={handleNext}
            className="w-9 h-9 rounded-full border border-white/10 hover:border-[#d4af37]/60 bg-[#090b12] text-stone-300 hover:text-white flex items-center justify-center transition-all cursor-pointer shadow-sm hover:scale-105 active:scale-95"
            title="Next review"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* MAIN TESTIMONIAL DISPLAY STAGE */}
      <TiltCard3D maxTilt={5} glare={false} className="rounded-3xl">
        <div className="bg-gradient-to-b from-[#111422] to-[#090b12] border border-[#c5a059]/35 rounded-3xl p-6 sm:p-12 shadow-2xl relative overflow-hidden">
          {/* Subtle Watermark */}
          <div className="absolute top-4 right-6 pointer-events-none opacity-5">
            <Quote className="w-44 h-44 text-[#d4af37]" />
          </div>

          {/* Top Hairline Gold Accent */}
          <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#d4af37] to-transparent" />

          {current ? (
            <div className="relative z-10 min-h-[360px] flex flex-col justify-between">
              <AnimatePresence mode="wait" custom={direction}>
                <motion.div
                  key={current.id}
                  custom={direction}
                  variants={slideVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  className="space-y-6"
                >
                  {/* Meta Bar: Stars & Verified Badge */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-5 border-b border-[#c5a059]/20">
                    <div className="flex items-center gap-3">
                      {/* Dynamic Star Rating */}
                      <div className="flex items-center gap-1 text-[#d4af37]" aria-label={`${current.rating} out of 5 stars`}>
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < current.rating
                                ? 'fill-[#d4af37] text-[#d4af37]'
                                : 'fill-stone-800 text-stone-700'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-[11px] font-serif uppercase tracking-widest text-[#f3e5ab] font-bold">
                        {current.rating}.0 / 5.0 Star Rating
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-xs font-serif text-stone-400">
                      <span className="flex items-center gap-1.5 text-stone-300">
                        <MapPin className="w-3.5 h-3.5 text-[#d4af37]" />
                        <span>{current.location}</span>
                      </span>
                      <span className="text-stone-600">·</span>
                      <span className="text-[#f3e5ab] font-medium">{current.year}</span>
                    </div>
                  </div>

                  {/* Primary Large Quote */}
                  <blockquote className="text-xl sm:text-2xl md:text-3xl font-serif font-bold text-white leading-snug tracking-tight">
                    &ldquo;{current.quote}&rdquo;
                  </blockquote>

                  {/* Detailed Narrative */}
                  <p className="text-xs sm:text-sm text-stone-300 font-serif font-light leading-relaxed max-w-4xl">
                    {current.detailedFeedback}
                  </p>

                  {/* Highlights tags */}
                  {current.highlights && current.highlights.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <span className="text-[11px] font-serif uppercase tracking-wider text-stone-400 mr-1">
                        Verified Specs:
                      </span>
                      {current.highlights.map((h, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 rounded-full bg-[#070912] border border-[#c5a059]/30 text-[#f3e5ab] text-xs font-serif flex items-center gap-1.5"
                        >
                          <CheckCircle2 className="w-3 h-3 text-[#d4af37]" />
                          <span>{h}</span>
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Author Badge & Project Reference */}
                  <div className="pt-6 border-t border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-13 h-13 rounded-2xl bg-gradient-to-br from-[#d4af37]/30 to-[#101422] border border-[#d4af37]/60 flex items-center justify-center text-lg font-serif font-bold text-[#f3e5ab] shadow-inner">
                        {current.avatarInitials}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-base font-serif font-bold text-white">
                            {current.name}
                          </h4>
                          {current.verifiedClient && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-serif uppercase tracking-wider text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-md">
                              <ShieldCheck className="w-3 h-3" /> Verified Alappuzha Patron
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-stone-400 font-serif">
                          {current.role}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="p-3 rounded-xl bg-[#070912] border border-white/5 sm:text-right">
                        <div className="text-[10px] font-serif uppercase tracking-wider text-stone-400">
                          Constructed Property:
                        </div>
                        <div className="text-xs font-serif font-bold text-[#f3e5ab] flex items-center sm:justify-end gap-1.5 mt-0.5">
                          <Building2 className="w-3.5 h-3.5 text-[#d4af37]" />
                          <span>{current.projectCompleted}</span>
                        </div>
                      </div>

                      {/* Helpful Button */}
                      <button
                        onClick={() => handleVoteHelpful(current.id)}
                        className="p-3 rounded-xl bg-white/5 hover:bg-[#d4af37]/15 border border-white/10 hover:border-[#d4af37]/50 text-stone-300 hover:text-white transition-all text-xs font-serif flex items-center gap-1.5 cursor-pointer"
                        title="Mark review as helpful"
                      >
                        <ThumbsUp className="w-3.5 h-3.5 text-[#d4af37]" />
                        <span>Helpful ({current.helpfulCount || 0})</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* Pagination Indicators Strip */}
              <div className="pt-8 flex items-center justify-between border-t border-white/5 mt-6">
                <div className="text-xs font-serif text-stone-400">
                  Review <span className="text-[#f3e5ab] font-bold">0{currentIndex + 1}</span>
                  <span className="mx-1.5 text-stone-600">/</span>
                  <span>0{filteredReviews.length}</span>
                </div>

                {/* Dot Selectors */}
                <div className="flex items-center gap-2">
                  {filteredReviews.map((r, idx) => (
                    <button
                      key={r.id}
                      onClick={() => {
                        setDirection(idx > currentIndex ? 1 : -1);
                        setCurrentIndex(idx);
                      }}
                      className={`h-2 transition-all duration-300 rounded-full cursor-pointer ${
                        currentIndex === idx
                          ? 'w-8 bg-gradient-to-r from-[#d4af37] to-[#f3e5ab]'
                          : 'w-2 bg-stone-700 hover:bg-stone-500'
                      }`}
                      title={`Read review by ${r.name}`}
                    />
                  ))}
                </div>

                <div className="text-xs font-serif text-stone-400 hidden sm:block">
                  Dedicated Exclusively to Alappuzha Architecture
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-stone-400 font-serif">
              No reviews found matching the selected star filter.
            </div>
          )}
        </div>
      </TiltCard3D>

      {/* QUICK CLIENT SUBMIT REVIEW MODAL */}
      <AnimatePresence>
        {isReviewModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.94, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.94, opacity: 0, y: 20 }}
              className="bg-[#0e121e] border border-[#c5a059]/50 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl relative p-6 sm:p-8"
            >
              {/* Close Button */}
              <button
                onClick={() => setIsReviewModalOpen(false)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/60 text-stone-300 hover:text-white border border-white/10 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              {!reviewSubmittedSuccess ? (
                <form onSubmit={handleReviewSubmit} className="space-y-4">
                  <div className="flex items-center gap-2 text-[#d4af37] mb-1">
                    <MessageSquare className="w-4 h-4" />
                    <span className="text-[10px] font-serif uppercase tracking-widest font-bold">
                      Verified Client Feedback
                    </span>
                  </div>
                  <h3 className="text-xl font-serif font-bold text-white">
                    Submit Your Alappuzha Review & Rating
                  </h3>
                  <p className="text-xs text-stone-400 font-serif leading-relaxed mb-4">
                    Share your experience working with APS Builders on your residential or commercial project in Alappuzha.
                  </p>

                  {/* Interactive Star Rating Selector */}
                  <div>
                    <label className="block text-xs font-serif uppercase text-stone-300 mb-1.5 font-semibold">
                      Star Rating (1 to 5 Stars) *
                    </label>
                    <div className="flex items-center gap-2 p-3 bg-[#080a12] border border-[#c5a059]/30 rounded-xl">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          type="button"
                          key={star}
                          onClick={() => setNewRating(star)}
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(0)}
                          className="p-1 cursor-pointer transition-transform hover:scale-120"
                        >
                          <Star
                            className={`w-6 h-6 ${
                              star <= (hoverRating || newRating)
                                ? 'fill-[#d4af37] text-[#d4af37]'
                                : 'fill-stone-800 text-stone-600'
                            }`}
                          />
                        </button>
                      ))}
                      <span className="text-xs font-serif text-[#f3e5ab] ml-2 font-bold">
                        {hoverRating || newRating} / 5 Stars
                      </span>
                    </div>
                  </div>

                  {/* Name and Role */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-serif uppercase text-stone-300 mb-1 font-semibold">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={newName}
                        onChange={(e) => setNewName(e.target.value)}
                        placeholder="e.g. Ramesh Varma"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#080a12] border border-[#c5a059]/30 text-xs text-white placeholder-stone-600 focus:outline-none focus:border-[#d4af37] font-serif"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-serif uppercase text-stone-300 mb-1 font-semibold">
                        Profession / Role
                      </label>
                      <input
                        type="text"
                        value={newRole}
                        onChange={(e) => setNewRole(e.target.value)}
                        placeholder="e.g. Homeowner / Doctor"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#080a12] border border-[#c5a059]/30 text-xs text-white placeholder-stone-600 focus:outline-none focus:border-[#d4af37] font-serif"
                      />
                    </div>
                  </div>

                  {/* Location and Project */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-serif uppercase text-stone-300 mb-1 font-semibold">
                        Location in Alappuzha
                      </label>
                      <input
                        type="text"
                        value={newLocation}
                        onChange={(e) => setNewLocation(e.target.value)}
                        placeholder="e.g. Punnamada, Beach Road"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#080a12] border border-[#c5a059]/30 text-xs text-white placeholder-stone-600 focus:outline-none focus:border-[#d4af37] font-serif"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-serif uppercase text-stone-300 mb-1 font-semibold">
                        Project Commissioned
                      </label>
                      <input
                        type="text"
                        value={newProject}
                        onChange={(e) => setNewProject(e.target.value)}
                        placeholder="e.g. Waterfront Villa"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#080a12] border border-[#c5a059]/30 text-xs text-white placeholder-stone-600 focus:outline-none focus:border-[#d4af37] font-serif"
                      />
                    </div>
                  </div>

                  {/* Headline Quote */}
                  <div>
                    <label className="block text-[11px] font-serif uppercase text-stone-300 mb-1 font-semibold">
                      Headline Review Summary *
                    </label>
                    <input
                      type="text"
                      required
                      value={newQuote}
                      onChange={(e) => setNewQuote(e.target.value)}
                      placeholder="e.g. Unmatched structural quality and honest communication"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#080a12] border border-[#c5a059]/30 text-xs text-white placeholder-stone-600 focus:outline-none focus:border-[#d4af37] font-serif"
                    />
                  </div>

                  {/* Detailed Feedback */}
                  <div>
                    <label className="block text-[11px] font-serif uppercase text-stone-300 mb-1 font-semibold">
                      Detailed Experience
                    </label>
                    <textarea
                      rows={3}
                      value={newDetailedFeedback}
                      onChange={(e) => setNewDetailedFeedback(e.target.value)}
                      placeholder="Share details regarding engineering quality, handover timelines, material standards..."
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#080a12] border border-[#c5a059]/30 text-xs text-white placeholder-stone-600 focus:outline-none focus:border-[#d4af37] font-serif resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmittingReview}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#f3e5ab] to-[#c5a059] text-stone-950 font-serif font-bold text-xs uppercase tracking-wider transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer hover:opacity-90 disabled:opacity-50"
                  >
                    {isSubmittingReview ? (
                      <span>Submitting Review...</span>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5 text-stone-950" />
                        <span>Publish Review</span>
                      </>
                    )}
                  </button>
                </form>
              ) : (
                <div className="text-center py-8">
                  <div className="w-14 h-14 rounded-full bg-[#d4af37]/20 border border-[#d4af37]/50 text-[#d4af37] flex items-center justify-center mx-auto mb-3">
                    <Check className="w-7 h-7" />
                  </div>
                  <h4 className="text-xl font-serif font-bold text-white mb-1">
                    Thank You for Your Review!
                  </h4>
                  <p className="text-xs text-stone-300 font-serif">
                    Your feedback and star rating have been added to the verified Alappuzha reviews registry.
                  </p>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
