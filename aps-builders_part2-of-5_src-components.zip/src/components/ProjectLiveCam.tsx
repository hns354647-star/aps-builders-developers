import React, { useState, useEffect } from 'react';
import { Camera, Radio, Maximize2, Shield, Settings, Info, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ProjectLiveCamProps {
  projectTitle: string;
  location: string;
}

export default function ProjectLiveCam({ projectTitle, location }: ProjectLiveCamProps) {
  const [timestamp, setTimestamp] = useState(new Date());
  const [isLive, setIsLive] = useState(true);

  useEffect(() => {
    const timer = setInterval(() => setTimestamp(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-slate-900 rounded-sm overflow-hidden flex flex-col h-[500px] border border-slate-800 shadow-2xl">
      {/* Feed Header */}
      <div className="bg-slate-950 p-3 flex items-center justify-between border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Radio className="w-4 h-4 text-rose-500" />
              <motion.div 
                animate={{ scale: [1, 1.5, 1], opacity: [1, 0, 1] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="absolute inset-0 bg-rose-500 rounded-full"
              />
            </div>
            <span className="text-[10px] font-bold text-white uppercase tracking-widest">Live Feed 01</span>
          </div>
          <div className="h-4 w-px bg-white/10" />
          <div className="flex items-center gap-1.5">
            <Shield className="w-3 h-3 text-emerald-500" />
            <span className="text-[9px] text-slate-400 font-medium uppercase tracking-tight">SECURE SSL TUNNEL</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
            <div className="text-[10px] font-mono text-slate-400">
                {timestamp.toLocaleTimeString([], { hour12: false })} IST
            </div>
            <div className="flex items-center gap-2">
                <button className="text-slate-400 hover:text-white transition-colors">
                    <Settings className="w-3.5 h-3.5" />
                </button>
                <button className="text-slate-400 hover:text-white transition-colors">
                    <Maximize2 className="w-3.5 h-3.5" />
                </button>
            </div>
        </div>
      </div>

      {/* Main Feed Stage */}
      <div className="flex-1 relative bg-black group overflow-hidden">
        {/* Simulating a real CCTV feel with a darker placeholder and scanning lines */}
        <div className="absolute inset-0 z-0 bg-[url('https://images.unsplash.com/photo-1541888946425-d81bb19240f5?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-40 grayscale contrast-125 brightness-50" />
        
        {/* Grid/Scanning Overlay */}
        <div className="absolute inset-0 pointer-events-none z-10 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.02),rgba(0,255,0,0.01),rgba(0,0,255,0.02))] bg-[length:100%_2px,3px_100%] opacity-20" />
        
        {/* HUD Elements */}
        <div className="absolute top-6 left-6 z-20 flex flex-col gap-1">
            <div className="bg-rose-600 text-white text-[9px] font-bold px-2 py-0.5 rounded-sm flex items-center gap-1 w-fit shadow-lg">
                <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                RECORDING
            </div>
            <div className="text-[11px] font-mono text-white/70 tracking-widest bg-black/40 px-2 py-0.5 backdrop-blur-sm rounded-sm">
                CAM_ID: {projectTitle.substring(0, 3).toUpperCase()}_082
            </div>
        </div>

        <div className="absolute bottom-6 right-6 z-20 text-right">
             <div className="text-[10px] font-mono text-white/50 mb-1 uppercase tracking-tighter">
                APS Site Monitoring System v4.2
             </div>
             <div className="text-[12px] font-mono text-white tracking-widest font-bold">
                {location.toUpperCase()} SITE
             </div>
        </div>

        {/* Action Overlay */}
        <div className="absolute inset-0 flex items-center justify-center z-20 opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 backdrop-blur-[2px]">
            <div className="flex flex-col items-center gap-4">
                <Camera className="w-10 h-10 text-white" />
                <p className="text-white font-bold text-xs uppercase tracking-[0.3em]">Encrypted Client Preview</p>
                <div className="flex gap-2">
                    <button className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-4 py-2 text-[10px] font-bold uppercase tracking-widest transition-all">
                        Switch View
                    </button>
                    <button className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 text-[10px] font-bold uppercase tracking-widest transition-all">
                        Take Snapshot
                    </button>
                </div>
            </div>
        </div>

        {/* Animated Corner Brackets */}
        <div className="absolute top-4 left-4 w-6 h-6 border-t-2 border-l-2 border-white/30" />
        <div className="absolute top-4 right-4 w-6 h-6 border-t-2 border-r-2 border-white/30" />
        <div className="absolute bottom-4 left-4 w-6 h-6 border-b-2 border-l-2 border-white/30" />
        <div className="absolute bottom-4 right-4 w-6 h-6 border-b-2 border-r-2 border-white/30" />
      </div>

      {/* Analytics Footer */}
      <div className="bg-slate-950 p-4 grid grid-cols-3 gap-6 border-t border-white/5">
        <div className="space-y-1">
            <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">Active Personnel</p>
            <div className="flex items-center gap-2">
                <Activity className="w-3 h-3 text-amber-500" />
                <span className="text-xs font-mono text-white">12 Detected</span>
            </div>
        </div>
        <div className="space-y-1">
            <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">Temp / Humidity</p>
            <p className="text-xs font-mono text-white">32°C / 78%</p>
        </div>
        <div className="space-y-1">
            <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">Network Latency</p>
            <p className="text-xs font-mono text-emerald-500">24ms (Optimal)</p>
        </div>
      </div>

      <div className="bg-amber-600/10 p-2 flex items-center gap-2 border-t border-amber-600/20">
        <Info className="w-3 h-3 text-amber-600" />
        <p className="text-[8px] text-amber-100/70 font-medium uppercase tracking-tighter">
            Note: This is a secure private feed for registered clients. Please report any anomalies to the site engineer.
        </p>
      </div>
    </div>
  );
}
