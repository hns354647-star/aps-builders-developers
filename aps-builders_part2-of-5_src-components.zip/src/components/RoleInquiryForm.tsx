import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Send, User, Phone, Mail, CheckCircle2, MessageSquare, Loader2, AlertCircle } from 'lucide-react';
import { roleInquirySchema, validateField } from '../schemas/validationSchemas';

interface RoleInquiryFormProps {
  member: {
    name: string;
    role: string;
  };
  onClose: () => void;
}

export default function RoleInquiryForm({ member, onClose }: RoleInquiryFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: `Hi ${member.name}, I'm interested in discussing the ${member.role} aspects of a new project...`
  });

  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleFieldChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));

    if (touched[field]) {
      const error = validateField(roleInquirySchema, field, value);
      setErrors(prev => {
        const next = { ...prev };
        if (error) {
          next[field] = error;
        } else {
          delete next[field];
        }
        return next;
      });
    }
  };

  const handleFieldBlur = (field: keyof typeof formData) => {
    setTouched(prev => ({ ...prev, [field]: true }));
    const error = validateField(roleInquirySchema, field, formData[field]);
    setErrors(prev => {
      const next = { ...prev };
      if (error) {
        next[field] = error;
      } else {
        delete next[field];
      }
      return next;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const allTouched = { name: true, phone: true, email: true, message: true };
    setTouched(allTouched);

    const parseResult = roleInquirySchema.safeParse(formData);
    if (!parseResult.success) {
      const fieldErrors: Record<string, string> = {};
      const issues = parseResult.error.issues || (parseResult.error as any).errors || [];
      issues.forEach((err: any) => {
        const pathKey = err.path[0] as string;
        if (pathKey && !fieldErrors[pathKey]) {
          fieldErrors[pathKey] = err.message;
        }
      });
      setErrors(fieldErrors);
      return;
    }

    setErrors({});
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  if (isSuccess) {
    return (
      <div className="text-center py-12 px-6">
        <motion.div 
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-6"
        >
          <CheckCircle2 className="w-10 h-10 text-green-500" />
        </motion.div>
        <h3 className="text-2xl font-display font-bold text-slate-900 mb-2">Message Sent!</h3>
        <p className="text-slate-500 text-sm mb-8">
          Your inquiry has been directly forwarded to <span className="font-bold text-slate-900">{member.name}</span>. 
          Expect a response within 24-48 business hours.
        </p>
        <button 
          onClick={onClose}
          className="w-full bg-slate-900 text-white py-4 rounded-sm font-bold text-xs uppercase tracking-widest hover:bg-amber-600 transition-all shadow-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
        >
          Close Drawer
        </button>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="flex items-start justify-between mb-8">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-1.5 h-1.5 bg-amber-600 rounded-full animate-pulse" />
            <span className="text-[10px] font-bold text-amber-600 uppercase tracking-widest">Priority Inquiry</span>
          </div>
          <h3 className="text-xl font-display font-bold text-slate-900 leading-tight">
            Consult with {member.name.split(' ')[1] || member.name}
          </h3>
          <p className="text-xs text-slate-500 mt-1">Direct channel to our {member.role}</p>
        </div>
        <button 
          onClick={onClose}
          aria-label="Close inquiry form"
          className="p-2 hover:bg-slate-100 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500"
        >
          <X className="w-5 h-5 text-slate-400" />
        </button>
      </div>

      <form onSubmit={handleSubmit} noValidate className="space-y-4">
        {/* Full Name */}
        <div className="space-y-1">
          <div className="flex items-center justify-between ml-1">
            <label htmlFor="inquiry-name" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Your Name *</label>
            {touched.name && !errors.name && formData.name && (
              <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Valid
              </span>
            )}
          </div>
          <div className="relative">
            <User className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${errors.name ? 'text-red-400' : 'text-slate-400'}`} />
            <input 
              id="inquiry-name"
              type="text"
              value={formData.name}
              onChange={e => handleFieldChange('name', e.target.value)}
              onBlur={() => handleFieldBlur('name')}
              placeholder="e.g. Vikram Verma"
              aria-invalid={errors.name ? 'true' : 'false'}
              className={`w-full pl-12 pr-4 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all ${
                errors.name 
                  ? 'border-red-500 bg-red-50/20 focus:border-red-600' 
                  : touched.name && formData.name 
                    ? 'border-emerald-500 focus:border-emerald-600' 
                    : 'border-slate-200 focus:border-amber-600 focus:bg-white'
              }`}
            />
          </div>
          {errors.name && (
            <p className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
              <AlertCircle className="w-3 h-3 shrink-0" /> {errors.name}
            </p>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Mobile */}
          <div className="space-y-1">
            <div className="flex items-center justify-between ml-1">
              <label htmlFor="inquiry-phone" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Mobile *</label>
              {touched.phone && !errors.phone && formData.phone && (
                <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Valid
                </span>
              )}
            </div>
            <div className="relative">
              <Phone className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${errors.phone ? 'text-red-400' : 'text-slate-400'}`} />
              <input 
                id="inquiry-phone"
                type="tel"
                value={formData.phone}
                onChange={e => handleFieldChange('phone', e.target.value)}
                onBlur={() => handleFieldBlur('phone')}
                placeholder="+91..."
                aria-invalid={errors.phone ? 'true' : 'false'}
                className={`w-full pl-12 pr-4 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all ${
                  errors.phone 
                    ? 'border-red-500 bg-red-50/20 focus:border-red-600' 
                    : touched.phone && formData.phone 
                      ? 'border-emerald-500 focus:border-emerald-600' 
                      : 'border-slate-200 focus:border-amber-600 focus:bg-white'
                }`}
              />
            </div>
            {errors.phone && (
              <p className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
                <AlertCircle className="w-3 h-3 shrink-0" /> {errors.phone}
              </p>
            )}
          </div>

          {/* Email */}
          <div className="space-y-1">
            <div className="flex items-center justify-between ml-1">
              <label htmlFor="inquiry-email" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Email *</label>
              {touched.email && !errors.email && formData.email && (
                <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Valid
                </span>
              )}
            </div>
            <div className="relative">
              <Mail className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${errors.email ? 'text-red-400' : 'text-slate-400'}`} />
              <input 
                id="inquiry-email"
                type="email"
                value={formData.email}
                onChange={e => handleFieldChange('email', e.target.value)}
                onBlur={() => handleFieldBlur('email')}
                placeholder="Email Address"
                aria-invalid={errors.email ? 'true' : 'false'}
                className={`w-full pl-12 pr-4 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all ${
                  errors.email 
                    ? 'border-red-500 bg-red-50/20 focus:border-red-600' 
                    : touched.email && formData.email 
                      ? 'border-emerald-500 focus:border-emerald-600' 
                      : 'border-slate-200 focus:border-amber-600 focus:bg-white'
                }`}
              />
            </div>
            {errors.email && (
              <p className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
                <AlertCircle className="w-3 h-3 shrink-0" /> {errors.email}
              </p>
            )}
          </div>
        </div>

        {/* Message */}
        <div className="space-y-1">
          <div className="flex items-center justify-between ml-1">
            <label htmlFor="inquiry-message" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Inquiry Details *</label>
            {touched.message && !errors.message && formData.message.length >= 10 && (
              <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Valid
              </span>
            )}
          </div>
          <div className="relative">
            <MessageSquare className={`absolute left-4 top-4 w-4 h-4 ${errors.message ? 'text-red-400' : 'text-slate-400'}`} />
            <textarea 
              id="inquiry-message"
              rows={4}
              value={formData.message}
              onChange={e => handleFieldChange('message', e.target.value)}
              onBlur={() => handleFieldBlur('message')}
              aria-invalid={errors.message ? 'true' : 'false'}
              className={`w-full pl-12 pr-4 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all resize-none ${
                errors.message 
                  ? 'border-red-500 bg-red-50/20 focus:border-red-600' 
                  : touched.message && formData.message.length >= 10 
                    ? 'border-emerald-500 focus:border-emerald-600' 
                    : 'border-slate-200 focus:border-amber-600 focus:bg-white'
              }`}
            />
          </div>
          {errors.message && (
            <p className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
              <AlertCircle className="w-3 h-3 shrink-0" /> {errors.message}
            </p>
          )}
        </div>

        <div className="pt-4">
          <button
            disabled={isSubmitting}
            type="submit"
            className="w-full bg-slate-900 text-white py-4 rounded-sm font-bold text-xs uppercase tracking-widest hover:bg-amber-600 transition-all disabled:opacity-50 flex items-center justify-center gap-3 group focus:outline-none focus:ring-2 focus:ring-amber-500"
          >
            {isSubmitting ? (
              <Loader2 className="w-4 h-4 animate-spin text-amber-500" />
            ) : (
              <>
                Send Direct Message
                <Send className="w-3 h-3 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </>
            )}
          </button>
          
          <p className="text-[8px] text-slate-400 text-center mt-4 uppercase tracking-[0.2em]">
            Secure encrypted channel via APS Architecture Pvt Ltd.
          </p>
        </div>
      </form>
    </div>
  );
}

