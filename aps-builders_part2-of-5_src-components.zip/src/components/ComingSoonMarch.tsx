import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Calendar, 
  Clock, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  Building2, 
  MapPin, 
  Volume2, 
  VolumeX, 
  MessageCircle, 
  PhoneCall, 
  ShieldCheck, 
  ChevronRight, 
  ChevronDown,
  ChevronLeft,
  X,
  Star,
  Award,
  Layers,
  HelpCircle,
  Share2,
  Compass,
  Check,
  Maximize2,
  Mail,
  FileText,
  Box,
  Eye,
  Rotate3d
} from "lucide-react";
import confetti from "canvas-confetti";
import { QRCodeSVG } from "qrcode.react";

// Interactive 3D Spatial and Tilt Components
import TiltCard3D from "./TiltCard3D";
import LuxuryScene3D from "./LuxuryScene3D";
import ServicesSection from "./ServicesSection";
import QuoteContactSection from "./QuoteContactSection";
import TestimonialCarousel from "./TestimonialCarousel";

// High-resolution architectural assets
import villaDroneImg from "../assets/images/luxury_villa_drone_kerala_1780828001461.png";
import glassTowerImg from "../assets/images/aps_glass_tower_1780810854036.png";
import penthouseImg from "../assets/images/luxury_penthouse_interior_1780827920432.png";
import grandEntranceImg from "../assets/images/luxury_hotel_grand_entrance_1780827890648.png";
import contemporaryMuseumImg from "../assets/images/contemporary_museum_kerala_night_1780827949977.png";
import poolNightImg from "../assets/images/luxury_infinity_pool_night_1780827664726.png";
import corporateDawnImg from "../assets/images/corporate_hq_dawn_1780827906397.png";

interface ShowcaseProject {
  id: string;
  title: string;
  subTitle: string;
  badge: string;
  tagline: string;
  location: string;
  category: "all" | "villas" | "towers" | "commercial";
  categoryLabel: string;
  image: string;
  units: string;
  priceGuidance: string;
  completionPhase: string;
  dimensions: string;
  structuralSpec: string;
  highlights: string[];
}

const MARCH_SHOWCASE: ShowcaseProject[] = [
  {
    id: "villas",
    title: "The Palm Crest Sovereign Villas",
    subTitle: "Alappuzha Lakefront Enclave",
    badge: "Signature Waterfront",
    tagline: "Eco-intelligent lakeside mansions with private yacht berths, natural lagoon pools, and bespoke teak joinery.",
    location: "Vembanad Backwaters, Alappuzha",
    category: "villas",
    categoryLabel: "Waterfront Estate",
    image: villaDroneImg,
    units: "12 Exclusive Waterfront Mansions",
    priceGuidance: "Private Pre-Launch Allotments",
    completionPhase: "Private Docks & Landscaping (90%)",
    dimensions: "35 Cents Plot • 6,400 Sq.Ft Built-Up",
    structuralSpec: "Zero-Carbon Concrete • Teak & Stained Walnut Joinery • Solar Microgrid",
    highlights: [
      "100% Solar Microgrid with Battery Power Bank",
      "Private Boat Berth & Lakefront Promenade",
      "Stepped Infinity Saltwater Pool Overlooking Lagoon",
      "Traditional Kerala Nalukettu Courtyard Infused with Modern Glass"
    ]
  },
  {
    id: "tower",
    title: "APS Glass Horizon Sky Residences",
    subTitle: "Alappuzha Beachfront Landmark",
    badge: "Sky Suites Collection",
    tagline: "An architectural marvel rising over the Arabian Sea coastline in Alappuzha, featuring full-height structural glazing and sky lounges.",
    location: "Beach Road, Alappuzha",
    category: "towers",
    categoryLabel: "Sky Suites",
    image: glassTowerImg,
    units: "24 Panoramic Coastal Residences",
    priceGuidance: "Founder Patron Tier Available",
    completionPhase: "Glazing & Interior Fit-out (93%)",
    dimensions: "G+18 Floors • 3,800 to 5,600 Sq.Ft",
    structuralSpec: "LEED Platinum Double Low-E Argon • Grade 80 Reinforced Coastal RCC",
    highlights: [
      "Automated Biometric High-Speed Elevators",
      "18th Floor Private Sky Club & Sunset Infinity Deck",
      "Marine-Grade Acoustic Silence Glazing STC 56",
      "Double-Height Italian Calacatta Marble Grand Atrium"
    ]
  },
  {
    id: "penthouse",
    title: "The Punnamada Crown Penthouse Collection",
    subTitle: "Punnamada Waterway Sky Villas",
    badge: "Crown Penthouses",
    tagline: "Double-height duplex sky villas with open-sky stargazing lounges and private heated plunge pools along Punnamada waters.",
    location: "Punnamada Finishing Point, Alappuzha",
    category: "towers",
    categoryLabel: "Penthouse",
    image: penthouseImg,
    units: "6 Crown Residences",
    priceGuidance: "By Private Invitation",
    completionPhase: "Italian Marble Fitting (95%)",
    dimensions: "7.2m Double-Height Ceilings • 6,800 Sq.Ft",
    structuralSpec: "Italian Calacatta Stone • DALI 4-Zone Lighting Automation",
    highlights: [
      "Private Heated Cantilevered Plunge Pool Over Waterways",
      "Temperature-Controlled Private Tasting Cellar",
      "Custom Italian Calacatta Oro Kitchen",
      "Dedicated Butler Quarters & Private Service Entry"
    ]
  },
  {
    id: "experience-centre",
    title: "APS Architectural Experience Studio",
    subTitle: "Alappuzha Flagship Innovation Pavilion",
    badge: "Grand Experience Hub",
    tagline: "A three-tier architectural pavilion featuring full-scale material galleries and private client salons in the heart of Alappuzha.",
    location: "Cullen Road, Alappuzha Town",
    category: "commercial",
    categoryLabel: "Design Studio",
    image: grandEntranceImg,
    units: "15,000 Sq.Ft Innovation Studio",
    priceGuidance: "Public Launch March 2027",
    completionPhase: "Gallery Installations (92%)",
    dimensions: "3-Tier Architectural Pavilion",
    structuralSpec: "Titanium Louvers • High-Flux Skylight Ring • Living Green Walls",
    highlights: [
      "Full-Scale 1:1 Architectural Facade Gallery",
      "Classical Vastu Shastra Architectural Planning Studio",
      "Biophilic Air-Purifying Living Green Atrium",
      "Private Architect Salons for Patrons"
    ]
  },
  {
    id: "retreat",
    title: "Ayur Heritage Commercial & Wellness Plaza",
    subTitle: "Bespoke Backwater Commercial Landmark",
    badge: "Institutional Landmark",
    tagline: "An integrated wellness and premium commercial destination fronting the backwaters with eco-cooling pergolas.",
    location: "Vembanad Waterways, Alappuzha",
    category: "commercial",
    categoryLabel: "Commercial Plaza",
    image: contemporaryMuseumImg,
    units: "24 Premium Boutique Spaces",
    priceGuidance: "Pre-Opening Lease Rights",
    completionPhase: "Facade & Promenade (88%)",
    dimensions: "Waterfront Esplanade • 45,000 Sq.Ft",
    structuralSpec: "Hydrotherapy Water Harvesting • Solar Shading Pergolas",
    highlights: [
      "Central Rainwater Harvesting Reservoir",
      "Solar Pergolas with Natural Shading & Ventilation",
      "Waterfront Amphitheatre for Cultural Exhibitions",
      "Dedicated High-Speed EV Fast-Charging Infrastructure"
    ]
  }
];

const LUXURY_MATERIALS = [
  {
    title: "Italian Calacatta Oro",
    type: "Quarried Marble",
    origin: "Carrara, Italy",
    desc: "Hand-selected bookmatched slabs featuring warm amber veins, honed to a velvety satin finish."
  },
  {
    title: "Seasoned Nilambur Teak",
    type: "Certified Hardwood",
    origin: "Malabar, Kerala",
    desc: "18-month naturally cured heritage teak, hand-rubbed with organic oils for lasting warmth."
  },
  {
    title: "Double Low-E Argon Glazing",
    type: "Acoustic Insulation",
    origin: "Saint-Gobain Europe",
    desc: "Acoustic laminated double-pane glass ensuring complete tranquility while framing panoramic views."
  },
  {
    title: "Pozzolanic Eco Concrete",
    type: "Monolithic Structure",
    origin: "Sustainable Sourcing",
    desc: "High-grade reinforced structural matrix engineered for century-long coastal durability."
  }
];

const FAQS = [
  {
    q: "When is the official Grand Opening in March 2027?",
    a: "The formal Ribbon Cutting Gala and Experience Studio inauguration will take place in early March 2027 in Alappuzha, followed by scheduled private walkthroughs for registered patrons."
  },
  {
    q: "Can I inspect the construction sites before the March opening?",
    a: "Yes. Registered patrons receive priority scheduling for private site visits guided personally by our Principal Project Architects across our Alappuzha waterfront, beachfront, and commercial development sites."
  },
  {
    q: "Are pre-launch founder prices available for March releases?",
    a: "Yes. The initial allotment of registered patrons qualifies for exclusive pre-launch pricing and priority unit selection prior to general public release."
  },
  {
    q: "Are the homes designed according to traditional Vastu principles?",
    a: "Every APS layout harmonizes centuries-old Kerala Thachu Shastra (traditional Vastu science) with bioclimatic modern architecture, ensuring optimal natural light, thermal comfort, and positive energy flow."
  }
];

export default function ComingSoonMarch() {
  // Target: March 1, 2027 10:00 AM IST
  const targetDate = new Date("2027-03-01T10:00:00+05:30").getTime();

  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    progressPercent: number;
  }>({ days: 145, hours: 0, minutes: 0, seconds: 0, progressPercent: 78 });

  const [activeHeroIndex, setActiveHeroIndex] = useState(0);
  const [hero3DMode, setHero3DMode] = useState(false);
  const [modal3DMode, setModal3DMode] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<"all" | "villas" | "towers" | "commercial">("all");
  const [selectedProject, setSelectedProject] = useState<ShowcaseProject | null>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [isMuted, setIsMuted] = useState(true);

  // Private Invitation Form State
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [interest, setInterest] = useState("The Palm Crest Sovereign Villas (Alappuzha)");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [invitationCode, setInvitationCode] = useState("");

  // Synthesizer Audio Ref
  const audioCtxRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Countdown calculation
  useEffect(() => {
    const calculateTime = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, progressPercent: 100 });
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      const totalSpanDays = 180;
      const daysPassed = Math.max(0, totalSpanDays - days);
      const progressPercent = Math.min(99, Math.max(25, Math.round((daysPassed / totalSpanDays) * 100)));

      setTimeLeft({ days, hours, minutes, seconds, progressPercent });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [targetDate]);

  // Slideshow auto-rotation for hero spotlight
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveHeroIndex((prev) => (prev + 1) % MARCH_SHOWCASE.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  // Web Audio Synth for ambient architectural soundscape
  const toggleSound = () => {
    if (isMuted) {
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();
        audioCtxRef.current = ctx;

        const masterGain = ctx.createGain();
        masterGain.gain.setValueAtTime(0, ctx.currentTime);
        masterGain.gain.linearRampToValueAtTime(0.06, ctx.currentTime + 1.5);
        masterGain.connect(ctx.destination);
        gainNodeRef.current = masterGain;

        const freqs = [146.83, 220.00, 329.63, 440.00];
        freqs.forEach((f, i) => {
          const osc = ctx.createOscillator();
          const oscGain = ctx.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(f, ctx.currentTime);
          oscGain.gain.setValueAtTime(0.2 / freqs.length, ctx.currentTime);
          osc.connect(oscGain);
          oscGain.connect(masterGain);
          osc.start();
        });

        setIsMuted(false);
      } catch (err) {
        console.error("Audio error:", err);
      }
    } else {
      if (gainNodeRef.current && audioCtxRef.current) {
        gainNodeRef.current.gain.linearRampToValueAtTime(0.001, audioCtxRef.current.currentTime + 0.5);
        setTimeout(() => {
          audioCtxRef.current?.close();
          audioCtxRef.current = null;
          gainNodeRef.current = null;
        }, 500);
      }
      setIsMuted(true);
    }
  };

  useEffect(() => {
    return () => {
      if (audioCtxRef.current) {
        audioCtxRef.current.close().catch(() => {});
      }
    };
  }, []);

  const handleInvitationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !phone.trim()) return;

    const code = `APS-MAR27-INV-${Math.floor(1000 + Math.random() * 9000)}`;
    setInvitationCode(code);
    setIsSubmitted(true);

    try {
      confetti({
        particleCount: 80,
        spread: 80,
        origin: { y: 0.6 },
        colors: ["#d4af37", "#f3e5ab", "#c5a059", "#ffffff", "#b8860b"]
      });
    } catch {
      // Graceful fallback
    }
  };

  const scrollToInvitationForm = () => {
    const el = document.getElementById("march-invitation-reservation-form");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToQuoteForm = () => {
    const el = document.getElementById("request-quote-section");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToServices = () => {
    const el = document.getElementById("our-services-section");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToTestimonials = () => {
    const el = document.getElementById("client-testimonials-section");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const currentHero = MARCH_SHOWCASE[activeHeroIndex];

  const filteredProjects = selectedCategory === "all"
    ? MARCH_SHOWCASE
    : MARCH_SHOWCASE.filter(p => p.category === selectedCategory);

  return (
    <div className="min-h-screen bg-[#08090d] text-stone-100 font-sans relative overflow-x-hidden select-none">
      
      {/* Top Rich Gold Hairline Border */}
      <div className="fixed top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#d4af37] to-transparent z-50 opacity-90" />

      {/* Warm Ambient Architectural Glows — Pure Rich Luxury (No Tech Simulator Grids) */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] left-1/2 -translate-x-1/2 w-[1000px] h-[550px] bg-[radial-gradient(ellipse_at_center,_rgba(212,175,55,0.08),transparent_70%)] blur-3xl" />
        <div className="absolute bottom-[-10%] left-1/4 w-[700px] h-[500px] bg-[radial-gradient(ellipse_at_center,_rgba(197,160,89,0.05),transparent_70%)] blur-3xl" />
        <div className="absolute top-1/2 right-[-10%] w-[600px] h-[600px] bg-[radial-gradient(ellipse_at_center,_rgba(243,229,171,0.03),transparent_70%)] blur-3xl" />
      </div>

      {/* PRESTIGE NAVIGATION BAR */}
      <header className="relative z-30 border-b border-[#c5a059]/20 bg-[#08090d]/90 backdrop-blur-xl sticky top-0 shadow-lg">
        <div className="max-w-7xl mx-auto px-6 h-22 flex items-center justify-between">
          
          {/* Brand Mark with Imperial Gold Crest */}
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-lg bg-gradient-to-br from-[#f3e5ab] via-[#d4af37] to-[#8c6d23] p-[1.5px] shadow-lg shadow-[#d4af37]/20">
              <div className="w-full h-full bg-[#0a0c12] rounded-[6px] flex items-center justify-center font-serif font-bold text-[#f3e5ab] text-lg tracking-widest">
                APS
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-serif font-bold text-lg tracking-[0.2em] text-stone-100">
                  APS BUILDERS & DEVELOPERS
                </span>
                <span className="hidden sm:inline-block w-1.5 h-1.5 rounded-full bg-[#d4af37] animate-pulse" />
                <span className="hidden sm:inline text-[11px] font-serif uppercase tracking-widest text-[#d4af37] font-semibold">
                  Unveiling March 2027
                </span>
              </div>
              <p className="text-[10px] text-stone-400 tracking-[0.25em] font-serif uppercase">
                ESTABLISHED 2008 · 16 YEARS OF DISTINCTION · GOD&apos;S OWN COUNTRY
              </p>
            </div>
          </div>

          {/* Prestige Controls */}
          <div className="flex items-center gap-3">
            {/* Quick Link to Services */}
            <button
              onClick={scrollToServices}
              className="hidden lg:flex items-center gap-1.5 px-3 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/15 text-stone-300 hover:text-white text-xs font-serif uppercase tracking-wider transition-all cursor-pointer shadow-sm hover:scale-105 active:scale-95"
            >
              <Building2 className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>Services</span>
            </button>

            {/* Quick Link to Testimonials */}
            <button
              onClick={scrollToTestimonials}
              className="hidden xl:flex items-center gap-1.5 px-3 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/15 text-stone-300 hover:text-white text-xs font-serif uppercase tracking-wider transition-all cursor-pointer shadow-sm hover:scale-105 active:scale-95"
            >
              <Star className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>Reviews</span>
            </button>

            {/* Quick Link to Quote Form */}
            <button
              onClick={scrollToQuoteForm}
              className="hidden lg:flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-gradient-to-r from-[#d4af37]/20 via-[#f3e5ab]/15 to-[#c5a059]/20 hover:from-[#d4af37]/35 hover:to-[#f3e5ab]/30 border border-[#d4af37]/50 text-[#f3e5ab] text-xs font-serif uppercase tracking-wider transition-all cursor-pointer shadow-sm hover:scale-105 active:scale-95"
            >
              <FileText className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>Request Quote</span>
            </button>

            {/* Ambient Soundscape */}
            <button
              onClick={toggleSound}
              className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 border border-[#c5a059]/30 text-stone-300 hover:text-white transition-all text-xs flex items-center gap-2 cursor-pointer shadow-sm"
              title={isMuted ? "Activate atmospheric architectural soundscape" : "Mute audio"}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-stone-400" /> : <Volume2 className="w-4 h-4 text-[#d4af37] animate-pulse" />}
              <span className="hidden lg:inline text-[11px] font-serif uppercase tracking-wider">
                {isMuted ? "Atmosphere: Off" : "Atmosphere: Live"}
              </span>
            </button>

            {/* Direct WhatsApp Concierge */}
            <a
              href="https://wa.me/917907656700?text=Hello%20APS%20Builders%2C%20I%20am%20inquiring%20about%20the%20March%202027%20Opening."
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-emerald-950/60 to-emerald-900/40 border border-emerald-500/40 text-emerald-300 hover:border-emerald-400 text-xs font-serif uppercase tracking-wider transition-all shadow-sm"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Concierge Desk</span>
              <span className="sm:hidden">Concierge</span>
            </a>

            {/* Private Line */}
            <a
              href="tel:7907656700"
              className="hidden md:flex items-center gap-1.5 px-4 py-2.5 rounded-full bg-white/5 hover:bg-[#d4af37]/15 border border-[#c5a059]/30 text-stone-300 hover:text-[#f3e5ab] text-xs font-serif uppercase tracking-wider transition-all"
            >
              <PhoneCall className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>+91 79076 56700</span>
            </a>
          </div>
        </div>

        {/* Dynamic 3D Animated Gold Brand Strip */}
        <div className="border-t border-[#c5a059]/20 bg-[#06080e] overflow-hidden py-2 select-none">
          <motion.div
            className="flex whitespace-nowrap text-[11px] font-serif uppercase tracking-[0.28em] text-[#d4af37]/80"
            animate={{ x: [0, -1200] }}
            transition={{ repeat: Infinity, ease: "linear", duration: 28 }}
          >
            {[1, 2, 3].map((key) => (
              <span key={key} className="flex items-center gap-6 mr-6">
                <span className="flex items-center gap-1.5 text-[#f3e5ab] font-bold">
                  <Rotate3d className="w-3 h-3 text-[#d4af37] animate-spin" style={{ animationDuration: '6s' }} />
                  GRAND MARCH 2027 ALAPPUZHA UNVEILING
                </span>
                <span>•</span>
                <span>EXCLUSIVELY IN ALAPPUZHA</span>
                <span>•</span>
                <span className="text-[#f3e5ab]">VEMBANAD BACKWATER VILLAS</span>
                <span>•</span>
                <span>ALAPPUZHA BEACH HORIZON RESIDENCES</span>
                <span>•</span>
                <span className="text-[#f3e5ab]">PUNNAMADA CROWN PENTHOUSES</span>
                <span>•</span>
                <span>AYUR HERITAGE COMMERCIAL PLAZA</span>
                <span>•</span>
              </span>
            ))}
          </motion.div>
        </div>
      </header>

      {/* HERO SECTION */}
      <main className="relative z-10 max-w-7xl mx-auto px-6 pt-14 pb-28 flex flex-col items-center">
        
        {/* Subtle Kicker */}
        <motion.div
          initial={{ opacity: 0, y: -15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center gap-2.5 text-xs font-serif uppercase tracking-[0.3em] text-[#d4af37] mb-6"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Private Grand Unveiling</span>
          <span className="text-stone-500">·</span>
          <span>March 2027</span>
          <span className="text-stone-500">·</span>
          <span>Alappuzha Exclusive</span>
        </motion.div>

        {/* Grand Headline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="text-center max-w-4xl"
        >
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-serif font-bold tracking-tight leading-[1.12] mb-6 text-stone-100">
            THE PINNACLE OF LUXURY ARCHITECTURE. <br />
            <span className="italic font-normal text-transparent bg-clip-text bg-gradient-to-r from-[#f3e5ab] via-[#d4af37] to-[#c5a059]">
              Exclusively in Alappuzha.
            </span>
          </h1>

          <p className="text-base sm:text-xl text-stone-300 max-w-2xl mx-auto leading-relaxed font-serif font-light mb-10">
            APS Builders & Developers presents an extraordinary portfolio of private waterfront estates, beachfront sky suites, and backwater commercial sanctuaries developed exclusively across prime corridors in Alappuzha.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 mb-16">
            <button
              onClick={scrollToInvitationForm}
              className="px-8 py-4 rounded-full bg-gradient-to-r from-[#d4af37] via-[#f3e5ab] to-[#c5a059] hover:from-[#f3e5ab] hover:to-[#d4af37] text-stone-950 font-serif font-bold text-xs uppercase tracking-[0.2em] transition-all shadow-xl shadow-[#d4af37]/25 flex items-center gap-2.5 cursor-pointer hover:scale-105 active:scale-95"
            >
              <Award className="w-4 h-4 text-stone-950" />
              <span>Request March Private Invitation</span>
            </button>

            <button
              onClick={scrollToQuoteForm}
              className="px-8 py-4 rounded-full bg-gradient-to-r from-[#171b29] to-[#0e121e] hover:bg-[#1a2032] border border-[#c5a059]/50 text-[#f3e5ab] font-serif font-semibold text-xs uppercase tracking-wider transition-all flex items-center gap-2 hover:border-[#d4af37] shadow-lg cursor-pointer hover:scale-105 active:scale-95"
            >
              <FileText className="w-4 h-4 text-[#d4af37]" />
              <span>Request Project Quote</span>
            </button>

            <a
              href="https://wa.me/917907656700?text=Hello%20APS%20Builders%2C%20I%20would%20like%20to%20reserve%20an%20exclusive%20preview%20for%20the%20March%20Opening."
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-4 rounded-full bg-white/5 hover:bg-white/10 border border-[#c5a059]/40 text-stone-100 font-serif font-semibold text-xs uppercase tracking-wider transition-all flex items-center gap-2 hover:border-[#d4af37]"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span>Direct Concierge Desk</span>
            </a>
          </div>
        </motion.div>

        {/* 🌟 FULL-WIDTH RICH ARCHITECTURAL HERO SPOTLIGHT CAROUSEL */}
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.2 }}
          className="w-full max-w-6xl mb-16 rounded-3xl border border-[#c5a059]/30 bg-[#0c0e15] shadow-2xl overflow-hidden relative"
        >
          {/* Main Visual Frame with 3D Spatial Animation Switcher */}
          <div className="relative h-[440px] sm:h-[520px] lg:h-[580px] overflow-hidden">
            {!hero3DMode ? (
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentHero.id}
                  initial={{ opacity: 0, scale: 1.05 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 1.2, ease: "easeInOut" }}
                  className="absolute inset-0 bg-cover bg-center"
                  style={{ backgroundImage: `url(${currentHero.image})` }}
                />
              </AnimatePresence>
            ) : (
              <div className="absolute inset-0 bg-[#070912]">
                <LuxuryScene3D 
                  modelType={currentHero.id === 'tower' ? 'tower' : currentHero.id === 'penthouse' ? 'penthouse' : 'villa'}
                  className="w-full h-full"
                />
                <div className="absolute top-4 left-4 z-20 pointer-events-none px-3 py-1 rounded-full bg-black/70 border border-[#d4af37]/40 text-[10px] font-serif uppercase tracking-widest text-[#f3e5ab]">
                  Interactive 3D Architectural Spatial View • Rotate with mouse / touch
                </div>
              </div>
            )}

            {/* Cinematic Gradient Vignettes */}
            <div className={`absolute inset-0 bg-gradient-to-t from-[#0c0e15] via-[#0c0e15]/45 to-transparent ${hero3DMode ? 'pointer-events-none opacity-60' : ''}`} />
            <div className={`absolute inset-0 bg-gradient-to-r from-[#0c0e15]/90 via-[#0c0e15]/30 to-transparent sm:w-2/3 ${hero3DMode ? 'pointer-events-none opacity-60' : ''}`} />

            {/* Overlay Content */}
            <div className="absolute inset-0 p-6 sm:p-10 flex flex-col justify-end sm:justify-between z-10 pointer-events-none">
              
              {/* Top Banner Tag & 3D Interactive Mode Toggle */}
              <div className="hidden sm:flex items-center justify-between pointer-events-auto">
                <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-black/60 border border-[#d4af37]/50 backdrop-blur-md text-[11px] font-serif text-[#f3e5ab] uppercase tracking-widest font-semibold shadow-lg">
                  <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>March 2027 Flagship Unveiling</span>
                </div>

                <div className="flex items-center gap-2.5">
                  {/* 3D View Animation Toggle Button */}
                  <button
                    onClick={() => setHero3DMode(!hero3DMode)}
                    className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-[#171c2b] to-[#0d101a] border border-[#d4af37]/60 text-xs font-serif text-[#f3e5ab] uppercase tracking-wider hover:border-[#f3e5ab] hover:text-white transition-all cursor-pointer shadow-lg hover:scale-105 active:scale-95"
                    title="Toggle Interactive 3D Spatial Animation"
                  >
                    <Box className="w-3.5 h-3.5 text-[#d4af37] animate-pulse" />
                    <span>{hero3DMode ? "View Editorial Photo" : "View Live 3D Model"}</span>
                  </button>

                  <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-black/60 border border-white/10 backdrop-blur-md text-xs font-serif text-stone-300">
                    <span className="w-2 h-2 rounded-full bg-[#d4af37] animate-pulse" />
                    <span>Status: {currentHero.completionPhase}</span>
                  </div>
                </div>
              </div>

              {/* Bottom Feature Card */}
              <div className="max-w-xl pointer-events-auto">
                <div className="flex items-center gap-2 text-xs font-serif text-[#d4af37] mb-2 tracking-wide">
                  <MapPin className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>{currentHero.location}</span>
                  <span className="text-stone-500">·</span>
                  <span className="text-stone-200 font-semibold">{currentHero.badge}</span>
                </div>

                <h2 className="text-2xl sm:text-4xl font-serif font-bold text-white mb-2 leading-tight drop-shadow-md">
                  {currentHero.title}
                </h2>

                <p className="text-xs sm:text-sm text-stone-300 leading-relaxed mb-6 font-serif font-light line-clamp-3">
                  {currentHero.tagline}
                </p>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => setSelectedProject(currentHero)}
                    className="px-5 py-2.5 rounded-full bg-gradient-to-r from-[#d4af37] to-[#c5a059] hover:from-[#f3e5ab] hover:to-[#d4af37] text-stone-950 font-serif font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-[#d4af37]/20 hover:scale-105 active:scale-95"
                  >
                    <span>View Architectural Dossier</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      setInterest(currentHero.title);
                      scrollToInvitationForm();
                    }}
                    className="px-5 py-2.5 rounded-full bg-white/10 hover:bg-white/15 border border-[#c5a059]/40 text-stone-100 font-serif font-semibold text-xs uppercase tracking-wider transition-all cursor-pointer hover:border-[#d4af37]"
                  >
                    Request Invitation for This Landmark
                  </button>
                </div>
              </div>
            </div>

            {/* Slide Arrows */}
            <div className="absolute right-6 bottom-6 hidden sm:flex items-center gap-2 z-20">
              <button
                onClick={() => setActiveHeroIndex((prev) => (prev - 1 + MARCH_SHOWCASE.length) % MARCH_SHOWCASE.length)}
                className="w-10 h-10 rounded-full bg-black/60 hover:bg-[#d4af37] hover:text-stone-950 border border-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
                title="Previous showcase"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => setActiveHeroIndex((prev) => (prev + 1) % MARCH_SHOWCASE.length)}
                className="w-10 h-10 rounded-full bg-black/60 hover:bg-[#d4af37] hover:text-stone-950 border border-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
                title="Next showcase"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Thumbnail Selector Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-5 border-t border-[#c5a059]/20 bg-[#090b10]">
            {MARCH_SHOWCASE.map((proj, idx) => (
              <button
                key={proj.id}
                onClick={() => setActiveHeroIndex(idx)}
                className={`p-3.5 text-left transition-all border-r border-white/5 last:border-r-0 cursor-pointer ${
                  activeHeroIndex === idx 
                    ? "bg-[#d4af37]/10 border-b-2 border-b-[#d4af37]" 
                    : "hover:bg-white/5 opacity-60 hover:opacity-100"
                }`}
              >
                <span className="text-[10px] font-serif uppercase tracking-wider text-[#d4af37] font-bold block mb-0.5 truncate">
                  0{idx + 1} · {proj.categoryLabel}
                </span>
                <h4 className="text-xs font-serif font-bold text-stone-200 truncate">
                  {proj.title}
                </h4>
              </button>
            ))}
          </div>
        </motion.div>

        {/* 🌟 LUXURY HOROLOGY COUNTDOWN CONSOLE (RICH GOLD TIMEPIECE AESTHETIC) */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="w-full max-w-4xl mb-24"
        >
          <div className="bg-gradient-to-b from-[#121520] to-[#0a0c14] border border-[#c5a059]/35 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
            {/* Top Gold Horizon Bar */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#c5a059] via-[#f3e5ab] to-[#c5a059]" />

            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-8 pb-6 border-b border-[#c5a059]/20">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-[#d4af37]/15 border border-[#d4af37]/40 flex items-center justify-center text-[#d4af37] shadow-inner">
                  <Calendar className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-serif font-bold uppercase tracking-wider text-stone-100">
                    Grand Opening Countdown
                  </h3>
                  <p className="text-xs text-[#d4af37] font-serif">
                    Target: March 1, 2027 • Cochin Unveiling Gala
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs font-serif text-stone-400">
                <Clock className="w-4 h-4 text-[#d4af37]" />
                <span>Opening in March 2027</span>
              </div>
            </div>

            {/* Embossed Luxury Digit Cards with 3D Spatial Tilt Physics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
              {[
                { label: "Days", value: timeLeft.days },
                { label: "Hours", value: timeLeft.hours },
                { label: "Minutes", value: timeLeft.minutes },
                { label: "Seconds", value: timeLeft.seconds }
              ].map((item, idx) => (
                <TiltCard3D key={item.label} maxTilt={14} glare={true} className="rounded-2xl">
                  <div className="bg-[#090b12] border border-[#c5a059]/25 group-hover:border-[#d4af37]/60 rounded-2xl p-5 sm:p-6 text-center relative transition-all shadow-inner">
                    <div className="text-4xl sm:text-5xl font-serif font-bold text-transparent bg-clip-text bg-gradient-to-b from-[#ffffff] via-[#f3e5ab] to-[#d4af37] tracking-tight tabular-nums mb-1">
                      {String(item.value).padStart(2, "0")}
                    </div>
                    <div className="text-[11px] font-serif uppercase tracking-[0.2em] text-[#d4af37] font-semibold">
                      {item.label}
                    </div>
                    {idx < 3 && (
                      <span className="hidden sm:block absolute -right-3.5 top-1/2 -translate-y-1/2 text-2xl font-serif text-[#d4af37]/35 pointer-events-none">
                        ·
                      </span>
                    )}
                  </div>
                </TiltCard3D>
              ))}
            </div>

            {/* Gold Readiness Status */}
            <div className="mt-8 pt-5 border-t border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <span className="text-stone-400 font-serif">
                Overall Architectural Progress & Handover Target: <strong className="text-[#f3e5ab] font-bold">{timeLeft.progressPercent}%</strong>
              </span>
              <div className="w-full sm:w-72 h-2.5 bg-stone-900 rounded-full overflow-hidden border border-[#c5a059]/20">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${timeLeft.progressPercent}%` }}
                  transition={{ duration: 1.2, ease: "easeOut" }}
                  className="h-full bg-gradient-to-r from-[#c5a059] via-[#f3e5ab] to-[#d4af37] rounded-full"
                />
              </div>
            </div>
          </div>
        </motion.div>

        {/* 🌟 CURATED LANDMARKS GALLERY & PRIVATE INVITATION SUITE */}
        <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-24">
          
          {/* LEFT: MARCH SNEAK PEEKS (7 Cols) */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="lg:col-span-7 space-y-6"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-2">
              <div>
                <span className="text-xs font-serif uppercase tracking-widest text-[#d4af37] font-semibold">
                  Curated Collection
                </span>
                <h3 className="text-2xl font-serif font-bold text-white mt-1">
                  Arriving in March 2027
                </h3>
              </div>

              {/* Segmented Filter Controls */}
              <div className="flex items-center gap-1.5 bg-[#0f121b] p-1.5 rounded-xl border border-[#c5a059]/20 text-xs">
                {(["all", "villas", "towers", "commercial"] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 rounded-lg capitalize font-serif font-medium transition-colors cursor-pointer ${
                      selectedCategory === cat 
                        ? "bg-gradient-to-r from-[#d4af37] to-[#c5a059] text-stone-950 font-bold shadow-md" 
                        : "text-stone-400 hover:text-white"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Landmark Cards Grid with 3D Spatial Tilt Interactions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filteredProjects.map((proj) => (
                <TiltCard3D
                  key={proj.id}
                  maxTilt={10}
                  glare={true}
                  className="rounded-2xl cursor-pointer"
                  onClick={() => setSelectedProject(proj)}
                >
                  <div className="group relative rounded-2xl overflow-hidden border border-[#c5a059]/25 hover:border-[#d4af37]/70 transition-all duration-300 bg-[#0e111a] shadow-xl">
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={proj.image} 
                        alt={proj.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-108" 
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0e111a] via-[#0e111a]/40 to-transparent" />
                      
                      <span className="absolute top-3 left-3 px-3 py-1 rounded-md text-[10px] font-serif uppercase tracking-wider font-bold bg-[#d4af37] text-stone-950 shadow-md">
                        {proj.badge}
                      </span>

                      <span className="absolute top-3 right-3 px-2.5 py-0.5 rounded-md text-[10px] font-serif uppercase bg-black/70 text-[#f3e5ab] border border-[#d4af37]/40">
                        Opening Mar &apos;27
                      </span>

                      <div className="absolute bottom-3 left-3 right-3">
                        <div className="flex items-center gap-1.5 text-[11px] text-[#f3e5ab] font-serif mb-1">
                          <MapPin className="w-3 h-3 shrink-0 text-[#d4af37]" />
                          <span className="truncate">{proj.location}</span>
                        </div>
                        <h4 className="text-base font-serif font-bold text-white leading-snug group-hover:text-[#f3e5ab] transition-colors">
                          {proj.title}
                        </h4>
                      </div>
                    </div>

                    <div className="p-4 border-t border-white/5 flex items-center justify-between text-xs text-stone-300">
                      <span className="text-[11px] font-serif text-stone-400">
                        {proj.units}
                      </span>
                      <span className="flex items-center gap-1 text-[#d4af37] group-hover:translate-x-1 transition-transform font-serif font-semibold text-[11px] uppercase tracking-wider">
                        View Dossier <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                </TiltCard3D>
              ))}
            </div>

            {/* Founder Patron Privileges Box */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-[#17130a]/60 via-[#111422] to-[#0e111a] border border-[#c5a059]/35 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#d4af37]/15 border border-[#d4af37]/40 flex items-center justify-center text-[#d4af37] shrink-0">
                <Award className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-serif font-bold text-white mb-0.5">
                  March Founder Patron Privileges
                </h4>
                <p className="text-xs text-stone-300 leading-relaxed font-serif font-light">
                  Pre-registered patrons receive exclusive pre-launch pricing, private architect consultation sessions, and guaranteed handover schedules.
                </p>
              </div>
            </div>
          </motion.div>

          {/* RIGHT: PRIVATE INVITATION SUITE WITH GOLD SEAL (5 Cols) */}
          <motion.div
            id="march-invitation-reservation-form"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="lg:col-span-5 scroll-mt-24"
          >
            <div className="bg-gradient-to-b from-[#121522] to-[#0a0d15] border border-[#c5a059]/40 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl relative">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-serif uppercase tracking-widest bg-[#d4af37]/15 text-[#f3e5ab] border border-[#d4af37]/40 mb-4 font-semibold">
                <Star className="w-3 h-3 fill-[#d4af37] text-[#d4af37]" />
                <span>Private Preview Invitation</span>
              </div>

              <h3 className="text-2xl font-serif font-bold text-white mb-2">
                Reserve Your March 2027 Invitation
              </h3>
              <p className="text-xs text-stone-300 leading-relaxed mb-6 font-serif font-light">
                Join our private opening reception and receive exclusive preview allocations for our landmark developments ahead of public unveiling.
              </p>

              {!isSubmitted ? (
                <form onSubmit={handleInvitationSubmit} className="space-y-4">
                  <div>
                    <label className="block text-[11px] font-serif uppercase text-stone-300 mb-1.5 font-semibold">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Dr. Anand Menon"
                      className="w-full px-4 py-3 rounded-xl bg-[#080a11] border border-[#c5a059]/25 text-white placeholder-stone-500 text-sm focus:outline-none focus:border-[#d4af37] transition-colors font-serif"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-serif uppercase text-stone-300 mb-1.5 font-semibold">
                      WhatsApp / Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 98470 12345"
                      className="w-full px-4 py-3 rounded-xl bg-[#080a11] border border-[#c5a059]/25 text-white placeholder-stone-500 text-sm focus:outline-none focus:border-[#d4af37] transition-colors font-serif"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-serif uppercase text-stone-300 mb-1.5 font-semibold">
                      Email Address
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="anand@example.com"
                      className="w-full px-4 py-3 rounded-xl bg-[#080a11] border border-[#c5a059]/25 text-white placeholder-stone-500 text-sm focus:outline-none focus:border-[#d4af37] transition-colors font-serif"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-serif uppercase text-stone-300 mb-1.5 font-semibold">
                      Primary Interest for March
                    </label>
                    <select
                      value={interest}
                      onChange={(e) => setInterest(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-[#080a11] border border-[#c5a059]/25 text-white text-sm focus:outline-none focus:border-[#d4af37] transition-colors font-serif"
                    >
                      <option value="The Palm Crest Sovereign Villas (Alappuzha)">The Palm Crest Sovereign Villas (Vembanad Backwaters)</option>
                      <option value="APS Glass Horizon Sky Residences (Alappuzha Beach)">APS Glass Horizon Sky Residences (Beach Road)</option>
                      <option value="The Punnamada Crown Penthouse Collection (Alappuzha)">The Punnamada Crown Penthouse Collection (Finishing Point)</option>
                      <option value="Ayur Heritage Commercial & Wellness Plaza (Alappuzha)">Ayur Heritage Commercial Plaza (Waterfront Esplanade)</option>
                      <option value="APS Architectural Experience Studio (Alappuzha)">APS Architectural Experience Studio (Cullen Road)</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-2 py-4 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#f3e5ab] to-[#c5a059] hover:from-[#f3e5ab] hover:to-[#d4af37] text-stone-950 font-serif font-bold text-xs uppercase tracking-[0.2em] shadow-xl shadow-[#d4af37]/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Award className="w-4 h-4 text-stone-950" />
                    <span>Request March Private Invitation</span>
                  </button>

                  <p className="text-[10px] text-center text-stone-400 font-serif mt-3">
                    Strictly confidential. Direct communication via Senior Management.
                  </p>
                </form>
              ) : (
                /* INVITATION CONFIRMED ELEVATED LUXURY CARD */
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-[#080b13] border border-[#d4af37]/60 rounded-2xl p-6 text-center relative overflow-hidden shadow-2xl"
                >
                  <div className="w-14 h-14 rounded-full bg-[#d4af37]/20 text-[#d4af37] flex items-center justify-center mx-auto mb-3 border border-[#d4af37]/40 shadow-inner">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>

                  <span className="text-[11px] font-serif uppercase tracking-[0.25em] text-[#d4af37] font-bold">
                    Official March 2027 Invitation Reserved
                  </span>
                  <h4 className="text-xl font-serif font-bold text-white mt-1 mb-2">
                    Welcome, {fullName}
                  </h4>

                  {/* QR Code Graphic with Luxury Gold Border */}
                  <div className="bg-white p-3.5 rounded-xl inline-block my-3 shadow-xl border-2 border-[#d4af37]">
                    <QRCodeSVG 
                      value={`https://wa.me/917907656700?text=INVITATION_${invitationCode}_${encodeURIComponent(fullName)}`} 
                      size={120}
                      level="M"
                    />
                  </div>
                  
                  <div className="mb-4 p-3 bg-[#0e121e] border border-[#c5a059]/40 rounded-xl inline-block w-full">
                    <span className="text-[10px] text-stone-400 font-serif uppercase block mb-0.5">Invitation Reference Number</span>
                    <span className="text-lg font-serif font-bold text-[#f3e5ab] tracking-wider">
                      {invitationCode}
                    </span>
                  </div>

                  <p className="text-xs text-stone-300 leading-relaxed mb-5 font-serif font-light">
                    Your private invitation reservation for the March 2027 Grand Opening has been recorded. Our Senior Relationship Director will contact your WhatsApp ({phone}) with your private preview dossier.
                  </p>

                  <div className="flex flex-col gap-2.5">
                    <a
                      href={`https://wa.me/917907656700?text=Hello%20APS%20Builders%2C%20I%20have%20reserved%20an%20invitation%20for%20the%20March%202027%20Opening%20with%20Ref%20${invitationCode}%20(${encodeURIComponent(fullName)}).%20Please%20confirm%20my%20preview%20schedule.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-700 to-emerald-600 hover:from-emerald-600 hover:to-emerald-500 text-white text-xs font-serif font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-700/25"
                    >
                      <MessageCircle className="w-4 h-4" /> Forward to Concierge on WhatsApp
                    </a>

                    <button
                      onClick={() => {
                        setIsSubmitted(false);
                        setFullName("");
                        setPhone("");
                        setEmail("");
                      }}
                      className="text-xs text-stone-400 hover:text-white pt-1 transition-colors cursor-pointer font-serif"
                    >
                      Register another guest
                    </button>
                  </div>
                </motion.div>
              )}

              {/* Quick Contact Line */}
              <div className="mt-6 pt-5 border-t border-white/10 flex items-center justify-between text-xs text-stone-400 font-serif">
                <span className="flex items-center gap-1.5">
                  <PhoneCall className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>+91 79076 56700</span>
                </span>
                <span>Alappuzha HQ • Venice of the East</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* 🌟 MATERIALS OF DISTINCTION (RICH ARCHITECTURAL CRAFTSMANSHIP) */}
        <div className="w-full max-w-5xl mb-24">
          <div className="text-center mb-10">
            <span className="text-xs font-serif uppercase tracking-[0.25em] text-[#d4af37] font-semibold">
              Heritage & Craftsmanship
            </span>
            <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white mt-1">
              Materials of Distinction
            </h3>
            <p className="text-xs sm:text-sm text-stone-300 mt-2 max-w-lg mx-auto font-serif font-light">
              Every square foot constructed with authentic luxury materials sourced globally and curated locally.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {LUXURY_MATERIALS.map((mat, i) => (
              <TiltCard3D key={i} maxTilt={12} glare={true} className="rounded-2xl">
                <div className="p-5 rounded-2xl bg-[#0c0e16] border border-[#c5a059]/25 hover:border-[#d4af37]/60 transition-all shadow-lg h-full flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-serif uppercase tracking-widest text-[#d4af37] font-bold block">
                        {mat.type}
                      </span>
                      <span className="text-[10px] font-serif text-stone-400">
                        {mat.origin}
                      </span>
                    </div>
                    <h4 className="text-base font-serif font-bold text-white mb-2">
                      {mat.title}
                    </h4>
                  </div>
                  <p className="text-xs text-stone-300 leading-relaxed font-serif font-light">
                    {mat.desc}
                  </p>
                </div>
              </TiltCard3D>
            ))}
          </div>
        </div>

        {/* MARCH OPENING ROADMAP STEPS */}
        <div className="w-full max-w-5xl mb-24">
          <div className="text-center mb-10">
            <span className="text-xs font-serif uppercase tracking-[0.25em] text-[#d4af37] font-semibold">
              The Journey to March
            </span>
            <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white mt-1">
              Opening Roadmap & Milestones
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              {
                step: "01",
                phase: "Architectural Reveal",
                date: "Q4 2026",
                desc: "Foundation and structural framing completion across all March release sites.",
                done: true
              },
              {
                step: "02",
                phase: "Private Client Previews",
                date: "January 2027",
                desc: "Exclusive walkthroughs for registered patrons and bespoke floorplan tuning.",
                done: true
              },
              {
                step: "03",
                phase: "Grand Opening Gala",
                date: "March 2027",
                desc: "Ribbon cutting ceremony, key handovers, and public unveiling of the experience hub.",
                active: true
              },
              {
                step: "04",
                phase: "Full Occupancy",
                date: "April 2027+",
                desc: "Move-in assistance, smart-home onboarding, and lifetime maintenance activation.",
                done: false
              }
            ].map((item) => (
              <TiltCard3D key={item.step} maxTilt={12} glare={true} className="rounded-2xl">
                <div
                  className={`p-6 rounded-2xl border transition-all h-full flex flex-col justify-between ${
                    item.active
                      ? "bg-gradient-to-b from-[#1b1509] to-[#0e121e] border-[#d4af37]/70 shadow-xl shadow-[#d4af37]/15 ring-1 ring-[#d4af37]/50"
                      : "bg-[#0b0e16] border-white/10"
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-serif font-bold text-[#d4af37]">
                        Phase {item.step}
                      </span>
                      {item.active ? (
                        <span className="px-2.5 py-0.5 rounded-full text-[9px] font-serif uppercase tracking-wider bg-[#d4af37] text-stone-950 font-bold animate-pulse">
                          Target March
                        </span>
                      ) : item.done ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <span className="text-[10px] font-serif text-stone-400">Upcoming</span>
                      )}
                    </div>
                    <h4 className="text-sm font-serif font-bold text-white mb-1">
                      {item.phase}
                    </h4>
                    <span className="text-[11px] font-serif text-[#f3e5ab]/80 block mb-2">
                      {item.date}
                    </span>
                  </div>
                  <p className="text-xs text-stone-300 leading-relaxed font-serif font-light">
                    {item.desc}
                  </p>
                </div>
              </TiltCard3D>
            ))}
          </div>
        </div>

        {/* MARCH OPENING FAQS */}
        <div className="w-full max-w-4xl mb-24">
          <div className="text-center mb-10">
            <span className="text-xs font-serif uppercase tracking-[0.25em] text-[#d4af37] font-semibold">
              Opening Information
            </span>
            <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white mt-1">
              Frequently Asked Questions
            </h3>
          </div>

          <div className="space-y-3">
            {FAQS.map((faq, index) => (
              <div
                key={index}
                className="bg-[#0c0e18] border border-[#c5a059]/20 rounded-2xl overflow-hidden transition-colors hover:border-[#d4af37]/50"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer"
                >
                  <span className="font-serif font-bold text-sm sm:text-base text-white">
                    {faq.q}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#d4af37] shrink-0 transition-transform ${
                      openFaq === index ? "rotate-180" : ""
                    }`}
                  />
                </button>
                <AnimatePresence>
                  {openFaq === index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="px-5 pb-5 text-xs sm:text-sm text-stone-300 leading-relaxed border-t border-white/5 pt-3 font-serif font-light"
                    >
                      {faq.a}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>

        {/* ALAPPUZHA PRIME DISTRICT FOOTPRINT */}
        <div className="w-full max-w-5xl bg-gradient-to-r from-[#0e111a] via-[#121624] to-[#0e111a] border border-[#c5a059]/30 rounded-3xl p-8 sm:p-10 mb-20 shadow-xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <span className="text-xs font-serif uppercase tracking-[0.25em] text-[#d4af37] font-semibold">
                District Exclusivity • Alappuzha
              </span>
              <h4 className="text-xl sm:text-2xl font-serif font-bold text-white mt-1 mb-2">
                Focused Exclusively Across Prime Alappuzha Corridors
              </h4>
              <p className="text-xs sm:text-sm text-stone-300 max-w-xl leading-relaxed font-serif font-light">
                From lakefront mansions along the Vembanad waters and Punnamada Finishing Point to beachfront sky suites and town commercial centers — APS Builders concentrates 100% of its craftsmanship exclusively within Alappuzha.
              </p>
            </div>
            <div className="flex flex-wrap gap-2.5 justify-center md:justify-end">
              {[
                "Vembanad Lakefront",
                "Punnamada Finishing Point",
                "Alappuzha Beach Road",
                "Cullen Road Town Center",
                "Kainakary Backwaters",
                "Mararikulam Coastal",
                "Pallathuruthy Waterways"
              ].map((loc) => (
                <span
                  key={loc}
                  className="px-3.5 py-1.5 rounded-full bg-[#080a11] border border-[#c5a059]/35 text-[#f3e5ab] text-xs font-serif"
                >
                  📍 {loc}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* 🌟 OUR SERVICES: CONSTRUCTION, ARCHITECTURAL DESIGN & CONSULTING */}
        <ServicesSection />

        {/* 🌟 VERIFIED CLIENT TESTIMONIALS & BRAND TRUST CAROUSEL */}
        <TestimonialCarousel />

        {/* 🌟 PROFESSIONAL ARCHITECTURAL QUOTE CONTACT SECTION */}
        <QuoteContactSection />

        {/* BOTTOM CALL TO ACTION: RESERVE PRIVATE INVITATION */}
        <div className="w-full max-w-4xl text-center bg-gradient-to-b from-[#141724] to-[#090b12] border border-[#c5a059]/40 rounded-3xl p-8 sm:p-12 relative overflow-hidden shadow-2xl">
          <div className="relative z-10">
            <span className="inline-block px-3.5 py-1.5 rounded-full text-[10px] font-serif uppercase tracking-widest bg-[#d4af37]/15 text-[#f3e5ab] border border-[#d4af37]/35 mb-4 font-semibold">
              Grand Opening In March 2027
            </span>
            <h3 className="text-2xl sm:text-4xl font-serif font-bold text-white mb-3">
              Experience Kerala&apos;s Next Architectural Horizon
            </h3>
            <p className="text-sm text-stone-300 max-w-xl mx-auto leading-relaxed mb-8 font-serif font-light">
              Secure your private invitation or connect directly with our Managing Director&apos;s office on WhatsApp for dedicated guidance.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={scrollToInvitationForm}
                className="w-full sm:w-auto px-8 py-4 rounded-full bg-gradient-to-r from-[#d4af37] via-[#f3e5ab] to-[#c5a059] hover:from-[#f3e5ab] hover:to-[#d4af37] text-stone-950 font-serif font-bold text-xs uppercase tracking-[0.2em] shadow-xl shadow-[#d4af37]/25 transition-all hover:scale-105 active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Reserve March Invitation</span>
                <ArrowRight className="w-4 h-4 text-stone-950" />
              </button>

              <a
                href="https://wa.me/917907656700?text=Hello%20APS%20Builders%2C%20I%20would%20like%20to%20inquire%20about%20the%20March%20Opening."
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-7 py-4 rounded-full bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/40 text-emerald-300 font-serif font-semibold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp Concierge Desk</span>
              </a>
            </div>
          </div>
        </div>
      </main>

      {/* FOOTER */}
      <footer className="relative z-20 border-t border-[#c5a059]/20 bg-[#08090d]/95 py-10 text-center text-xs text-stone-400 font-serif">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            © {new Date().getFullYear()} APS BUILDERS & DEVELOPERS. All Rights Reserved.
          </div>
          <div className="flex items-center gap-4 text-stone-400">
            <span className="text-[#d4af37] font-semibold">Alappuzha Opening: March 2027</span>
            <span>·</span>
            <span>Head Office: Cullen Road, Alappuzha</span>
            <span>·</span>
            <span>Direct Desk: +91 79076 56700</span>
          </div>
        </div>
      </footer>

      {/* ARCHITECTURAL DOSSIER MODAL */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/85 backdrop-blur-md p-4"
          >
            <motion.div
              initial={{ scale: 0.94, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.94, opacity: 0, y: 20 }}
              className="bg-[#0d101a] border border-[#c5a059]/50 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl relative"
            >
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/70 text-stone-300 hover:text-white border border-white/10 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="relative h-64 sm:h-72 bg-[#080a13]">
                {!modal3DMode ? (
                  <>
                    <img
                      src={selectedProject.image}
                      alt={selectedProject.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0d101a] via-[#0d101a]/40 to-transparent" />
                  </>
                ) : (
                  <div className="w-full h-full">
                    <LuxuryScene3D
                      modelType={selectedProject.id === 'tower' ? 'tower' : selectedProject.id === 'penthouse' ? 'penthouse' : 'villa'}
                      className="w-full h-full"
                    />
                  </div>
                )}

                {/* 3D Model Switcher inside Modal */}
                <div className="absolute top-4 left-6 z-20">
                  <button
                    onClick={() => setModal3DMode(!modal3DMode)}
                    className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/75 hover:bg-[#d4af37] text-stone-200 hover:text-stone-950 border border-[#d4af37]/50 text-[10px] font-serif uppercase tracking-wider transition-all cursor-pointer shadow-md"
                  >
                    <Box className="w-3 h-3 text-[#d4af37]" />
                    <span>{modal3DMode ? "Photo View" : "3D Spatial View"}</span>
                  </button>
                </div>

                <div className="absolute bottom-4 left-6 right-6 pointer-events-none">
                  <span className="px-3 py-0.5 rounded-full text-[10px] font-serif uppercase bg-[#d4af37] text-stone-950 font-bold mb-1.5 inline-block">
                    {selectedProject.badge} • Opening March 2027
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white drop-shadow-md">
                    {selectedProject.title}
                  </h3>
                  <p className="text-xs text-[#f3e5ab] font-serif mt-0.5">
                    {selectedProject.location} • Status: {selectedProject.completionPhase}
                  </p>
                </div>
              </div>

              <div className="p-6 sm:p-8">
                <p className="text-sm text-stone-300 leading-relaxed mb-6 font-serif font-light">
                  {selectedProject.tagline}
                </p>

                <h4 className="text-xs font-serif uppercase tracking-widest text-[#d4af37] font-semibold mb-3">
                  Architectural Specifications & Highlights
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-6">
                  {selectedProject.highlights.map((h, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-stone-200 bg-[#070910] p-3 rounded-xl border border-white/5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#d4af37] shrink-0" />
                      <span className="font-serif">{h}</span>
                    </div>
                  ))}
                </div>

                <div className="space-y-2 mb-6 text-xs font-serif">
                  <div className="p-3 bg-[#070910] rounded-xl border border-white/5 flex items-center justify-between">
                    <span className="text-stone-400">Dimensions:</span>
                    <span className="text-[#f3e5ab] font-bold">{selectedProject.dimensions}</span>
                  </div>
                  <div className="p-3 bg-[#070910] rounded-xl border border-white/5 flex items-center justify-between">
                    <span className="text-stone-400">Structural Specs:</span>
                    <span className="text-white text-right max-w-xs">{selectedProject.structuralSpec}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 pt-4 border-t border-white/10">
                  <button
                    onClick={() => {
                      setInterest(selectedProject.title);
                      setSelectedProject(null);
                      scrollToInvitationForm();
                    }}
                    className="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#c5a059] hover:from-[#f3e5ab] hover:to-[#d4af37] text-stone-950 text-xs font-serif font-bold uppercase tracking-wider transition-colors text-center cursor-pointer shadow-lg shadow-[#d4af37]/20"
                  >
                    Request Invitation for This Landmark
                  </button>
                  <a
                    href={`https://wa.me/917907656700?text=Hello%20APS%20Builders%2C%20I%20am%20interested%20in%20${encodeURIComponent(selectedProject.title)}%20opening%20in%20March%202027.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-5 py-3.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-serif font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Inquire</span>
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
