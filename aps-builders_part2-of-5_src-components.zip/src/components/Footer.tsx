import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { OFFICES } from '../data/mockSanityData';
import { Instagram, Linkedin, MapPin, ArrowUpRight } from 'lucide-react';

export const Footer: React.FC = () => {
  const { locale, navigateTo, t } = useLanguage();
  const prefix = locale === 'en' ? '/en' : '';

  const mainNavLinks = [
    { label: t.nav.agency, path: `${prefix}/agence/` },
    { label: t.nav.projects, path: `${prefix}/realisations/` },
    { label: t.nav.immersion, path: `${prefix}/lieu/` },
    { label: t.nav.news, path: `${prefix}/actualites/` },
    { label: t.nav.contact, path: `${prefix}/contact/` },
  ];

  return (
    <footer className="bg-[#111111] text-[#F5F3EF] pt-24 pb-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12">
        {/* Top Tier: Large Logo & Main Navigation Repeat */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-10 pb-16 border-b border-white/10">
          <div>
            <button
              onClick={() => navigateTo(prefix ? '/en/' : '/')}
              className="text-left group focus:outline-none"
            >
              <span className="font-serif text-4xl sm:text-5xl lg:text-6xl tracking-[0.16em] uppercase font-light text-white block">
                Archidomo
              </span>
              <span className="text-[12px] tracking-[0.24em] uppercase text-[#8E8880] mt-2 block font-sans">
                Architecture contemporaine &amp; chalets d'exception
              </span>
            </button>
          </div>

          {/* Repeated Main Navigation */}
          <nav className="flex flex-wrap items-center gap-6 sm:gap-8 text-xs tracking-[0.18em] uppercase text-stone-300">
            {mainNavLinks.map((item) => (
              <button
                key={item.path}
                onClick={() => navigateTo(item.path)}
                className="hover:text-white transition-colors editorial-link"
              >
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Middle Tier: 4 Columns (Offices, Contact, Socials, Statement) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 py-16 border-b border-white/10">
          {/* Column 1: 3 Offices with Google Maps links */}
          <div className="lg:col-span-6 space-y-6">
            <span className="text-xs uppercase tracking-[0.22em] text-[#8E8880] block">
              {t.footer.officesColumn}
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {OFFICES.map((office) => (
                <div key={office.city} className="space-y-2 text-sm text-stone-300">
                  <div className="font-serif text-lg text-white font-normal flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                    <span>{office.city}</span>
                  </div>
                  <p className="text-xs text-stone-400 leading-relaxed">
                    {office.label}
                    <br />
                    {office.address}
                  </p>
                  <a
                    href={office.googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] tracking-wider uppercase text-stone-400 hover:text-white transition-colors pt-1 group"
                  >
                    <span>Google Maps</span>
                    <ArrowUpRight className="w-3 h-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* Column 2: Contact Details */}
          <div className="lg:col-span-3 space-y-4">
            <span className="text-xs uppercase tracking-[0.22em] text-[#8E8880] block">
              {t.footer.contactColumn}
            </span>
            <div className="space-y-3 text-sm text-stone-300">
              <p>
                <span className="block text-xs text-stone-500 uppercase tracking-widest">
                  Téléphone direct
                </span>
                <a
                  href="tel:+33450221840"
                  className="font-serif text-lg text-white hover:text-stone-300 transition-colors"
                >
                  +33 4 50 22 18 40
                </a>
              </p>
              <p>
                <span className="block text-xs text-stone-500 uppercase tracking-widest">
                  Correspondance
                </span>
                <a
                  href="mailto:contact@archidomo.fr"
                  className="text-stone-300 hover:text-white transition-colors text-sm underline underline-offset-4 decoration-white/20"
                >
                  contact@archidomo.fr
                </a>
              </p>
            </div>
          </div>

          {/* Column 3: Networks (Réseaux) */}
          <div className="lg:col-span-3 space-y-4">
            <span className="text-xs uppercase tracking-[0.22em] text-[#8E8880] block">
              {t.footer.networksColumn}
            </span>
            <div className="space-y-3 text-sm">
              <a
                href="https://www.instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between py-1.5 text-stone-300 hover:text-white border-b border-white/5 transition-colors group"
              >
                <div className="flex items-center gap-2">
                  <Instagram className="w-4 h-4 text-stone-400 group-hover:text-white" />
                  <span>Instagram</span>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 transition-opacity" />
              </a>
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between py-1.5 text-stone-300 hover:text-white border-b border-white/5 transition-colors group"
              >
                <div className="flex items-center gap-2">
                  <Linkedin className="w-4 h-4 text-stone-400 group-hover:text-white" />
                  <span>LinkedIn</span>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 transition-opacity" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Legal links */}
        <div className="pt-10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <div>
            <span>{t.footer.copyright}</span>
          </div>

          <div className="flex items-center gap-6">
            <button
              onClick={() => navigateTo(`${prefix}/mentions-legales/`)}
              className="hover:text-stone-300 transition-colors"
            >
              {t.footer.legalLinks}
            </button>
            <span className="text-stone-700">·</span>
            <button
              onClick={() => navigateTo(`${prefix}/politique-de-confidentialite/`)}
              className="hover:text-stone-300 transition-colors"
            >
              {t.footer.privacyPolicy}
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
