import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MapPin, 
  Building2, 
  Search, 
  ArrowRight, 
  ArrowUpDown, 
  Grid, 
  LayoutGrid, 
  SlidersHorizontal,
  ChevronLeft, 
  ChevronRight, 
  Image as ImageIcon,
  CheckCircle2,
  Clock,
  Sparkles,
  Layers,
  ChevronDown,
  Play,
  Pause,
  RotateCw,
  Gauge
} from 'lucide-react';
import { PROJECTS, Project } from '../data/projects';
import LazyImage from './LazyImage';
import Skeleton from './Skeleton';

interface ProjectPortfolioProps {
  onSelectProject: (project: Project) => void;
  onLaunchExperience?: (projectId: string) => void;
  initialSearchQuery?: string;
  onSearchQueryChange?: (query: string) => void;
}

const CATEGORIES = ["All", "Residential", "Commercial", "Infrastructure", "Institutional"];
const STATUS_FILTERS = ["All", "Completed", "Under Construction", "Planning"];
const SPEED_OPTIONS = [
  { value: 2000, label: "2s (Fast)" },
  { value: 3000, label: "3s (Normal)" },
  { value: 5000, label: "5s (Relaxed)" }
];

type SortOption = 'featured' | 'newest' | 'oldest' | 'status' | 'alphabetical' | 'photos';
type ViewMode = 'standard' | 'compact' | 'slider';

export const ProjectCardSkeleton = ({ viewMode = 'standard' }: { viewMode?: ViewMode }) => (
  <div 
    className="bg-white rounded-sm overflow-hidden border border-slate-100 p-0 shadow-xs select-none"
    aria-hidden="true"
  >
    <div className={`relative overflow-hidden rounded-sm bg-slate-100 mb-4 border border-slate-100 ${
      viewMode === 'compact' ? 'aspect-[16/10]' : 'aspect-[4/3]'
    }`}>
      <Skeleton 
        className="w-full h-full" 
        variant="blueprint" 
        icon={Building2} 
      />
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5">
        <div className="h-4 w-20 bg-amber-500/30 rounded-xs animate-pulse" />
      </div>
    </div>
    <div className="px-1 space-y-2 mb-2">
      <div className="h-5 bg-slate-200/90 rounded-xs w-4/5 animate-pulse" />
    </div>
    <div className="px-1 flex items-center justify-between gap-4 pt-1">
      <div className="h-3.5 bg-slate-100 rounded-xs w-24 animate-pulse" />
      <div className="h-3.5 bg-amber-200/60 rounded-xs w-16 animate-pulse" />
    </div>
  </div>
);

export default function ProjectPortfolio({ 
  onSelectProject, 
  onLaunchExperience, 
  initialSearchQuery = "", 
  onSearchQueryChange 
}: ProjectPortfolioProps) {
  const [activeCategory, setActiveCategory] = useState("All");
  const [activeStatus, setActiveStatus] = useState("All");
  const [sortBy, setSortBy] = useState<SortOption>('featured');
  const [viewMode, setViewMode] = useState<ViewMode>('standard');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(6); // Default 6 to eliminate long scrolling
  const [cardPhotoIndex, setCardPhotoIndex] = useState<Record<string, number>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [isSortDropdownOpen, setIsSortDropdownOpen] = useState(false);

  // Slideshow playback & speed controls (WCAG Accessibility Compliant)
  const [isGlobalSlideshowActive, setIsGlobalSlideshowActive] = useState<boolean>(true);
  const [cardPausedOverrides, setCardPausedOverrides] = useState<Record<string, boolean>>({});
  const [slideshowSpeed, setSlideshowSpeed] = useState<number>(3000); // Default 3000ms
  const [hoveredCardId, setHoveredCardId] = useState<string | null>(null);
  
  const sliderRef = useRef<HTMLDivElement>(null);

  // Respect system prefers-reduced-motion
  useEffect(() => {
    if (typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setIsGlobalSlideshowActive(false);
    }
  }, []);

  // Automatic Rotation Engine for multi-photo cards
  useEffect(() => {
    if (!isGlobalSlideshowActive) return;

    const interval = setInterval(() => {
      setCardPhotoIndex(prevIndices => {
        const nextIndices = { ...prevIndices };
        PROJECTS.forEach(project => {
          const photos = project.images && project.images.length > 0 
            ? project.images 
            : project.image ? [project.image] : [];
          
          if (photos.length > 1) {
            // Check if this individual card is paused or currently hovered
            const isCardPaused = cardPausedOverrides[project.id] === true;
            const isCardHovered = hoveredCardId === project.id;

            if (!isCardPaused && !isCardHovered) {
              const currentIdx = prevIndices[project.id] || 0;
              nextIndices[project.id] = (currentIdx + 1) % photos.length;
            }
          }
        });
        return nextIndices;
      });
    }, slideshowSpeed);

    return () => clearInterval(interval);
  }, [isGlobalSlideshowActive, cardPausedOverrides, hoveredCardId, slideshowSpeed]);

  // Toggle individual card slideshow state
  const toggleCardSlideshow = (projectId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCardPausedOverrides(prev => {
      const currentlyPaused = prev[projectId] !== undefined 
        ? prev[projectId] 
        : !isGlobalSlideshowActive;
      return {
        ...prev,
        [projectId]: !currentlyPaused
      };
    });
  };

  // Next/Prev Photo on Card
  const navigateCardPhoto = (projectId: string, totalPhotos: number, direction: 'next' | 'prev', e: React.MouseEvent) => {
    e.stopPropagation();
    setCardPhotoIndex(prev => {
      const current = prev[projectId] || 0;
      const nextIdx = direction === 'next' 
        ? (current + 1) % totalPhotos 
        : (current - 1 + totalPhotos) % totalPhotos;
      return { ...prev, [projectId]: nextIdx };
    });
  };

  // Cycle speed for individual card / globally
  const cycleSlideshowSpeed = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSlideshowSpeed(prev => {
      if (prev === 2000) return 3000;
      if (prev === 3000) return 5000;
      return 2000;
    });
  };

  // Trigger brief shimmer on filter or sort switch
  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 250);
    return () => clearTimeout(timer);
  }, [activeCategory, activeStatus, sortBy, initialSearchQuery]);

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [activeCategory, activeStatus, sortBy, initialSearchQuery]);

  // Filter and sort projects
  const sortedAndFilteredProjects = useMemo(() => {
    let list = PROJECTS.filter(p => {
      const q = initialSearchQuery.toLowerCase().trim();
      const matchesSearch = !q || 
        p.title.toLowerCase().includes(q) || 
        p.location.toLowerCase().includes(q) ||
        p.type.toLowerCase().includes(q) ||
        (p.year && p.year.includes(q)) ||
        (p.status && p.status.toLowerCase().includes(q));
      
      const matchesCategory = activeCategory === "All" || p.type === activeCategory;
      const matchesStatus = activeStatus === "All" || p.status === activeStatus;
      
      return matchesSearch && matchesCategory && matchesStatus;
    });

    // Apply Sorting
    return list.sort((a, b) => {
      if (sortBy === 'newest') {
        const yearA = parseInt(a.year || '2020', 10);
        const yearB = parseInt(b.year || '2020', 10);
        return yearB - yearA;
      }
      if (sortBy === 'oldest') {
        const yearA = parseInt(a.year || '2020', 10);
        const yearB = parseInt(b.year || '2020', 10);
        return yearA - yearB;
      }
      if (sortBy === 'status') {
        const statusOrder: Record<string, number> = {
          'Completed': 1,
          'Featured': 2,
          'Under Construction': 3,
          'Planning': 4
        };
        const orderA = statusOrder[a.status] || 5;
        const orderB = statusOrder[b.status] || 5;
        return orderA - orderB;
      }
      if (sortBy === 'alphabetical') {
        return a.title.localeCompare(b.title);
      }
      if (sortBy === 'photos') {
        const photosA = a.images?.length || (a.image ? 1 : 0);
        const photosB = b.images?.length || (b.image ? 1 : 0);
        return photosB - photosA;
      }
      // 'featured' default: Keep crystal-point and flagship works first
      if (a.id === 'crystal-point') return -1;
      if (b.id === 'crystal-point') return 1;
      return 0;
    });
  }, [activeCategory, activeStatus, sortBy, initialSearchQuery]);

  // Pagination calculations (if not slider and itemsPerPage is limited)
  const totalPages = itemsPerPage === 999 
    ? 1 
    : Math.ceil(sortedAndFilteredProjects.length / itemsPerPage);

  const displayedProjects = useMemo(() => {
    if (viewMode === 'slider' || itemsPerPage === 999) {
      return sortedAndFilteredProjects;
    }
    const start = (currentPage - 1) * itemsPerPage;
    return sortedAndFilteredProjects.slice(start, start + itemsPerPage);
  }, [sortedAndFilteredProjects, currentPage, itemsPerPage, viewMode]);

  // Handle slide scrolling in horizontal mode
  const scrollSlider = (direction: 'left' | 'right') => {
    if (sliderRef.current) {
      const { scrollLeft, clientWidth } = sliderRef.current;
      const scrollAmount = clientWidth * 0.8;
      sliderRef.current.scrollTo({
        left: direction === 'left' ? scrollLeft - scrollAmount : scrollLeft + scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const sortLabels: Record<SortOption, string> = {
    featured: "Featured & Curated",
    newest: "Newest Projects (2025 → 2021)",
    oldest: "Oldest Projects (2021 → 2025)",
    status: "Status (Completed First)",
    alphabetical: "Project Name (A — Z)",
    photos: "Most Photos & Media"
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.05 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0, scale: 0.97 },
    visible: {
      y: 0,
      opacity: 1,
      scale: 1,
      transition: { 
        type: "spring" as const,
        stiffness: 140,
        damping: 18,
        duration: 0.45
      }
    }
  };

  return (
    <section id="projects" className="py-24 bg-white scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Header Title & Summary */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-6"
        >
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-amber-600 font-bold tracking-widest uppercase text-xs">Portfolio Gallery</span>
              <span className="text-slate-300">•</span>
              <span className="text-slate-500 text-xs font-semibold">
                {sortedAndFilteredProjects.length} Projects Sorted
              </span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900">
              Architectural & Engineering Works
            </h2>
          </div>

          {/* View Mode Switcher (Grid vs Compact vs Zero-Scroll Slider) */}
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-sm self-start md:self-auto border border-slate-200/70 shadow-xs">
            <button
              onClick={() => setViewMode('standard')}
              title="Standard 3-Column Grid"
              aria-label="Switch to Standard Grid View"
              className={`p-2 rounded-xs transition-all flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider ${
                viewMode === 'standard' 
                  ? 'bg-white text-slate-900 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Grid className="w-4 h-4" />
              <span className="hidden sm:inline">Grid</span>
            </button>
            <button
              onClick={() => setViewMode('compact')}
              title="Compact 4-Column Matrix (Zero Excess Scroll)"
              aria-label="Switch to Compact Matrix View"
              className={`p-2 rounded-xs transition-all flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider ${
                viewMode === 'compact' 
                  ? 'bg-white text-slate-900 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
              <span className="hidden sm:inline">Compact</span>
            </button>
            <button
              onClick={() => setViewMode('slider')}
              title="Horizontal Carousel (Zero Vertical Scrolling)"
              aria-label="Switch to Horizontal Slider View"
              className={`p-2 rounded-xs transition-all flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider ${
                viewMode === 'slider' 
                  ? 'bg-white text-amber-600 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span className="hidden sm:inline">Scroll-Free Slider</span>
            </button>
          </div>
        </motion.div>

        {/* Filter & Sorting Toolbar */}
        <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-sm mb-8 space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            
            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mr-1 hidden sm:inline">Type:</span>
              {CATEGORIES.map((cat) => {
                const count = cat === "All" 
                  ? PROJECTS.length 
                  : PROJECTS.filter(p => p.type === cat).length;
                return (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      activeCategory === cat 
                        ? 'bg-amber-600 text-white shadow-sm' 
                        : 'bg-white text-slate-600 border border-slate-200 hover:border-amber-500 hover:text-amber-600'
                    }`}
                  >
                    <span>{cat}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                      activeCategory === cat ? 'bg-amber-700 text-white' : 'bg-slate-100 text-slate-500'
                    }`}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Sort Dropdown & Status Filter & Global Slideshow Switch */}
            <div className="flex flex-wrap items-center gap-2.5">
              
              {/* Accessibility Global Slideshow Controller */}
              <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-sm p-1 text-xs shadow-xs">
                <button
                  onClick={() => setIsGlobalSlideshowActive(prev => !prev)}
                  aria-label={isGlobalSlideshowActive ? "Pause automatic card photo slideshow" : "Start automatic card photo slideshow"}
                  className={`px-2.5 py-1 rounded-xs font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                    isGlobalSlideshowActive 
                      ? 'bg-amber-600 text-white shadow-xs' 
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                  title={isGlobalSlideshowActive ? "Automatic card rotation is ON. Click to pause all cards for accessibility." : "Automatic card rotation is PAUSED. Click to play."}
                >
                  {isGlobalSlideshowActive ? (
                    <>
                      <Pause className="w-3 h-3 fill-current" />
                      <span className="text-[10px] uppercase tracking-wider">Auto-Rotate On</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3 h-3 fill-current" />
                      <span className="text-[10px] uppercase tracking-wider">Auto-Rotate Off</span>
                    </>
                  )}
                </button>

                {/* Slideshow Speed Selector */}
                <button
                  onClick={cycleSlideshowSpeed}
                  aria-label={`Current rotation speed is ${slideshowSpeed / 1000} seconds. Click to cycle speed.`}
                  className="px-2 py-1 bg-slate-50 hover:bg-amber-50 hover:text-amber-700 text-slate-700 rounded-xs text-[10px] font-mono font-bold flex items-center gap-1 transition-colors cursor-pointer border border-slate-100"
                  title="Card rotation interval. Click to toggle 2s / 3s / 5s."
                >
                  <Gauge className="w-3 h-3 text-amber-600" />
                  <span>{slideshowSpeed / 1000}s</span>
                </button>
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-sm p-1 text-xs shadow-xs">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-1">Status:</span>
                <select
                  value={activeStatus}
                  onChange={(e) => setActiveStatus(e.target.value)}
                  className="bg-transparent text-slate-700 font-semibold outline-none cursor-pointer pr-2 text-xs py-0.5"
                  aria-label="Filter by project status"
                >
                  {STATUS_FILTERS.map((st) => (
                    <option key={st} value={st}>{st === 'All' ? 'All Statuses' : st}</option>
                  ))}
                </select>
              </div>

              {/* Sort By Selector */}
              <div className="relative">
                <button
                  onClick={() => setIsSortDropdownOpen(prev => !prev)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 rounded-sm text-xs font-bold text-slate-800 hover:border-amber-600 hover:text-amber-600 transition-colors shadow-xs cursor-pointer"
                  aria-haspopup="listbox"
                  aria-expanded={isSortDropdownOpen}
                  aria-label="Sort projects"
                >
                  <ArrowUpDown className="w-3.5 h-3.5 text-amber-600" />
                  <span className="truncate max-w-[160px]">{sortLabels[sortBy]}</span>
                  <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isSortDropdownOpen ? 'rotate-180' : ''}`} />
                </button>

                {/* Sort Options Menu */}
                <AnimatePresence>
                  {isSortDropdownOpen && (
                    <>
                      <div 
                        className="fixed inset-0 z-30" 
                        onClick={() => setIsSortDropdownOpen(false)} 
                      />
                      <motion.div
                        initial={{ opacity: 0, y: 6, scale: 0.98 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 6, scale: 0.98 }}
                        transition={{ duration: 0.15 }}
                        className="absolute right-0 mt-1 w-64 bg-white border border-slate-200 rounded-sm shadow-xl z-40 py-1 overflow-hidden"
                        role="listbox"
                      >
                        <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">
                          Sort Project Photos By
                        </div>
                        {(Object.keys(sortLabels) as SortOption[]).map((option) => (
                          <button
                            key={option}
                            role="option"
                            aria-selected={sortBy === option}
                            onClick={() => {
                              setSortBy(option);
                              setIsSortDropdownOpen(false);
                            }}
                            className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                              sortBy === option 
                                ? 'bg-amber-50 text-amber-900 font-bold' 
                                : 'text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            <span>{sortLabels[option]}</span>
                            {sortBy === option && <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />}
                          </button>
                        ))}
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>

              {/* Items Per View Toggle (To remove long scrolling) */}
              {viewMode !== 'slider' && (
                <div className="hidden sm:flex items-center gap-1 bg-white border border-slate-200 rounded-sm p-1 text-xs">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-1">View:</span>
                  <button
                    onClick={() => setItemsPerPage(6)}
                    className={`px-2 py-0.5 text-xs font-bold rounded-xs transition-colors ${
                      itemsPerPage === 6 ? 'bg-slate-900 text-white' : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="Show 6 items per page to eliminate scrolling"
                  >
                    6
                  </button>
                  <button
                    onClick={() => setItemsPerPage(9)}
                    className={`px-2 py-0.5 text-xs font-bold rounded-xs transition-colors ${
                      itemsPerPage === 9 ? 'bg-slate-900 text-white' : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="Show 9 items per page"
                  >
                    9
                  </button>
                  <button
                    onClick={() => setItemsPerPage(999)}
                    className={`px-2 py-0.5 text-xs font-bold rounded-xs transition-colors ${
                      itemsPerPage === 999 ? 'bg-slate-900 text-white' : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="Show all projects in continuous grid"
                  >
                    All
                  </button>
                </div>
              )}

            </div>
          </div>
        </div>

        {/* --- MAIN PROJECT PHOTO VIEWER MODES --- */}
        {viewMode === 'slider' ? (
          /* =========================================================================
             ZERO-SCROLL HORIZONTAL SLIDER MODE
             Users can swipe/scroll sideways through all project photos without ANY vertical scrolling!
             ========================================================================= */
          <div className="relative group">
            {/* Left/Right Navigation Arrows */}
            <button
              onClick={() => scrollSlider('left')}
              aria-label="Scroll projects left"
              className="absolute -left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 bg-slate-900/90 text-white rounded-full flex items-center justify-center shadow-xl hover:bg-amber-600 transition-all cursor-pointer opacity-90 hover:opacity-100 hover:scale-105"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={() => scrollSlider('right')}
              aria-label="Scroll projects right"
              className="absolute -right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 bg-slate-900/90 text-white rounded-full flex items-center justify-center shadow-xl hover:bg-amber-600 transition-all cursor-pointer opacity-90 hover:opacity-100 hover:scale-105"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Scrollable Row */}
            <div 
              ref={sliderRef}
              className="flex gap-6 overflow-x-auto pb-6 pt-2 scroll-smooth snap-x snap-mandatory scrollbar-none"
              style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
              {sortedAndFilteredProjects.map((project) => {
                const projectPhotos = project.images && project.images.length > 0 
                  ? project.images 
                  : project.image ? [project.image] : [];
                const activePhotoIdx = cardPhotoIndex[project.id] || 0;
                const currentPhoto = projectPhotos[activePhotoIdx] || project.image;
                const hasMultiplePhotos = projectPhotos.length > 1;
                const isCardPaused = cardPausedOverrides[project.id] !== undefined 
                  ? cardPausedOverrides[project.id] 
                  : !isGlobalSlideshowActive;
                const isCardHovered = hoveredCardId === project.id;
                const isAutoRotating = hasMultiplePhotos && !isCardPaused && !isCardHovered && isGlobalSlideshowActive;

                return (
                  <motion.div
                    key={project.id || project.title}
                    className="shrink-0 w-[300px] sm:w-[360px] snap-start bg-white rounded-sm border border-slate-200 hover:border-amber-500 hover:shadow-xl transition-all cursor-pointer flex flex-col justify-between overflow-hidden group/card"
                    onClick={() => onSelectProject(project)}
                    onMouseEnter={() => setHoveredCardId(project.id)}
                    onMouseLeave={() => setHoveredCardId(null)}
                  >
                    <div>
                      {/* Photo Container */}
                      <div className="relative aspect-[4/3] overflow-hidden bg-slate-100">
                        {currentPhoto ? (
                          <LazyImage 
                            src={currentPhoto} 
                            alt={project.title} 
                            className="w-full h-full object-cover group-hover/card:scale-105 transition-transform duration-500"
                            containerClassName="w-full h-full"
                            showSkeleton={true}
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-slate-300">
                            <Building2 className="w-12 h-12 stroke-[1px]" />
                          </div>
                        )}

                        {/* Slideshow Progress Bar */}
                        {isAutoRotating && (
                          <motion.div
                            key={`progress-slider-${project.id}-${activePhotoIdx}`}
                            initial={{ scaleX: 0 }}
                            animate={{ scaleX: 1 }}
                            transition={{ duration: slideshowSpeed / 1000, ease: "linear" }}
                            className="absolute top-0 left-0 right-0 h-1 bg-amber-500 origin-left z-30"
                          />
                        )}

                        {/* Badges */}
                        <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 pointer-events-none">
                          <span className="bg-amber-600 text-white text-[9px] font-bold px-2 py-0.5 uppercase tracking-wider rounded-xs shadow-sm">
                            {project.type}
                          </span>
                          {project.year && (
                            <span className="bg-slate-900/90 text-white text-[8px] font-bold px-1.5 py-0.5 uppercase tracking-widest rounded-xs border border-white/10 w-fit">
                              {project.year}
                            </span>
                          )}
                        </div>

                        {/* Top-Right Status Tooltip for Accessibility */}
                        {hasMultiplePhotos && (
                          <div className="absolute top-3 right-3 z-20 pointer-events-none">
                            {isCardHovered && !isCardPaused && isGlobalSlideshowActive ? (
                              <span className="bg-slate-900/80 backdrop-blur-xs text-amber-300 text-[8px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full border border-amber-400/20">
                                Hover Paused
                              </span>
                            ) : isCardPaused ? (
                              <span className="bg-slate-950/80 backdrop-blur-xs text-slate-400 text-[8px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full border border-white/10">
                                Paused
                              </span>
                            ) : null}
                          </div>
                        )}

                        {/* Interactive Slideshow Playback Toolbar on Card */}
                        {hasMultiplePhotos && (
                          <div 
                            className="absolute bottom-2 left-2 right-2 z-20 flex items-center justify-between gap-1 bg-slate-950/85 backdrop-blur-sm py-1 px-2 rounded-sm border border-white/10 shadow-lg"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {/* Play / Pause Toggle Button */}
                            <div className="flex items-center gap-1">
                              <button
                                onClick={(e) => toggleCardSlideshow(project.id, e)}
                                aria-label={isCardPaused ? `Start slideshow for ${project.title}` : `Pause slideshow for ${project.title}`}
                                title={isCardPaused ? "Play slideshow" : "Pause slideshow"}
                                className={`w-6 h-6 rounded-xs flex items-center justify-center transition-colors cursor-pointer ${
                                  !isCardPaused && isGlobalSlideshowActive 
                                    ? 'bg-amber-600 text-white hover:bg-amber-500' 
                                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                                }`}
                              >
                                {!isCardPaused && isGlobalSlideshowActive ? (
                                  <Pause className="w-3 h-3 fill-current" />
                                ) : (
                                  <Play className="w-3 h-3 fill-current ml-0.5" />
                                )}
                              </button>

                              {/* Prev / Next Step Buttons */}
                              <button
                                onClick={(e) => navigateCardPhoto(project.id, projectPhotos.length, 'prev', e)}
                                aria-label={`Previous photo of ${project.title}`}
                                title="Previous photo"
                                className="w-5 h-6 rounded-xs bg-slate-900/60 hover:bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer text-xs"
                              >
                                <ChevronLeft className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={(e) => navigateCardPhoto(project.id, projectPhotos.length, 'next', e)}
                                aria-label={`Next photo of ${project.title}`}
                                title="Next photo"
                                className="w-5 h-6 rounded-xs bg-slate-900/60 hover:bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer text-xs"
                              >
                                <ChevronRight className="w-3.5 h-3.5" />
                              </button>

                              {/* Photo Counter */}
                              <span className="text-[9px] font-mono text-amber-400 font-bold px-1 hidden sm:inline">
                                {activePhotoIdx + 1}/{projectPhotos.length}
                              </span>
                            </div>

                            {/* Center Mini Thumbnail Indicators */}
                            <div className="flex items-center gap-1">
                              {projectPhotos.map((_, pIdx) => (
                                <button
                                  key={pIdx}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setCardPhotoIndex(prev => ({ ...prev, [project.id]: pIdx }));
                                  }}
                                  aria-label={`Jump to photo ${pIdx + 1} for ${project.title}`}
                                  className={`h-1.5 rounded-full transition-all cursor-pointer ${
                                    activePhotoIdx === pIdx 
                                      ? 'w-3.5 bg-amber-500 shadow-xs' 
                                      : 'w-1.5 bg-white/40 hover:bg-white/80'
                                  }`}
                                />
                              ))}
                            </div>

                            {/* Speed Selector Button */}
                            <button
                              onClick={cycleSlideshowSpeed}
                              aria-label={`Slideshow speed: ${slideshowSpeed / 1000}s. Click to adjust.`}
                              title="Click to cycle rotation speed (2s / 3s / 5s)"
                              className="text-[9px] font-mono font-bold text-slate-300 hover:text-amber-400 px-1.5 py-0.5 rounded-xs bg-slate-900 hover:bg-slate-800 transition-colors flex items-center gap-0.5 cursor-pointer border border-white/5"
                            >
                              <Gauge className="w-2.5 h-2.5 text-amber-500" />
                              <span>{slideshowSpeed / 1000}s</span>
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Content */}
                      <div className="p-4">
                        <h4 className="font-display font-bold text-lg text-slate-900 group-hover/card:text-amber-600 transition-colors line-clamp-1 mb-1">
                          {project.title}
                        </h4>
                        <p className="text-slate-500 text-xs flex items-center gap-1 font-medium line-clamp-1">
                          <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" /> {project.location}
                        </p>
                      </div>
                    </div>

                    <div className="px-4 pb-4 pt-0 flex items-center justify-between border-t border-slate-100/80 mt-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                        {project.status}
                      </span>
                      <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider group-hover/card:translate-x-0.5 transition-transform flex items-center gap-1">
                        View Dossier <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </div>
            
            <div className="flex items-center justify-center gap-2 mt-4 text-xs font-semibold text-slate-400">
              <span>← Swipe or use arrows to view all {sortedAndFilteredProjects.length} projects without scrolling →</span>
            </div>
          </div>
        ) : (
          /* =========================================================================
             GRID & COMPACT MATRIX VIEWS
             ========================================================================= */
          <motion.div 
            layout
            key={`${activeCategory}-${activeStatus}-${sortBy}-${viewMode}-${currentPage}`}
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className={viewMode === 'compact' 
              ? "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5" 
              : "grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            }
          >
            <AnimatePresence mode="popLayout" initial={false}>
              {isLoading ? (
                Array.from({ length: itemsPerPage === 999 ? 6 : itemsPerPage }).map((_, idx) => (
                  <motion.div
                    key={`skeleton-${idx}`}
                    layout
                    initial={{ opacity: 0, scale: 0.96 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.96 }}
                    transition={{ duration: 0.15 }}
                  >
                    <ProjectCardSkeleton viewMode={viewMode} />
                  </motion.div>
                ))
              ) : displayedProjects.length === 0 ? (
                <motion.div 
                  layout
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="col-span-full py-16 text-center space-y-4"
                >
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-300">
                    <Search className="w-8 h-8" />
                  </div>
                  <h4 className="font-bold text-slate-900">No projects match the selected criteria</h4>
                  <p className="text-sm text-slate-500">Try adjusting your filters, sort order, or search keyword.</p>
                  <button 
                    onClick={() => {
                      setActiveCategory("All");
                      setActiveStatus("All");
                      setSortBy("featured");
                      if (onSearchQueryChange) onSearchQueryChange("");
                    }}
                    className="bg-slate-900 text-white px-6 py-2 rounded-sm text-xs font-bold uppercase tracking-widest mt-4 cursor-pointer hover:bg-amber-600 transition-colors"
                  >
                    Reset All Filters
                  </button>
                </motion.div>
              ) : (
                displayedProjects.map((project) => {
                  const projectPhotos = project.images && project.images.length > 0 
                    ? project.images 
                    : project.image ? [project.image] : [];
                  const activePhotoIdx = cardPhotoIndex[project.id] || 0;
                  const currentPhoto = projectPhotos[activePhotoIdx] || project.image;
                  const hasMultiplePhotos = projectPhotos.length > 1;
                  const isCardPaused = cardPausedOverrides[project.id] !== undefined 
                    ? cardPausedOverrides[project.id] 
                    : !isGlobalSlideshowActive;
                  const isCardHovered = hoveredCardId === project.id;
                  const isAutoRotating = hasMultiplePhotos && !isCardPaused && !isCardHovered && isGlobalSlideshowActive;

                  return (
                    <motion.div
                      key={project.id || project.title}
                      layoutId={`project-card-${project.id}`}
                      layout
                      variants={itemVariants}
                      exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.15 } }}
                      whileHover={{ y: -6 }}
                      className="group cursor-pointer bg-white rounded-sm border border-slate-100 hover:border-amber-500/60 transition-all hover:shadow-xl overflow-hidden flex flex-col justify-between"
                      onClick={() => onSelectProject(project)}
                      onMouseEnter={() => setHoveredCardId(project.id)}
                      onMouseLeave={() => setHoveredCardId(null)}
                    >
                      <div>
                        {/* Fixed aspect ratio container preventing layout shifts */}
                        <div className={`relative overflow-hidden rounded-sm bg-slate-100 mb-4 border border-slate-100 ${
                          viewMode === 'compact' ? 'aspect-[16/10]' : 'aspect-[4/3]'
                        }`}>
                          {currentPhoto ? (
                            <LazyImage 
                              src={currentPhoto} 
                              alt={project.title} 
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                              containerClassName="w-full h-full"
                              showSkeleton={true}
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-300 font-display font-bold bg-slate-50">
                              <Building2 className="w-12 h-12 stroke-[1px]" />
                            </div>
                          )}

                          {/* Slideshow Progress Bar */}
                          {isAutoRotating && (
                            <motion.div
                              key={`progress-grid-${project.id}-${activePhotoIdx}`}
                              initial={{ scaleX: 0 }}
                              animate={{ scaleX: 1 }}
                              transition={{ duration: slideshowSpeed / 1000, ease: "linear" }}
                              className="absolute top-0 left-0 right-0 h-1 bg-amber-500 origin-left z-30"
                            />
                          )}
                          
                          {/* Hover Gradient Overlay */}
                          <div className="absolute inset-0 bg-slate-900/10 group-hover:bg-transparent transition-all z-10 pointer-events-none" />
                          
                          {/* Category and Year Badges */}
                          <div className="absolute top-3 left-3 z-20 flex flex-col gap-1.5 pointer-events-none">
                            <span className="bg-amber-600 text-white text-[9px] font-bold px-2 py-0.5 uppercase tracking-wider shadow-sm rounded-xs">
                              {project.type}
                            </span>
                            {project.milestone && (
                              <span className="bg-slate-900/90 text-white text-[8px] font-bold px-1.5 py-0.5 uppercase tracking-widest shadow-sm backdrop-blur-xs border border-white/10 w-fit rounded-xs">
                                {project.milestone}
                              </span>
                            )}
                          </div>

                          {/* Top-Right Status Tooltip for Accessibility */}
                          {hasMultiplePhotos && (
                            <div className="absolute top-3 right-3 z-20 pointer-events-none">
                              {isCardHovered && !isCardPaused && isGlobalSlideshowActive ? (
                                <span className="bg-slate-900/80 backdrop-blur-xs text-amber-300 text-[8px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full border border-amber-400/20">
                                  Hover Paused
                                </span>
                              ) : isCardPaused ? (
                                <span className="bg-slate-950/80 backdrop-blur-xs text-slate-400 text-[8px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full border border-white/10">
                                  Paused
                                </span>
                              ) : null}
                            </div>
                          )}

                          {/* Dedicated Photo Slideshow & Playback Toolbar on Card */}
                          {hasMultiplePhotos && (
                            <div 
                              className="absolute bottom-2 left-2 right-2 z-20 flex items-center justify-between gap-1 bg-slate-950/85 backdrop-blur-sm py-1 px-2.5 rounded-sm border border-white/10 shadow-lg opacity-90 group-hover:opacity-100 transition-opacity"
                              onClick={(e) => e.stopPropagation()}
                            >
                              {/* Left Controls: Play/Pause and Step Buttons */}
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={(e) => toggleCardSlideshow(project.id, e)}
                                  aria-label={isCardPaused ? `Start slideshow for ${project.title}` : `Pause slideshow for ${project.title}`}
                                  title={isCardPaused ? "Play slideshow" : "Pause slideshow"}
                                  className={`w-6 h-6 rounded-xs flex items-center justify-center transition-colors cursor-pointer ${
                                    !isCardPaused && isGlobalSlideshowActive 
                                      ? 'bg-amber-600 text-white hover:bg-amber-500' 
                                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                                  }`}
                                >
                                  {!isCardPaused && isGlobalSlideshowActive ? (
                                    <Pause className="w-3 h-3 fill-current" />
                                  ) : (
                                    <Play className="w-3 h-3 fill-current ml-0.5" />
                                  )}
                                </button>

                                <button
                                  onClick={(e) => navigateCardPhoto(project.id, projectPhotos.length, 'prev', e)}
                                  aria-label={`Previous photo of ${project.title}`}
                                  title="Previous photo"
                                  className="w-5 h-6 rounded-xs bg-slate-900/60 hover:bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer text-xs"
                                >
                                  <ChevronLeft className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={(e) => navigateCardPhoto(project.id, projectPhotos.length, 'next', e)}
                                  aria-label={`Next photo of ${project.title}`}
                                  title="Next photo"
                                  className="w-5 h-6 rounded-xs bg-slate-900/60 hover:bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer text-xs"
                                >
                                  <ChevronRight className="w-3.5 h-3.5" />
                                </button>

                                <span className="text-[9px] font-mono text-amber-400 font-bold px-1 hidden sm:inline">
                                  {activePhotoIdx + 1}/{projectPhotos.length}
                                </span>
                              </div>

                              {/* Center Mini Indicators */}
                              <div className="flex items-center gap-1">
                                {projectPhotos.map((_, pIdx) => (
                                  <button
                                    key={pIdx}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setCardPhotoIndex(prev => ({ ...prev, [project.id]: pIdx }));
                                    }}
                                    aria-label={`Preview photo ${pIdx + 1} of ${project.title}`}
                                    className={`h-2 rounded-xs transition-all cursor-pointer ${
                                      activePhotoIdx === pIdx 
                                        ? 'w-4 bg-amber-500 shadow-xs' 
                                        : 'w-1.5 bg-white/40 hover:bg-white/80'
                                    }`}
                                  />
                                ))}
                              </div>

                              {/* Right Speed Toggle */}
                              <button
                                onClick={cycleSlideshowSpeed}
                                aria-label={`Slideshow speed: ${slideshowSpeed / 1000}s. Click to adjust.`}
                                title="Click to cycle rotation speed (2s / 3s / 5s)"
                                className="text-[9px] font-mono font-bold text-slate-300 hover:text-amber-400 px-1.5 py-0.5 rounded-xs bg-slate-900 hover:bg-slate-800 transition-colors flex items-center gap-0.5 cursor-pointer border border-white/5"
                              >
                                <Gauge className="w-2.5 h-2.5 text-amber-500" />
                                <span>{slideshowSpeed / 1000}s</span>
                              </button>
                            </div>
                          )}
                        </div>

                        {/* Title and location */}
                        <div className="px-1">
                          <h4 className={`font-display font-bold text-slate-900 mb-1 group-hover:text-amber-600 transition-colors line-clamp-1 ${
                            viewMode === 'compact' ? 'text-base' : 'text-xl'
                          }`}>
                            {project.title}
                          </h4>
                          <p className="text-slate-500 text-xs flex items-center gap-1 font-medium line-clamp-1">
                            <MapPin className="w-3 h-3 text-amber-600 shrink-0" /> {project.location}
                          </p>
                        </div>
                      </div>

                      {/* Footer Actions */}
                      <div className="px-1 flex items-center justify-between gap-3 pt-3 mt-2 border-t border-slate-100/90">
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest truncate">
                          {project.status} {project.year ? `• ${project.year}` : ''}
                        </span>
                        
                        <div className="flex items-center gap-3 shrink-0">
                          {project.id === 'crystal-point' && onLaunchExperience && (
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                onLaunchExperience(project.id);
                              }}
                              className="text-[9px] font-bold text-slate-900 uppercase tracking-widest hover:text-amber-600 transition-colors border-b border-slate-900/20 pb-0.5 cursor-pointer"
                            >
                              Immersion
                            </button>
                          )}
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectProject(project);
                            }}
                            className="text-[9px] font-bold text-amber-600 uppercase tracking-widest hover:text-slate-900 transition-colors border-b border-amber-600/30 pb-0.5 cursor-pointer flex items-center gap-0.5"
                          >
                            Details <ArrowRight className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  );
                })
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {/* --- PAGINATION & ZERO-SCROLL CONTROLS --- */}
        {viewMode !== 'slider' && totalPages > 1 && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-12 flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-slate-100"
          >
            <div className="text-xs text-slate-500 font-medium">
              Showing <span className="font-bold text-slate-900">{displayedProjects.length}</span> of <span className="font-bold text-slate-900">{sortedAndFilteredProjects.length}</span> projects
              {itemsPerPage !== 999 && ` (Page ${currentPage} of ${totalPages})`}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="px-3 py-1.5 border border-slate-200 rounded-sm text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1 cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" /> Prev
              </button>

              {Array.from({ length: totalPages }).map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentPage(idx + 1)}
                  className={`w-8 h-8 rounded-sm text-xs font-bold transition-all cursor-pointer ${
                    currentPage === idx + 1
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'border border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {idx + 1}
                </button>
              ))}

              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="px-3 py-1.5 border border-slate-200 rounded-sm text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1 cursor-pointer"
              >
                Next <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        )}

      </div>
    </section>
  );
}
