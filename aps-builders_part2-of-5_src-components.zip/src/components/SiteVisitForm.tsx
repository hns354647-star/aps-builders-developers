import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar as CalendarIcon, Clock, User, Phone, Mail, CheckCircle2, ChevronRight, ChevronLeft, AlertCircle, MessageSquare } from 'lucide-react';
import { siteVisitSchema, validateField, SiteVisitFormData } from '../schemas/validationSchemas';

interface SiteVisitFormProps {
  projectName: string;
  onClose: () => void;
}

export default function SiteVisitForm({ projectName, onClose }: SiteVisitFormProps) {
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState<number | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [stepError, setStepError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: ''
  });

  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Mock dates for the current month
  const today = new Date();
  const dates = Array.from({ length: 14 }, (_, i) => {
    const d = new Date();
    d.setDate(today.getDate() + i + 1);
    return d;
  });

  const timeSlots = ["10:00 AM", "11:30 AM", "02:00 PM", "03:30 PM", "05:00 PM"];

  const handleFieldChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Real-time validation
    if (touched[field]) {
      const error = validateField(siteVisitSchema, field, value);
      setErrors(prev => {
        const next = { ...prev };
        if (error) {
          next[field] = error;
        } else {
          delete next[field];
        }
        return next;
      });
    }
  };

  const handleFieldBlur = (field: keyof typeof formData) => {
    setTouched(prev => ({ ...prev, [field]: true }));
    const error = validateField(siteVisitSchema, field, formData[field]);
    setErrors(prev => {
      const next = { ...prev };
      if (error) {
        next[field] = error;
      } else {
        delete next[field];
      }
      return next;
    });
  };

  const handleStep1Next = () => {
    if (!selectedDate) {
      setStepError("Please select a date for your site visit.");
      return;
    }
    setStepError(null);
    setStep(2);
  };

  const handleStep2Next = () => {
    if (!selectedTime) {
      setStepError("Please pick a time slot for your appointment.");
      return;
    }
    setStepError(null);
    setStep(3);
  };

  const handleBack = () => {
    setStepError(null);
    setStep(prev => prev - 1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Mark all fields as touched
    const allTouched = { name: true, phone: true, email: true, message: true };
    setTouched(allTouched);

    // Full Zod validation
    const payload = {
      selectedDate: selectedDate || 0,
      selectedTime: selectedTime || '',
      name: formData.name,
      phone: formData.phone,
      email: formData.email,
      message: formData.message || undefined
    };

    const parseResult = siteVisitSchema.safeParse(payload);

    if (!parseResult.success) {
      const fieldErrors: Record<string, string> = {};
      const issues = parseResult.error.issues || (parseResult.error as any).errors || [];
      issues.forEach((err: any) => {
        const pathKey = err.path[0] as string;
        if (pathKey && !fieldErrors[pathKey]) {
          fieldErrors[pathKey] = err.message;
        }
      });
      setErrors(fieldErrors);
      return;
    }

    setErrors({});
    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  if (isSuccess) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center justify-center py-12 px-6 text-center"
      >
        <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-6">
          <CheckCircle2 className="w-10 h-10 text-green-500" />
        </div>
        <h3 className="text-2xl font-display font-bold text-slate-900 mb-2">Visit Scheduled!</h3>
        <p className="text-slate-500 text-sm mb-8 max-w-xs">
          Your site inspection for <span className="font-bold text-slate-900">{projectName}</span> has been booked for{' '}
          <span className="font-bold text-slate-900">
            {selectedDate ? new Date(selectedDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : ''} at {selectedTime}
          </span>. 
          Our representative will call you shortly to confirm.
        </p>
        <button 
          onClick={onClose}
          className="w-full bg-slate-900 text-white py-4 rounded-sm font-bold text-xs uppercase tracking-widest hover:bg-amber-600 transition-all focus:outline-none focus:ring-2 focus:ring-amber-500"
        >
          Return to Project
        </button>
      </motion.div>
    );
  }

  return (
    <div className="relative">
      <motion.div
        animate={{ height: "auto" }}
        transition={{ duration: 0.4, ease: "anticipate" }}
        className="overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <span className="text-[10px] font-bold text-amber-600 uppercase tracking-widest block mb-1">
              Step {step} of 3 • Site Inspection
            </span>
            <h3 className="text-xl font-display font-bold text-slate-900">
              {step === 1 ? "Select inspection date" : step === 2 ? "Pick a time slot" : "Your details"}
            </h3>
          </div>
          <button 
            onClick={onClose}
            aria-label="Close form"
            className="p-2 hover:bg-slate-100 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500"
          >
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="h-1 w-full bg-slate-100 rounded-full mb-8 overflow-hidden">
          <motion.div 
            className="h-full bg-amber-600"
            initial={{ width: "33%" }}
            animate={{ width: `${(step / 3) * 100}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>

        {stepError && (
          <motion.div 
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 p-3 bg-red-50 border border-red-200 rounded-sm flex items-center gap-2 text-red-700 text-xs font-semibold"
          >
            <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
            <span>{stepError}</span>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div 
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-4 gap-3">
                {dates.map((date, idx) => {
                  const isSelected = selectedDate === date.getTime();
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setSelectedDate(date.getTime());
                        setStepError(null);
                      }}
                      className={`flex flex-col items-center justify-center p-4 rounded-sm border transition-all ${
                        isSelected
                          ? "bg-slate-900 border-slate-900 text-white shadow-lg scale-105"
                          : "bg-white border-slate-200 hover:border-amber-600 text-slate-600"
                      }`}
                    >
                      <span className="text-[10px] uppercase font-bold tracking-tighter opacity-60">
                        {date.toLocaleDateString('en-US', { weekday: 'short' })}
                      </span>
                      <span className="text-lg font-bold">
                        {date.getDate()}
                      </span>
                    </button>
                  );
                })}
              </div>

              <button
                type="button"
                onClick={handleStep1Next}
                className="w-full bg-slate-900 text-white py-4 rounded-sm font-bold text-xs uppercase tracking-widest hover:bg-amber-600 transition-all flex items-center justify-center gap-2 group focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                Continue <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div 
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="space-y-3">
                {timeSlots.map((time) => {
                  const isSelected = selectedTime === time;
                  return (
                    <button
                      key={time}
                      type="button"
                      onClick={() => {
                        setSelectedTime(time);
                        setStepError(null);
                      }}
                      className={`w-full flex items-center justify-between p-4 rounded-sm border transition-all ${
                        isSelected
                          ? "bg-slate-900 border-slate-900 text-white shadow-lg"
                          : "bg-white border-slate-200 hover:border-amber-600 text-slate-600"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Clock className="w-4 h-4 opacity-50" />
                        <span className="font-bold text-sm">{time}</span>
                      </div>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-amber-500" />}
                    </button>
                  );
                })}
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={handleBack}
                  className="w-full border border-slate-200 text-slate-500 py-4 rounded-sm font-bold text-xs uppercase tracking-widest hover:bg-slate-50 transition-all flex items-center justify-center gap-2 focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  <ChevronLeft className="w-4 h-4" /> Back
                </button>
                <button
                  type="button"
                  onClick={handleStep2Next}
                  className="w-full bg-slate-900 text-white py-4 rounded-sm font-bold text-xs uppercase tracking-widest hover:bg-amber-600 transition-all flex items-center justify-center gap-2 group focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  Confirm <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div 
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <form onSubmit={handleSubmit} noValidate className="space-y-4">
                {/* Full Name */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between ml-1">
                    <label htmlFor="site-visit-name" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      Full Name *
                    </label>
                    {touched.name && !errors.name && formData.name && (
                      <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Valid
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <User className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${errors.name ? 'text-red-400' : 'text-slate-400'}`} />
                    <input 
                      id="site-visit-name"
                      type="text"
                      value={formData.name}
                      onChange={e => handleFieldChange('name', e.target.value)}
                      onBlur={() => handleFieldBlur('name')}
                      placeholder="e.g. Rahul Sharma"
                      aria-invalid={errors.name ? 'true' : 'false'}
                      aria-describedby={errors.name ? 'site-visit-name-error' : undefined}
                      className={`w-full pl-12 pr-4 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all ${
                        errors.name
                          ? 'border-red-500 bg-red-50/20 focus:border-red-600 focus:ring-1 focus:ring-red-500'
                          : touched.name && formData.name
                            ? 'border-emerald-500 focus:border-emerald-600'
                            : 'border-slate-200 focus:border-amber-600 focus:bg-white'
                      }`}
                    />
                  </div>
                  {errors.name && (
                    <p id="site-visit-name-error" className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
                      <AlertCircle className="w-3 h-3 shrink-0" /> {errors.name}
                    </p>
                  )}
                </div>
                
                {/* Phone Number */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between ml-1">
                    <label htmlFor="site-visit-phone" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      Phone Number *
                    </label>
                    {touched.phone && !errors.phone && formData.phone && (
                      <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Valid
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <Phone className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${errors.phone ? 'text-red-400' : 'text-slate-400'}`} />
                    <input 
                      id="site-visit-phone"
                      type="tel"
                      value={formData.phone}
                      onChange={e => handleFieldChange('phone', e.target.value)}
                      onBlur={() => handleFieldBlur('phone')}
                      placeholder="+91 98765 43210"
                      aria-invalid={errors.phone ? 'true' : 'false'}
                      aria-describedby={errors.phone ? 'site-visit-phone-error' : undefined}
                      className={`w-full pl-12 pr-4 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all ${
                        errors.phone
                          ? 'border-red-500 bg-red-50/20 focus:border-red-600 focus:ring-1 focus:ring-red-500'
                          : touched.phone && formData.phone
                            ? 'border-emerald-500 focus:border-emerald-600'
                            : 'border-slate-200 focus:border-amber-600 focus:bg-white'
                      }`}
                    />
                  </div>
                  {errors.phone && (
                    <p id="site-visit-phone-error" className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
                      <AlertCircle className="w-3 h-3 shrink-0" /> {errors.phone}
                    </p>
                  )}
                </div>

                {/* Email Address */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between ml-1">
                    <label htmlFor="site-visit-email" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      Email Address *
                    </label>
                    {touched.email && !errors.email && formData.email && (
                      <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Valid
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <Mail className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${errors.email ? 'text-red-400' : 'text-slate-400'}`} />
                    <input 
                      id="site-visit-email"
                      type="email"
                      value={formData.email}
                      onChange={e => handleFieldChange('email', e.target.value)}
                      onBlur={() => handleFieldBlur('email')}
                      placeholder="rahul@example.com"
                      aria-invalid={errors.email ? 'true' : 'false'}
                      aria-describedby={errors.email ? 'site-visit-email-error' : undefined}
                      className={`w-full pl-12 pr-4 py-3.5 bg-slate-50 border rounded-sm text-sm outline-none transition-all ${
                        errors.email
                          ? 'border-red-500 bg-red-50/20 focus:border-red-600 focus:ring-1 focus:ring-red-500'
                          : touched.email && formData.email
                            ? 'border-emerald-500 focus:border-emerald-600'
                            : 'border-slate-200 focus:border-amber-600 focus:bg-white'
                      }`}
                    />
                  </div>
                  {errors.email && (
                    <p id="site-visit-email-error" className="text-[10px] text-red-600 font-semibold flex items-center gap-1 mt-1 ml-1">
                      <AlertCircle className="w-3 h-3 shrink-0" /> {errors.email}
                    </p>
                  )}
                </div>

                {/* Optional Message / Notes */}
                <div className="space-y-1">
                  <label htmlFor="site-visit-notes" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">
                    Special Requirements / Questions (Optional)
                  </label>
                  <div className="relative">
                    <MessageSquare className="absolute left-4 top-4 w-4 h-4 text-slate-400" />
                    <textarea 
                      id="site-visit-notes"
                      rows={2}
                      value={formData.message}
                      onChange={e => handleFieldChange('message', e.target.value)}
                      placeholder="e.g. Interested in floor plans, architectural structural specs..."
                      className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-sm text-sm focus:border-amber-600 focus:bg-white outline-none transition-all resize-none"
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-4 pt-2">
                  <div className="bg-amber-50 p-4 rounded-sm border border-amber-100 flex items-start gap-4">
                    <CalendarIcon className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-[10px] font-bold text-amber-900 uppercase tracking-widest">Selected Schedule</p>
                      <p className="text-xs text-amber-800 font-medium">
                        {selectedDate ? new Date(selectedDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) : ''} at {selectedTime}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <button
                      type="button"
                      onClick={handleBack}
                      className="w-full border border-slate-200 text-slate-500 py-4 rounded-sm font-bold text-xs uppercase tracking-widest hover:bg-slate-50 transition-all focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      Back
                    </button>
                    <button
                      disabled={isSubmitting}
                      type="submit"
                      className="w-full bg-amber-600 text-white py-4 rounded-sm font-bold text-xs uppercase tracking-widest hover:bg-slate-900 transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Request Site Visit"}
                    </button>
                  </div>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

function Loader2({ className }: { className: string }) {
  return (
    <motion.div
      animate={{ rotate: 360 }}
      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
      className={className}
    >
      <Clock className="w-full h-full" />
    </motion.div>
  );
}

