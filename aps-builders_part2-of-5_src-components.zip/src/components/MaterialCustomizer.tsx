import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Check, 
  Info, 
  Box, 
  Smartphone, 
  Wand2, 
  Building2, 
  Home as HomeIcon, 
  TreePine, 
  GraduationCap, 
  ShieldCheck, 
  Gauge, 
  Activity, 
  Flame, 
  ArrowRight,
  ChevronDown,
  ChevronUp,
  RotateCcw
} from 'lucide-react';
import Room3DPreview from './Room3DPreview';
import ARVisualizer from './ARVisualizer';

export type MaterialType = 'original' | 'marble' | 'granite' | 'oak' | 'slate';

export interface Material {
  id: MaterialType;
  name: string;
  color: string;
  description: string;
  filter: string;
  tagline: string;
  bestFor: string;
}

export const materials: Material[] = [
  { 
    id: 'original', 
    name: 'Standard', 
    color: 'bg-slate-200',
    description: 'Original architectural render finish',
    filter: 'none',
    tagline: 'Base Baseline Finish',
    bestFor: 'Design Blueprint Review'
  },
  { 
    id: 'marble', 
    name: 'Italian Marble', 
    color: 'bg-white',
    description: 'High-gloss white with subtle grey calacatta veining',
    filter: 'brightness(1.1) contrast(0.9) saturate(0.8)',
    tagline: 'Opulent & Light Reflective',
    bestFor: 'Luxury Villas, Penthouses & Palaces'
  },
  { 
    id: 'granite', 
    name: 'Black Granite', 
    color: 'bg-slate-800',
    description: 'Dense polished black textured finish with micro-flecks',
    filter: 'brightness(0.7) contrast(1.2) grayscale(0.5)',
    tagline: 'Heavy Duty & Executive',
    bestFor: 'Commercial Offices, Plazas & IT Parks'
  },
  { 
    id: 'oak', 
    name: 'Natural Oak', 
    color: 'bg-amber-100',
    description: 'Warm organic grain with satin protective seal',
    filter: 'sepia(0.3) saturate(1.5) brightness(0.9) hue-rotate(-10deg)',
    tagline: 'Biophilic Warmth & Eco-Luxury',
    bestFor: 'Sustainable Homes, Resorts & Duplexes'
  },
  { 
    id: 'slate', 
    name: 'Brushed Slate', 
    color: 'bg-slate-600',
    description: 'Matte dark grey anti-slip volcanic stone texture',
    filter: 'contrast(1.1) brightness(0.8) saturate(0.5)',
    tagline: 'Contemporary & Non-Glare',
    bestFor: 'Institutions, Civic Facilities & Modern Facades'
  },
];

export interface SuggestionResult {
  primaryMaterial: MaterialType;
  secondaryMaterial: MaterialType;
  matchScore: number;
  categoryLabel: string;
  headline: string;
  reasoning: string;
  advantages: string[];
  metrics: {
    durability: string;
    aesthetics: string;
    footTraffic: string;
    thermalComfort: string;
  };
}

export function autoSuggestMaterial(
  projectType?: string,
  title?: string,
  description?: string
): SuggestionResult {
  const combinedText = `${projectType || ''} ${title || ''} ${description || ''}`.toLowerCase();

  // Heuristic Rule 1: Luxury Residential / Villas
  if (
    combinedText.includes('luxury') ||
    combinedText.includes('villa') ||
    combinedText.includes('palace') ||
    combinedText.includes('mansion') ||
    combinedText.includes('penthouse') ||
    combinedText.includes('waterfront') ||
    combinedText.includes('apartment')
  ) {
    return {
      primaryMaterial: 'marble',
      secondaryMaterial: 'oak',
      matchScore: 98,
      categoryLabel: 'Luxury Residential & Villa',
      headline: 'Italian Calacatta Marble',
      reasoning: 'For luxury villas and private residential estates, Italian Marble maximizes natural light dispersion, delivers timeless prestige, and stays naturally cool in tropical climates.',
      advantages: [
        'Superior high-gloss ambient light reflectance (+35%)',
        'Naturally cool surface temperature in humid conditions',
        'Elevates long-term luxury property resale value'
      ],
      metrics: {
        durability: '8.8 / 10',
        aesthetics: '9.9 / 10',
        footTraffic: 'Medium - Residential',
        thermalComfort: 'High (Cooling)'
      }
    };
  }

  // Heuristic Rule 2: Commercial Office / Plazas / Towers
  if (
    combinedText.includes('commercial') ||
    combinedText.includes('plaza') ||
    combinedText.includes('mall') ||
    combinedText.includes('tower') ||
    combinedText.includes('retail') ||
    combinedText.includes('corporate') ||
    combinedText.includes('office') ||
    combinedText.includes('it park') ||
    combinedText.includes('business')
  ) {
    return {
      primaryMaterial: 'granite',
      secondaryMaterial: 'slate',
      matchScore: 97,
      categoryLabel: 'Commercial Office & Plaza',
      headline: 'Polished Black Granite',
      reasoning: 'For commercial plazas and corporate office environments, Black Granite provides ultra-high compressive strength, stain resistance, and sleek executive presence under heavy daily foot traffic.',
      advantages: [
        'Exceptional scratch & abrasion resistance under heavy traffic',
        'Ultra-low porosity (<0.2%) preventing spills and stains',
        'Monolithic executive aesthetic suited for corporate foyers'
      ],
      metrics: {
        durability: '9.9 / 10',
        aesthetics: '9.3 / 10',
        footTraffic: 'Ultra-Heavy Commercial',
        thermalComfort: 'High Thermal Mass'
      }
    };
  }

  // Heuristic Rule 3: Sustainable / Eco / Hillside / Resorts
  if (
    combinedText.includes('sustainable') ||
    combinedText.includes('eco') ||
    combinedText.includes('resort') ||
    combinedText.includes('green') ||
    combinedText.includes('estate') ||
    combinedText.includes('homestay') ||
    combinedText.includes('duplex') ||
    combinedText.includes('nalukettu') ||
    combinedText.includes('cottage')
  ) {
    return {
      primaryMaterial: 'oak',
      secondaryMaterial: 'marble',
      matchScore: 96,
      categoryLabel: 'Sustainable & Biophilic Architecture',
      headline: 'Natural Warm Oak Wood',
      reasoning: 'For sustainable and nature-integrated spaces, Natural Oak enhances organic biophilic wellness, lowers interior reverberation, and provides warm tactile comfort.',
      advantages: [
        'Low embodied carbon & renewable FSC-certified origin',
        'Biophilic acoustic dampening for quiet living spaces',
        'Warm, inviting texture balancing Kerala tropical architecture'
      ],
      metrics: {
        durability: '8.6 / 10',
        aesthetics: '9.7 / 10',
        footTraffic: 'Medium Residential',
        thermalComfort: 'Bioclimatic Thermal Balance'
      }
    };
  }

  // Heuristic Rule 4: Institutional / Civic / Educational / Healthcare
  if (
    combinedText.includes('institution') ||
    combinedText.includes('school') ||
    combinedText.includes('education') ||
    combinedText.includes('panchayath') ||
    combinedText.includes('public') ||
    combinedText.includes('hospital') ||
    combinedText.includes('auditorium') ||
    combinedText.includes('civic')
  ) {
    return {
      primaryMaterial: 'slate',
      secondaryMaterial: 'granite',
      matchScore: 95,
      categoryLabel: 'Institutional & Public Infrastructure',
      headline: 'Brushed Volcanic Slate',
      reasoning: 'For institutional facilities and government/public infrastructure, Brushed Slate delivers non-glare matte visual comfort, natural slip resistance, and low-maintenance longevity.',
      advantages: [
        'Natural micro-textured slip resistance rating (R11)',
        'Matte finish eliminating eye fatigue from glare',
        'Highly resilient against moisture and heavy public use'
      ],
      metrics: {
        durability: '9.6 / 10',
        aesthetics: '8.9 / 10',
        footTraffic: 'High Public Volume',
        thermalComfort: 'Stable Natural Stone'
      }
    };
  }

  // Fallback: General Contemporary Residential
  return {
    primaryMaterial: 'marble',
    secondaryMaterial: 'granite',
    matchScore: 92,
    categoryLabel: 'Contemporary Residential',
    headline: 'Italian Calacatta Marble',
    reasoning: 'Recommended for balanced residential aesthetics, superior light distribution, and elevated architectural appeal.',
    advantages: [
      'Enhances natural interior illumination',
      'Timeless appeal across modern architectural themes',
      'Highly valued standard for residential projects'
    ],
    metrics: {
      durability: '8.9 / 10',
      aesthetics: '9.5 / 10',
      footTraffic: 'Standard Residential',
      thermalComfort: 'Naturally Cool'
    }
  };
}

interface MaterialCustomizerProps {
  selected: MaterialType;
  onSelect: (material: MaterialType) => void;
  projectType?: string;
  projectTitle?: string;
  projectDescription?: string;
}

export default function MaterialCustomizer({ 
  selected, 
  onSelect,
  projectType = "Residential",
  projectTitle,
  projectDescription
}: MaterialCustomizerProps) {
  const [show3D, setShow3D] = useState(false);
  const [showAR, setShowAR] = useState(false);
  const [showSuggestionDetails, setShowSuggestionDetails] = useState(false);
  const [overrideTypology, setOverrideTypology] = useState<string | null>(null);
  const [justAutoSuggested, setJustAutoSuggested] = useState(false);

  // Active typology for heuristic calculations
  const effectiveTypology = overrideTypology || projectType;

  // Run the Heuristic Rule Engine
  const suggestion = useMemo(() => {
    return autoSuggestMaterial(
      effectiveTypology, 
      overrideTypology ? undefined : projectTitle, 
      overrideTypology ? undefined : projectDescription
    );
  }, [effectiveTypology, projectTitle, projectDescription, overrideTypology]);

  // Handle Auto-Suggest trigger
  const handleAutoSuggest = (targetMaterial?: MaterialType) => {
    const materialToApply = targetMaterial || suggestion.primaryMaterial;
    onSelect(materialToApply);
    setShowSuggestionDetails(true);
    setJustAutoSuggested(true);
    setTimeout(() => {
      setJustAutoSuggested(false);
    }, 2500);
  };

  return (
    <div className="bg-slate-50 p-6 rounded-xl border border-slate-200/80 space-y-4 shadow-sm" id="material-customizer-component">
      <ARVisualizer 
        materialId={selected} 
        isOpen={showAR} 
        onClose={() => setShowAR(false)} 
      />

      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200/60 pb-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-600">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-widest flex items-center gap-2">
              Finish & Material Customizer
            </h4>
            <p className="text-[10px] text-slate-500">
              Interactive architectural rendering & surface material simulation
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center flex-wrap gap-2">
          {/* AUTO-SUGGEST BUTTON */}
          <button 
            onClick={() => handleAutoSuggest()}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-bold text-[10px] uppercase tracking-wider transition-all shadow-sm ${
              justAutoSuggested || selected === suggestion.primaryMaterial
                ? 'bg-amber-500 border-amber-600 text-slate-950 shadow-amber-500/20'
                : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white border-amber-600 hover:shadow-md'
            }`}
            title="Auto-suggest materials based on project type heuristic"
            id="auto-suggest-material-btn"
          >
            <Wand2 className={`w-3.5 h-3.5 ${justAutoSuggested ? 'animate-bounce' : ''}`} />
            <span>Auto-Suggest</span>
            <span className="text-[8px] bg-black/20 text-white px-1.5 py-0.2 rounded font-mono">
              AI Heuristic
            </span>
          </button>

          <button 
            onClick={() => setShowAR(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border bg-white border-slate-200 text-slate-600 hover:border-amber-600 hover:text-amber-600 transition-all text-[10px] font-bold uppercase tracking-wider shadow-sm"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>AR Mode</span>
          </button>

          <button 
            onClick={() => setShow3D(!show3D)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[10px] font-bold uppercase tracking-wider transition-all shadow-sm ${
              show3D 
                ? 'bg-slate-900 border-slate-900 text-white' 
                : 'bg-white border-slate-200 text-slate-600 hover:border-slate-400'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>{show3D ? 'Hide 3D' : '3D Spatial'}</span>
          </button>
        </div>
      </div>

      {/* Typology Heuristic Preset Bar (Allows quick testing of Villa vs Commercial vs Sustainable vs Institutional) */}
      <div className="bg-white/80 border border-slate-200/70 p-2.5 rounded-lg flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-500 uppercase font-bold">
          <Building2 className="w-3.5 h-3.5 text-amber-600" />
          <span>Project Typology:</span>
        </div>

        <div className="flex flex-wrap items-center gap-1">
          {[
            { label: 'Luxury Villa', id: 'Luxury Villa', icon: HomeIcon },
            { label: 'Commercial Office', id: 'Commercial Office', icon: Building2 },
            { label: 'Sustainable Eco-Home', id: 'Sustainable Home', icon: TreePine },
            { label: 'Institutional / Civic', id: 'Institutional Facility', icon: GraduationCap }
          ].map((type) => {
            const isCurrent = effectiveTypology.toLowerCase().includes(type.id.toLowerCase().split(' ')[0]);
            return (
              <button
                key={type.id}
                onClick={() => {
                  setOverrideTypology(type.id);
                  const newSuggestion = autoSuggestMaterial(type.id);
                  onSelect(newSuggestion.primaryMaterial);
                  setShowSuggestionDetails(true);
                }}
                className={`px-2 py-1 rounded text-[9px] font-bold tracking-tight transition-all flex items-center gap-1 border ${
                  isCurrent 
                    ? 'bg-slate-900 text-white border-slate-900 shadow-sm' 
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
                id={`typology-preset-${type.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <type.icon className="w-2.5 h-2.5 text-amber-500" />
                <span>{type.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Auto-Suggest Recommendation Banner & Details Accordion */}
      <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/30 rounded-xl p-3.5 relative overflow-hidden">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-700 border border-amber-500/30 flex items-center justify-center shrink-0 mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-amber-700 bg-amber-500/20 px-2 py-0.5 rounded">
                  {suggestion.matchScore}% Match for {suggestion.categoryLabel}
                </span>
                {selected === suggestion.primaryMaterial && (
                  <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200 flex items-center gap-0.5">
                    <Check className="w-2.5 h-2.5" /> Applied
                  </span>
                )}
              </div>
              <h5 className="text-xs font-bold text-slate-900">
                Recommended: <span className="text-amber-700">{suggestion.headline}</span>
              </h5>
              <p className="text-[11px] text-slate-600 leading-relaxed mt-0.5 max-w-xl">
                {suggestion.reasoning}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {selected !== suggestion.primaryMaterial && (
              <button
                onClick={() => handleAutoSuggest(suggestion.primaryMaterial)}
                className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 text-[10px] font-bold uppercase tracking-wider rounded transition-all shadow-sm"
              >
                Apply Top Pick
              </button>
            )}
            <button
              onClick={() => setShowSuggestionDetails(!showSuggestionDetails)}
              className="p-1 text-slate-500 hover:text-slate-900 rounded hover:bg-white/60 transition-colors"
              title="Toggle Heuristic Rationale"
            >
              {showSuggestionDetails ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Expanded Heuristic Insights & Material Metrics */}
        <AnimatePresence>
          {showSuggestionDetails && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden pt-3 mt-3 border-t border-amber-500/20 space-y-3"
            >
              {/* Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="bg-white/90 p-2 rounded-lg border border-slate-200/80">
                  <div className="text-[8px] font-mono uppercase text-slate-400 font-bold flex items-center gap-1">
                    <ShieldCheck className="w-2.5 h-2.5 text-amber-600" /> Durability Index
                  </div>
                  <div className="text-xs font-extrabold text-slate-900 mt-0.5">
                    {suggestion.metrics.durability}
                  </div>
                </div>

                <div className="bg-white/90 p-2 rounded-lg border border-slate-200/80">
                  <div className="text-[8px] font-mono uppercase text-slate-400 font-bold flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5 text-amber-600" /> Aesthetic Rating
                  </div>
                  <div className="text-xs font-extrabold text-slate-900 mt-0.5">
                    {suggestion.metrics.aesthetics}
                  </div>
                </div>

                <div className="bg-white/90 p-2 rounded-lg border border-slate-200/80">
                  <div className="text-[8px] font-mono uppercase text-slate-400 font-bold flex items-center gap-1">
                    <Activity className="w-2.5 h-2.5 text-amber-600" /> Foot-Traffic Rating
                  </div>
                  <div className="text-xs font-extrabold text-slate-900 mt-0.5">
                    {suggestion.metrics.footTraffic}
                  </div>
                </div>

                <div className="bg-white/90 p-2 rounded-lg border border-slate-200/80">
                  <div className="text-[8px] font-mono uppercase text-slate-400 font-bold flex items-center gap-1">
                    <Flame className="w-2.5 h-2.5 text-amber-600" /> Thermal Comfort
                  </div>
                  <div className="text-xs font-extrabold text-slate-900 mt-0.5">
                    {suggestion.metrics.thermalComfort}
                  </div>
                </div>
              </div>

              {/* Heuristic Advantage Bullets */}
              <div className="bg-white/80 p-2.5 rounded-lg border border-slate-200/80">
                <div className="text-[9px] font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1">
                  <Check className="w-3 h-3 text-emerald-600" /> Key Material Suitability Factors:
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {suggestion.advantages.map((adv, i) => (
                    <div key={i} className="text-[10px] text-slate-600 flex items-start gap-1.5 leading-snug">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1 shrink-0" />
                      <span>{adv}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Alternative Choice Recommendation */}
              <div className="flex items-center justify-between bg-slate-900 text-white p-2.5 rounded-lg text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-mono uppercase text-amber-400 font-bold">Alternative Pick:</span>
                  <span className="font-bold">{materials.find(m => m.id === suggestion.secondaryMaterial)?.name}</span>
                  <span className="text-[10px] text-slate-400 hidden sm:inline">({materials.find(m => m.id === suggestion.secondaryMaterial)?.tagline})</span>
                </div>
                <button
                  onClick={() => onSelect(suggestion.secondaryMaterial)}
                  className={`px-2 py-1 rounded text-[9px] font-bold uppercase tracking-wider transition-colors ${
                    selected === suggestion.secondaryMaterial
                      ? 'bg-emerald-500 text-slate-950 font-black'
                      : 'bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-200'
                  }`}
                >
                  {selected === suggestion.secondaryMaterial ? 'Selected' : 'Apply Alternative'}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 3D Visualizer Drawer */}
      <AnimatePresence>
        {show3D && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden rounded-xl border border-slate-200"
          >
            <Room3DPreview materialId={selected} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* 5 Material Swatches Grid */}
      <div className="grid grid-cols-5 gap-2.5 pt-1">
        {materials.map((material) => {
          const isSelected = selected === material.id;
          const isTopPick = material.id === suggestion.primaryMaterial;
          const isAltPick = material.id === suggestion.secondaryMaterial;

          return (
            <button
              key={material.id}
              onClick={() => onSelect(material.id)}
              className={`relative flex flex-col items-center p-2.5 rounded-xl border transition-all duration-200 text-center group ${
                isSelected 
                  ? 'bg-white border-amber-600 shadow-md ring-1 ring-amber-600' 
                  : 'bg-white/60 border-slate-200 hover:border-slate-300 hover:bg-white'
              }`}
              id={`material-btn-${material.id}`}
            >
              {/* Top Pick / Alternative Badge */}
              {isTopPick && (
                <span className="absolute -top-2 left-1/2 -translate-x-1/2 px-1.5 py-0.2 bg-amber-500 text-slate-950 font-black text-[7px] uppercase tracking-tighter rounded-full shadow-sm">
                  ★ Top Pick
                </span>
              )}
              {!isTopPick && isAltPick && (
                <span className="absolute -top-2 left-1/2 -translate-x-1/2 px-1.5 py-0.2 bg-slate-800 text-slate-200 font-bold text-[7px] uppercase tracking-tighter rounded-full shadow-sm">
                  Alt Pick
                </span>
              )}

              {/* Swatch Circle */}
              <div className={`w-10 h-10 rounded-full border-2 transition-all p-0.5 mb-1.5 ${
                isSelected ? 'border-amber-600 scale-105 shadow-sm' : 'border-slate-200 group-hover:border-slate-300'
              }`}>
                <div className={`w-full h-full rounded-full ${material.color} border border-black/10 shadow-inner`} />
              </div>

              {/* Name */}
              <span className={`text-[10px] font-bold uppercase tracking-wider truncate w-full ${
                isSelected ? 'text-amber-600 font-extrabold' : 'text-slate-700'
              }`}>
                {material.name}
              </span>

              {/* Tagline */}
              <span className="text-[8px] text-slate-400 line-clamp-1 mt-0.5">
                {material.tagline}
              </span>

              {/* Selected Check Indicator */}
              {isSelected && (
                <motion.div 
                  layoutId="active-mat-dot"
                  className="absolute top-1.5 right-1.5 bg-amber-600 text-white p-0.5 rounded-full shadow-sm"
                >
                  <Check className="w-2.5 h-2.5" />
                </motion.div>
              )}
            </button>
          );
        })}
      </div>

      {/* Active Material Description Summary */}
      <div className="pt-2 border-t border-slate-200/60 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[10px]">
        <p className="text-slate-500">
          Selected Finish: <strong className="text-slate-800">{materials.find(m => m.id === selected)?.name}</strong> — {materials.find(m => m.id === selected)?.description}
        </p>
        <span className="text-slate-400 font-mono text-[9px] shrink-0">
          Best for: {materials.find(m => m.id === selected)?.bestFor}
        </span>
      </div>
    </div>
  );
}

export function getMaterialFilter(id: MaterialType): string {
  return materials.find(m => m.id === id)?.filter || 'none';
}
