import React, { useState, Suspense, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stage, useGLTF, Environment, ContactShadows } from '@react-three/drei';
import { Maximize2, Layers, Map as MapIcon, Home, Loader2, Box, View as ViewIcon, Smartphone, Glasses, X } from 'lucide-react';
import LazyImage from './LazyImage';

// Register model-viewer web component
import '@google/model-viewer';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'model-viewer': any;
    }
  }
}

interface ArchitecturalView {
  id: string;
  title: string;
  type: '3d' | 'blueprint' | 'elevation';
  url: string;
}

interface ArchitecturalViewerProps {
  views: ArchitecturalView[];
}

function Model({ url }: { url: string }) {
  const { scene } = useGLTF(url);
  return <primitive object={scene} />;
}

function CameraTracker({ syncRef }: { syncRef: React.MutableRefObject<any> }) {
  useFrame(({ camera }) => {
    syncRef.current = camera;
  });
  return null;
}

function CameraFollower({ syncRef }: { syncRef: React.MutableRefObject<any> }) {
  useFrame(({ camera }) => {
    const leftCamera = syncRef.current;
    if (leftCamera) {
      // Copy rotation exactly
      camera.quaternion.copy(leftCamera.quaternion);
      
      // Calculate right direction vector directly from left camera matrix
      const rx = leftCamera.matrix.elements[0];
      const ry = leftCamera.matrix.elements[1];
      const rz = leftCamera.matrix.elements[2];
      
      // Shift Right Eye camera position along local right vector by human IPD distance (~0.15)
      const ipd = 0.14; 
      camera.position.set(
        leftCamera.position.x + rx * ipd,
        leftCamera.position.y + ry * ipd,
        leftCamera.position.z + rz * ipd
      );
    }
  });
  return null;
}

export default function ArchitecturalViewer({ views }: ArchitecturalViewerProps) {
  const [activeView, setActiveView] = useState<ArchitecturalView>(views[0]);
  const [isRotating, setIsRotating] = useState(true);
  const [isARSupported, setIsARSupported] = useState(false);
  const [isVrMode, setIsVrMode] = useState(false);
  const cameraSyncRef = useRef<any>(null);

  useEffect(() => {
    // Basic check for AR support (iOS Quick Look or Android ARCore)
    const a = document.createElement('a');
    if (a.relList.supports('ar') || /android/i.test(navigator.userAgent)) {
      setIsARSupported(true);
    }
  }, []);

  const triggerAR = () => {
    if (activeView.type !== '3d') return;
    
    // Create a temporary model-viewer element to trigger AR
    const mv = document.createElement('model-viewer');
    mv.src = activeView.url;
    mv.setAttribute('ar', '');
    mv.setAttribute('ar-modes', 'webxr scene-viewer quick-look');
    mv.style.display = 'none';
    document.body.appendChild(mv);
    
    // Wait for it to be ready then trigger
    mv.addEventListener('load', () => {
       (mv as any).activateAR();
       setTimeout(() => document.body.removeChild(mv), 5000);
    });
  };

  if (!views || views.length === 0) return null;

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-sm overflow-hidden border border-white/10 shadow-2xl">
      {/* Header / Tabs */}
      <div className="flex items-center justify-between px-6 py-4 bg-slate-900/50 border-b border-white/5">
        <div className="flex items-center gap-3">
          <Layers className="w-4 h-4 text-amber-500" />
          <h3 className="text-sm font-bold uppercase tracking-[0.2em] text-white">Architectural Explorer</h3>
        </div>
        <div className="flex gap-2">
          {views.map((view) => (
            <button
              key={view.id}
              onClick={() => setActiveView(view)}
              className={`px-3 py-1.5 rounded-sm text-[10px] font-bold uppercase tracking-wider transition-all duration-300 ${
                activeView.id === view.id
                  ? 'bg-amber-600 text-white shadow-lg'
                  : 'bg-white/5 text-slate-400 hover:bg-white/10'
              }`}
            >
              {view.type === '3d' && <Box className="w-3 h-3 inline-block mr-1 opacity-70" />}
              {view.type === 'blueprint' && <MapIcon className="w-3 h-3 inline-block mr-1 opacity-70" />}
              {view.type === 'elevation' && <Home className="w-3 h-3 inline-block mr-1 opacity-70" />}
              {view.title}
            </button>
          ))}
        </div>
      </div>

      {/* Main Viewer Area */}
      <div className="relative flex-1 bg-slate-950 overflow-hidden min-h-[420px]">
        {/* Floating Controls in top-right corner of viewer */}
        {!isVrMode && (
          <div className="absolute top-6 right-6 z-20 flex items-center gap-2">
            <button
              onClick={() => setIsVrMode(true)}
              className="px-3.5 py-2 bg-slate-900/90 hover:bg-slate-800 text-white rounded-xs border border-white/10 shadow-xl transition-all transform hover:scale-105 active:scale-95 group backdrop-blur-md flex items-center gap-2"
              title="Activate Side-by-Side Stereoscopic Cardboard VR Mode"
            >
              <Glasses className="w-3.5 h-3.5 text-amber-500 group-hover:rotate-6 transition-transform" />
              <span className="text-[9px] font-bold uppercase tracking-widest whitespace-nowrap">VR Cardboard</span>
            </button>
          </div>
        )}

        {isVrMode && (
          <button
            onClick={() => setIsVrMode(false)}
            className="absolute top-6 right-6 z-50 flex items-center gap-2 px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-full shadow-2xl font-bold uppercase tracking-[0.1em] text-[10px] transition-all transform hover:scale-105 active:scale-95 border border-rose-500/20"
          >
            <X className="w-3.5 h-3.5" />
            <span>Exit VR View</span>
          </button>
        )}

        <AnimatePresence mode="wait">
          {isVrMode ? (
            <motion.div
              key="vr-split-viewer"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 grid grid-cols-2 gap-[1px] bg-slate-900 w-full h-full relative overflow-hidden"
            >
              {/* Central Split Line with calibration mark */}
              <div className="absolute inset-y-0 left-1/2 w-[1px] bg-white/15 z-40 pointer-events-none flex flex-col items-center justify-between py-12">
                <div className="w-3 h-3 border-t border-r border-white/30 rotate-45 transform -translate-x-1/2" />
                <div className="w-8 h-8 rounded-full border border-white/15 bg-slate-950 flex items-center justify-center text-[9px] text-white/40 font-bold tracking-widest pointer-events-auto shadow-xl">
                  VR
                </div>
                <div className="w-3 h-3 border-b border-l border-white/30 rotate-45 transform translate-x-1/2" />
              </div>

              {/* LEFT EYE */}
              <div className="relative overflow-hidden w-full h-full bg-slate-950 border-r border-white/5 select-none">
                {activeView.type === '3d' ? (
                  <Suspense fallback={
                    <div className="flex flex-col items-center justify-center h-full text-slate-500 gap-4">
                      <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
                      <p className="text-[10px] font-bold uppercase tracking-widest animate-pulse font-mono">Aligning L-Eye...</p>
                    </div>
                  }>
                    <Canvas shadows camera={{ position: [5, 5, 5], fov: 45 }}>
                      <color attach="background" args={['#020617']} />
                      <Stage environment="city" intensity={0.5}>
                        <Model url={activeView.url} />
                      </Stage>
                      <OrbitControls 
                        autoRotate={isRotating} 
                        autoRotateSpeed={0.5} 
                        enableDamping 
                        makeDefault 
                      />
                      <Environment preset="city" />
                      <ContactShadows opacity={0.4} scale={10} blur={2} far={4.5} />
                      <CameraTracker syncRef={cameraSyncRef} />
                    </Canvas>
                  </Suspense>
                ) : (
                  <div className="w-full h-full p-6 flex items-center justify-center relative translate-x-1.5 transition-transform">
                    <LazyImage 
                      src={activeView.url} 
                      alt={activeView.title}
                      className="w-full h-auto max-h-[85%] rounded-xs shadow-2xl border border-white/5 object-contain"
                      showSkeleton={true}
                    />
                  </div>
                )}
                {/* Visual Alignment Circle */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full border border-dashed border-white/10 pointer-events-none flex items-center justify-center">
                  <div className="w-1.5 h-1.5 bg-white/15 rounded-full" />
                </div>
                <div className="absolute top-4 left-4 text-[9px] font-bold text-white/30 uppercase tracking-widest bg-slate-900/80 px-2 py-0.5 rounded-sm select-none border border-white/5">
                  Left Eye
                </div>
              </div>

              {/* RIGHT EYE */}
              <div className="relative overflow-hidden w-full h-full bg-slate-950 select-none">
                {activeView.type === '3d' ? (
                  <Suspense fallback={
                    <div className="flex flex-col items-center justify-center h-full text-slate-500 gap-4">
                      <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
                      <p className="text-[10px] font-bold uppercase tracking-widest animate-pulse font-mono">Aligning R-Eye...</p>
                    </div>
                  }>
                    <Canvas shadows camera={{ position: [5, 5, 5], fov: 45 }}>
                      <color attach="background" args={['#020617']} />
                      <Stage environment="city" intensity={0.5}>
                        <Model url={activeView.url} />
                      </Stage>
                      <Environment preset="city" />
                      <ContactShadows opacity={0.4} scale={10} blur={2} far={4.5} />
                      <CameraFollower syncRef={cameraSyncRef} />
                    </Canvas>
                  </Suspense>
                ) : (
                  <div className="w-full h-full p-6 flex items-center justify-center relative -translate-x-1.5 transition-transform">
                    <LazyImage 
                      src={activeView.url} 
                      alt={activeView.title}
                      className="w-full h-auto max-h-[85%] rounded-xs shadow-2xl border border-white/5 object-contain"
                      showSkeleton={true}
                    />
                  </div>
                )}
                {/* Visual Alignment Circle */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full border border-dashed border-white/10 pointer-events-none flex items-center justify-center">
                  <div className="w-1.5 h-1.5 bg-white/15 rounded-full" />
                </div>
                <div className="absolute top-4 left-4 text-[9px] font-bold text-white/30 uppercase tracking-widest bg-slate-900/80 px-2 py-0.5 rounded-sm select-none border border-white/5">
                  Right Eye
                </div>
              </div>
            </motion.div>
          ) : activeView.type === '3d' ? (
            <motion.div
              key="3d-viewer"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 cursor-grab active:cursor-grabbing"
            >
              <Suspense fallback={
                <div className="flex flex-col items-center justify-center h-full text-slate-500 gap-4">
                  <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
                  <p className="text-[10px] font-bold uppercase tracking-widest animate-pulse">Initializing 3D Engine...</p>
                </div>
              }>
                <Canvas shadows camera={{ position: [5, 5, 5], fov: 45 }}>
                  <color attach="background" args={['#020617']} />
                  <Stage environment="city" intensity={0.5}>
                    <Model url={activeView.url} />
                  </Stage>
                  <OrbitControls 
                    autoRotate={isRotating} 
                    autoRotateSpeed={0.5} 
                    enableDamping 
                    makeDefault 
                  />
                  <Environment preset="city" />
                  <ContactShadows opacity={0.4} scale={10} blur={2} far={4.5} />
                </Canvas>
              </Suspense>

              {/* 3D Controls Overlay */}
              <div className="absolute bottom-6 left-6 flex items-center gap-4">
                <button 
                  onClick={() => setIsRotating(!isRotating)}
                  className={`p-2 rounded-full border transition-all ${
                    isRotating ? 'border-amber-600 bg-amber-600/20 text-amber-500' : 'border-white/20 text-white/50'
                  }`}
                >
                   <div className={`w-2 h-2 rounded-full bg-current ${isRotating ? 'animate-ping' : ''}`} />
                </button>
                <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest bg-black/40 px-3 py-1 rounded-full backdrop-blur-md border border-white/5">
                   Orbit Mode: Interactive
                </div>

                {isARSupported && (
                  <button 
                    onClick={triggerAR}
                    className="flex items-center gap-2 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-full shadow-lg transition-all transform hover:scale-105 active:scale-95 group"
                  >
                    <Smartphone className="w-3.5 h-3.5 group-hover:rotate-12 transition-transform" />
                    <span className="text-[10px] font-bold uppercase tracking-widest whitespace-nowrap">View in AR</span>
                  </button>
                )}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key={activeView.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="absolute inset-0 p-8 flex items-center justify-center"
            >
              <div className="relative group w-full h-full max-w-4xl">
                 <LazyImage 
                   src={activeView.url} 
                   alt={activeView.title}
                   className="w-full h-full rounded-sm shadow-2xl border border-white/5"
                   showSkeleton={true}
                 />
                 <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-8">
                    <div className="space-y-1">
                       <p className="text-amber-500 text-[10px] font-bold uppercase tracking-widest">{activeView.type}</p>
                       <h4 className="text-white font-display text-xl font-bold">{activeView.title}</h4>
                    </div>
                 </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* View Details Label */}
        <div className="absolute top-6 left-6 pointer-events-none">
           <div className="bg-black/60 backdrop-blur-xl border border-white/10 px-4 py-2 rounded-sm space-y-1">
              <h4 className="text-white text-xs font-bold uppercase tracking-widest leading-none">{activeView.title}</h4>
              <p className="text-[10px] text-slate-500 font-medium uppercase tracking-wider leading-none">Perspective Scale: 1:100</p>
           </div>
        </div>
      </div>
    </div>
  );
}
