import React from 'react';
import { motion } from 'motion/react';

interface ListeningWaveformProps {
  color?: string; // e.g. "bg-red-500" or "bg-amber-500"
  barCount?: number;
  height?: string; // e.g. "h-8"
}

export default function ListeningWaveform({ 
  color = "bg-amber-500", 
  barCount = 7,
  height = "h-8"
}: ListeningWaveformProps) {
  // Generate pseudo-random animations for each frequency bar to simulate realistic sound spectrum input
  const bars = Array.from({ length: barCount }, (_, i) => {
    // Varying speeds and heights to look organic
    const duration = 0.5 + (i * 0.13) % 0.6;
    const delay = (i * 0.08) % 0.4;
    
    return {
      duration,
      delay,
      heights: [0.2, 1.0, 0.4, 1.2, 0.3, 0.8, 0.2]
    };
  });

  return (
    <div className={`flex items-end gap-[3px] ${height} px-1.5 py-1 justify-center shrink-0`} id="audio-listening-waveform">
      {bars.map((bar, idx) => (
        <motion.div
          key={idx}
          className={`w-[3.5px] rounded-full ${color}`}
          initial={{ scaleY: 0.2 }}
          animate={{ 
            scaleY: bar.heights,
          }}
          transition={{
            duration: bar.duration,
            delay: bar.delay,
            repeat: Infinity,
            repeatType: "mirror",
            ease: "easeInOut"
          }}
          style={{ originY: 1 }}
        />
      ))}
    </div>
  );
}
