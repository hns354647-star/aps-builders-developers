import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Stage, PerspectiveCamera, Environment, Grid } from '@react-three/drei';
import * as THREE from 'three';
import { MaterialType } from './MaterialCustomizer';

interface Room3DPreviewProps {
  materialId: MaterialType;
}

const materialConfigs: Record<MaterialType, { color: string; roughness: number; metalness: number; map?: string }> = {
  original: { color: '#e2e8f0', roughness: 0.8, metalness: 0 },
  marble: { color: '#ffffff', roughness: 0.1, metalness: 0.1 },
  granite: { color: '#1e293b', roughness: 0.3, metalness: 0.2 },
  oak: { color: '#fef3c7', roughness: 0.7, metalness: 0 },
  slate: { color: '#475569', roughness: 0.9, metalness: 0 },
};

function Room({ materialId }: { materialId: MaterialType }) {
  const config = materialConfigs[materialId];
  
  return (
    <group>
      {/* Floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
        <planeGeometry args={[20, 20]} />
        <meshStandardMaterial 
          color={config.color} 
          roughness={config.roughness} 
          metalness={config.metalness}
        />
      </mesh>

      {/* Wall 1 (Back) */}
      <mesh position={[0, 4, -10]} receiveShadow>
        <planeGeometry args={[20, 8]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.9} />
      </mesh>

      {/* Wall 2 (Left) - This one takes the material color if chosen */}
      <mesh rotation={[0, Math.PI / 2, 0]} position={[-10, 4, 0]} receiveShadow>
        <planeGeometry args={[20, 8]} />
        <meshStandardMaterial 
          color={materialId === 'original' ? '#f1f5f9' : config.color} 
          roughness={config.roughness} 
          metalness={config.metalness}
        />
      </mesh>

      {/* Modern Accent Piece */}
      <mesh position={[2, 1, -4]} castShadow receiveShadow rotation={[0, Math.PI / 4, 0]}>
        <boxGeometry args={[2, 2, 2]} />
        <meshStandardMaterial color="#334155" roughness={0.5} />
      </mesh>
      
      <mesh position={[-2, 0.5, -6]} castShadow receiveShadow>
        <cylinderGeometry args={[0.5, 0.5, 1, 32]} />
        <meshStandardMaterial color="#94a3b8" roughness={0.3} metalness={0.8} />
      </mesh>
    </group>
  );
}

export default function Room3DPreview({ materialId }: Room3DPreviewProps) {
  return (
    <div className="w-full h-[300px] bg-slate-900 rounded-sm overflow-hidden relative border border-white/10 shadow-2xl">
      <div className="absolute top-3 left-3 z-10">
        <span className="text-[9px] font-bold text-white/50 uppercase tracking-[0.2em] bg-black/40 backdrop-blur-md px-2 py-1 rounded-full border border-white/5">
          3D Interactive Visualizer
        </span>
      </div>
      
      <Canvas shadows>
        <PerspectiveCamera makeDefault position={[5, 5, 8]} fov={50} />
        <Suspense fallback={null}>
          <Stage environment="city" intensity={0.6} shadows="contact">
             <Room materialId={materialId} />
          </Stage>
          <Environment preset="city" />
        </Suspense>
        <OrbitControls 
          enablePan={false} 
          enableZoom={true} 
          maxPolarAngle={Math.PI / 2.1} 
          minDistance={5}
          maxDistance={15}
        />
        <Grid 
          infiniteGrid 
          fadeDistance={30} 
          sectionSize={1} 
          sectionThickness={1} 
          sectionColor="#334155" 
          cellSize={0.5} 
          cellThickness={0.5} 
          cellColor="#1e293b" 
        />
      </Canvas>
    </div>
  );
}
