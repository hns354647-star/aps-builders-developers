import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export default function ReservationForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    dates: '',
    guests: '2 Guests',
    notes: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API request
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setFormData({ name: '', email: '', dates: '', guests: '2 Guests', notes: '' });
    }, 1800);
  };

  return (
    <div className="w-full max-w-xl mx-auto">
      <AnimatePresence mode="wait">
        {isSubmitted ? (
          <motion.div 
            key="success"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="w-full bg-[#161616] border border-[#333] p-12 text-center rounded-sm space-y-4"
          >
            <div className="text-[#e5d5b8] text-4xl font-serif">Thank You</div>
            <p className="text-gray-400 font-light text-sm tracking-wide">
              Your inquiry has been registered. An invitation and booking schedule have been sent to your inbox.
            </p>
            <button 
              onClick={() => setIsSubmitted(false)}
              className="mt-6 text-xs uppercase tracking-widest text-[#e5d5b8] underline underline-offset-4 hover:text-white transition-colors"
            >
              Submit another request
            </button>
          </motion.div>
        ) : (
          <motion.form 
            key="form"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            onSubmit={handleSubmit} 
            className="w-full bg-[#161616] border border-[#262626] p-8 md:p-12 space-y-8 rounded-sm shadow-2xl"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Full Name */}
              <div className="flex flex-col space-y-2">
                <label className="text-[10px] font-semibold tracking-widest uppercase text-gray-400">Full Name</label>
                <input 
                  type="text" 
                  name="name"
                  required
                  value={formData.name}
                  onChange={handleInputChange}
                  className="bg-transparent border-b border-[#333] py-2 text-sm text-white focus:outline-none focus:border-[#e5d5b8] transition-colors font-light"
                  placeholder="John Doe"
                />
              </div>

              {/* Email Address */}
              <div className="flex flex-col space-y-2">
                <label className="text-[10px] font-semibold tracking-widest uppercase text-gray-400">Email Address</label>
                <input 
                  type="email" 
                  name="email"
                  required
                  value={formData.email}
                  onChange={handleInputChange}
                  className="bg-transparent border-b border-[#333] py-2 text-sm text-white focus:outline-none focus:border-[#e5d5b8] transition-colors font-light"
                  placeholder="johndoe@example.com"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Desired Dates */}
              <div className="flex flex-col space-y-2">
                <label className="text-[10px] font-semibold tracking-widest uppercase text-gray-400">Desired Dates</label>
                <input 
                  type="text" 
                  name="dates"
                  required
                  value={formData.dates}
                  onChange={handleInputChange}
                  className="bg-transparent border-b border-[#333] py-2 text-sm text-white focus:outline-none focus:border-[#e5d5b8] transition-colors font-light"
                  placeholder="e.g., Oct 12 - Oct 19"
                />
              </div>

              {/* Number of Guests */}
              <div className="flex flex-col space-y-2">
                <label className="text-[10px] font-semibold tracking-widest uppercase text-gray-400">Party Size</label>
                <div className="relative">
                  <select 
                    name="guests"
                    value={formData.guests}
                    onChange={handleInputChange}
                    className="w-full bg-transparent border-b border-[#333] py-2 text-sm text-white focus:outline-none focus:border-[#e5d5b8] transition-colors font-light appearance-none cursor-pointer"
                  >
                    <option value="1 Guest" className="bg-[#161616]">1 Guest</option>
                    <option value="2 Guests" className="bg-[#161616]">2 Guests</option>
                    <option value="4 Guests" className="bg-[#161616]">4 Guests</option>
                    <option value="6+ Guests" className="bg-[#161616]">6+ Guests</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Special Notes */}
            <div className="flex flex-col space-y-2">
              <label className="text-[10px] font-semibold tracking-widest uppercase text-gray-400">Special Preferences / Requests</label>
              <textarea 
                name="notes"
                rows={3}
                value={formData.notes}
                onChange={handleInputChange}
                className="bg-transparent border-b border-[#333] py-2 text-sm text-white focus:outline-none focus:border-[#e5d5b8] transition-colors font-light resize-none"
                placeholder="Dietary preferences, wellness services, etc."
              />
            </div>

            {/* Submit Button */}
            <motion.button 
              type="submit" 
              disabled={isSubmitting}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full mt-4 border border-[#e5d5b8] bg-[#e5d5b8] py-4 text-xs font-semibold tracking-[0.2em] uppercase text-black transition-all duration-300 hover:bg-transparent hover:text-[#e5d5b8] disabled:opacity-50"
            >
              {isSubmitting ? 'Processing Inquiry...' : 'Request Invitation'}
            </motion.button>
          </motion.form>
        )}
      </AnimatePresence>
    </div>
  );
}
