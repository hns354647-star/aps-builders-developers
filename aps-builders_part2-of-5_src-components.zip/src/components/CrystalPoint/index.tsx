import React, { useEffect } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import Navigation from './Navigation';
import ReservationForm from './ReservationForm';

const fadeUp = {
  initial: { opacity: 0, y: 40 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-100px" },
  transition: { duration: 1, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }
};

const staggerContainer = {
  initial: { opacity: 0 },
  whileInView: { opacity: 1 },
  viewport: { once: true },
  transition: { staggerChildren: 0.2 }
};

export default function CrystalPoint() {
  const { scrollY } = useScroll();
  const heroY = useTransform(scrollY, [0, 1000], [0, 300]);
  const heroOpacity = useTransform(scrollY, [0, 500], [1, 0]);

  // Smooth scrolling effect
  useEffect(() => {
    document.documentElement.style.scrollBehavior = 'smooth';
    return () => {
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  return (
    <div className="relative w-full bg-[#111] font-sans text-white overflow-x-hidden selection:bg-[#e5d5b8] selection:text-black">
      <Navigation />
      
      {/* 1. HERO SECTION */}
      <section id="home" className="relative min-h-screen w-full flex flex-col items-center justify-center overflow-hidden">
        <motion.div 
          style={{ y: heroY, opacity: heroOpacity }}
          className="absolute inset-0 z-0"
        >
          <motion.img 
            animate={{ 
              scale: [1, 1.15],
              x: [0, -15],
              y: [0, -10]
            }}
            transition={{ 
              duration: 25, 
              ease: "linear", 
              repeat: Infinity, 
              repeatType: "reverse" 
            }}
            src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1920&q=80" 
            alt="Luxury coastal villa at sunset" 
            className="h-full w-full object-cover brightness-[0.75] scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-[#111]" />
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 1.5, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="relative z-10 text-center px-6"
        >
          <span className="text-[10px] font-bold tracking-[0.6em] uppercase text-[#e5d5b8] mb-6 block">The Private Collection</span>
          <h1 className="text-6xl md:text-8xl font-serif text-[#f3e8d5] tracking-tight mb-8">Crystal Point</h1>
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: "100px" }}
            transition={{ delay: 1.2, duration: 1 }}
            className="h-[1px] bg-[#e5d5b8] mx-auto mb-8"
          />
          <p className="text-xs md:text-sm font-light tracking-[0.2em] uppercase text-gray-400 max-w-lg mx-auto leading-relaxed">
            A sanctuary where architecture <br/> meets the edge of the world.
          </p>
        </motion.div>

        <div className="absolute bottom-16 left-1/2 -translate-x-1/2 z-10">
          <motion.a 
            href="#experience" 
            className="flex flex-col items-center space-y-4 cursor-pointer hover:opacity-70 transition-opacity"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2, duration: 1 }}
          >
            <span className="text-[8px] font-bold tracking-[0.4em] uppercase text-gray-500">
              Explore The Estate
            </span>
            <div className="h-24 w-[1px] bg-gradient-to-b from-[#e5d5b8] to-transparent" />
          </motion.a>
        </div>
      </section>

      {/* 2. EXPERIENCE SECTION */}
      <section id="experience" className="relative flex min-h-screen items-center justify-center px-8 py-32 md:px-16 container mx-auto">
        <div className="grid max-w-6xl grid-cols-1 md:grid-cols-2 gap-24 items-center">
          <motion.div {...fadeUp} className="space-y-10">
            <div className="space-y-4">
              <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-[#e5d5b8]">Sanctuary</span>
              <h2 className="text-4xl md:text-5xl font-serif text-[#f3e8d5] tracking-wide leading-tight">Redefining Coastal <br/> Luxury</h2>
            </div>
            <p className="text-gray-400 leading-relaxed font-light tracking-wide text-lg">
              Step into a sanctuary where modern design meets the raw, untamed beauty of the ocean. 
              Every detail is curated to provide an immersive escape from the ordinary, using local textures and global precision.
            </p>
            <motion.div 
              whileHover={{ x: 10 }}
              className="flex items-center gap-4 cursor-pointer group"
            >
              <div className="h-[1px] w-12 bg-[#e5d5b8] group-hover:w-20 transition-all duration-500" />
              <span className="text-[10px] font-bold tracking-[0.3em] uppercase text-[#e5d5b8]">View Architecture</span>
            </motion.div>
          </motion.div>
          
          <motion.div 
            {...fadeUp}
            transition={{ ...fadeUp.transition, delay: 0.3 }}
            className="relative"
          >
            <div className="absolute inset-0 border border-[#e5d5b8]/20 -m-8 pointer-events-none" />
            <img 
              src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=800&q=80" 
              alt="Villa interior" 
              className="w-full h-[600px] object-cover rounded-sm grayscale hover:grayscale-0 transition-all duration-1000 ease-in-out shadow-2xl"
            />
          </motion.div>
        </div>
      </section>

      {/* 3. WAVES SECTION */}
      <section id="waves" className="relative min-h-screen flex items-center bg-[#0a0a0a] px-8 py-32 md:px-16 overflow-hidden">
        <div className="max-w-7xl mx-auto w-full space-y-20">
          <motion.div {...fadeUp} className="text-center space-y-4">
            <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-[#e5d5b8]">Landscape</span>
            <h2 className="text-3xl md:text-5xl font-serif text-white tracking-widest uppercase">The Break</h2>
          </motion.div>
          
          <motion.div 
            variants={staggerContainer}
            initial="initial"
            whileInView="whileInView"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {[
              "https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=600&q=80",
              "https://images.unsplash.com/photo-1518182170546-076616fd4cb7?auto=format&fit=crop&w=600&q=80",
              "https://images.unsplash.com/photo-1526342122811-2a9c8512023d?auto=format&fit=crop&w=600&q=80"
            ].map((img, i) => (
              <motion.div 
                key={i} 
                variants={fadeUp}
                className="overflow-hidden group cursor-pointer aspect-[3/4]"
              >
                <img 
                  src={img} 
                  alt="Surf waves" 
                  className="w-full h-full object-cover transform scale-110 group-hover:scale-100 transition-transform duration-[2s] opacity-60 group-hover:opacity-100 ease-out"
                />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* 4. GUESTS SECTION (Spacer) */}
      <section id="guests" className="bg-[#111] h-32" />

      {/* 5. RESERVE SECTION */}
      <section id="reserve" className="relative flex flex-col items-center justify-center min-h-screen bg-[#111] px-6 py-32">
        <motion.div 
          {...fadeUp}
          className="w-full max-w-xl mx-auto text-center space-y-6 mb-16"
        >
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-[#e5d5b8]">Booking</span>
          <h2 className="text-4xl md:text-6xl font-serif text-[#f3e8d5] tracking-wide">Secure Your <br/> Journey</h2>
          <p className="text-sm text-gray-400 font-light tracking-wide max-w-md mx-auto leading-relaxed">
            Please submit your details below. Our reservation concierge will review availability and connect with you within 24 hours.
          </p>
        </motion.div>

        <ReservationForm />

        <footer className="mt-32 text-center space-y-8 pb-12 w-full">
          <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-[#e5d5b8]/20 to-transparent mb-12" />
          <p className="text-[10px] tracking-[0.4em] text-gray-600 uppercase font-bold">
            © {new Date().getFullYear()} Crystal Point. <br/>
            <span className="mt-2 block opacity-40">Architectural Heritage Collection</span>
          </p>
        </footer>
      </section>
    </div>
  );
}
