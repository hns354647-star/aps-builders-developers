import React from 'react';
import { motion } from 'motion/react';

export default function Navigation() {
  return (
    <motion.header 
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-8 py-6 md:px-16 bg-gradient-to-b from-black/70 to-transparent backdrop-blur-[2px]"
    >
      <a href="#home" className="text-xl font-serif tracking-wide text-[#f3e8d5] cursor-pointer hover:opacity-90 transition-opacity">
        Crystal Point
      </a>

      <nav className="hidden md:flex items-center space-x-10 text-xs font-semibold tracking-[0.2em] uppercase text-gray-300">
        {['Experience', 'Waves', 'Guests', 'Reserve'].map((item) => (
          <motion.a 
            key={item}
            href={`#${item.toLowerCase()}`} 
            className="hover:text-white transition-colors relative group"
            whileHover={{ y: -2 }}
          >
            {item}
            <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#e5d5b8] transition-all duration-300 group-hover:w-full" />
          </motion.a>
        ))}
      </nav>

      <motion.a 
        href="#reserve" 
        whileHover={{ scale: 1.05, backgroundColor: "#e5d5b8", color: "#000" }}
        whileTap={{ scale: 0.95 }}
        className="border border-[#e5d5b8] px-6 py-2 text-xs font-semibold tracking-[0.15em] uppercase text-[#e5d5b8] transition-all duration-300"
      >
        Inquire
      </motion.a>
    </motion.header>
  );
}
