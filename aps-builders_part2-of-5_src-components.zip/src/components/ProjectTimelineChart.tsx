import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface TimelineData {
  phase: string;
  completion: number;
}

const data: TimelineData[] = [
  { phase: 'Project Design', completion: 100 },
  { phase: 'Site Foundation', completion: 100 },
  { phase: 'Structural Work', completion: 90 },
  { phase: 'Interior Finish', completion: 45 },
  { phase: 'Final Handover', completion: 10 },
];

export default function ProjectTimelineChart() {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const width = 300;
    const height = 150;
    const margin = { top: 10, right: 30, bottom: 20, left: 80 };

    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const x = d3.scaleLinear()
      .domain([0, 100])
      .range([0, innerWidth]);

    const y = d3.scaleBand()
      .domain(data.map(d => d.phase))
      .range([0, innerHeight])
      .padding(0.3);

    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Axes
    g.append('g')
      .call(d3.axisLeft(y).tickSize(0))
      .selectAll('text')
      .style('font-size', '7px')
      .style('font-family', 'Inter, sans-serif')
      .style('font-weight', 'bold')
      .style('text-transform', 'uppercase')
      .style('letter-spacing', '0.05em')
      .attr('color', '#64748b');

    g.select('.domain').remove();

    // Bars Background
    g.selectAll('.bar-bg')
      .data(data)
      .enter()
      .append('rect')
      .attr('class', 'bar-bg')
      .attr('y', d => y(d.phase)!)
      .attr('x', 0)
      .attr('width', innerWidth)
      .attr('height', y.bandwidth())
      .attr('fill', '#f1f5f9')
      .attr('rx', 2);

    // Bars
    const bars = g.selectAll('.bar')
      .data(data)
      .enter()
      .append('rect')
      .attr('class', 'bar')
      .attr('y', d => y(d.phase)!)
      .attr('x', 0)
      .attr('height', y.bandwidth())
      .attr('fill', '#d97706') // amber-600
      .attr('rx', 2)
      .attr('width', 0); // Start with 0 for animation

    bars.transition()
      .duration(1000)
      .attr('width', d => x(d.completion));

    // Percentage Labels
    g.selectAll('.label')
      .data(data)
      .enter()
      .append('text')
      .attr('class', 'label')
      .attr('x', d => x(d.completion) + 5)
      .attr('y', d => y(d.phase)! + y.bandwidth() / 2 + 3)
      .text(d => `${d.completion}%`)
      .style('font-size', '7px')
      .style('font-weight', 'bold')
      .style('font-family', 'monospace')
      .attr('fill', '#d97706')
      .style('opacity', 0)
      .transition()
      .delay(800)
      .duration(500)
      .style('opacity', 1);

    // X-Axis (Bottom)
    g.append('g')
      .attr('transform', `translate(0, ${innerHeight})`)
      .call(d3.axisBottom(x).ticks(5).tickFormat(d => `${d}%`))
      .selectAll('text')
      .style('font-size', '6px')
      .style('font-family', 'monospace')
      .attr('color', '#94a3b8');
    
    g.selectAll('.tick line').attr('stroke', '#f1f5f9');
    g.select('.domain').attr('stroke', '#f1f5f9');

  }, []);

  return (
    <div className="flex flex-col items-center">
      <div className="w-full flex items-center justify-between mb-4">
         <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Phase Progression</span>
         <span className="text-[8px] font-bold text-amber-600 uppercase tracking-widest bg-amber-50 px-2 py-0.5 rounded-full">Real-time Data</span>
      </div>
      <svg 
        ref={svgRef} 
        viewBox="0 0 300 150" 
        className="w-full h-auto overflow-visible"
      />
    </div>
  );
}
