import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { QrCode, Share2, Download } from 'lucide-react';
import { motion } from 'motion/react';

interface ProjectQRCodeProps {
  url: string;
  projectName: string;
}

export default function ProjectQRCode({ url, projectName }: ProjectQRCodeProps) {
  const downloadQRCode = () => {
    const svg = document.getElementById('project-qr-code');
    if (!svg) return;
    
    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx?.drawImage(img, 0, 0);
      const pngFile = canvas.toDataURL('image/png');
      const downloadLink = document.createElement('a');
      downloadLink.download = `QR-${projectName.replace(/\s+/g, '-').toLowerCase()}.png`;
      downloadLink.href = pngFile;
      downloadLink.click();
    };
    
    img.src = 'data:image/svg+xml;base64,' + btoa(svgData);
  };

  return (
    <div className="bg-slate-50 p-6 rounded-sm border border-slate-100 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <QrCode className="w-4 h-4 text-amber-600" />
          <h4 className="text-[10px] font-bold text-slate-900 uppercase tracking-widest">Mobile Sharing</h4>
        </div>
        <button 
          onClick={downloadQRCode}
          className="text-slate-400 hover:text-amber-600 transition-colors"
          title="Download QR Code"
        >
          <Download className="w-3 h-3" />
        </button>
      </div>

      <div className="flex items-center gap-6">
        <div className="p-3 bg-white rounded-sm border border-slate-100 shadow-sm">
          <QRCodeSVG 
            id="project-qr-code"
            value={url} 
            size={100}
            level="H"
            includeMargin={false}
            imageSettings={{
              src: "/favicon.ico", // Ensure we have a logo or fallback
              x: undefined,
              y: undefined,
              height: 24,
              width: 24,
              excavate: true,
            }}
          />
        </div>
        
        <div className="space-y-2 flex-1">
          <p className="text-[10px] text-slate-500 leading-relaxed font-sans">
            Scan this code with your phone camera to view and share this project instantly on mobile.
          </p>
          <div className="flex items-center gap-2 text-amber-600">
            <Share2 className="w-3 h-3" />
            <span className="text-[8px] font-bold uppercase tracking-widest">Scan to share</span>
          </div>
        </div>
      </div>
    </div>
  );
}
