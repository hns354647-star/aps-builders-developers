const CACHE_NAME = 'aps-cache-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/src/main.tsx',
  '/src/index.css',
];

const IMAGE_CACHE_NAME = 'aps-image-cache-v1';

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME && cacheName !== IMAGE_CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// ==========================================
// Web Push Notifications & Milestone Alerts
// ==========================================

// Handle Incoming Web Push Events
self.addEventListener('push', (event) => {
  let data = {
    title: 'APS Milestone Alert',
    body: 'A project you are tracking has reached a new construction milestone.',
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    tag: 'aps-milestone-alert',
    data: {
      url: '/',
      projectId: '',
      milestone: 'New Phase Unlocked',
      timestamp: Date.now()
    },
    actions: [
      { action: 'view_project', title: '🏗️ View Milestone' },
      { action: 'dismiss', title: 'Dismiss' }
    ],
    vibrate: [200, 100, 200, 100, 200],
    renotify: true
  };

  if (event.data) {
    try {
      const parsed = event.data.json();
      data = { ...data, ...parsed };
    } catch (e) {
      data.body = event.data.text() || data.body;
    }
  }

  const notificationOptions = {
    body: data.body,
    icon: data.icon || '/favicon.ico',
    image: data.image,
    badge: data.badge || '/favicon.ico',
    tag: data.tag || `milestone-${data.data?.projectId || 'update'}`,
    data: data.data,
    actions: data.actions || [
      { action: 'view_project', title: '🏗️ View Milestone' },
      { action: 'dismiss', title: 'Dismiss' }
    ],
    vibrate: data.vibrate || [200, 100, 200],
    renotify: true,
    requireInteraction: false
  };

  event.waitUntil(
    self.registration.showNotification(data.title, notificationOptions)
  );
});

// Handle Notification Clicks (Navigates to project and focuses tab)
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const action = event.action;
  if (action === 'dismiss') {
    return;
  }

  const notifData = event.notification.data || {};
  const projectId = notifData.projectId || '';
  const milestone = notifData.milestone || '';
  const targetUrl = notifData.url || (projectId ? `/?project=${projectId}` : '/');

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // If a window client is already open, focus it and post a message to open the project modal
      for (const client of clientList) {
        if ('focus' in client) {
          client.postMessage({
            type: 'NOTIFICATION_OPEN_PROJECT',
            projectId: projectId,
            milestone: milestone,
            url: targetUrl
          });
          return client.focus();
        }
      }

      // If no tab is open, open a new window
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});

// Handle direct client-to-service-worker messages for milestone alerts
self.addEventListener('message', (event) => {
  if (!event.data) return;

  if (event.data.type === 'TRIGGER_MILESTONE_NOTIFICATION') {
    const { title, body, icon, image, projectId, milestone, date } = event.data;
    
    const options = {
      body: body || `Milestone achieved: "${milestone}"`,
      icon: icon || '/favicon.ico',
      image: image,
      tag: `milestone-${projectId || 'alert'}`,
      data: {
        url: `/?project=${projectId || ''}`,
        projectId: projectId,
        milestone: milestone,
        date: date,
        timestamp: Date.now()
      },
      actions: [
        { action: 'view_project', title: '🏗️ View Blueprint & Milestone' },
        { action: 'dismiss', title: 'Dismiss' }
      ],
      vibrate: [200, 100, 200],
      renotify: true
    };

    self.registration.showNotification(title || 'APS Construction Milestone Alert', options);
  }
});

self.addEventListener('fetch', (event) => {
  // Only intercept GET requests
  if (event.request.method !== 'GET') {
    return;
  }

  const url = new URL(event.request.url);

  // Skip API calls, internal control plane endpoints, Vite dev endpoints, and WebSockets
  if (
    url.pathname.startsWith('/api/') ||
    url.pathname.startsWith('/@') ||
    url.pathname.startsWith('/__') ||
    url.protocol.startsWith('ws')
  ) {
    return;
  }

  // Cache strategy for images (specifically project thumbnails from Unsplash or other external sources)
  if (event.request.destination === 'image' || url.hostname.includes('unsplash.com')) {
    event.respondWith(
      caches.open(IMAGE_CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          return (
            response ||
            fetch(event.request).then((networkResponse) => {
              if (networkResponse.status === 200) {
                cache.put(event.request, networkResponse.clone());
              }
              return networkResponse;
            }).catch(() => response)
          );
        });
      })
    );
    return;
  }

  // Stale-while-revalidate for static assets
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      const fetchPromise = fetch(event.request).then((networkResponse) => {
        if (networkResponse && networkResponse.status === 200) {
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, networkResponse.clone());
          });
        }
        return networkResponse;
      }).catch(() => cachedResponse);

      return cachedResponse || fetchPromise;
    })
  );
});
