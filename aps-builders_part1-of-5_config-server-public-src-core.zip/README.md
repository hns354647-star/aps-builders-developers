# Archidomo – Architecture Contemporaine & Chalets d'Exception

A bilingual (French / English) editorial web experience for luxury architecture studio **Archidomo** (Annecy, Courchevel, Megève, Cannes, Nice, Geneva).

---

## 1. Project Structure

```text
├── public/
│   ├── robots.txt
│   └── sitemap.xml
├── src/
│   ├── components/
│   │   ├── Header.tsx              # Scrolled blur header, desktop nav & full-screen mobile reveal
│   │   ├── Footer.tsx              # 3 Google Maps offices, direct lines, copyright & legal links
│   │   ├── HeroCarousel.tsx        # 8-slide hero with crossfade, 1920x940 crop & typography
│   │   ├── ProjectIndexSection.tsx # Typographic index with cursor-following image preview
│   │   ├── ImageLightbox.tsx       # High-res full-screen architectural viewer
│   │   └── CookieBanner.tsx        # GDPR privacy-first consent banner
│   ├── context/
│   │   └── LanguageContext.tsx     # Bilingual router & locale state synchronizer
│   ├── data/
│   │   └── mockSanityData.ts       # Full architectural dataset (projects, showroom, news, offices)
│   ├── i18n/
│   │   └── translations.ts         # Complete French & English editorial copy
│   ├── lib/
│   │   └── sanityClient.ts         # Sanity Image CDN URL builder (w, h, rect, q=80, fit=crop)
│   ├── pages/
│   │   ├── HomePage.tsx            # Sections 4.1 to 4.6 in strict order
│   │   ├── StudioPage.tsx          # /agence/: founders, philosophy & 4-step process
│   │   ├── ProjectsPage.tsx        # /realisations/: filterable grid by location & typology
│   │   ├── ProjectDetailPage.tsx   # /realisations/[slug]/: monograph, gallery & next project
│   │   ├── ImmersionPage.tsx       # /lieu/: Annecy showroom & private appointment booking
│   │   ├── NewsPage.tsx            # /actualites/: press awards & architectural essays
│   │   ├── NewsDetailPage.tsx      # /actualites/[slug]/: editorial reader
│   │   ├── ContactPage.tsx         # /contact/: inquiry form, spam protection & 3 offices
│   │   └── LegalPage.tsx           # /mentions-legales/ & /politique-de-confidentialite/
│   ├── sanity/
│   │   └── schemas/
│   │       ├── project.ts
│   │       ├── inspirationCategory.ts
│   │       ├── newsPost.ts
│   │       ├── siteSettings.ts
│   │       ├── homepage.ts
│   │       └── index.ts
│   ├── App.tsx                     # Master layout & path matcher
│   ├── index.css                   # Tailwind CSS theme & editorial typography rules
│   └── main.tsx
├── index.html                      # SEO meta tags, hreflang, OpenGraph & JSON-LD schema
└── package.json
```

---

## 2. Setup & Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Compile and verify types
npm run build
```

---

## 3. Sanity CMS Studio Integration

To deploy Sanity Studio alongside the app:

```bash
npm install next-sanity @sanity/image-url sanity
npx sanity init --dataset production
```

The schemas in `src/sanity/schemas/` are ready to plug into `sanity.config.ts`.
Images use the Sanity CDN with URL parameters:
- `w`: width
- `h`: height
- `rect`: crop rectangle
- `q=80`: quality 80
- `fit=crop`: edge crop
- `auto=format`: WebP / AVIF auto negotiation

---

## 4. Vercel Deployment

1. Push your repository to GitHub.
2. Import the project into [Vercel](https://vercel.com).
3. Configure environment variables in `.env`:
   - `NEXT_PUBLIC_SANITY_PROJECT_ID=archidomo_prod`
   - `NEXT_PUBLIC_SANITY_DATASET=production`
4. Deploy with standard preset.
