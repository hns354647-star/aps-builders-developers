import express from "express";
import path from "path";
import fs from "fs";
import type { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();

// Dev server must listen on port 3000 (port 8080 is reserved for Nginx reverse proxy)
const getPort = (): number => {
  const portArgIndex = process.argv.indexOf("--port");
  if (portArgIndex !== -1 && process.argv[portArgIndex + 1]) {
    const parsed = parseInt(process.argv[portArgIndex + 1], 10);
    if (!isNaN(parsed) && parsed !== 8080) return parsed;
  }
  const envPort = process.env.PORT ? parseInt(process.env.PORT, 10) : null;
  if (envPort && envPort !== 8080 && !isNaN(envPort)) {
    return envPort;
  }
  return 3000;
};

const PORT = getPort();

app.use(express.json());

// Health check endpoint for deployment and container probes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

// Lazy Gemini Client Initialization to prevent crashing on boot when apiKey is missing
let _aiInstance: GoogleGenAI | null = null;
async function getAI(): Promise<GoogleGenAI> {
  if (!_aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined. Please set it in Settings > Secrets.");
    }
    const { GoogleGenAI } = await import("@google/genai");
    _aiInstance = new GoogleGenAI({ 
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return _aiInstance;
}

// Company knowledge base to inject into system instruction
const COMPANY_CONTEXT = `
You are the "APS Concierge" - a highly specialized Virtual Architect and Customer Support Assistant for APS BUILDERS & DEVELOPERS (APS Architecture Pvt Ltd).
Your style is professional, efficient, and proactive, reflecting the premium standards of APS. 

CORE OBJECTIVES:
1. Act as the first point of contact for new clients (Concierge).
2. Assist with project status inquiries for existing clients.
3. Provide technical information about Vastu, materials, and construction phases.
4. Guide users through the website sections using [NAVIGATE:section] tags.

TONE & STYLE:
- Use formal but welcoming language.
- Provide structured answers (bullet points where appropriate).
- Be concise. Avoid fluff.
- If a user reaches a point where human expertise is needed (e.g., specific structural calculations, custom pricing, or scheduling a visit), politely suggest using the "Consult with Architect" option or contact +91 85904 00500.

KEY INFORMATION:
- Company: APS Architecture Pvt Ltd / APS BUILDERS & DEVELOPERS.
- Headquarters: Nedumudy, Alappuzha, Kerala - 688503.
- Contact: +91 85904 00500 | design@apsarch.com.
- Specializations: Tropical Modernism, Sustainable Construction, Vastu-compliant designs.
- Regions: Primarily active across Kerala (Kochi, Alappuzha, Kottayam, etc.).

NAVIGATION & ACTIONS:
Available sections for [NAVIGATE:section]:
- 'projects': Portfolio and site maps.
- 'services': List of what we offer.
- 'contact': General contact and lead architect inquiry.
- 'about': Company history and team.
- 'vastu': Vastu consultancy details.
- 'estimator': Construction cost calculator.

INTENT HANDLING FOR QUICK REPLIES:
- If a user clicks "Check Portfolio": Explain our legacy and [NAVIGATE:projects].
- If a user clicks "Get a Quote": Guide them to the [NAVIGATE:estimator].
- If a user clicks "Speak to Architect": Guide them to the Contact section [NAVIGATE:contact] or provide the phone number.
- If a user clicks "Vastu Consultation": Explain our expertise and [NAVIGATE:vastu].

Always start by introducing yourself if it's the first message: "Welcome to APS Architecture. I am your Virtual Concierge. How can I assist with your architectural vision today?"
`;

// API routes
app.post("/api/push/milestone", (req, res) => {
  const { projectId, projectTitle, milestone, image, date } = req.body;
  if (!milestone) {
    return res.status(400).json({ error: "Milestone details required" });
  }
  res.json({
    status: "dispatched",
    timestamp: Date.now(),
    payload: {
      projectId: projectId || "general",
      projectTitle: projectTitle || "APS Construction",
      milestone,
      image,
      date: date || new Date().toISOString()
    }
  });
});

app.post("/api/chat", async (req, res) => {
  const { messages } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Invalid messages format" });
  }

  try {
    const ai = await getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: messages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      })),
      config: {
        systemInstruction: COMPANY_CONTEXT,
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    if (error.status === 429 || error.message?.includes('quota')) {
      console.warn("Chat Quota Exceeded, falling back to static help message.");
      return res.json({ text: "I'm currently handling many requests. Please feel free to explore our projects or contact our team directly at +91 85904 00500 for immediate assistance." });
    }
    console.error("Gemini API Error (Chat):", error);
    res.status(500).json({ error: "Failed to generate response", details: error.message });
  }
});

// Added streaming endpoint for better UX
app.get("/api/chat-stream", async (req, res) => {
  const { q } = req.query;
  if (!q) return res.status(400).send("Query required");

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  try {
    const ai = await getAI();
    const result = await ai.models.generateContentStream({
      model: "gemini-3.5-flash",
      contents: [{ role: 'user', parts: [{ text: String(q) }] }],
      config: { systemInstruction: COMPANY_CONTEXT }
    });

    for await (const chunk of result) {
      if (chunk.text) {
        res.write(`data: ${JSON.stringify({ text: chunk.text })}\n\n`);
      }
    }
    res.write('event: end\ndata: {}\n\n');
    res.end();
  } catch (error: any) {
    console.error("Stream Error:", error);
    res.write(`data: ${JSON.stringify({ error: "Stream interrupted" })}\n\n`);
    res.end();
  }
});

app.post("/api/generate-design", async (req, res) => {
  const { prompt, category, style, direction, selectedMaterial, selectedLighting } = req.body;

  if (!prompt && !category) {
    return res.status(400).json({ error: "Prompt or category is required" });
  }

  try {
    const architecturalKeywords = "professional architectural photography, 8k resolution, cinematic lighting, sharp focus, high-end luxury materials, award-winning design, hyper-realistic textures, photorealistic architectural visualization";
    
    // Constructing a more fluid prompt
    const fullPrompt = `High-end architectural photography of: ${prompt}. ${category ? `Category: ${category}.` : ''} ${style ? `Style: ${style}.` : ''} ${architecturalKeywords}`;

    const ai = await getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-image',
      contents: {
        parts: [{ text: fullPrompt }]
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9",
          imageSize: "1K"
        },
      },
    });

    let imageData = null;
    let explanation = "";

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        imageData = `data:image/png;base64,${part.inlineData.data}`;
      } else if (part.text) {
        explanation += part.text;
      }
    }

    if (!imageData) {
       // if image generation fails or isn't supported, we fallback or error
       return res.status(500).json({ error: "No image generated by the model." });
    }

    res.json({ imageUrl: imageData, explanation });
  } catch (error: any) {
    console.error("Gemini API Error (Image Gen):", error);
    if (error.status === 429 || error.message?.toLowerCase().includes('quota') || error.message?.toLowerCase().includes('limit')) {
      console.warn("Design Generation Quota/Limit Exceeded. Returning fallback instruction.");
      return res.status(200).json({ 
        isFallback: true,
        error: "Quota Exceeded", 
        details: "Our high-fidelity neural engine is currently receiving too many requests. We've loaded a premium Vastu-verified template instead. Please try again in a few minutes." 
      });
    }
    res.status(500).json({ error: "Image generation failed", details: error.message });
  }
});

// Vite middleware and static serving
async function setupServer() {
  const distPath = path.join(process.cwd(), "dist");
  const isProduction = process.env.NODE_ENV === "production" || process.env.npm_lifecycle_event === "start";

  console.log(`[BOOT] Server launching in ${isProduction ? "PRODUCTION" : "DEVELOPMENT"} mode on port ${PORT}`);

  if (!isProduction) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: "0.0.0.0",
        port: Number(PORT),
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log(`[BOOT] Serving static assets from: ${distPath}`);
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get("*", (req, res) => {
        res.sendFile(path.join(distPath, "index.html"));
      });
    } else {
      console.warn(`[BOOT] dist directory not found at ${distPath}`);
    }
  }

  const server = app.listen(Number(PORT), "0.0.0.0", () => {
    console.log(`[BOOT] Server successfully listening on http://0.0.0.0:${PORT}`);
  });

  server.on("error", (err: any) => {
    console.error(`[BOOT] Server encountered error on port ${PORT}:`, err);
    if (err.code === "EADDRINUSE") {
      console.error(`[BOOT] Port ${PORT} is already in use. Please check running processes.`);
    }
    process.exit(1);
  });
}

setupServer().catch((err) => {
  console.error("Failed to start the Express server:", err);
  process.exit(1);
});
