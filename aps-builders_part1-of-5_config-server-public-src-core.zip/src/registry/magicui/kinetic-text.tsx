import React from "react";
import { motion } from "motion/react";

interface KineticTextProps {
  text: string;
  className?: string;
}

export function KineticText({ text, className = "" }: KineticTextProps) {
  // Split into words, then characters
  const words = text.split(" ");

  // Master staggering container
  const containerVariants = {
    initial: {},
    animate: {
      transition: {
        staggerChildren: 0.04,
        delayChildren: 0.2,
      },
    },
  };

  // Entrance spring animation for individual characters
  const letterVariants: any = {
    initial: { 
      y: 40, 
      opacity: 0,
      scaleY: 0.3,
      skewX: -15,
      rotateX: -30,
    },
    animate: { 
      y: 0, 
      opacity: 1,
      scaleY: 1,
      skewX: 0,
      rotateX: 0,
      transition: {
        type: "spring",
        stiffness: 140,
        damping: 14,
      },
    },
  };

  return (
    <motion.div
      className={`inline-flex flex-wrap items-center justify-center font-display font-bold ${className}`}
      variants={containerVariants}
      initial="initial"
      animate="animate"
      style={{ perspective: 1000 }}
    >
      {words.map((word, wordIdx) => (
        <span key={wordIdx} className="inline-flex whitespace-nowrap mr-[0.3em] pb-2">
          {word.split("").map((char, charIdx) => (
            <motion.span
              key={charIdx}
              variants={letterVariants}
              className="inline-block origin-bottom cursor-pointer select-none transition-colors duration-150"
              whileHover={{
                y: -18,
                scale: 1.25,
                skewX: 5,
                rotate: [0, -8, 8, 0],
                color: "#d97706", // Tailwind Amber-600
                textShadow: "0 10px 20px rgba(217, 119, 6, 0.35)",
                transition: {
                  type: "spring",
                  stiffness: 350,
                  damping: 8,
                  rotate: {
                    type: "keyframes",
                    ease: "easeInOut",
                    duration: 0.5,
                  },
                },
              }}
              animate={{
                y: [0, -3, 0],
              }}
              transition={{
                y: {
                  repeat: Infinity,
                  repeatType: "reverse",
                  duration: 2 + (charIdx * 0.15) % 1.5,
                  ease: "easeInOut",
                  delay: charIdx * 0.08,
                }
              }}
            >
              {char}
            </motion.span>
          ))}
        </span>
      ))}
    </motion.div>
  );
}
