import React from 'react';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CookieBanner } from './components/CookieBanner';
import { HomePage } from './pages/HomePage';
import { StudioPage } from './pages/StudioPage';
import { ProjectsPage } from './pages/ProjectsPage';
import { ProjectDetailPage } from './pages/ProjectDetailPage';
import { ImmersionPage } from './pages/ImmersionPage';
import { NewsPage } from './pages/NewsPage';
import { NewsDetailPage } from './pages/NewsDetailPage';
import { ContactPage } from './pages/ContactPage';
import { LegalPage } from './pages/LegalPage';

const AppContent: React.FC = () => {
  const { currentPath } = useLanguage();

  // Normalize path by stripping /en if present and trailing slash
  let cleanPath = currentPath;
  if (cleanPath.startsWith('/en/')) {
    cleanPath = cleanPath.slice(3); // becomes /something
  } else if (cleanPath === '/en') {
    cleanPath = '/';
  }

  // Remove trailing slash for matching unless it's just '/'
  if (cleanPath.length > 1 && cleanPath.endsWith('/')) {
    cleanPath = cleanPath.slice(0, -1);
  }

  // Route matching logic
  const renderRoute = () => {
    // 1. Home
    if (cleanPath === '' || cleanPath === '/') {
      return <HomePage />;
    }

    // 2. Studio / Agence
    if (cleanPath === '/agence') {
      return <StudioPage />;
    }

    // 3. Project Detail: /realisations/:slug
    if (cleanPath.startsWith('/realisations/')) {
      const slug = cleanPath.replace('/realisations/', '');
      return <ProjectDetailPage slug={slug} />;
    }

    // 4. Projects Portfolio: /realisations
    if (cleanPath === '/realisations') {
      return <ProjectsPage />;
    }

    // 5. Immersion / Showroom: /lieu
    if (cleanPath === '/lieu') {
      return <ImmersionPage />;
    }

    // 6. News Detail: /actualites/:slug
    if (cleanPath.startsWith('/actualites/')) {
      const slug = cleanPath.replace('/actualites/', '');
      return <NewsDetailPage slug={slug} />;
    }

    // 7. News List: /actualites
    if (cleanPath === '/actualites') {
      return <NewsPage />;
    }

    // 8. Contact: /contact
    if (cleanPath === '/contact') {
      return <ContactPage />;
    }

    // 9. Mentions Légales: /mentions-legales
    if (cleanPath === '/mentions-legales') {
      return <LegalPage type="mentions" />;
    }

    // 10. Politique de Confidentialité: /politique-de-confidentialite
    if (cleanPath === '/politique-de-confidentialite') {
      return <LegalPage type="privacy" />;
    }

    // Default Fallback: Home
    return <HomePage />;
  };

  return (
    <div className="min-h-screen flex flex-col justify-between selection:bg-[#111111] selection:text-[#F5F3EF]">
      <Header />
      <main className="flex-1">
        {renderRoute()}
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}
