import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { NEWS_POSTS, NewsPost } from '../data/mockSanityData';
import { buildSanityImageUrl } from '../lib/sanityClient';
import { ArrowLeft } from 'lucide-react';

interface NewsDetailPageProps {
  slug: string;
}

export const NewsDetailPage: React.FC<NewsDetailPageProps> = ({ slug }) => {
  const { locale, navigateTo, t } = useLanguage();
  const prefix = locale === 'en' ? '/en' : '';

  const post: NewsPost = NEWS_POSTS.find((p) => p.slug === slug) || NEWS_POSTS[0];

  return (
    <div className="bg-[#F5F3EF] text-[#111111] pt-32 pb-36">
      <div className="max-w-4xl mx-auto px-6 sm:px-8">
        {/* Back Link */}
        <button
          onClick={() => navigateTo(`${prefix}/actualites/`)}
          className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-stone-500 hover:text-black transition-colors mb-8 group focus:outline-none"
        >
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform" />
          <span>{t.newsPage.backToNews}</span>
        </button>

        {/* Article Header */}
        <div className="space-y-4 pb-12 border-b border-[#111111]/10">
          <div className="flex items-center gap-3 text-xs uppercase tracking-widest text-stone-500 font-mono">
            <span>{post.date}</span>
            <span>·</span>
            <span>{post.category[locale]}</span>
            <span>·</span>
            <span>{post.readTime}</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-5xl font-light text-[#111111] leading-tight">
            {post.title[locale]}
          </h1>

          <p className="font-serif text-xl sm:text-2xl text-stone-700 italic font-light pt-2">
            « {post.excerpt[locale]} »
          </p>
        </div>

        {/* Cover Image */}
        <div className="my-12 aspect-[16/9] overflow-hidden bg-stone-300 shadow-lg">
          <img
            src={buildSanityImageUrl(post.coverImage, {
              width: 1400,
              quality: 85,
              auto: 'format',
            })}
            alt={post.title[locale]}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Body Paragraphs */}
        <div className="space-y-6 text-base sm:text-lg text-stone-800 font-sans font-light leading-relaxed">
          {post.body[locale].map((p, idx) => (
            <p key={idx}>{p}</p>
          ))}
        </div>

        {/* Author Signoff */}
        <div className="mt-16 pt-8 border-t border-[#111111]/10 flex items-center justify-between text-xs text-stone-500">
          <span>Archidomo · Rédaction d'architecture</span>
          <span>Annecy · Courchevel · Cannes</span>
        </div>
      </div>
    </div>
  );
};

export default NewsDetailPage;
