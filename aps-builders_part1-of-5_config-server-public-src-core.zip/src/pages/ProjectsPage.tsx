import React, { useState, useMemo } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { PROJECTS_INDEX, FEATURED_PROJECT, SanityProject } from '../data/mockSanityData';
import { buildSanityImageUrl } from '../lib/sanityClient';
import { ArrowUpRight, Filter } from 'lucide-react';

export const ProjectsPage: React.FC = () => {
  const { locale, navigateTo, t } = useLanguage();
  const prefix = locale === 'en' ? '/en' : '';

  // Combine Featured project + all projects in index
  const allProjects: SanityProject[] = useMemo(() => {
    return [FEATURED_PROJECT, ...PROJECTS_INDEX];
  }, []);

  const [selectedType, setSelectedType] = useState<'all' | 'villa' | 'chalet'>('all');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');

  const filteredProjects = useMemo(() => {
    return allProjects.filter((project) => {
      const matchType = selectedType === 'all' || project.type === selectedType;
      const matchRegion = selectedRegion === 'all' || project.region === selectedRegion;
      return matchType && matchRegion;
    });
  }, [allProjects, selectedType, selectedRegion]);

  const regionOptions = [
    { value: 'all', label: t.portfolioPage.allRegions },
    { value: 'annecy', label: t.portfolioPage.regionAnnecy },
    { value: 'alpes', label: t.portfolioPage.regionAlpes },
    { value: 'geneve', label: t.portfolioPage.regionGeneve },
    { value: 'riviera', label: t.portfolioPage.regionRiviera },
    { value: 'provence', label: t.portfolioPage.regionProvence },
  ];

  return (
    <div className="bg-[#F5F3EF] text-[#111111] pt-32 pb-36">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12">
        {/* Page Header */}
        <div className="pb-16 border-b border-[#111111]/10 space-y-4">
          <span className="text-xs uppercase tracking-[0.25em] text-[#8E8880] block font-sans">
            Portfolio architectural
          </span>
          <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl font-light text-[#111111] tracking-tight">
            {t.portfolioPage.title}
          </h1>
          <p className="text-stone-600 text-sm sm:text-base font-sans font-light max-w-xl">
            {t.portfolioPage.subtitle}
          </p>
        </div>

        {/* Filter Controls (Type tabs & Region select) */}
        <div className="py-8 border-b border-[#111111]/10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          {/* Type Filter Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedType('all')}
              className={`px-4 py-2 text-xs uppercase tracking-[0.16em] transition-colors ${
                selectedType === 'all'
                  ? 'bg-[#111111] text-[#F5F3EF] font-semibold'
                  : 'bg-stone-200/70 text-stone-700 hover:bg-stone-300'
              }`}
            >
              {t.portfolioPage.allTypes}
            </button>
            <button
              onClick={() => setSelectedType('villa')}
              className={`px-4 py-2 text-xs uppercase tracking-[0.16em] transition-colors ${
                selectedType === 'villa'
                  ? 'bg-[#111111] text-[#F5F3EF] font-semibold'
                  : 'bg-stone-200/70 text-stone-700 hover:bg-stone-300'
              }`}
            >
              {t.portfolioPage.villasOnly}
            </button>
            <button
              onClick={() => setSelectedType('chalet')}
              className={`px-4 py-2 text-xs uppercase tracking-[0.16em] transition-colors ${
                selectedType === 'chalet'
                  ? 'bg-[#111111] text-[#F5F3EF] font-semibold'
                  : 'bg-stone-200/70 text-stone-700 hover:bg-stone-300'
              }`}
            >
              {t.portfolioPage.chaletsOnly}
            </button>
          </div>

          {/* Region Filter */}
          <div className="flex items-center gap-3">
            <Filter className="w-4 h-4 text-stone-400" />
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="bg-transparent border-b border-[#111111]/30 py-1.5 text-xs uppercase tracking-[0.14em] text-[#111111] focus:outline-none cursor-pointer"
            >
              {regionOptions.map((opt) => (
                <option key={opt.value} value={opt.value} className="bg-[#FAF8F5] text-black">
                  {opt.label}
                </option>
              ))}
            </select>

            <span className="text-xs text-stone-400 font-mono pl-4">
              {filteredProjects.length} {t.portfolioPage.projectCount}
            </span>
          </div>
        </div>

        {/* Filtered Grid */}
        {filteredProjects.length === 0 ? (
          <div className="py-24 text-center space-y-4">
            <p className="font-serif text-2xl text-stone-500">
              {t.portfolioPage.emptyState}
            </p>
            <button
              onClick={() => {
                setSelectedType('all');
                setSelectedRegion('all');
              }}
              className="text-xs uppercase tracking-widest text-stone-800 underline underline-offset-4"
            >
              {t.portfolioPage.resetFilters}
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16 pt-16">
            {filteredProjects.map((project) => (
              <div
                key={project._id}
                onClick={() => navigateTo(`${prefix}/realisations/${project.slug}/`)}
                className="group cursor-pointer space-y-4 flex flex-col justify-between"
              >
                {/* Image Container with Editorial Zoom */}
                <div className="aspect-[4/3] w-full overflow-hidden bg-stone-300 shadow-sm relative">
                  <img
                    src={buildSanityImageUrl(project.heroImage.url, {
                      width: 900,
                      height: 675,
                      quality: 80,
                      fit: 'crop',
                      auto: 'format',
                    })}
                    alt={project.heroImage.alt}
                    className="w-full h-full object-cover img-editorial-zoom"
                    loading="lazy"
                  />
                  <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/40 backdrop-blur-xs text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>

                {/* Card Metadata */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center justify-between text-xs text-stone-500 font-mono">
                    <span>[ {project.area} m² ]</span>
                    <span>[ {project.year} ]</span>
                  </div>

                  <h3 className="font-serif text-2xl font-light text-[#111111] group-hover:underline underline-offset-4 decoration-1">
                    {project.title}
                  </h3>

                  <p className="text-xs uppercase tracking-wider text-stone-600 font-sans">
                    {project.location}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectsPage;
