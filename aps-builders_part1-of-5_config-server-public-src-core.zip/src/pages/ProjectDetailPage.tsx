import React, { useMemo, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { PROJECTS_INDEX, FEATURED_PROJECT, SanityProject } from '../data/mockSanityData';
import { buildSanityImageUrl } from '../lib/sanityClient';
import { ImageLightbox, LightboxImage } from '../components/ImageLightbox';
import { ArrowLeft, ArrowRight, ArrowUpRight, Maximize2 } from 'lucide-react';

interface ProjectDetailPageProps {
  slug: string;
}

export const ProjectDetailPage: React.FC<ProjectDetailPageProps> = ({ slug }) => {
  const { locale, navigateTo, t } = useLanguage();
  const prefix = locale === 'en' ? '/en' : '';

  const allProjects = useMemo(() => [FEATURED_PROJECT, ...PROJECTS_INDEX], []);

  const currentIndex = allProjects.findIndex((p) => p.slug === slug);
  const project: SanityProject = allProjects[currentIndex >= 0 ? currentIndex : 0];

  const nextProject = allProjects[(currentIndex + 1) % allProjects.length];

  // Lightbox state
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  const galleryImages: LightboxImage[] = useMemo(() => {
    const list: LightboxImage[] = [
      {
        url: project.heroImage.url,
        alt: project.heroImage.alt,
        caption: project.heroImage.caption || project.title,
        category: project.title,
      },
    ];
    project.gallery.forEach((g) => {
      list.push({
        url: g.url,
        alt: g.alt,
        caption: g.caption[locale],
        category: project.title,
      });
    });
    return list;
  }, [project, locale]);

  const openLightboxAt = (idx: number) => {
    setLightboxIndex(idx);
    setLightboxOpen(true);
  };

  return (
    <div className="bg-[#F5F3EF] text-[#111111] overflow-x-hidden">
      {/* Full-Bleed Hero */}
      <section className="relative w-full h-[85vh] min-h-[600px] overflow-hidden bg-[#111111] flex flex-col justify-end">
        <img
          src={buildSanityImageUrl(project.heroImage.url, {
            width: 2200,
            quality: 85,
            auto: 'format',
          })}
          alt={project.heroImage.alt}
          className="absolute inset-0 w-full h-full object-cover filter brightness-[0.8]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-black/30" />

        <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-8 md:px-12 pb-16 sm:pb-24 w-full">
          {/* Back button */}
          <button
            onClick={() => navigateTo(`${prefix}/realisations/`)}
            className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-white/70 hover:text-white transition-colors mb-6 group focus:outline-none"
          >
            <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform" />
            <span>{t.projectDetailPage.backToList}</span>
          </button>

          <div className="space-y-4 max-w-4xl text-white">
            <div className="flex flex-wrap items-center gap-3 text-xs font-mono tracking-wider text-stone-300">
              <span className="bg-white/10 px-2.5 py-1">[ {project.area} m² ]</span>
              <span className="bg-white/10 px-2.5 py-1">[ {project.location} ]</span>
              <span className="bg-white/10 px-2.5 py-1">[ {project.year} ]</span>
              <span className="uppercase text-[11px] tracking-widest text-amber-200 ml-2">
                {project.type === 'villa' ? 'Villa Contemporaine' : "Chalet d'Exception"}
              </span>
            </div>

            <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-light tracking-tight">
              {project.title}
            </h1>
          </div>
        </div>
      </section>

      {/* Narrative & Specifications Grid */}
      <section className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12 py-24 md:py-36">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-24">
          {/* Left Column: Monograph Description */}
          <div className="lg:col-span-7 space-y-8">
            <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-light text-[#111111]/90 leading-relaxed">
              « {project.teaser[locale]} »
            </h2>

            <p className="text-base sm:text-lg text-stone-700 font-sans font-light leading-relaxed">
              {project.description[locale]}
            </p>
          </div>

          {/* Right Column: Architectural Specifications */}
          <div className="lg:col-span-5 bg-[#FAF8F5] p-8 sm:p-10 border border-[#111111]/10 space-y-6">
            <span className="text-xs uppercase tracking-[0.22em] text-[#8E8880] block font-sans">
              {t.projectDetailPage.specifications}
            </span>

            <div className="divide-y divide-[#111111]/10 text-xs sm:text-sm font-sans space-y-4">
              <div className="pt-3 flex justify-between">
                <span className="text-stone-500">{t.projectDetailPage.areaLabel}</span>
                <span className="font-mono font-medium text-[#111111]">{project.area} m²</span>
              </div>

              <div className="pt-3 flex justify-between">
                <span className="text-stone-500">{t.projectDetailPage.locationLabel}</span>
                <span className="font-medium text-[#111111]">{project.location}</span>
              </div>

              <div className="pt-3 flex justify-between">
                <span className="text-stone-500">{t.projectDetailPage.yearLabel}</span>
                <span className="font-mono text-[#111111]">{project.year}</span>
              </div>

              <div className="pt-3 space-y-1">
                <span className="text-stone-500 block">{t.projectDetailPage.materialsLabel}</span>
                <span className="text-[#111111] block font-light leading-relaxed">
                  {project.specifications.materials[locale]}
                </span>
              </div>

              <div className="pt-3 space-y-1">
                <span className="text-stone-500 block">{t.projectDetailPage.exposureLabel}</span>
                <span className="text-[#111111] block font-light leading-relaxed">
                  {project.specifications.exposure[locale]}
                </span>
              </div>

              <div className="pt-3 space-y-1">
                <span className="text-stone-500 block">{t.projectDetailPage.amenitiesLabel}</span>
                <span className="text-[#111111] block font-light leading-relaxed">
                  {project.specifications.amenities[locale]}
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Image Gallery with Big Alternating Layouts */}
      <section className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12 pb-32">
        <div className="pb-12 flex items-center justify-between border-b border-[#111111]/10">
          <span className="text-xs uppercase tracking-[0.22em] text-[#8E8880] font-sans">
            {t.projectDetailPage.galleryTitle}
          </span>
          <button
            onClick={() => openLightboxAt(0)}
            className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-stone-700 hover:text-black focus:outline-none"
          >
            <span>Plein écran</span>
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-16 pt-12">
          {project.gallery.map((img, idx) => {
            const isFull = img.layoutStyle === 'full' || img.layoutStyle === 'wide';

            return (
              <div
                key={idx}
                onClick={() => openLightboxAt(idx + 1)}
                className="cursor-pointer group relative overflow-hidden bg-stone-200"
              >
                <div className={isFull ? 'aspect-[16/9] w-full overflow-hidden' : 'aspect-[4/3] max-w-4xl mx-auto overflow-hidden'}>
                  <img
                    src={buildSanityImageUrl(img.url, {
                      width: isFull ? 2000 : 1400,
                      quality: 85,
                      auto: 'format',
                    })}
                    alt={img.alt}
                    className="w-full h-full object-cover img-editorial-zoom"
                    loading="lazy"
                  />
                </div>
                <div className="py-3 flex items-center justify-between text-xs text-stone-500 font-sans">
                  <span>{img.caption[locale]}</span>
                  <span className="font-mono text-stone-400">[ 0{idx + 1} ]</span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Inquiry Block */}
      <section className="bg-[#FAF8F5] border-y border-[#111111]/10 py-24 text-center">
        <div className="max-w-2xl mx-auto px-6 space-y-6">
          <span className="text-xs uppercase tracking-[0.25em] text-[#8E8880] font-sans">
            Consultation privée
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#111111] font-light">
            {t.projectDetailPage.inquiryTitle}
          </h2>
          <p className="text-sm text-stone-600 font-sans leading-relaxed">
            {t.projectDetailPage.inquiryDesc}
          </p>
          <div className="pt-4">
            <button
              onClick={() => navigateTo(`${prefix}/contact/`)}
              className="px-8 py-3.5 bg-[#111111] text-[#F5F3EF] uppercase tracking-[0.2em] text-xs font-semibold hover:bg-stone-800 transition-colors"
            >
              {t.projectDetailPage.inquiryCta}
            </button>
          </div>
        </div>
      </section>

      {/* "Next Project" Navigation */}
      <section
        onClick={() => navigateTo(`${prefix}/realisations/${nextProject.slug}/`)}
        className="relative group cursor-pointer w-full bg-[#111111] text-white py-24 sm:py-32 overflow-hidden border-t border-white/10"
      >
        <div className="absolute inset-0 opacity-25 group-hover:opacity-40 transition-opacity duration-700">
          <img
            src={buildSanityImageUrl(nextProject.heroImage.url, {
              width: 1800,
              quality: 75,
              auto: 'format',
            })}
            alt={nextProject.title}
            className="w-full h-full object-cover img-editorial-zoom"
          />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-8 md:px-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-3">
            <span className="text-xs uppercase tracking-[0.25em] text-stone-400 block font-mono">
              {t.projectDetailPage.nextProject} →
            </span>
            <h3 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-light text-white group-hover:translate-x-3 transition-transform duration-500">
              {nextProject.title}
            </h3>
            <p className="text-xs uppercase tracking-widest text-stone-300 font-sans">
              [ {nextProject.area} m² ] · {nextProject.location}
            </p>
          </div>

          <div className="w-12 h-12 rounded-full border border-white/40 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all">
            <ArrowUpRight className="w-5 h-5" />
          </div>
        </div>
      </section>

      {/* Image Lightbox */}
      <ImageLightbox
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        images={galleryImages}
        currentIndex={lightboxIndex}
        onNavigate={setLightboxIndex}
      />
    </div>
  );
};

export default ProjectDetailPage;
