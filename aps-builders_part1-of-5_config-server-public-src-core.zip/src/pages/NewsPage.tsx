import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { NEWS_POSTS } from '../data/mockSanityData';
import { buildSanityImageUrl } from '../lib/sanityClient';
import { ArrowUpRight } from 'lucide-react';

export const NewsPage: React.FC = () => {
  const { locale, navigateTo, t } = useLanguage();
  const prefix = locale === 'en' ? '/en' : '';

  return (
    <div className="bg-[#F5F3EF] text-[#111111] pt-32 pb-36">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12">
        {/* Header */}
        <div className="pb-16 border-b border-[#111111]/10 space-y-4">
          <span className="text-xs uppercase tracking-[0.25em] text-[#8E8880] block font-sans">
            Presse &amp; Revue
          </span>
          <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl font-light text-[#111111] tracking-tight">
            {t.newsPage.h1}
          </h1>
          <p className="text-stone-600 text-sm sm:text-base font-sans font-light max-w-xl">
            {t.newsPage.subtitle}
          </p>
        </div>

        {/* News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 pt-16">
          {NEWS_POSTS.map((post) => (
            <article
              key={post._id}
              onClick={() => navigateTo(`${prefix}/actualites/${post.slug}/`)}
              className="group cursor-pointer flex flex-col justify-between space-y-5"
            >
              <div className="aspect-[16/10] overflow-hidden bg-stone-300 relative shadow-sm">
                <img
                  src={buildSanityImageUrl(post.coverImage, {
                    width: 900,
                    quality: 80,
                    auto: 'format',
                  })}
                  alt={post.title[locale]}
                  className="w-full h-full object-cover img-editorial-zoom"
                  loading="lazy"
                />
                <div className="absolute top-3 right-3 w-7 h-7 rounded-full bg-black/40 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between text-[11px] uppercase tracking-widest text-stone-500 font-mono">
                  <span>{post.date}</span>
                  <span>{post.readTime}</span>
                </div>

                <span className="text-[10px] uppercase tracking-[0.2em] font-semibold text-stone-800 block">
                  {post.category[locale]}
                </span>

                <h2 className="font-serif text-2xl font-light text-[#111111] group-hover:underline underline-offset-4 decoration-1 leading-snug">
                  {post.title[locale]}
                </h2>

                <p className="text-xs text-stone-600 font-sans line-clamp-3 leading-relaxed">
                  {post.excerpt[locale]}
                </p>
              </div>

              <div className="pt-2 text-xs uppercase tracking-widest text-[#111111] font-semibold border-b border-[#111111]/20 pb-1 self-start">
                {t.newsPage.readArticle} →
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NewsPage;
