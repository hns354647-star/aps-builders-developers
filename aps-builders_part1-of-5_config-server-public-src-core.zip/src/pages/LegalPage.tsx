import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { ArrowLeft } from 'lucide-react';

interface LegalPageProps {
  type: 'mentions' | 'privacy';
}

export const LegalPage: React.FC<LegalPageProps> = ({ type }) => {
  const { locale, navigateTo } = useLanguage();
  const prefix = locale === 'en' ? '/en' : '';

  const isPrivacy = type === 'privacy';

  return (
    <div className="bg-[#F5F3EF] text-[#111111] pt-32 pb-36">
      <div className="max-w-3xl mx-auto px-6 sm:px-8">
        <button
          onClick={() => navigateTo(prefix ? '/en/' : '/')}
          className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-stone-500 hover:text-black transition-colors mb-8 group focus:outline-none"
        >
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform" />
          <span>{locale === 'fr' ? 'Retour à l\'accueil' : 'Back to home'}</span>
        </button>

        <h1 className="font-serif text-3xl sm:text-5xl font-light text-[#111111] pb-8 border-b border-[#111111]/10">
          {isPrivacy
            ? locale === 'fr'
              ? 'Politique de Confidentialité'
              : 'Privacy Policy'
            : locale === 'fr'
            ? 'Mentions Légales'
            : 'Legal Notice'}
        </h1>

        <div className="pt-10 space-y-8 text-sm text-stone-700 font-sans font-light leading-relaxed">
          {isPrivacy ? (
            <>
              <section className="space-y-3">
                <h2 className="font-serif text-xl text-black">1. Protection des données personnelles (RGPD)</h2>
                <p>
                  Le cabinet Archidomo attache la plus haute importance à la protection et au respect de la vie privée de ses clients et interlocuteurs. Conformément au Règlement Général sur la Protection des Données (RGPD 2016/679) et à la loi Informatique et Libertés, les données recueillies via notre formulaire de contact sont strictement limitées aux informations nécessaires à l'étude des projets architecturaux.
                </p>
              </section>

              <section className="space-y-3">
                <h2 className="font-serif text-xl text-black">2. Finalité et durée de conservation</h2>
                <p>
                  Les informations recueillies ne font l'objet d'aucune commercialisation ou cession à des tiers. Elles sont conservées pendant une durée maximale de 3 ans à compter du dernier contact avec nos associés.
                </p>
              </section>

              <section className="space-y-3">
                <h2 className="font-serif text-xl text-black">3. Vos droits</h2>
                <p>
                  Vous disposez d'un droit d'accès, de rectification, de portabilité et d'effacement de vos données. Pour exercer ce droit, écrivez à : <code>privacy@archidomo.fr</code> ou par courrier à notre siège social à Talloires-Montmin.
                </p>
              </section>
            </>
          ) : (
            <>
              <section className="space-y-3">
                <h2 className="font-serif text-xl text-black">1. Éditeur du site</h2>
                <p>
                  Archidomo SARL d'Architecture au capital de 100 000 €<br />
                  Inscrite à l'Ordre des Architectes de la région Auvergne-Rhône-Alpes<br />
                  Siège social : Route du Port, 74290 Talloires-Montmin (France)<br />
                  Directeurs de la publication : Carole Gibert &amp; Fabrice Gibert<br />
                  Téléphone : +33 4 50 22 18 40 · Email : contact@archidomo.fr
                </p>
              </section>

              <section className="space-y-3">
                <h2 className="font-serif text-xl text-black">2. Propriété intellectuelle</h2>
                <p>
                  L'ensemble de ce site relève de la législation française et internationale sur le droit d'auteur et la propriété intellectuelle. Tous les droits de reproduction sont réservés, y compris pour les documents photographiques et les esquisses architecturales.
                </p>
              </section>

              <section className="space-y-3">
                <h2 className="font-serif text-xl text-black">3. Hébergement</h2>
                <p>
                  Plateforme cloud de haute disponibilité conforme aux standards de sécurité européens.
                </p>
              </section>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default LegalPage;
