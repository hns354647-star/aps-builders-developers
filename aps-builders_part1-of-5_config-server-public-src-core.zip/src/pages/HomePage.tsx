import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { HeroCarousel } from '../components/HeroCarousel';
import { ProjectIndexSection } from '../components/ProjectIndexSection';
import { ImageLightbox, LightboxImage } from '../components/ImageLightbox';
import {
  FEATURED_PROJECT,
  AGENCY_COLLAGE,
  VISION_DATA,
  INSPIRATION_CATEGORIES,
} from '../data/mockSanityData';
import { buildSanityImageUrl } from '../lib/sanityClient';
import { ArrowRight, ArrowUpRight, Maximize2 } from 'lucide-react';

export const HomePage: React.FC = () => {
  const { locale, navigateTo, t } = useLanguage();
  const prefix = locale === 'en' ? '/en' : '';

  // Lightbox state for Inspiration section & collage
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxImages, setLightboxImages] = useState<LightboxImage[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  const openLightbox = (images: LightboxImage[], startIndex = 0) => {
    setLightboxImages(images);
    setLightboxIndex(startIndex);
    setLightboxOpen(true);
  };

  return (
    <div className="bg-[#F5F3EF] text-[#111111] overflow-x-hidden">
      {/* 4.1 Hero Section */}
      <HeroCarousel />

      {/* 4.2 "Notre agence" (Studio Intro) */}
      <section className="py-28 md:py-44 px-6 sm:px-8 md:px-12 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-20 items-start">
          {/* Left Column: Title & Text Content */}
          <div className="lg:col-span-5 space-y-8 lg:sticky lg:top-32">
            <div>
              <span className="text-xs uppercase tracking-[0.25em] text-[#8E8880] block mb-3 font-sans">
                4.2 · {t.nav.agency}
              </span>
              <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-light tracking-tight text-[#111111]">
                {t.agencyIntro.h2}
              </h2>
            </div>

            <p className="font-serif text-2xl sm:text-3xl font-light leading-relaxed text-[#111111]/90">
              {t.agencyIntro.paragraph}
            </p>

            <div className="pt-4 border-t border-[#111111]/15 space-y-4">
              <p className="text-xs uppercase tracking-[0.18em] text-[#8E8880] font-sans leading-relaxed">
                {t.agencyIntro.caption}
              </p>

              <blockquote className="font-serif italic text-lg text-stone-700 pl-4 border-l-2 border-[#111111]/30">
                « {t.agencyIntro.closing} »
              </blockquote>
            </div>

            <div className="pt-4">
              <button
                onClick={() => navigateTo(`${prefix}/agence/`)}
                className="group inline-flex items-center gap-3 text-xs uppercase tracking-[0.2em] font-semibold text-[#111111] hover:text-stone-600 transition-colors border-b border-[#111111] pb-1.5 focus:outline-none"
              >
                <span>{t.agencyIntro.discoverAgency}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </button>
            </div>
          </div>

          {/* Right Column: Asymmetric Collage of 3-4 Images */}
          <div className="lg:col-span-7 grid grid-cols-12 gap-4 sm:gap-6 items-start">
            {/* Image 1: Main vertical portrait */}
            <div className="col-span-12 sm:col-span-7 group relative overflow-hidden bg-stone-200">
              <div className="aspect-[4/5] overflow-hidden">
                <img
                  src={buildSanityImageUrl(AGENCY_COLLAGE[0].url, {
                    width: 900,
                    quality: 80,
                    auto: 'format',
                  })}
                  alt={AGENCY_COLLAGE[0].alt}
                  className="w-full h-full object-cover img-editorial-zoom"
                  loading="lazy"
                />
              </div>
              <div className="py-2.5 px-1 flex justify-between items-center text-[11px] text-stone-500 uppercase tracking-widest font-sans">
                <span>{AGENCY_COLLAGE[0].caption[locale]}</span>
                <span className="font-mono text-stone-400">[ 01 ]</span>
              </div>
            </div>

            {/* Image 2: Square offset */}
            <div className="col-span-12 sm:col-span-5 sm:mt-16 group relative overflow-hidden bg-stone-200">
              <div className="aspect-square overflow-hidden">
                <img
                  src={buildSanityImageUrl(AGENCY_COLLAGE[1].url, {
                    width: 700,
                    quality: 80,
                    auto: 'format',
                  })}
                  alt={AGENCY_COLLAGE[1].alt}
                  className="w-full h-full object-cover img-editorial-zoom"
                  loading="lazy"
                />
              </div>
              <div className="py-2.5 px-1 flex justify-between items-center text-[11px] text-stone-500 uppercase tracking-widest font-sans">
                <span>{AGENCY_COLLAGE[1].caption[locale]}</span>
                <span className="font-mono text-stone-400">[ 02 ]</span>
              </div>
            </div>

            {/* Image 3: Slim portrait */}
            <div className="col-span-12 sm:col-span-5 group relative overflow-hidden bg-stone-200">
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src={buildSanityImageUrl(AGENCY_COLLAGE[2].url, {
                    width: 700,
                    quality: 80,
                    auto: 'format',
                  })}
                  alt={AGENCY_COLLAGE[2].alt}
                  className="w-full h-full object-cover img-editorial-zoom"
                  loading="lazy"
                />
              </div>
              <div className="py-2.5 px-1 flex justify-between items-center text-[11px] text-stone-500 uppercase tracking-widest font-sans">
                <span>{AGENCY_COLLAGE[2].caption[locale]}</span>
                <span className="font-mono text-stone-400">[ 03 ]</span>
              </div>
            </div>

            {/* Image 4: Landscape wide */}
            <div className="col-span-12 sm:col-span-7 sm:-mt-10 group relative overflow-hidden bg-stone-200">
              <div className="aspect-[16/10] overflow-hidden">
                <img
                  src={buildSanityImageUrl(AGENCY_COLLAGE[3].url, {
                    width: 900,
                    quality: 80,
                    auto: 'format',
                  })}
                  alt={AGENCY_COLLAGE[3].alt}
                  className="w-full h-full object-cover img-editorial-zoom"
                  loading="lazy"
                />
              </div>
              <div className="py-2.5 px-1 flex justify-between items-center text-[11px] text-stone-500 uppercase tracking-widest font-sans">
                <span>{AGENCY_COLLAGE[3].caption[locale]}</span>
                <span className="font-mono text-stone-400">[ 04 ]</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4.3 Featured Project: Villa Elektra */}
      <section className="py-28 md:py-40 bg-[#FAF8F5] border-y border-[#111111]/8">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            {/* Square Image (~600x600) */}
            <div className="lg:col-span-6">
              <div className="relative group aspect-square max-w-[600px] mx-auto overflow-hidden bg-stone-300 shadow-xl">
                <img
                  src={buildSanityImageUrl(FEATURED_PROJECT.heroImage.url, {
                    width: 800,
                    height: 800,
                    quality: 85,
                    fit: 'crop',
                    auto: 'format',
                  })}
                  alt={FEATURED_PROJECT.heroImage.alt}
                  className="w-full h-full object-cover img-editorial-zoom"
                  loading="lazy"
                />
                <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-xs text-white text-[10px] uppercase tracking-[0.2em] px-3 py-1 font-mono">
                  4.3 · {t.featured.label}
                </div>
              </div>
            </div>

            {/* Editorial Content */}
            <div className="lg:col-span-6 space-y-6">
              <div className="space-y-3">
                <span className="text-xs uppercase tracking-[0.22em] text-[#8E8880] font-sans">
                  {FEATURED_PROJECT.location}
                </span>

                <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-light text-[#111111] tracking-tight">
                  {FEATURED_PROJECT.title}
                </h2>

                {/* Metadata chips in brackets: [ 1150 m² ] [ Lac de Genève ] [ 2025 ] */}
                <div className="flex flex-wrap items-center gap-3 pt-2 text-xs sm:text-sm font-mono text-stone-800">
                  <span className="bg-stone-200/80 px-2.5 py-1">[ {FEATURED_PROJECT.area} m² ]</span>
                  <span className="bg-stone-200/80 px-2.5 py-1">[ {FEATURED_PROJECT.location} ]</span>
                  <span className="bg-stone-200/80 px-2.5 py-1">[ {FEATURED_PROJECT.year} ]</span>
                </div>
              </div>

              {/* One teaser sentence about a "majestic sleight of hand" */}
              <p className="font-serif text-2xl sm:text-3xl font-light text-[#111111]/90 leading-relaxed pt-2">
                « {FEATURED_PROJECT.teaser[locale]} »
              </p>

              <p className="text-stone-600 text-sm leading-relaxed max-w-xl font-sans font-light">
                {FEATURED_PROJECT.description[locale].slice(0, 220)}...
              </p>

              <div className="pt-4">
                <button
                  onClick={() => navigateTo(`${prefix}/realisations/${FEATURED_PROJECT.slug}/`)}
                  className="group inline-flex items-center gap-4 px-7 py-3.5 bg-[#111111] text-[#F5F3EF] hover:bg-stone-800 transition-colors uppercase tracking-[0.2em] text-xs font-semibold focus:outline-none"
                >
                  <span>{t.featured.cta}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4.4 Project Index (Large typographic list with cursor-follow preview) */}
      <ProjectIndexSection />

      {/* 4.5 "La vision" */}
      <section className="relative w-full bg-[#111111] text-[#F5F3EF] overflow-hidden">
        {/* Full-viewport (16:9) Background Image with Dark Gradient Overlay */}
        <div className="relative w-full aspect-[16/9] min-h-[560px] max-h-[850px] overflow-hidden">
          <img
            src={buildSanityImageUrl(VISION_DATA.bgImage, {
              width: 2200,
              quality: 85,
              auto: 'format',
            })}
            alt="La vision panoramique Archidomo"
            className="w-full h-full object-cover object-center filter brightness-[0.7]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-black/40 to-black/60" />

          {/* Vision Heading & Paragraph */}
          <div className="absolute inset-0 flex items-center justify-center p-6 sm:p-12 text-center">
            <div className="max-w-3xl space-y-6">
              <span className="text-xs uppercase tracking-[0.28em] text-[#8E8880] block font-sans">
                4.5 · {VISION_DATA.title[locale]}
              </span>
              <h2 className="font-serif text-4xl sm:text-6xl md:text-7xl font-light text-white tracking-tight">
                {VISION_DATA.title[locale]}
              </h2>
              <p className="font-serif text-xl sm:text-2xl md:text-3xl font-light text-stone-200 leading-relaxed max-w-2xl mx-auto">
                {VISION_DATA.paragraph[locale]}
              </p>
            </div>
          </div>
        </div>

        {/* Below it: Two Portrait Images (~614x780) side by side with parallax offset */}
        <div className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12 py-24 sm:py-36">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Portrait Left */}
            <div className="space-y-4">
              <div className="aspect-[3/4] max-w-[614px] overflow-hidden bg-stone-900 border border-white/5 group">
                <img
                  src={buildSanityImageUrl(VISION_DATA.portraitLeft.url, {
                    width: 900,
                    height: 1140,
                    quality: 85,
                    fit: 'crop',
                    auto: 'format',
                  })}
                  alt={VISION_DATA.portraitLeft.alt}
                  className="w-full h-full object-cover img-editorial-zoom"
                  loading="lazy"
                />
              </div>
              <p className="text-xs sm:text-sm font-sans text-stone-400 font-light max-w-md italic">
                « {VISION_DATA.portraitLeft.caption[locale]} »
              </p>
            </div>

            {/* Portrait Right (Parallax offset downwards on desktop) */}
            <div className="space-y-4 md:mt-24">
              <div className="aspect-[3/4] max-w-[614px] overflow-hidden bg-stone-900 border border-white/5 group">
                <img
                  src={buildSanityImageUrl(VISION_DATA.portraitRight.url, {
                    width: 900,
                    height: 1140,
                    quality: 85,
                    fit: 'crop',
                    auto: 'format',
                  })}
                  alt={VISION_DATA.portraitRight.alt}
                  className="w-full h-full object-cover img-editorial-zoom"
                  loading="lazy"
                />
              </div>
              <p className="text-xs sm:text-sm font-sans text-stone-400 font-light max-w-md italic">
                « {VISION_DATA.portraitRight.caption[locale]} »
              </p>
            </div>
          </div>

          {/* Text link "l'agence" -> /agence/ */}
          <div className="pt-16 sm:pt-24 text-center">
            <button
              onClick={() => navigateTo(`${prefix}/agence/`)}
              className="editorial-link font-serif text-2xl sm:text-3xl text-stone-300 hover:text-white transition-colors tracking-wide focus:outline-none"
            >
              {t.vision.linkAgency} →
            </button>
          </div>
        </div>
      </section>

      {/* 4.6 "Inspiration" */}
      <section className="py-28 md:py-44 bg-[#F5F3EF] text-[#111111]">
        {/* Full-bleed 16:9 Background Section with Short Text */}
        <div className="relative w-full aspect-[16/9] min-h-[500px] max-h-[780px] overflow-hidden mb-24 md:mb-36">
          <img
            src="https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=2200&q=85"
            alt="Inspiration architecturale Archidomo"
            className="w-full h-full object-cover filter brightness-[0.75]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/60 flex items-center justify-center p-6 sm:p-12 text-center text-white">
            <div className="max-w-3xl space-y-6">
              <span className="text-xs uppercase tracking-[0.25em] text-stone-300 block font-sans">
                4.6 · {t.inspiration.h2}
              </span>
              <h2 className="font-serif text-4xl sm:text-6xl md:text-7xl font-light tracking-tight">
                {t.inspiration.h2}
              </h2>
              <div className="space-y-3 font-serif text-xl sm:text-2xl text-stone-200 font-light max-w-2xl mx-auto leading-relaxed">
                <p>{t.inspiration.textPart1}</p>
                <p className="text-stone-300">{t.inspiration.textPart2}</p>
              </div>

              {/* CTA "Le showroom" -> /lieu/ */}
              <div className="pt-6">
                <button
                  onClick={() => navigateTo(`${prefix}/lieu/`)}
                  className="group inline-flex items-center gap-3 px-8 py-3.5 bg-white text-[#111111] hover:bg-stone-200 transition-colors uppercase tracking-[0.2em] text-xs font-semibold focus:outline-none"
                >
                  <span>{t.inspiration.showroomCta}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 5 Category Rows. Each has an H3, one-line caption, and pair of portrait images (260x340, 3:4 ratio, staggered vertically, subtle parallax, opens lightbox) */}
        <div className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12 space-y-28 md:space-y-40">
          {INSPIRATION_CATEGORIES.map((cat, rowIdx) => {
            const isReversed = rowIdx % 2 === 1;

            return (
              <div
                key={cat.id}
                className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center pb-20 border-b border-[#111111]/10 last:border-b-0"
              >
                {/* Category Header & Caption */}
                <div
                  className={`lg:col-span-5 space-y-4 ${
                    isReversed ? 'lg:order-2 lg:pl-12' : 'lg:order-1 lg:pr-12'
                  }`}
                >
                  <span className="font-mono text-xs text-[#8E8880] tracking-widest block uppercase">
                    Catégorie [ 0{rowIdx + 1} ]
                  </span>
                  <h3 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light text-[#111111] tracking-tight">
                    {cat.title[locale]}
                  </h3>
                  <p className="text-stone-600 text-sm sm:text-base font-sans font-light leading-relaxed">
                    {cat.caption[locale]}
                  </p>
                  <button
                    onClick={() =>
                      openLightbox(
                        cat.images.map((img) => ({
                          url: img.url,
                          alt: img.alt,
                          caption: img.caption[locale],
                          category: cat.title[locale],
                        })),
                        0
                      )
                    }
                    className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-[#111111] hover:text-stone-600 font-semibold border-b border-[#111111]/30 pb-1 pt-2 focus:outline-none"
                  >
                    <span>{t.inspiration.viewGallery}</span>
                    <Maximize2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Pair of 3:4 Portrait Images (260x340 ratio, staggered vertically) */}
                <div
                  className={`lg:col-span-7 grid grid-cols-2 gap-4 sm:gap-8 items-start ${
                    isReversed ? 'lg:order-1' : 'lg:order-2'
                  }`}
                >
                  {/* Image 1 */}
                  <div
                    onClick={() =>
                      openLightbox(
                        cat.images.map((img) => ({
                          url: img.url,
                          alt: img.alt,
                          caption: img.caption[locale],
                          category: cat.title[locale],
                        })),
                        0
                      )
                    }
                    className="cursor-pointer group relative overflow-hidden bg-stone-300 shadow-sm"
                  >
                    <div className="aspect-[3/4] overflow-hidden">
                      <img
                        src={buildSanityImageUrl(cat.images[0].url, {
                          width: 600,
                          height: 800,
                          quality: 85,
                          fit: 'crop',
                          auto: 'format',
                        })}
                        alt={cat.images[0].alt}
                        className="w-full h-full object-cover img-editorial-zoom"
                        loading="lazy"
                      />
                    </div>
                    <div className="p-2 text-[11px] text-stone-500 font-sans tracking-wide">
                      {cat.images[0].caption[locale]}
                    </div>
                  </div>

                  {/* Image 2 (Staggered vertically with mt-10 md:mt-16) */}
                  <div
                    onClick={() =>
                      openLightbox(
                        cat.images.map((img) => ({
                          url: img.url,
                          alt: img.alt,
                          caption: img.caption[locale],
                          category: cat.title[locale],
                        })),
                        1
                      )
                    }
                    className="cursor-pointer group relative overflow-hidden bg-stone-300 shadow-sm mt-8 sm:mt-16"
                  >
                    <div className="aspect-[3/4] overflow-hidden">
                      <img
                        src={buildSanityImageUrl(cat.images[1].url, {
                          width: 600,
                          height: 800,
                          quality: 85,
                          fit: 'crop',
                          auto: 'format',
                        })}
                        alt={cat.images[1].alt}
                        className="w-full h-full object-cover img-editorial-zoom"
                        loading="lazy"
                      />
                    </div>
                    <div className="p-2 text-[11px] text-stone-500 font-sans tracking-wide">
                      {cat.images[1].caption[locale]}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Lightbox for gallery viewing */}
      <ImageLightbox
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        images={lightboxImages}
        currentIndex={lightboxIndex}
        onNavigate={setLightboxIndex}
      />
    </div>
  );
};

export default HomePage;
