import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { buildSanityImageUrl } from '../lib/sanityClient';
import { ArrowRight, MapPin, Compass, ShieldCheck, PenTool, Sparkles } from 'lucide-react';

export const StudioPage: React.FC = () => {
  const { locale, navigateTo, t } = useLanguage();
  const prefix = locale === 'en' ? '/en' : '';

  const processSteps = [
    {
      num: '01',
      title: t.studioPage.step1Title,
      desc: t.studioPage.step1Desc,
      icon: Compass,
    },
    {
      num: '02',
      title: t.studioPage.step2Title,
      desc: t.studioPage.step2Desc,
      icon: PenTool,
    },
    {
      num: '03',
      title: t.studioPage.step3Title,
      desc: t.studioPage.step3Desc,
      icon: ShieldCheck,
    },
    {
      num: '04',
      title: t.studioPage.step4Title,
      desc: t.studioPage.step4Desc,
      icon: Sparkles,
    },
  ];

  return (
    <div className="bg-[#F5F3EF] text-[#111111] pt-32 pb-32">
      {/* Editorial Header */}
      <section className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12 pt-8 pb-20">
        <div className="max-w-4xl space-y-6">
          <span className="text-xs uppercase tracking-[0.25em] text-[#8E8880] block font-sans">
            {t.studioPage.h1} · Annecy · Cannes · Lyon
          </span>
          <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl font-light text-[#111111] tracking-tight leading-[1.08]">
            {t.studioPage.subtitle}
          </h1>
        </div>
      </section>

      {/* Hero Studio Photography */}
      <section className="w-full max-w-7xl mx-auto px-6 sm:px-8 md:px-12 mb-28">
        <div className="aspect-[16/9] w-full overflow-hidden bg-stone-300 shadow-xl">
          <img
            src={buildSanityImageUrl('https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=2200&q=85', {
              width: 2000,
              quality: 85,
              auto: 'format',
            })}
            alt="Atelier d'architecture Archidomo à Annecy"
            className="w-full h-full object-cover"
          />
        </div>
      </section>

      {/* Genesis & Philosophy */}
      <section className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12 py-16 border-t border-[#111111]/10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20">
          <div className="lg:col-span-5">
            <span className="font-mono text-xs uppercase tracking-widest text-[#8E8880] block mb-2">
              Philosophie
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-light text-[#111111]">
              {t.studioPage.storyTitle}
            </h2>
          </div>

          <div className="lg:col-span-7 space-y-6 font-serif text-xl sm:text-2xl font-light leading-relaxed text-stone-800">
            <p>{t.studioPage.storyP1}</p>
            <p>{t.studioPage.storyP2}</p>
          </div>
        </div>
      </section>

      {/* Founders Section: Carole & Fabrice Gibert */}
      <section className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12 py-24 border-t border-[#111111]/10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          <div className="lg:col-span-6 space-y-6">
            <span className="text-xs uppercase tracking-[0.22em] text-[#8E8880] block font-sans">
              Fondateurs
            </span>
            <h2 className="font-serif text-4xl sm:text-5xl font-light text-[#111111]">
              {t.studioPage.foundersTitle}
            </h2>
            <span className="text-xs uppercase tracking-widest font-mono text-stone-500 block">
              {t.studioPage.foundersRole}
            </span>
            <p className="text-sm sm:text-base text-stone-700 font-sans font-light leading-relaxed">
              {t.studioPage.foundersBio}
            </p>
            <div className="pt-2">
              <button
                onClick={() => navigateTo(`${prefix}/contact/`)}
                className="group inline-flex items-center gap-3 text-xs uppercase tracking-[0.2em] font-semibold text-[#111111] hover:text-stone-600 transition-colors border-b border-[#111111] pb-1.5 focus:outline-none"
              >
                <span>{t.studioPage.contactCta}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </button>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="aspect-[4/5] max-w-lg mx-auto overflow-hidden bg-stone-200 shadow-lg">
              <img
                src={buildSanityImageUrl('https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1200&q=85', {
                  width: 900,
                  quality: 85,
                  auto: 'format',
                })}
                alt="Carole et Fabrice Gibert - Architectes fondateurs"
                className="w-full h-full object-cover filter grayscale contrast-105"
              />
            </div>
            <p className="text-center text-xs text-stone-400 mt-3 font-mono">
              Carole &amp; Fabrice Gibert · Annecy
            </p>
          </div>
        </div>
      </section>

      {/* 4-Step Methodology */}
      <section className="bg-[#FAF8F5] py-28 border-y border-[#111111]/10">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12">
          <div className="text-center max-w-3xl mx-auto mb-20 space-y-4">
            <span className="text-xs uppercase tracking-[0.25em] text-[#8E8880] block font-sans">
              Méthodologie
            </span>
            <h2 className="font-serif text-3xl sm:text-5xl font-light text-[#111111]">
              {t.studioPage.processTitle}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step) => {
              const Icon = step.icon;
              return (
                <div key={step.num} className="bg-white p-8 border border-[#111111]/5 space-y-4 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-lg font-light text-stone-400">
                        {step.num}
                      </span>
                      <Icon className="w-5 h-5 text-stone-400" />
                    </div>
                    <h3 className="font-serif text-xl text-[#111111]">
                      {step.title}
                    </h3>
                    <p className="text-xs text-stone-600 font-sans leading-relaxed">
                      {step.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Showroom Immersion CTA */}
      <section className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12 py-24 text-center">
        <div className="max-w-2xl mx-auto space-y-6">
          <span className="text-xs uppercase tracking-[0.25em] text-[#8E8880] font-sans">
            Visite confidentielle
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#111111] font-light">
            Découvrez notre showroom « Immersion » à Talloires-Montmin
          </h2>
          <p className="text-sm text-stone-600 font-sans leading-relaxed">
            Un espace au bord du lac d'Annecy réunissant nos prototypes de matériaux, échantillons de roche et menuiseries affleurantes.
          </p>
          <div className="pt-4">
            <button
              onClick={() => navigateTo(`${prefix}/lieu/`)}
              className="px-8 py-3.5 bg-[#111111] text-[#F5F3EF] uppercase tracking-[0.2em] text-xs font-semibold hover:bg-stone-800 transition-colors"
            >
              Découvrir le showroom
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default StudioPage;
