import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { SHOWROOM_DATA } from '../data/mockSanityData';
import { buildSanityImageUrl } from '../lib/sanityClient';
import { MapPin, Phone, Mail, ArrowUpRight, CheckCircle2, Clock } from 'lucide-react';

export const ImmersionPage: React.FC = () => {
  const { locale, t } = useLanguage();

  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    projectNature: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.name || !formState.email || !formState.phone) {
      setErrorMsg(
        locale === 'fr'
          ? 'Veuillez renseigner les champs obligatoires (nom, email, téléphone).'
          : 'Please complete all required fields (name, email, phone).'
      );
      return;
    }
    setErrorMsg('');
    setIsSubmitted(true);
  };

  return (
    <div className="bg-[#F5F3EF] text-[#111111] pt-32 pb-36">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12">
        {/* Page Header */}
        <div className="max-w-4xl space-y-6 pb-20 border-b border-[#111111]/10">
          <span className="text-xs uppercase tracking-[0.25em] text-[#8E8880] block font-sans">
            Showroom confidentiel
          </span>
          <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl font-light tracking-tight text-[#111111]">
            {SHOWROOM_DATA.title[locale]}
          </h1>
          <p className="font-serif text-2xl sm:text-3xl text-stone-700 font-light leading-relaxed">
            « {SHOWROOM_DATA.subtitle[locale]} »
          </p>
        </div>

        {/* Narrative & Showroom Intro */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 py-16">
          <div className="lg:col-span-5 space-y-6">
            <span className="font-mono text-xs uppercase tracking-widest text-[#8E8880] block">
              Le Manifeste
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-light">
              L'expérience de la matière à fleur d'eau
            </h2>
            <div className="space-y-4 pt-4 text-xs font-sans text-stone-600">
              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-stone-400 shrink-0" />
                <span>{SHOWROOM_DATA.address}</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-stone-400 shrink-0" />
                <span>{SHOWROOM_DATA.phone}</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-stone-400 shrink-0" />
                <span>{SHOWROOM_DATA.email}</span>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-stone-400 shrink-0" />
                <span>Du lundi au vendredi · Sur rendez-vous uniquement</span>
              </div>
              <div className="pt-2">
                <a
                  href="https://maps.google.com/?q=Talloires-Montmin+74290"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs uppercase tracking-wider text-stone-800 underline underline-offset-4 font-medium"
                >
                  <span>Ouvrir dans Google Maps</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-6 font-serif text-xl sm:text-2xl font-light text-stone-800 leading-relaxed">
            <p>{SHOWROOM_DATA.description[locale]}</p>
          </div>
        </div>

        {/* Showroom Image Gallery */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-16">
          {SHOWROOM_DATA.gallery.map((img, idx) => (
            <div key={idx} className="group relative overflow-hidden bg-stone-300">
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={buildSanityImageUrl(img.url, {
                    width: 900,
                    quality: 80,
                    auto: 'format',
                  })}
                  alt={img.alt}
                  className="w-full h-full object-cover img-editorial-zoom"
                  loading="lazy"
                />
              </div>
              <div className="p-3 text-xs text-stone-500 font-sans">
                {img.caption[locale]}
              </div>
            </div>
          ))}
        </div>

        {/* Visit Request Form */}
        <div className="bg-[#FAF8F5] p-8 sm:p-16 border border-[#111111]/10 mt-20 max-w-4xl mx-auto">
          <div className="max-w-xl mx-auto space-y-4 text-center mb-10">
            <span className="text-xs uppercase tracking-[0.25em] text-[#8E8880] block font-sans">
              Réservation
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-light text-[#111111]">
              {t.immersionPage.bookingTitle}
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 font-sans">
              {t.immersionPage.bookingSubtitle}
            </p>
          </div>

          {isSubmitted ? (
            <div className="text-center py-12 space-y-4 bg-white p-8 border border-stone-200">
              <CheckCircle2 className="w-12 h-12 text-stone-800 mx-auto" />
              <h3 className="font-serif text-2xl text-[#111111]">
                Demande transmise avec succès
              </h3>
              <p className="text-sm text-stone-600 max-w-md mx-auto">
                {t.immersionPage.formSuccess}
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6 max-w-xl mx-auto">
              {errorMsg && (
                <div className="p-3 bg-red-50 text-red-700 text-xs border border-red-200">
                  {errorMsg}
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs uppercase tracking-wider text-stone-500 block">
                  {t.immersionPage.formName} *
                </label>
                <input
                  type="text"
                  required
                  value={formState.name}
                  onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                  className="w-full bg-white border border-[#111111]/15 px-4 py-2.5 text-sm text-[#111111] focus:outline-none focus:border-stone-800"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs uppercase tracking-wider text-stone-500 block">
                    {t.immersionPage.formEmail} *
                  </label>
                  <input
                    type="email"
                    required
                    value={formState.email}
                    onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                    className="w-full bg-white border border-[#111111]/15 px-4 py-2.5 text-sm text-[#111111] focus:outline-none focus:border-stone-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs uppercase tracking-wider text-stone-500 block">
                    {t.immersionPage.formPhone} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formState.phone}
                    onChange={(e) => setFormState({ ...formState, phone: e.target.value })}
                    className="w-full bg-white border border-[#111111]/15 px-4 py-2.5 text-sm text-[#111111] focus:outline-none focus:border-stone-800"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs uppercase tracking-wider text-stone-500 block">
                  {t.immersionPage.formDate}
                </label>
                <input
                  type="date"
                  value={formState.date}
                  onChange={(e) => setFormState({ ...formState, date: e.target.value })}
                  className="w-full bg-white border border-[#111111]/15 px-4 py-2.5 text-sm text-[#111111] focus:outline-none focus:border-stone-800"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs uppercase tracking-wider text-stone-500 block">
                  {t.immersionPage.formProjectNature}
                </label>
                <input
                  type="text"
                  placeholder="ex: Construction villa contemporary Lac d'Annecy"
                  value={formState.projectNature}
                  onChange={(e) => setFormState({ ...formState, projectNature: e.target.value })}
                  className="w-full bg-white border border-[#111111]/15 px-4 py-2.5 text-sm text-[#111111] focus:outline-none focus:border-stone-800"
                />
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  className="w-full py-4 bg-[#111111] text-[#F5F3EF] uppercase tracking-[0.2em] text-xs font-semibold hover:bg-stone-800 transition-colors"
                >
                  {t.immersionPage.formSubmit}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImmersionPage;
