import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { OFFICES } from '../data/mockSanityData';
import { MapPin, Phone, Mail, ArrowUpRight, CheckCircle2, ShieldCheck } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const { locale, t } = useLanguage();

  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    location: '',
    message: '',
    gdpr: false,
    honeypot: '', // anti-spam bot field
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Spam honeypot detection
    if (formState.honeypot) {
      return;
    }

    if (!formState.name || !formState.email || !formState.message) {
      setErrorMessage(
        locale === 'fr'
          ? 'Veuillez renseigner votre nom, votre email et votre message.'
          : 'Please provide your name, email, and message.'
      );
      return;
    }

    if (!formState.gdpr) {
      setErrorMessage(
        locale === 'fr'
          ? 'Veuillez accepter les termes de confidentialité RGPD pour transmettre votre demande.'
          : 'Please accept the GDPR consent to submit your inquiry.'
      );
      return;
    }

    setErrorMessage('');
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 800);
  };

  return (
    <div className="bg-[#F5F3EF] text-[#111111] pt-32 pb-36">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 md:px-12">
        {/* Header */}
        <div className="max-w-4xl space-y-4 pb-16 border-b border-[#111111]/10">
          <span className="text-xs uppercase tracking-[0.25em] text-[#8E8880] block font-sans">
            Correspondance &amp; Rendez-vous
          </span>
          <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl font-light tracking-tight text-[#111111]">
            {t.contactPage.h1}
          </h1>
          <p className="text-stone-600 text-sm sm:text-base font-sans font-light max-w-xl">
            {t.contactPage.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 pt-16">
          {/* Left Column: Form */}
          <div className="lg:col-span-7 bg-[#FAF8F5] p-8 sm:p-12 border border-[#111111]/10">
            <span className="text-xs uppercase tracking-[0.22em] text-[#8E8880] block mb-6 font-sans">
              {t.contactPage.formTitle}
            </span>

            {isSubmitted ? (
              <div className="py-12 text-center space-y-4 bg-white p-8 border border-stone-200">
                <CheckCircle2 className="w-12 h-12 text-stone-800 mx-auto" />
                <h3 className="font-serif text-2xl text-[#111111]">
                  {t.contactPage.successTitle}
                </h3>
                <p className="text-sm text-stone-600 max-w-md mx-auto leading-relaxed">
                  {t.contactPage.successMessage}
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Honeypot field (hidden from real users) */}
                <input
                  type="text"
                  name="company_fax"
                  value={formState.honeypot}
                  onChange={(e) => setFormState({ ...formState, honeypot: e.target.value })}
                  style={{ display: 'none' }}
                  tabIndex={-1}
                  autoComplete="off"
                />

                {errorMessage && (
                  <div className="p-3 bg-red-50 text-red-700 text-xs border border-red-200">
                    {errorMessage}
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-xs uppercase tracking-wider text-stone-600 block">
                    {t.contactPage.name} *
                  </label>
                  <input
                    type="text"
                    required
                    value={formState.name}
                    onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                    className="w-full bg-white border border-[#111111]/15 px-4 py-2.5 text-sm text-[#111111] focus:outline-none focus:border-stone-800"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs uppercase tracking-wider text-stone-600 block">
                      {t.contactPage.email} *
                    </label>
                    <input
                      type="email"
                      required
                      value={formState.email}
                      onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                      className="w-full bg-white border border-[#111111]/15 px-4 py-2.5 text-sm text-[#111111] focus:outline-none focus:border-stone-800"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs uppercase tracking-wider text-stone-600 block">
                      {t.contactPage.phone}
                    </label>
                    <input
                      type="tel"
                      value={formState.phone}
                      onChange={(e) => setFormState({ ...formState, phone: e.target.value })}
                      className="w-full bg-white border border-[#111111]/15 px-4 py-2.5 text-sm text-[#111111] focus:outline-none focus:border-stone-800"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs uppercase tracking-wider text-stone-600 block">
                    {t.contactPage.location}
                  </label>
                  <input
                    type="text"
                    placeholder={t.contactPage.locationPlaceholder}
                    value={formState.location}
                    onChange={(e) => setFormState({ ...formState, location: e.target.value })}
                    className="w-full bg-white border border-[#111111]/15 px-4 py-2.5 text-sm text-[#111111] focus:outline-none focus:border-stone-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs uppercase tracking-wider text-stone-600 block">
                    {t.contactPage.message} *
                  </label>
                  <textarea
                    rows={5}
                    required
                    value={formState.message}
                    onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                    className="w-full bg-white border border-[#111111]/15 px-4 py-2.5 text-sm text-[#111111] focus:outline-none focus:border-stone-800"
                  />
                </div>

                {/* GDPR Consent Checkbox */}
                <div className="flex items-start gap-3 pt-2">
                  <input
                    type="checkbox"
                    id="gdpr"
                    checked={formState.gdpr}
                    onChange={(e) => setFormState({ ...formState, gdpr: e.target.checked })}
                    className="mt-1 accent-black cursor-pointer"
                  />
                  <label htmlFor="gdpr" className="text-xs text-stone-500 font-sans leading-relaxed cursor-pointer">
                    {t.contactPage.gdpr}
                  </label>
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 bg-[#111111] text-[#F5F3EF] uppercase tracking-[0.2em] text-xs font-semibold hover:bg-stone-800 transition-colors disabled:opacity-50"
                  >
                    {isSubmitting ? t.contactPage.submitting : t.contactPage.submit}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Right Column: 3 Offices + Direct Contact */}
          <div className="lg:col-span-5 space-y-12">
            <div>
              <span className="text-xs uppercase tracking-[0.22em] text-[#8E8880] block mb-6 font-sans">
                {t.contactPage.officesTitle}
              </span>

              <div className="space-y-8">
                {OFFICES.map((office) => (
                  <div
                    key={office.city}
                    className="p-6 bg-white border border-[#111111]/5 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-serif text-xl font-light text-[#111111]">
                        {office.city}
                      </h3>
                      <span className="text-[11px] uppercase tracking-wider text-stone-500 font-mono">
                        {office.label}
                      </span>
                    </div>

                    <p className="text-xs text-stone-600 font-sans leading-relaxed">
                      {office.address}
                      <br />
                      {office.postalCode} {office.region}
                    </p>

                    <div className="pt-2 flex flex-col gap-1 text-xs text-stone-700 font-sans">
                      <a href={`tel:${office.phone}`} className="hover:underline">
                        {office.phone}
                      </a>
                      <a href={`mailto:${office.email}`} className="text-stone-500 hover:text-black">
                        {office.email}
                      </a>
                    </div>

                    <div className="pt-2 border-t border-stone-100">
                      <a
                        href={office.googleMapsUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-stone-800 hover:text-black font-medium"
                      >
                        <span>{t.contactPage.openInMaps}</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Direct Lines */}
            <div className="p-6 bg-[#FAF8F5] border border-[#111111]/10 space-y-2">
              <span className="text-xs uppercase tracking-widest text-[#8E8880] block">
                Permanence du Cabinet
              </span>
              <p className="font-serif text-2xl text-[#111111]">
                +33 4 50 22 18 40
              </p>
              <p className="text-xs text-stone-500">
                Lundi au vendredi : 09h00 – 19h00
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
