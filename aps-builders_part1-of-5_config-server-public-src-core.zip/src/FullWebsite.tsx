/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, useScroll, useSpring, useTransform, AnimatePresence, type Variants } from "motion/react";
import { ArrowRight, Phone, Mail, MapPin, Home, Building2, Hammer, ChevronRight, X, Menu, Briefcase, Users, Target, ShieldCheck, Instagram, Facebook, Linkedin, Plus, Minus, Search, MessageCircle, MessageSquare, Quote, Star, Sparkles, Loader2, Share2, ZoomIn, Play, Pause, Check, Mic, Calendar, Printer, Maximize2, Layers } from "lucide-react";

import ProcessRoadmap from "./components/ProcessRoadmap";
import ProjectPortfolio from "./components/ProjectPortfolio";
import LazyImage from "./components/LazyImage";
import ArchitecturalViewer from "./components/ArchitecturalViewer";
import LeadershipSection from "./components/LeadershipSection";
import PartnerCarousel from "./components/PartnerCarousel";
import VastuConsultant from "./components/VastuConsultant";
// Import components (customizer removed)
import AIChatWidget from "./components/AIChatWidget";
import BackToTop from "./components/BackToTop";
import ProjectMap from "./components/ProjectMap";
import ReviewForm from "./components/ReviewForm";
import SiteVisitForm from "./components/SiteVisitForm";
import MaterialCustomizer, { MaterialType, getMaterialFilter } from "./components/MaterialCustomizer";
import ProjectQRCode from "./components/ProjectQRCode";
import ProjectCostWidget from "./components/ProjectCostWidget";
import ProjectTimeline from "./components/ProjectTimeline";
import ProjectTeam from "./components/ProjectTeam";
import ProjectStructuralSpecs from "./components/ProjectStructuralSpecs";
import ProjectExpandedDetailsModal from "./components/ProjectExpandedDetailsModal";
import RoleInquiryForm from "./components/RoleInquiryForm";
import CareerApplicationForm from "./components/CareerApplicationForm";
import FloorPlanAnnotator from "./components/FloorPlanAnnotator";
import ProjectWeatherWidget from "./components/ProjectWeatherWidget";
import SiteUpdateSubscription from "./components/SiteUpdateSubscription";
import ProjectPrintSummary from "./components/ProjectPrintSummary";
import ProjectROIChart from "./components/ProjectROIChart";
import VoiceGuidedTour from "./components/VoiceGuidedTour";
import ListeningWaveform from "./components/ListeningWaveform";
import ProjectLiveCam from "./components/ProjectLiveCam";
import WhatsAppLeadQualifier from "./components/WhatsAppLeadQualifier";
import CrystalPoint from "./components/CrystalPoint";
import ProjectMilestoneTracker from "./components/ProjectMilestoneTracker";
import MovingBrandBackground from "./components/MovingBrandBackground";
import AnimatedCounter from "./components/AnimatedCounter";
import ComingSoonMarch from "./components/ComingSoonMarch";
import { KineticText } from "@/registry/magicui/kinetic-text";
import { Project, PROJECTS } from "./data/projects";
import confetti from "canvas-confetti";

const ModalScrollProgress = ({ children }: { children: React.ReactNode }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ container: containerRef });
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });

  return (
    <div className="md:w-2/5 md:h-full md:overflow-y-auto" ref={containerRef}>
      <motion.div 
        className="h-1 bg-amber-600 origin-left sticky top-0 z-[40]"
        style={{ scaleX }}
      />
      {children}
    </div>
  );
};

// Staggered Entrance Animation Variants for Project Modal
const modalDialogVariants: Variants = {
  hidden: { opacity: 0, scale: 0.94, y: 24 },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: {
      type: "spring",
      damping: 28,
      stiffness: 320,
      mass: 0.85,
      staggerChildren: 0.06,
      delayChildren: 0.04,
    }
  },
  exit: { 
    opacity: 0, 
    scale: 0.96, 
    y: 16, 
    transition: { duration: 0.18, ease: "easeIn" } 
  }
};

const modalImageVariants: Variants = {
  hidden: { opacity: 0, x: -24, scale: 0.98 },
  visible: {
    opacity: 1,
    x: 0,
    scale: 1,
    transition: {
      type: "spring",
      damping: 26,
      stiffness: 240,
      mass: 0.8,
    }
  }
};

const modalDetailsContainerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
      delayChildren: 0.06,
    }
  }
};

const modalDetailItemVariants: Variants = {
  hidden: { opacity: 0, y: 18 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      type: "spring",
      damping: 24,
      stiffness: 280,
      mass: 0.7,
    }
  }
};

const modalButtonsContainerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.04,
      delayChildren: 0.15,
    }
  }
};

const modalButtonVariants: Variants = {
  hidden: { opacity: 0, y: 14, scale: 0.98 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: "spring",
      damping: 22,
      stiffness: 300,
    }
  }
};

interface Testimonial {
  name: string;
  role: string;
  text: string;
  rating: number;
}

import constructionBg from "./assets/images/construction_with_people_1780827052276.png";
import heroBg from "./assets/images/architect_portrait_about_1780827079505.png";

// Import images for hero slider
import villaImg from "./assets/images/luxury_villa_with_people_1780826940427.png";
import commercialImg from "./assets/images/commercial_plaza_with_people_1780827020678.png";
import estateImg from "./assets/images/residential_estate_with_people_1780827005899.png";
import glassTowerImg from "./assets/images/aps_glass_tower_1780810854036.png";
import sustainableImg from "./assets/images/sustainable_home_with_people_1780826956508.png";
import airportImg from "./assets/images/modern_airport_terminal_kerala_1780827557721.png";
import hotelImg from "./assets/images/boutique_hotel_backwaters_1780827576126.png";
import churchImg from "./assets/images/minimalist_modern_church_kerala_1780827590876.png";
import galleryImg from "./assets/images/contemporary_art_gallery_kochi_1780827605840.png";
import techParkImg from "./assets/images/urban_tech_park_building_1780827618863.png";
import duplexImg from "./assets/images/aps_contemporary_duplex_1780810868582.png";
import officeImg from "./assets/images/panchayath_office_with_people_1780826972320.png";
import educationalImg from "./assets/images/educational_block_with_people_1780826987325.png";
import schoolGateImg from "./assets/images/aps_school_gate_1780811027011.png";
import apartmentImg from "./assets/images/aps_luxury_apartments_1780811619781.png";
import stadiumImg from "./assets/images/modern_stadium_kerala_1780827648443.png";
import poolImg from "./assets/images/luxury_infinity_pool_night_1780827664726.png";
import nalukettuImg from "./assets/images/modern_nalukettu_interior_1780827679869.png";
import libraryImg from "./assets/images/modern_library_interior_1780827694824.png";
import cabinImg from "./assets/images/hillside_modern_cabin_1780827709690.png";
import royalPalaceImg from "./assets/images/royal_palace_modern_mix_1780827876354.png";
import hotelEntranceImg from "./assets/images/luxury_hotel_grand_entrance_1780827890648.png";
import corporateHQImg from "./assets/images/corporate_hq_dawn_1780827906397.png";
import penthouseImg from "./assets/images/luxury_penthouse_interior_1780827920432.png";
import mosqueImg from "./assets/images/modern_mosque_kerala_1780827935955.png";
import museumImg from "./assets/images/contemporary_museum_kerala_night_1780827949977.png";
import wellnessImg from "./assets/images/premium_wellness_retreat_misty_1780827966245.png";
import researchCenterImg from "./assets/images/high_end_research_center_daylight_1780827982226.png";
import villaDroneImg from "./assets/images/luxury_villa_drone_kerala_1780828001461.png";
import highRiseImg from "./assets/images/modern_high_rise_apartments_kochi_1780828016500.png";
import banquetHallImg from "./assets/images/traditional_kerala_modern_hall_1780828030670.png";
import boathouseImg from "./assets/images/luxury_boathouse_reimagined_kerala_1780828051209.png";
import culturalCenterImg from "./assets/images/modern_cultural_center_kerala_1780828070617.png";

const HERO_IMAGES_SOURCE = [
  constructionBg, royalPalaceImg, hotelEntranceImg, corporateHQImg,
  penthouseImg, mosqueImg, museumImg, wellnessImg, researchCenterImg,
  villaDroneImg, highRiseImg, banquetHallImg, boathouseImg, culturalCenterImg,
  villaImg, commercialImg, estateImg, glassTowerImg, sustainableImg,
  airportImg, hotelImg, churchImg, galleryImg, techParkImg, duplexImg,
  officeImg, educationalImg, schoolGateImg, apartmentImg, stadiumImg,
  poolImg, nalukettuImg, libraryImg, cabinImg
];

// Replicating to reach ~100 as requested for the visual slider dots
const HERO_IMAGES = [...HERO_IMAGES_SOURCE, ...HERO_IMAGES_SOURCE, ...HERO_IMAGES_SOURCE];

export default function App() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isExpandedDetailsOpen, setIsExpandedDetailsOpen] = useState(false);
  const [activeProjectTab, setActiveProjectTab] = useState<'details' | 'live'>('details');
  const [modalSubTab, setModalSubTab] = useState<'overview' | 'design' | 'engineering'>('overview');
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialType>('original');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isContactDrawerOpen, setIsContactDrawerOpen] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(0);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNewsletterOpen, setIsNewsletterOpen] = useState(false);
  const [isReviewFormOpen, setIsReviewFormOpen] = useState(false);
  const [isSiteVisitFormOpen, setIsSiteVisitFormOpen] = useState(false);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);
  const [showCrystalPoint, setShowCrystalPoint] = useState(false);
  const [selectedInquiryMember, setSelectedInquiryMember] = useState<{name: string, role: string} | null>(null);
  const [isCareerDrawerOpen, setIsCareerDrawerOpen] = useState(false);
  const [isDesignLabActive, setIsDesignLabActive] = useState(false);
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);
  const [hoveredNav, setHoveredNav] = useState<string | null>(null);
  const [hoveredMobileNav, setHoveredMobileNav] = useState<string | null>(null);
  const [showComingSoon, setShowComingSoon] = useState(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get('preview') === 'true' || params.get('access') === 'preview' || params.get('key') === 'aps2027') {
        sessionStorage.setItem('aps_preview_unlocked', 'true');
        return false;
      }
      if (sessionStorage.getItem('aps_preview_unlocked') === 'true') {
        return false;
      }
    } catch {
      // ignore
    }
    // All other people CAN ONLY see the Coming Soon preview!
    return true;
  });
  const [showVoiceSearchTooltip, setShowVoiceSearchTooltip] = useState(true);
  const [isSearchIconHovered, setIsSearchIconHovered] = useState(false);
  const [activeMilestoneToast, setActiveMilestoneToast] = useState<{
    projectId: string;
    projectTitle: string;
    milestone: string;
    date?: string;
  } | null>(null);

  useEffect(() => {
    const handleMilestoneAlert = (e: any) => {
      if (e.detail) {
        setActiveMilestoneToast(e.detail);
        setTimeout(() => {
          setActiveMilestoneToast(null);
        }, 6000);
      }
    };
    window.addEventListener('aps-milestone-alert-received', handleMilestoneAlert);
    return () => window.removeEventListener('aps-milestone-alert-received', handleMilestoneAlert);
  }, []);

  // WhatsApp Nudge Logic: Auto-open qualifier after 10s of project viewing
  useEffect(() => {
    let nudgeTimer: NodeJS.Timeout;
    
    if (selectedProject && !isWhatsAppModalOpen) {
      nudgeTimer = setTimeout(() => {
        setIsWhatsAppModalOpen(true);
      }, 10000); // 10 second trigger
    }

    return () => clearTimeout(nudgeTimer);
  }, [selectedProject, isWhatsAppModalOpen]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    // Check URL query parameters on load for ?project=projectId
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const projectIdFromUrl = urlParams.get('project');
      if (projectIdFromUrl) {
        const match = PROJECTS.find(p => String(p.id) === projectIdFromUrl || p.title.toLowerCase().includes(projectIdFromUrl.toLowerCase()));
        if (match) {
          setSelectedProject(match);
        }
      }
    } catch (e) {
      console.error("Error reading URL search params:", e);
    }

    // Listen for Service Worker Notification click message events
    const handleServiceWorkerMessage = (event: MessageEvent) => {
      if (event.data?.type === 'NOTIFICATION_OPEN_PROJECT') {
        const pId = event.data.projectId;
        if (pId) {
          const match = PROJECTS.find(p => String(p.id) === String(pId) || p.title.toLowerCase().includes(String(pId).toLowerCase()));
          if (match) {
            setSelectedProject(match);
          }
        }
      }
    };

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', handleServiceWorkerMessage);
    }

    // Listen for in-app open project events from notifications
    const handleCustomOpenProject = (e: any) => {
      const pId = e.detail?.projectId;
      if (pId) {
        const match = PROJECTS.find(p => String(p.id) === String(pId) || p.title.toLowerCase().includes(String(pId).toLowerCase()));
        if (match) {
          setSelectedProject(match);
        }
      }
    };
    window.addEventListener('aps-open-project-modal', handleCustomOpenProject);

    const handleKeyDown = (e: KeyboardEvent) => {
      // Escape key to close drawers, modals, panels, and lightbox
      if (e.key === "Escape") {
        setIsMobileMenuOpen(false);
        setIsContactDrawerOpen(false);
        setIsSearchOpen(false);
        setIsNewsletterOpen(false);
        setIsReviewFormOpen(false);
        setIsSiteVisitFormOpen(false);
        setIsWhatsAppModalOpen(false);
        setShowCrystalPoint(false);
        setSelectedInquiryMember(null);
        setIsCareerDrawerOpen(false);
        setIsDesignLabActive(false);
        setSelectedProject(null);
      }

      // Ctrl + K (or Cmd + K on macOS) to toggle and focus search bar
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setIsSearchOpen(prev => !prev);
        setTimeout(() => {
          const input = document.getElementById("main-project-search-input");
          if (input) {
            (input as HTMLInputElement).focus();
            (input as HTMLInputElement).select();
          }
        }, 80);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener('aps-open-project-modal', handleCustomOpenProject);
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.removeEventListener('message', handleServiceWorkerMessage);
      }
    };
  }, []);

  const [isListening, setIsListening] = useState(false);
  const [language, setLanguage] = useState<'en' | 'ml'>(() => {
    const saved = localStorage.getItem('aps_language');
    return (saved as 'en' | 'ml') || 'en';
  });

  const [langOpacity, setLangOpacity] = useState(1);

  useEffect(() => {
    setLangOpacity(0.15);
    const timer = setTimeout(() => {
      setLangOpacity(1);
    }, 45);
    return () => clearTimeout(timer);
  }, [language]);

  const translations = {
    en: {
      getQuote: "GET A QUOTE",
      services: "Services",
      projects: "Projects",
      map: "Map",
      designHub: "Design Hub",
      careers: "Careers",
      backToHome: "Back to Home",
      designLabActive: "AI Design Lab Active",
      searchPlaceholder: "Search projects...",
      premierBuilders: "Premier Builders & Developers",
      heroTitle: "Crafting Structures That Last.",
      heroSubtitle: "From residential dream homes to massive commercial complexes, APS Builders & Developers delivers excellence in every square foot.",
      ourProjects: "OUR PROJECTS",
      aiDesignLab: "AI DESIGN LAB",
      expertise: "Expertise",
      whatWeBuild: "What We Build",
      servicesDesc: "We leverage modern technology and traditional craftsmanship to provide comprehensive construction and development solutions.",
      legacy: "Our Legacy",
      aboutTitle: "Building Foundations for the Future",
      projectsCompleted: "Projects Completed",
      happyFamilies: "Happy Families",
      yearsExperience: "Years Experience",
      citiesReached: "Cities Reached",
      quickLinks: "Quick Links",
      contact: "Contact",
      newsletter: "Newsletter",
      residentialProjects: "Residential Projects",
      regionalPresence: "Regional Presence",
      joinOurTeam: "Join Our Team",
      aboutUs: "About Us",
      callNow: "Call Now",
      followJourney: "Follow Our Journey",
      privacyPolicy: "Privacy Policy",
      termsOfUse: "Terms of Use",
      copyright: "APS BUILDERS & DEVELOPERS. ALL RIGHTS RESERVED.",
      residentialDev: "Residential Development",
      commercialProjects: "Commercial Projects",
      qualityInfrastructure: "Quality Infrastructure",
      ourLegacy: "Our Legacy",
      viewDetails: "View Details",
      consultation: "Consultation",
      requestCallback: "Request Callback",
      sendMessage: "Send Message",
      preferredTime: "Preferred Time",
      whatsAppCallback: "WhatsApp Callback",
      callbackScheduled: "Callback Scheduled",
      callbackDesc: "A representative will contact you via WhatsApp at your scheduled time.",
      applyNow: "Apply Now",
      portfolioUrl: "Portfolio / Resume Link",
      position: "Position",
      applicationSuccess: "Application Submitted Successfully",
      recruitmentTeam: "Our recruitment team will review your profile."
    },
    ml: {
      getQuote: "ക്വോട്ട് നേടുക",
      services: "സേവനങ്ങൾ",
      projects: "പ്രോജക്റ്റുകൾ",
      map: "മാപ്പ്",
      designHub: "ഡിസൈൻ ഹബ്",
      careers: "കരിയർ",
      backToHome: "തിരികെ ഹോമിലേക്ക്",
      designLabActive: "AI ഡിസൈൻ ലാബ് സജീവം",
      searchPlaceholder: "പ്രോജക്റ്റുകൾ തിരയുക...",
      premierBuilders: "പ്രീമിയർ ബിൽഡേഴ്‌സ് & ഡെവലപ്പർമാർ",
      heroTitle: "നിലനിൽക്കുന്ന നിർമ്മിതികൾ ഒരുക്കുന്നു.",
      heroSubtitle: "റെസിഡൻഷ്യൽ സ്വപ്ന ഭവനങ്ങൾ മുതൽ കൂറ്റൻ കൊമേഴ്സ്യൽ കോംപ്ലക്സുകൾ വരെ, APS ബിൽഡേഴ്‌സ് ഓരോ ചതുരശ്ര അടിയിലും മികവ് നൽകുന്നു.",
      ourProjects: "ഞങ്ങളുടെ പ്രോജക്റ്റുകൾ",
      aiDesignLab: "AI ഡിസൈൻ ലാബ്",
      expertise: "വൈദഗ്ധ്യം",
      whatWeBuild: "ഞങ്ങൾ നിർമ്മിക്കുന്നത്",
      servicesDesc: "സമഗ്രമായ നിർമ്മാണ പരിഹാരങ്ങൾ നൽകുന്നതിന് ഞങ്ങൾ ആധുനിക സാങ്കേതികവിദ്യയും പരമ്പരാഗത നൈപുണ്യവും ഉപയോഗിക്കുന്നു.",
      legacy: "പൈതൃകം",
      aboutTitle: "ഭാവിയിലേക്കുള്ള അടിത്തറ പാകുന്നു",
      projectsCompleted: "പൂർത്തിയാക്കിയ പ്രോജക്റ്റുകൾ",
      happyFamilies: "സന്തുഷ്ട കുടുംബങ്ങൾ",
      yearsExperience: "വർഷത്തെ പരിചയം",
      citiesReached: "പ്രവർത്തന മേഖലകൾ",
      quickLinks: "ദ്രുത ലിങ്കുകൾ",
      contact: "ബന്ധപ്പെടുക",
      newsletter: "വാർത്താക്കുറിപ്പ്",
      residentialProjects: "പാർപ്പിട പദ്ധതികൾ",
      regionalPresence: "പ്രാദേശിക പ്രവർത്തനങ്ങൾ",
      joinOurTeam: "ഞങ്ങളുടെ ടീമിൽ ചേരുക",
      aboutUs: "ഞങ്ങളെക്കുറിച്ച്",
      callNow: "ഇപ്പോൾ വിളിക്കുക",
      followJourney: "ഞങ്ങളെ പിന്തുടരുക",
      privacyPolicy: "സ്വകാര്യതാ നയം",
      termsOfUse: "ഉപയോഗ നിബന്ധനകൾ",
      copyright: "APS ബിൽഡേഴ്‌സ് & ഡെവലപ്പർമാർ. എല്ലാ അവകാശങ്ങളും നിക്ഷിപ്തം.",
      residentialDev: "പാർപ്പിട വികസനം",
      commercialProjects: "കൊമേഴ്സ്യൽ പ്രോജക്റ്റുകൾ",
      qualityInfrastructure: "മികച്ച അടിസ്ഥാന സൗകര്യങ്ങൾ",
      ourLegacy: "ഞങ്ങളുടെ പൈതൃകം",
      viewDetails: "വിശദാംശങ്ങൾ കാണുക",
      consultation: "കൂടിയാലോചന",
      requestCallback: "തിരികെ വിളിക്കാൻ ആവശ്യപ്പെടുക",
      sendMessage: "സന്ദേശം അയക്കുക",
      preferredTime: "അനുയോജ്യമായ സമയം",
      whatsAppCallback: "വാട്സാപ്പ് കോൾബാക്ക്",
      callbackScheduled: "കോൾബാക്ക് ഷെഡ്യൂൾ ചെയ്തു",
      callbackDesc: "നിങ്ങൾ തിരഞ്ഞെടുത്ത സമയത്ത് ഞങ്ങളുടെ പ്രതിനിധി നിങ്ങളെ വാട്സാപ്പ് വഴി ബന്ധപ്പെടും.",
      applyNow: "ഇപ്പോൾ അപേക്ഷിക്കുക",
      portfolioUrl: "പോർട്ട്ഫോളിയോ / റെസ്യൂമെ ലിങ്ക്",
      position: "തസ്തിക",
      applicationSuccess: "അപേക്ഷ വിജയകരമായി സമർപ്പിച്ചു",
      recruitmentTeam: "ഞങ്ങളുടെ റിക്രൂട്ട്‌മെൻ്റ് ടീം നിങ്ങളുടെ പ്രൊഫൈൽ പരിശോധിക്കും."
    }
  };

  const t = (key: keyof typeof translations.en) => translations[language][key];

  useEffect(() => {
    localStorage.setItem('aps_language', language);
  }, [language]);

  // Contact Form State
  const [contactFormData, setContactFormData] = useState(() => {
    try {
      const saved = localStorage.getItem('aps_contact_form_data');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error("Failed to parse saved contact form data", e);
    }
    return {
      name: "",
      email: "",
      phone: "",
      projectType: "",
      details: "",
      preferredTime: "",
      isCallback: false
    };
  });

  useEffect(() => {
    localStorage.setItem('aps_contact_form_data', JSON.stringify(contactFormData));
  }, [contactFormData]);

  const [contactFormErrors, setContactFormErrors] = useState<Record<string, string>>({});
  const [isContactSubmitting, setIsContactSubmitting] = useState(false);
  const [contactSuccess, setContactSuccess] = useState(false);

  const validateContactForm = () => {
    const errors: Record<string, string> = {};
    if (!contactFormData.name.trim()) errors.name = "Name is required";
    
    if (!contactFormData.isCallback) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!contactFormData.email.trim()) {
        errors.email = "Email is required";
      } else if (!emailRegex.test(contactFormData.email)) {
        errors.email = "Invalid email format";
      }
      if (!contactFormData.details.trim()) errors.details = "Project details are required";
    } else {
      if (!contactFormData.preferredTime) errors.preferredTime = "Preferred time is required";
    }

    const phoneRegex = /^\+?[0-9\s-]{10,}$/;
    if (!contactFormData.phone.trim()) {
      errors.phone = "Phone number is required";
    } else if (!phoneRegex.test(contactFormData.phone)) {
      errors.phone = "Invalid phone number format";
    }

    if (!contactFormData.projectType) errors.projectType = "Please select a project type";

    setContactFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const playSuccessSound = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      
      const playTone = (freq: number, startTime: number, duration: number) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, startTime);
        
        gain.gain.setValueAtTime(0, startTime);
        gain.gain.linearRampToValueAtTime(0.12, startTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.start(startTime);
        osc.stop(startTime + duration);
      };

      const now = ctx.currentTime;
      playTone(523.25, now, 0.5);
      playTone(783.99, now + 0.07, 0.5);
      playTone(1046.50, now + 0.14, 0.7);
    } catch (err) {
      console.warn("Audio Context playback ignored or not supported", err);
    }
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateContactForm()) {
      setIsContactSubmitting(true);
      // Simulate API call
      setTimeout(() => {
        setIsContactSubmitting(false);
        setContactSuccess(true);
        playSuccessSound();
        confetti({
          particleCount: 150,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#d97706', '#0f172a', '#ffffff']
        });
        setTimeout(() => {
          setIsContactDrawerOpen(false);
          setContactSuccess(false);
          setContactFormData({
            name: "",
            email: "",
            phone: "",
            projectType: "",
            details: "",
            preferredTime: "",
            isCallback: false
          });
        }, 2000);
      }, 1500);
    }
  };

  const handleVoiceSearch = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setSearchQuery(transcript);
      setIsListening(false);
    };

    recognition.onerror = () => {
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };
  
  const [reviews, setReviews] = useState<Testimonial[]>([
    {
      name: "Rajesh Kumar",
      role: "Business Owner",
      text: "APS Builders transformed our vision into a stunning commercial reality. Their attention to structural integrity and aesthetic detail is unmatched in Kerala's construction landscape.",
      rating: 5
    },
    {
      name: "Anjali Menon",
      role: "Homeowner",
      text: "Building our dream home was a seamless experience with APS. They handled every challenge with professionalism and delivered a week ahead of schedule. Truly Exceptional!",
      rating: 5
    },
    {
      name: "Thomas Varghese",
      role: "Project Consultant",
      text: "I've collaborated with many developers, but APS stands out for their honest communication and commitment to using premium materials without compromise.",
      rating: 5
    }
  ]);
  
  // Project Update Subscription State
  const [projectSubscribed, setProjectSubscribed] = useState(false);
  const [projectSubEmail, setProjectSubEmail] = useState("");
  const [isProjectSubmitting, setIsProjectSubmitting] = useState(false);
  const [currentProjectImageIndex, setCurrentProjectImageIndex] = useState(0);
  const [isSlideshowPlaying, setIsSlideshowPlaying] = useState(true);
  const [isHoveringCarousel, setIsHoveringCarousel] = useState(false);
  const [slideshowKey, setSlideshowKey] = useState(0);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const [activeVideoUrl, setActiveVideoUrl] = useState<string | null>(null);
  const [currentHeroImageIndex, setCurrentHeroImageIndex] = useState(0);
  const { scrollY, scrollYProgress } = useScroll();
  
  const heroY = useTransform(scrollYProgress, [0, 0.3], [0, 150]);
  const heroRotate = useTransform(scrollYProgress, [0, 0.3], [0, 3]);
  const delayedHeroY = useSpring(heroY, { stiffness: 50, damping: 20 });
  const delayedHeroRotate = useSpring(heroRotate, { stiffness: 50, damping: 20 });

  // Scroll Parallax Transforms
  const heroParallaxY = useTransform(scrollY, [0, 800], [0, 160]);
  const heroParallaxScale = useTransform(scrollY, [0, 800], [1.02, 1.15]);
  const heroContentY = useTransform(scrollY, [0, 600], [0, 85]);
  const heroContentOpacity = useTransform(scrollY, [0, 480], [1, 0.15]);
  const scrollIndicatorOpacity = useTransform(scrollY, [0, 150], [1, 0]);

  // Statistics section ambient parallax
  const statsOrbY = useTransform(scrollYProgress, [0.15, 0.45], [-50, 50]);

  // About section parallax
  const aboutBadgeY = useTransform(scrollYProgress, [0.3, 0.6], [30, -30]);
  const aboutImageScale = useTransform(scrollYProgress, [0.3, 0.6], [0.97, 1.03]);

  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    const INACTIVITY_TIME = 30000; // 30 seconds

    const resetTimer = () => {
      clearTimeout(timeout);
      if (!isNewsletterOpen) {
        timeout = setTimeout(() => {
          const hasSeen = localStorage.getItem('aps_newsletter_seen');
          if (!hasSeen) {
            setIsNewsletterOpen(true);
            localStorage.setItem('aps_newsletter_seen', 'true');
          }
        }, INACTIVITY_TIME);
      }
    };

    window.addEventListener('mousemove', resetTimer);
    window.addEventListener('keydown', resetTimer);
    window.addEventListener('click', resetTimer);
    window.addEventListener('scroll', resetTimer);

    resetTimer();

    return () => {
      window.removeEventListener('mousemove', resetTimer);
      window.removeEventListener('keydown', resetTimer);
      window.removeEventListener('click', resetTimer);
      window.removeEventListener('scroll', resetTimer);
      clearTimeout(timeout);
    };
  }, [isNewsletterOpen]);

  // Reset material customizer and reset/start slideshow when project changes
  useEffect(() => {
    if (selectedProject) {
      setSelectedMaterial('original');
      setCurrentProjectImageIndex(0);
      setIsSlideshowPlaying(true);
      setIsHoveringCarousel(false);
      setSlideshowKey(0);
    }
  }, [selectedProject?.id]);

  // Automatic slideshow playback with a 3-second delay between images
  useEffect(() => {
    if (!selectedProject?.images || selectedProject.images.length <= 1) return;
    if (!isSlideshowPlaying || isHoveringCarousel) return;

    const interval = setInterval(() => {
      setCurrentProjectImageIndex((prev) => {
        const nextIdx = (prev + 1) % selectedProject.images!.length;
        if (lightboxImage) {
          setLightboxImage(selectedProject.images![nextIdx]);
        }
        return nextIdx;
      });
      setSlideshowKey((k) => k + 1);
    }, 3000); // 3-second delay between images

    return () => clearInterval(interval);
  }, [selectedProject, isSlideshowPlaying, isHoveringCarousel, currentProjectImageIndex, lightboxImage]);

  // Keyboard navigation for image carousel & lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!selectedProject?.images || selectedProject.images.length <= 1) return;
      if (e.key === "ArrowRight") {
        setCurrentProjectImageIndex((prev) => {
          const next = (prev + 1) % selectedProject.images!.length;
          if (lightboxImage) setLightboxImage(selectedProject.images![next]);
          return next;
        });
        setSlideshowKey((k) => k + 1);
      } else if (e.key === "ArrowLeft") {
        setCurrentProjectImageIndex((prev) => {
          const next = (prev - 1 + selectedProject.images!.length) % selectedProject.images!.length;
          if (lightboxImage) setLightboxImage(selectedProject.images![next]);
          return next;
        });
        setSlideshowKey((k) => k + 1);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedProject, lightboxImage]);

  // Image Preloading Utility for Carousel smooth transitions
  useEffect(() => {
    if (selectedProject?.images && selectedProject.images.length > 0) {
      const nextIndex = (currentProjectImageIndex + 1) % selectedProject.images.length;
      const prevIndex = (currentProjectImageIndex - 1 + selectedProject.images.length) % selectedProject.images.length;
      
      [nextIndex, prevIndex].forEach(index => {
        const img = new Image();
        img.src = selectedProject.images![index];
      });
    }
  }, [selectedProject, currentProjectImageIndex]);

  // Hero Background Slider Logic
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentHeroImageIndex((prev) => (prev + 1) % HERO_IMAGES.length);
    }, 5000);

    // Preload next image
    const nextImg = new Image();
    nextImg.src = HERO_IMAGES[(currentHeroImageIndex + 1) % HERO_IMAGES.length];

    return () => clearInterval(interval);
  }, [currentHeroImageIndex]);

  const isHomeScreenOnly = 
    !selectedProject && 
    !isWhatsAppModalOpen && 
    !isMobileMenuOpen && 
    !isContactDrawerOpen && 
    !isSearchOpen && 
    !isNewsletterOpen && 
    !isReviewFormOpen && 
    !isSiteVisitFormOpen && 
    !showCrystalPoint && 
    !selectedInquiryMember && 
    !isCareerDrawerOpen && 
    !isDesignLabActive && 
    !lightboxImage && 
    !activeVideoUrl;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.3,
      },
    }
  };

  const itemVariants = {
    hidden: { y: 40, opacity: 0, skewY: 2 },
    visible: {
      y: 0,
      opacity: 1,
      skewY: 0,
      transition: { 
        duration: 0.8, 
        ease: [0.16, 1, 0.3, 1] as any
      },
    },
  };

  const maskedTextRevealVariants = {
    hidden: { y: "115%", opacity: 0 },
    visible: {
      y: "0%",
      opacity: 1,
      transition: {
        duration: 0.95,
        ease: [0.16, 1, 0.3, 1] as any,
      },
    },
  };

  const fadeUpVariants = {
    hidden: { opacity: 0, y: 40 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { 
        duration: 0.8, 
        ease: "anticipate" as const
      },
    },
  };

  const iconVariants = {
    hidden: { scale: 0, opacity: 0, rotate: -20 },
    visible: { 
      scale: 1, 
      opacity: 1, 
      rotate: 0,
      transition: { type: "spring" as const, stiffness: 260, damping: 20 }
    },
    hover: { 
      scale: 1.1, 
      rotate: [0, -5, 5, 0],
      transition: { duration: 0.5, ease: "easeInOut" as const }
    }
  };

  return (
    <div className="min-h-screen font-sans selection:bg-amber-100">
      <AnimatePresence>
        {showComingSoon && (
          <motion.div
            key="coming-soon-march-page"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-0 z-[200] overflow-y-auto bg-slate-950"
          >
            <ComingSoonMarch />
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCrystalPoint && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-[#111]"
          >
            <CrystalPoint />
            <button 
              onClick={() => setShowCrystalPoint(false)}
              className="fixed bottom-6 right-6 z-[110] bg-white/10 backdrop-blur-md border border-white/20 text-white px-5 py-2.5 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-white/20 transition-all active:scale-95 flex items-center gap-2"
            >
              <X className="w-3 h-3" /> Exit Experience
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div 
        className="print:hidden"
        animate={{ opacity: langOpacity }}
        transition={{ duration: 0.35, ease: "easeInOut" }}
      >
        {/* Stakeholder Preview Mode Header Banner */}
        {!showComingSoon && (
          <div className="bg-amber-500 text-slate-950 px-4 py-1.5 text-xs font-mono font-bold flex items-center justify-between z-[60] relative">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-slate-950 animate-ping" />
              <span>AUTHORIZED PREVIEW ACTIVE • PUBLIC VISITORS ONLY SEE COMING SOON</span>
            </div>
            <button
              onClick={() => {
                sessionStorage.removeItem('aps_preview_unlocked');
                setShowComingSoon(true);
              }}
              className="bg-slate-950 text-white hover:bg-slate-800 px-3 py-0.5 rounded text-[11px] uppercase tracking-wider transition-colors cursor-pointer"
            >
              Lock Site to Coming Soon Preview
            </button>
          </div>
        )}

        {/* Global Scroll Progress Bar */}
        <div className="fixed top-0 left-0 right-0 h-1 bg-slate-900/10 z-[70] pointer-events-none">
          <motion.div
            className="h-full bg-gradient-to-r from-amber-600 via-amber-400 to-amber-500 origin-left shadow-[0_0_10px_rgba(245,158,11,0.8)]"
            style={{ scaleX }}
          />
        </div>

      {/* Navigation */}
      <nav role="navigation" aria-label="Main Navigation" className="fixed top-0 w-full z-50 bg-white/90 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div 
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                setIsDesignLabActive(false);
              }
            }}
            aria-label="APS Builders and Developers - Return to main view"
            className="font-display font-bold text-2xl tracking-tight text-slate-900 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-sm" 
            onClick={() => setIsDesignLabActive(false)}
          >
            APS<span className="text-amber-600">.</span>
          </div>
          
          {/* Desktop Menu */}
          {!isDesignLabActive && (
            <div className="hidden md:flex items-center gap-10 text-sm font-semibold text-slate-600 uppercase tracking-wider">
              <div className="flex items-center gap-8">
                {[
                  { href: "#services", label: t('services'), id: "nav-services" },
                  { href: "#projects", label: t('projects'), id: "nav-projects" },
                  { href: "#project-map", label: t('map'), id: "nav-map" },
                  { href: "#careers", label: t('careers'), id: "nav-careers" },
                ].map((link) => {
                  const isHovered = hoveredNav === link.href;
                  return (
                    <a
                      key={link.href}
                      id={link.id}
                      href={link.href}
                      aria-label={`Navigate to ${link.label} section`}
                      onMouseEnter={() => setHoveredNav(link.href)}
                      onMouseLeave={() => setHoveredNav(null)}
                      className="relative py-2 text-slate-600 hover:text-amber-600 transition-colors font-semibold text-xs lg:text-sm tracking-wider inline-flex flex-col items-center group focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-sm"
                    >
                      <span>{link.label}</span>
                      <motion.div
                        className="absolute bottom-0 left-0 right-0 h-[2px] bg-amber-600 rounded-full origin-left"
                        initial={{ scaleX: 0, opacity: 0 }}
                        animate={{
                          scaleX: isHovered ? 1 : 0,
                          opacity: isHovered ? 1 : 0,
                        }}
                        transition={{
                          type: "spring",
                          stiffness: 380,
                          damping: 28,
                        }}
                      />
                    </a>
                  );
                })}
              </div>

              <div className="flex items-center gap-4 border-l border-slate-100 pl-8">
                <button
                  onClick={() => {
                    sessionStorage.removeItem('aps_preview_unlocked');
                    setShowComingSoon(true);
                  }}
                  aria-label="Lock Site to Coming Soon Preview"
                  className="hidden xl:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-mono uppercase tracking-wider bg-amber-500/10 text-amber-700 hover:text-amber-950 border border-amber-500/30 hover:bg-amber-500/20 transition-all font-bold cursor-pointer"
                >
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
                  <span>Lock to Preview 🔒</span>
                </button>

                <a 
                  href="tel:7907656700" 
                  aria-label="Call APS Builders at +91 79076 56700"
                  className="flex items-center gap-2 text-amber-600 hover:text-slate-900 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-sm px-1 py-0.5"
                >
                  <Phone className="w-4 h-4" aria-hidden="true" />
                  <span className="font-bold">CALL</span>
                </a>
                
                <div 
                  className="relative flex items-center"
                  onMouseEnter={() => setIsSearchIconHovered(true)}
                  onMouseLeave={() => setIsSearchIconHovered(false)}
                >
                  <AnimatePresence>
                    {isSearchOpen && (
                      <motion.div
                        initial={{ width: 0, opacity: 0 }}
                        animate={{ width: 250, opacity: 1 }}
                        exit={{ width: 0, opacity: 0 }}
                        className="overflow-hidden mr-2"
                      >
                      <div className="relative flex items-center">
                        <input 
                          id="main-project-search-input"
                          type="text"
                          value={isListening ? "Listening... Speak now" : searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder={t('searchPlaceholder') + " (Ctrl+K)"}
                          aria-label="Search architectural projects by name, location, or type"
                          aria-keyshortcuts="Control+k"
                          className={`w-full pl-4 pr-24 py-2 border rounded-sm text-xs outline-none transition-all ${isListening ? 'bg-red-50/50 border-red-200 text-red-600 font-medium' : 'bg-slate-50 border-slate-100 focus:border-amber-600 text-slate-800'}`}
                          autoFocus
                          disabled={isListening}
                        />
                        <div className="absolute right-2 flex items-center gap-1">
                          {isListening && (
                            <ListeningWaveform color="bg-red-500" barCount={4} height="h-4" />
                          )}
                          <button 
                            onClick={handleVoiceSearch}
                            className={`p-1.5 rounded-full transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 ${isListening ? 'text-white bg-red-500 animate-pulse' : 'text-slate-400 hover:text-amber-600 hover:bg-amber-50'}`}
                            title="Voice Search"
                            aria-label={isListening ? "Listening for voice search query... Click to stop" : "Search projects using voice input"}
                            id="header-voice-search-mic-btn"
                          >
                            <Mic className="w-3.5 h-3.5" aria-hidden="true" />
                          </button>
                          {searchQuery && (
                            <button 
                              onClick={() => setSearchQuery("")}
                              aria-label="Clear project search query"
                              className="p-1.5 text-slate-400 hover:text-amber-600 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-full"
                            >
                              <X className="w-3.5 h-3.5" aria-hidden="true" />
                            </button>
                          )}
                        </div>
                      </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                  <button 
                    onClick={() => setIsSearchOpen(!isSearchOpen)}
                    title="Search projects (Ctrl+K)"
                    aria-label={isSearchOpen ? "Close project search input" : "Open project search input (Shortcut: Control+K)"}
                    aria-expanded={isSearchOpen}
                    aria-controls="main-project-search-input"
                    id="header-search-toggle-btn"
                    className={`p-2 rounded-full transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 ${isSearchOpen ? 'text-amber-600 bg-amber-50' : 'text-slate-400 hover:text-amber-600 hover:bg-slate-50'}`}
                  >
                    <Search className="w-5 h-5" aria-hidden="true" />
                  </button>

                  {/* Voice Search Helper Text Tooltip */}
                  <AnimatePresence>
                    {((showVoiceSearchTooltip && !isSearchOpen) || isSearchIconHovered) && (
                      <motion.div
                        initial={{ opacity: 0, y: 6, scale: 0.94 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 4, scale: 0.94 }}
                        transition={{ type: "spring", stiffness: 380, damping: 25 }}
                        className="absolute right-0 top-full mt-2.5 z-40 pointer-events-auto"
                        id="voice-search-helper-tooltip"
                        role="tooltip"
                      >
                        {/* Caret Arrow */}
                        <div className="absolute -top-1.5 right-3.5 w-3 h-3 bg-slate-900 rotate-45 border-l border-t border-slate-700/60" />

                        {/* Tooltip Pill */}
                        <div className="relative bg-slate-900 text-white rounded-lg px-3 py-1.5 shadow-2xl border border-slate-800 flex items-center gap-2 text-[11px] whitespace-nowrap group/tooltip">
                          <div className="w-4 h-4 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                            <Mic className="w-2.5 h-2.5 animate-pulse" aria-hidden="true" />
                          </div>
                          <div 
                            role="button"
                            tabIndex={0}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' || e.key === ' ') {
                                e.preventDefault();
                                setIsSearchOpen(true);
                                handleVoiceSearch();
                              }
                            }}
                            onClick={() => {
                              setIsSearchOpen(true);
                              handleVoiceSearch();
                            }}
                            className="cursor-pointer flex items-center gap-1.5 hover:text-amber-300 transition-colors focus:outline-none focus-visible:underline"
                            title="Click to activate voice search: 'Show me luxury villas'"
                            aria-label="Activate voice search for luxury villas"
                          >
                            <span className="text-slate-400 font-medium">Try saying:</span>
                            <span className="text-amber-400 font-bold tracking-tight group-hover/tooltip:underline">
                              &ldquo;Show me luxury villas&rdquo;
                            </span>
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setShowVoiceSearchTooltip(false);
                            }}
                            className="ml-1 p-0.5 text-slate-400 hover:text-white transition-colors rounded hover:bg-slate-800 focus:outline-none focus-visible:ring-1 focus-visible:ring-white"
                            title="Dismiss hint"
                            aria-label="Dismiss voice search hint"
                          >
                            <X className="w-3 h-3" aria-hidden="true" />
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Dynamic Search Preview Dropdown List */}
                  {isSearchOpen && searchQuery.trim() !== "" && (() => {
                    const query = searchQuery.toLowerCase().trim();
                    const filteredMatches = PROJECTS.filter(project => 
                      project.title.toLowerCase().includes(query) ||
                      project.location.toLowerCase().includes(query) ||
                      project.type.toLowerCase().includes(query) ||
                      (project.description && project.description.toLowerCase().includes(query)) ||
                      (project.status && project.status.toLowerCase().includes(query))
                    );

                    return (
                      <div 
                        role="region" 
                        aria-label="Matching project search results"
                        className="absolute right-0 top-full mt-3 w-[325px] bg-white rounded-lg border border-slate-200/80 shadow-2xl overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-200"
                      >
                        <div className="px-4 py-2 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                          <span className="uppercase tracking-[0.15em] font-bold text-[9px] text-slate-400">
                            Matching Projects ({filteredMatches.length})
                          </span>
                          {filteredMatches.length > 5 && (
                            <span className="text-[9px] font-medium text-slate-400">
                              Showing top 5
                            </span>
                          )}
                        </div>
                        <div className="max-h-[320px] overflow-y-auto divide-y divide-slate-100" role="listbox" aria-label="Projects list">
                          {filteredMatches.length === 0 ? (
                            <div className="px-4 py-6 text-center text-slate-400">
                              <Building2 className="w-8 h-8 mx-auto text-slate-300 stroke-[1.5] mb-2" aria-hidden="true" />
                              <p className="text-xs font-medium">No projects match your search</p>
                            </div>
                          ) : (
                            filteredMatches.slice(0, 5).map(project => (
                              <div
                                key={project.id}
                                role="option"
                                tabIndex={0}
                                aria-selected={selectedProject?.id === project.id}
                                aria-label={`View details for ${project.title}, ${project.location}, status ${project.status}`}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' || e.key === ' ') {
                                    e.preventDefault();
                                    setSelectedProject(project);
                                    setIsSearchOpen(false);
                                    setSearchQuery("");
                                  }
                                }}
                                onClick={() => {
                                  setSelectedProject(project);
                                  setIsSearchOpen(false);
                                  setSearchQuery("");
                                }}
                                className="group p-3 hover:bg-amber-50/40 cursor-pointer flex items-center gap-3 transition-colors focus:outline-none focus:bg-amber-50/60"
                              >
                                {project.image ? (
                                  <img
                                    src={project.image}
                                    alt={`Preview of ${project.title}`}
                                    referrerPolicy="no-referrer"
                                    className="w-10 h-10 rounded-sm object-cover border border-slate-100 flex-shrink-0 animate-fade-in"
                                  />
                                ) : (
                                  <div className="w-10 h-10 bg-amber-50 rounded-sm flex items-center justify-center text-amber-600 flex-shrink-0 border border-amber-100/40">
                                    <Building2 className="w-5 h-5 stroke-[1.5]" aria-hidden="true" />
                                  </div>
                                )}
                                <div className="flex-grow min-w-0">
                                  <div className="flex items-center justify-between gap-1">
                                    <p className="font-bold text-xs text-slate-850 truncate group-hover:text-amber-600 transition-colors">
                                      {project.title}
                                    </p>
                                    <span className={`text-[8px] px-1 py-0.5 rounded-sm font-extrabold uppercase tracking-wide flex-shrink-0 ${
                                      project.status === "Completed" 
                                        ? "bg-green-50 text-green-700 border border-green-100"
                                        : project.status === "Under Construction" 
                                        ? "bg-amber-50 text-amber-700 border border-amber-100"
                                        : "bg-blue-50 text-blue-700 border border-blue-100"
                                    }`}>
                                      {project.status === "Under Construction" ? "Construction" : project.status}
                                    </span>
                                  </div>
                                  <p className="text-[10px] text-slate-400 font-medium tracking-wide flex items-center gap-1 mt-0.5">
                                    <MapPin className="w-2.5 h-2.5 text-slate-300 flex-shrink-0" aria-hidden="true" />
                                    <span className="truncate">{project.location}</span>
                                    <span className="text-slate-200">•</span>
                                    <span className="font-semibold text-amber-600">{project.type}</span>
                                  </p>
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    );
                  })()}
                </div>

                <button 
                  onClick={() => setIsContactDrawerOpen(true)}
                  aria-label="Get a custom construction quote - opens inquiry form"
                  className="bg-slate-900 text-white px-6 py-2.5 rounded-sm hover:bg-amber-600 transition-all font-bold whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                >
                  {t('getQuote')}
                </button>
              </div>
            </div>
          )}

          {isDesignLabActive && (
             <div className="flex items-center gap-6">
                <button 
                  onClick={() => setIsDesignLabActive(false)}
                  aria-label="Exit Design Lab and return to homepage"
                  className="text-slate-500 hover:text-slate-900 font-bold uppercase text-[10px] tracking-widest flex items-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-sm p-1"
                >
                  <ArrowRight className="w-4 h-4 rotate-180" aria-hidden="true" /> {t('backToHome')}
                </button>
                <div className="h-6 w-[1px] bg-slate-100" />
                <div className="flex items-center gap-2 text-amber-500 font-bold uppercase text-[10px] tracking-widest">
                   <Sparkles className="w-3.5 h-3.5" aria-hidden="true" /> {t('designLabActive')}
                </div>
             </div>
          )}

          {/* Mobile Menu Toggle */}
          {!isDesignLabActive && (
            <div className="md:hidden flex items-center gap-4">
               <a 
                 href="tel:7907656700" 
                 className="p-2 text-amber-600 bg-amber-50 rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                 aria-label="Call APS Builders at +91 79076 56700"
               >
                 <Phone className="w-5 h-5" aria-hidden="true" />
               </a>
               <button 
                 className="p-2 text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-sm"
                 onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                 aria-label={isMobileMenuOpen ? "Close navigation menu" : "Open mobile navigation menu"}
                 aria-expanded={isMobileMenuOpen}
               >
                 {isMobileMenuOpen ? <X className="w-8 h-8" aria-hidden="true" /> : <Menu className="w-8 h-8" />}
               </button>
            </div>
          )}
        </div>

        {/* Mobile Menu Overlay */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              role="dialog"
              aria-modal="true"
              aria-label="Mobile Navigation Menu"
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-xl z-[100] md:hidden"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <motion.div
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
                className="absolute top-0 right-0 h-full w-full max-w-sm bg-white shadow-2xl flex flex-col p-8"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between mb-12">
                  <div className="font-display font-bold text-2xl tracking-tight text-slate-900">
                    APS<span className="text-amber-600">.</span>
                  </div>
                  <button 
                    onClick={() => setIsMobileMenuOpen(false)}
                    aria-label="Close navigation menu"
                    className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400 hover:text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                  >
                    <X className="w-8 h-8" aria-hidden="true" />
                  </button>
                </div>

                <div className="flex flex-col space-y-6 text-lg font-bold text-slate-900 uppercase tracking-[0.2em]" role="navigation" aria-label="Mobile Links">
                  {[
                    { href: "#services", label: "Services", id: "mobile-nav-services" },
                    { href: "#projects", label: "Projects", id: "mobile-nav-projects" },
                    { href: "#project-map", label: "Local Presence", id: "mobile-nav-map" },
                    { href: "#careers", label: "Careers", id: "mobile-nav-careers" },
                  ].map((link) => {
                    const isHovered = hoveredMobileNav === link.href;
                    return (
                      <a
                        key={link.href}
                        id={link.id}
                        href={link.href}
                        aria-label={`Navigate to ${link.label} section`}
                        onClick={() => setIsMobileMenuOpen(false)}
                        onMouseEnter={() => setHoveredMobileNav(link.href)}
                        onMouseLeave={() => setHoveredMobileNav(null)}
                        className="relative py-1 inline-block hover:text-amber-600 transition-colors self-start group focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-sm"
                      >
                        <span>{link.label}</span>
                        <motion.div
                          className="absolute bottom-0 left-0 right-0 h-[2px] bg-amber-600 rounded-full origin-left"
                          initial={{ scaleX: 0, opacity: 0 }}
                          animate={{
                            scaleX: isHovered ? 1 : 0,
                            opacity: isHovered ? 1 : 0,
                          }}
                          transition={{
                            type: "spring",
                            stiffness: 350,
                            damping: 25,
                          }}
                        />
                      </a>
                    );
                  })}
                </div>

                <div className="mt-auto space-y-4">
                  <button
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      sessionStorage.removeItem('aps_preview_unlocked');
                      setShowComingSoon(true);
                    }}
                    className="w-full text-left py-3 px-4 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 font-bold text-xs uppercase tracking-wider flex items-center justify-between hover:bg-amber-100 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-600" />
                      <span>Lock Site to Coming Soon Preview</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-amber-600" />
                  </button>

                  <button 
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      setIsContactDrawerOpen(true);
                    }}
                    aria-label="Get a custom construction quote - opens inquiry form"
                    className="w-full bg-slate-900 text-white py-5 rounded-sm font-bold text-center tracking-widest hover:bg-amber-600 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                  >
                    GET A QUOTE
                  </button>
                  <div className="flex items-center justify-between border-t border-slate-100 pt-6">
                     <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Connect with us</p>
                     <div className="flex gap-4">
                        <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Visit APS Builders on Facebook" className="focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded p-0.5">
                          <Facebook className="w-4 h-4 text-slate-400 hover:text-amber-600 cursor-pointer" aria-hidden="true" />
                        </a>
                        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Visit APS Builders on Instagram" className="focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded p-0.5">
                          <Instagram className="w-4 h-4 text-slate-400 hover:text-amber-600 cursor-pointer" aria-hidden="true" />
                        </a>
                        <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="Visit APS Builders on LinkedIn" className="focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded p-0.5">
                          <Linkedin className="w-4 h-4 text-slate-400 hover:text-amber-600 cursor-pointer" aria-hidden="true" />
                        </a>
                     </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <AnimatePresence mode="wait">
        {isDesignLabActive ? (
          <motion.div
            key="design-lab"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="pt-20 min-h-screen bg-slate-950"
          >
            {null}
          </motion.div>
        ) : (
          <motion.div
            key="home-page"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
          >
            {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-20 pb-20 overflow-hidden">
        <motion.div 
          style={{ y: heroParallaxY, scale: heroParallaxScale }}
          className="absolute inset-0 -z-10 bg-slate-950 will-change-transform"
        >
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={currentHeroImageIndex}
              initial={{ opacity: 0, scale: 1.1, filter: "blur(40px)" }}
              animate={{ opacity: 0.85, scale: 1, filter: "blur(0px)" }}
              exit={{ opacity: 0, scale: 1.05, filter: "blur(40px)" }}
              style={{ y: delayedHeroY, rotate: delayedHeroRotate }}
              transition={{ 
                duration: 2.2, 
                ease: [0.33, 1, 0.68, 1],
                opacity: { duration: 1.5 }
              }}
              className="absolute inset-0"
            >
              <motion.img 
                animate={{ 
                  scale: [1, 1.15],
                  x: [0, -10],
                  y: [0, -5]
                }}
                transition={{ 
                  duration: 20, 
                  ease: "linear", 
                  repeat: Infinity, 
                  repeatType: "reverse" 
                }}
                src={HERO_IMAGES[currentHeroImageIndex]} 
                alt="APS Showreel" 
                className="w-full h-full object-cover scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-slate-950/80 via-slate-950/20 to-transparent" />
              <div className="absolute inset-0 bg-amber-900/5 mix-blend-overlay" />
            </motion.div>
          </AnimatePresence>
          
          {/* Slider Progress Indicators - Scaled for many photos */}
          <div className="absolute bottom-10 left-6 z-20 flex flex-col gap-4">
            <div className="flex flex-wrap gap-1.5 max-w-[280px] md:max-w-xl">
              {HERO_IMAGES.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentHeroImageIndex(i)}
                  className={`h-0.5 transition-all duration-1000 rounded-full border-none outline-none ${
                    currentHeroImageIndex === i ? "w-6 bg-amber-600 shadow-[0_0_8px_rgba(217,119,6,0.8)]" : "w-1 bg-white/10 hover:bg-white/30"
                  }`}
                />
              ))}
            </div>
            <div className="text-[10px] font-display font-medium text-white/50 uppercase tracking-[0.3em] flex items-center gap-4">
              <span className="text-amber-500 font-bold">{String(currentHeroImageIndex + 1).padStart(3, '0')}</span>
              <div className="w-12 h-[1px] bg-white/20" />
              <span>{String(HERO_IMAGES.length).padStart(3, '0')} SHOWCASE REEL</span>
            </div>
          </div>
        </motion.div>
        
        {/* Decorative Floating Elements */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <MovingBrandBackground variant="hero" />
          <motion.div 
            animate={{ 
              y: [0, -20, 0],
              rotate: [0, 5, 0]
            }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
            className="absolute top-[20%] right-[10%] w-64 h-64 border border-white/5 rounded-full"
          />
          <motion.div 
            animate={{ 
              y: [0, 30, 0],
              x: [0, 20, 0],
              rotate: [0, -10, 0]
            }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
            className="absolute bottom-[20%] left-[5%] w-96 h-96 border border-amber-600/10 rounded-full"
          />
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.1 }}
            transition={{ delay: 1, duration: 2 }}
            className="absolute top-1/2 left-1/4 w-[1px] h-full bg-gradient-to-b from-transparent via-white to-transparent" 
          />
        </div>
        
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          style={{ y: heroContentY, opacity: heroContentOpacity }}
          className="max-w-7xl mx-auto px-6 w-full will-change-transform"
        >
          <div className="max-w-3xl space-y-8">
            <div className="flex flex-col gap-4 select-none">
              <div className="overflow-hidden">
                <motion.div 
                  variants={maskedTextRevealVariants} 
                  className="inline-flex self-start items-center gap-2 px-4 py-1.5 bg-amber-600 text-white rounded-sm text-xs font-bold tracking-[0.2em] uppercase shadow-md"
                >
                  {t('premierBuilders')}
                </motion.div>
              </div>
              
              <div className="overflow-hidden py-1">
                <motion.div variants={maskedTextRevealVariants}>
                  <KineticText
                    text="APS BUILDERS & DEVELOPERS"
                    className="text-2xl sm:text-3xl md:text-5xl lg:text-6xl text-amber-500 font-black tracking-tight uppercase"
                  />
                </motion.div>
              </div>
            </div>
            
            {/* Masked Container Text-Reveal for Title */}
            <div className="overflow-hidden py-1">
              <motion.h1 
                variants={maskedTextRevealVariants} 
                className="font-display text-5xl lg:text-8xl font-bold leading-[1.08] text-white tracking-tight will-change-transform"
              >
                {language === 'ml' ? (
                  <span className="block">
                    അവിസ്മരണീയമായ <span className="text-amber-500">നിർമ്മിതികൾ</span>
                  </span>
                ) : (
                  <span className="block">
                    Crafting <span className="text-amber-500">Structures</span> That Last.
                  </span>
                )}
              </motion.h1>
            </div>
            
            <div className="overflow-hidden py-0.5">
              <motion.p 
                variants={maskedTextRevealVariants} 
                className="text-xl text-slate-200 max-w-xl leading-relaxed will-change-transform"
              >
                {t('heroSubtitle')}
              </motion.p>
            </div>
            
            <motion.div variants={itemVariants} className="flex flex-wrap items-center gap-6 pt-4">
              <button 
                onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
                className="flex items-center gap-3 bg-white text-slate-900 px-10 py-5 rounded-sm font-bold hover:bg-amber-600 hover:text-white transition-all group scale-100 hover:scale-105 active:scale-95 shadow-xl"
              >
                {t('ourProjects')} <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <div className="hidden lg:flex items-center gap-6 pl-4 border-l border-white/10">
                <a href="tel:7907656700" className="flex items-center gap-2 text-white font-semibold hover:text-amber-500 transition-colors">
                  <Phone className="w-5 h-5" /> <span>79076 56700</span>
                </a>
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* Floating Scroll Down Indicator */}
        <motion.div 
          style={{ opacity: scrollIndicatorOpacity }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 pointer-events-none"
        >
          <span className="text-[10px] uppercase font-bold tracking-[0.25em] text-white/60">Scroll to Explore</span>
          <div className="w-5 h-8 border border-white/30 rounded-full flex justify-center pt-1.5 backdrop-blur-xs">
            <motion.div 
              animate={{ y: [0, 10, 0], opacity: [1, 0.3, 1] }}
              transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
              className="w-1 h-1.5 bg-amber-500 rounded-full"
            />
          </div>
        </motion.div>
      </section>

      {/* Moving Brand Background Strip */}
      <MovingBrandBackground variant="ambient" />

      {/* Services Section */}
      <section id="services" className="py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
            className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8"
          >
            <motion.div variants={fadeUpVariants} className="space-y-4">
              <h2 className="text-amber-600 font-bold tracking-widest uppercase text-sm">{t('expertise')}</h2>
              <h3 className="font-display text-4xl lg:text-5xl font-bold text-slate-900">{t('whatWeBuild')}</h3>
            </motion.div>
            <motion.p variants={fadeUpVariants} className="text-slate-500 max-w-md leading-relaxed">
              {t('servicesDesc')}
            </motion.p>
          </motion.div>

          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.1 }}
            variants={containerVariants}
            className="grid md:grid-cols-3 gap-12"
          >
            {[
              { 
                icon: <Home className="w-10 h-10" />, 
                title: t('residentialDev'), 
                desc: language === 'ml' 
                  ? "അത്യാധുനിക സൗകര്യങ്ങളോടെയുള്ള ലക്ഷ്വറി വീടുകളും റെസിഡൻഷ്യൽ ടൗൺഷിപ്പുകളും ഞങ്ങൾ രൂപകൽപ്പന ചെയ്യുന്നു."
                  : "Designing and building customized luxury homes and residential townships with a focus on comfort.",
                details: language === 'ml'
                  ? "മികച്ച ആർക്കിടെക്ചറൽ പ്ലാനിംഗ്, വാസ്തു അധിഷ്ഠിത ഡിസൈനുകൾ, പ്രീമിയം ഇൻ്റീരിയർ ഫിനിഷുകൾ എന്നിവയിൽ ഞങ്ങൾ വൈദഗ്ദ്ധ്യം നേടിയിട്ടുണ്ട്."
                  : "We specialize in personalized architectural planning, Vastu-compliant designs, and premium interior finishes. Our team ensures every detail reflects your lifestyle.",
                packages: [
                  { name: "Premium Villa", price: "Starting ₹3500/sq.ft" },
                  { name: "Luxury Estate", price: "Starting ₹5500/sq.ft" }
                ],
                accent: "bg-blue-50 text-blue-600"
              },
              { 
                icon: <Building2 className="w-10 h-10" />, 
                title: t('commercialProjects'), 
                desc: language === 'ml'
                  ? "കാര്യക്ഷമതയോടെ രൂപകൽപ്പന ചെയ്ത ഇന്നൊവേറ്റീവ് ഓഫീസുകൾ, റീട്ടെയിൽ സെൻ്ററുകൾ, ഇൻഡസ്ട്രിയൽ സൗകര്യങ്ങൾ എന്നിവ ഒരുക്കുന്നു."
                  : "Innovative office spaces, retail centers, and industrial facilities engineered for efficiency.",
                details: language === 'ml'
                  ? "കോർപ്പറേറ്റ് ടവറുകൾ മുതൽ റീട്ടെയിൽ സ്പേസുകൾ വരെ, ആധുനിക ബിസിനസ് ആവശ്യങ്ങൾക്കനുസൃതമായി ഞങ്ങൾ നിർമ്മിതികൾ ഒരുക്കുന്നു."
                  : "From high-rise corporate towers to boutique retail spaces, we deliver structures optimized for modern business needs and maximum footfall.",
                packages: [
                  { name: "Office Shell", price: "Starting ₹4200/sq.ft" },
                  { name: "Full Fit-out", price: "Starting ₹6800/sq.ft" }
                ],
                accent: "bg-amber-50 text-amber-600"
              },
              { 
                icon: <Hammer className="w-10 h-10" />, 
                title: t('qualityInfrastructure'), 
                desc: language === 'ml'
                  ? "റോഡുകൾ, പാലങ്ങൾ, നഗര വികസന പദ്ധതികൾ എന്നിവയിലുള്ള മികച്ച ഇൻഫ്രാസ്ട്രക്ചർ വൈദഗ്ദ്ധ്യം."
                  : "Specialized infrastructure development including roads, bridges, and urban utility planning.",
                details: language === 'ml'
                  ? "സാങ്കേതിക തികവോടെയുള്ള നഗര നിർമ്മാണം. ഗവൺമെൻ്റ് കരാറുകളും പ്രൈവറ്റ് ഇൻഫ്രാസ്ട്രക്ചർ സംരംഭങ്ങളും സുരക്ഷാ മാനദണ്ഡങ്ങൾ പാലിച്ച് ചെയ്യുന്നു."
                  : "Building the backbone of modern cities with engineering precision. We handle government contracts and private infrastructure ventures with strict compliance.",
                packages: [
                  { name: "Urban Utility", price: "Custom Quote" },
                  { name: "Civic Structures", price: "Budget Responsive" }
                ],
                accent: "bg-slate-100 text-slate-900"
              },
            ].map((service, idx) => (
              <motion.div 
                key={idx}
                variants={itemVariants}
                whileHover="hover"
                className="group relative h-[420px] bg-white rounded-sm border border-slate-100 overflow-hidden perspective-1000"
              >
                {/* Default View */}
                <div className="absolute inset-0 p-8 flex flex-col transition-all duration-500 group-hover:opacity-0 group-hover:scale-95 group-hover:-translate-y-4">
                  <motion.div 
                    variants={iconVariants}
                    className={`w-16 h-16 ${service.accent} flex items-center justify-center rounded-sm mb-8`}
                  >
                    {service.icon}
                  </motion.div>
                  <h4 className="font-display font-bold text-2xl text-slate-900 mb-4">{service.title}</h4>
                  <p className="text-slate-600 leading-relaxed text-sm mb-6">{service.desc}</p>
                  
                  <div className="mt-auto flex items-center gap-2 text-amber-600 font-bold text-xs uppercase tracking-widest translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all">
                    {t('viewDetails')} <ArrowRight className="w-4 h-4" />
                  </div>
                </div>

                {/* Hover/Revealed View */}
                <div className="absolute inset-0 p-8 bg-slate-900 text-white flex flex-col translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out z-20">
                  <div className="flex justify-between items-start mb-6">
                    <motion.div 
                      variants={iconVariants}
                      className="text-amber-500"
                    >
                      {service.icon}
                    </motion.div>
                    <div className="bg-amber-600/20 text-amber-500 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border border-amber-600/30">
                      Pro Grade
                    </div>
                  </div>
                  
                  <h4 className="font-display font-bold text-xl mb-4 text-white uppercase tracking-tight">{service.title}</h4>
                  <p className="text-slate-400 text-xs leading-relaxed mb-8">{service.details}</p>
                  
                  <div className="space-y-4 mb-8">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-2">Estimate Packages</div>
                    {service.packages.map((pkg, pIdx) => (
                      <div key={pIdx} className="flex justify-between items-center border-b border-white/10 pb-2">
                        <span className="text-xs font-semibold text-slate-200">{pkg.name}</span>
                        <span className="text-[10px] font-mono text-amber-500">{pkg.price}</span>
                      </div>
                    ))}
                  </div>

                  <button className="mt-auto w-full py-3 bg-amber-600 text-white font-bold text-[10px] uppercase tracking-[0.2em] rounded-sm hover:bg-white hover:text-slate-900 transition-colors">
                    {t('consultation')}
                  </button>
                </div>
                
                {/* Visual Decoration */}
                <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-slate-50 rounded-full opacity-50 transition-transform group-hover:scale-[3] duration-700" />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-24 bg-slate-900 text-white relative overflow-hidden">
        <motion.div 
          style={{ y: statsOrbY }}
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1 }}
          className="absolute inset-0 bg-amber-600/10 rotate-12 translate-x-1/2 translate-y-1/2 rounded-full blur-3xl pointer-events-none will-change-transform" 
        />
        <motion.div 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          variants={containerVariants}
          className="max-w-7xl mx-auto px-6 grid grid-cols-2 lg:grid-cols-4 gap-12 text-center text-slate-300 relative z-10"
        >
          <motion.div variants={fadeUpVariants}>
            <div className="text-5xl font-display font-bold text-amber-500 mb-2">
              <AnimatedCounter to={150} suffix="+" />
            </div>
            <div className="text-xs font-bold uppercase tracking-widest text-slate-400">{t('projectsCompleted')}</div>
          </motion.div>
          <motion.div variants={fadeUpVariants}>
            <div className="text-5xl font-display font-bold text-amber-500 mb-2">
              <AnimatedCounter to={15} suffix="k+" />
            </div>
            <div className="text-xs font-bold uppercase tracking-widest text-slate-400">{t('happyFamilies')}</div>
          </motion.div>
          <motion.div variants={fadeUpVariants}>
            <div className="text-5xl font-display font-bold text-amber-500 mb-2">
              <AnimatedCounter to={25} suffix="+" />
            </div>
            <div className="text-xs font-bold uppercase tracking-widest text-slate-400">{t('yearsExperience')}</div>
          </motion.div>
          <motion.div variants={fadeUpVariants}>
            <div className="text-5xl font-display font-bold text-amber-500 mb-2">
              <AnimatedCounter to={12} suffix="+" />
            </div>
            <div className="text-xs font-bold uppercase tracking-widest text-slate-400">{t('citiesReached')}</div>
          </motion.div>
        </motion.div>
      </section>

      <PartnerCarousel />

      {/* About Section */}
      <section id="about" className="py-32 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-20 items-center">
            <div className="lg:w-1/2 relative">
              <motion.div 
                style={{ scale: aboutImageScale }}
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                className="aspect-square bg-slate-100 rounded-sm overflow-hidden relative shadow-2xl will-change-transform"
              >
                <LazyImage 
                  src={heroBg} 
                  alt="Founder of APS Builders" 
                  className="w-full h-full"
                />
                <div className="absolute inset-0 bg-amber-600/10" />
              </motion.div>
              <motion.div 
                style={{ y: aboutBadgeY }}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="absolute -bottom-10 -right-10 hidden md:block bg-amber-600 p-10 text-white rounded-sm shadow-2xl max-w-[200px] z-10 will-change-transform"
              >
                <div className="text-4xl font-bold mb-2">25+</div>
                <div className="text-xs uppercase font-bold tracking-widest leading-tight">Years of Architectural Excellence</div>
              </motion.div>
            </div>
            
            <div className="lg:w-1/2 space-y-8">
              <motion.div 
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={containerVariants}
                className="space-y-8"
              >
                <motion.div variants={fadeUpVariants} className="space-y-4">
                  <h2 className="text-amber-600 font-bold tracking-widest uppercase text-sm">{t('ourLegacy')}</h2>
                  <h3 className="font-display text-4xl lg:text-5xl font-bold text-slate-900">{t('aboutTitle')}</h3>
                </motion.div>
              
                <motion.div variants={fadeUpVariants} className="space-y-6 text-slate-600 leading-relaxed">
                  <p>
                    {language === 'ml' 
                      ? "കേരളത്തിൻ്റെ ആകാശരൂപങ്ങൾ പുനർനിർവചിക്കുക എന്ന ലക്ഷ്യത്തോടെ സ്ഥാപിതമായ APS ബിൽഡേഴ്‌സ് & ഡെവലപ്പർമാർ ഇന്ന് നിർമ്മാണ രംഗത്തെ പ്രമുഖ ശക്തിയായി വളർന്നു. ഒരു കെട്ടിടം വെറുമൊരു ഘടന മാത്രമല്ല, മറിച്ച് ഗുണനിലവാരത്തോടും നൂതനത്വത്തോടും വിശ്വാസത്തോടുമുള്ള ഞങ്ങളുടെ പ്രതിബദ്ധതയുടെ തെളിവുമാണെന്ന് ഞങ്ങൾ വിശ്വസിക്കുന്നു."
                      : "Founded with a vision to redefine the skyline of Kerala, APS Builders & Developers has grown into a premier construction powerhouse. We believe that a building is not just a structure, but a testament to our commitment to quality, innovation, and trust."}
                  </p>
                  <p>
                    {language === 'ml'
                      ? "കൃത്യമായ ആസൂത്രണം മുതൽ അവസാന മിനുക്കുപണികൾ വരെ, ഞങ്ങളുടെ വിദഗ്ധ സംഘം ഓരോ പ്രോജക്റ്റും അന്താരാഷ്ട്ര നിലവാരത്തിൽ പൂർത്തിയാക്കുന്നു. ഒപ്പം നമ്മുടെ തനിമ നിലനിർത്താനും ഞങ്ങൾ ശ്രദ്ധിക്കുന്നു."
                      : "From meticulous planning to the final finishing touch, our team of experts ensures that every project meets the highest standards of international architecture while staying true to our local roots."}
                  </p>
                </motion.div>

                <motion.div variants={fadeUpVariants} className="grid sm:grid-cols-2 gap-8 pt-6">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-slate-900 text-amber-500 rounded-sm flex items-center justify-center shrink-0">
                      <Target className="w-6 h-6" />
                    </div>
                    <div>
                      <h5 className="font-bold text-slate-900 mb-1">Our Mission</h5>
                      <p className="text-xs text-slate-500">To deliver exceptional living spaces that prioritize comfort and sustainability.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-slate-900 text-amber-500 rounded-sm flex items-center justify-center shrink-0">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <div>
                      <h5 className="font-bold text-slate-900 mb-1">Quality First</h5>
                      <p className="text-xs text-slate-500">Every brick laid is backed by our guarantee of durability and precision.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-slate-900 text-amber-500 rounded-sm flex items-center justify-center shrink-0">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <div>
                      <h5 className="font-bold text-slate-900 mb-1">Deep Innovation</h5>
                      <p className="text-xs text-slate-500">Utilizing AI and modular tech to accelerate high-precision construction.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-slate-900 text-amber-500 rounded-sm flex items-center justify-center shrink-0">
                      <Home className="w-6 h-6" />
                    </div>
                    <div>
                      <h5 className="font-bold text-slate-900 mb-1">Vastu Integrity</h5>
                      <p className="text-xs text-slate-500">Harmonizing modern blueprints with time-tested Vedic spatial science.</p>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      <LeadershipSection />

      <div id="vastu">
        <VastuConsultant />
      </div>

      {/* Featured Projects Section */}
      <div id="portfolio">
        <ProjectPortfolio 
          onSelectProject={setSelectedProject} 
          onLaunchExperience={(id) => id === 'crystal-point' && setShowCrystalPoint(true)}
          initialSearchQuery={searchQuery}
          onSearchQueryChange={setSearchQuery}
        />
      </div>

      {/* Process Section */}
      <ProcessRoadmap />

      {/* Testimonials Section */}
      <motion.section 
        initial={{ opacity: 0, y: 35 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15, margin: "-40px 0px" }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="py-32 bg-slate-50 overflow-hidden border-y border-slate-100"
      >
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUpVariants}
              className="lg:w-1/3 space-y-6"
            >
              <div className="space-y-4">
                <h2 className="text-amber-600 font-bold tracking-widest uppercase text-sm">Testimonials</h2>
                <h3 className="font-display text-4xl lg:text-5xl font-bold text-slate-900 leading-tight">
                  What Our Clients <span className="text-amber-600">Say</span>
                </h3>
              </div>
              <p className="text-slate-500 text-lg">
                Building trust through transparency and exceptional quality. Read about the experiences of those we've worked with.
              </p>
              <div className="flex gap-4 pt-4">
                <button 
                  onClick={() => setActiveTestimonial((prev) => (prev - 1 + reviews.length) % reviews.length)}
                  className="w-12 h-12 rounded-full border border-slate-200 flex items-center justify-center text-slate-400 hover:text-amber-600 hover:border-amber-600 transition-all bg-white"
                >
                  <ChevronRight className="w-5 h-5 rotate-180" />
                </button>
                <button 
                  onClick={() => setActiveTestimonial((prev) => (prev + 1) % reviews.length)}
                  className="w-12 h-12 rounded-full border border-slate-200 flex items-center justify-center text-slate-400 hover:text-amber-600 hover:border-amber-600 transition-all bg-white"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              <div className="pt-8">
                 <button 
                   onClick={() => setIsReviewFormOpen(true)}
                   className="px-6 py-3 bg-slate-900 text-white font-bold uppercase tracking-widest text-[10px] hover:bg-amber-600 transition-all flex items-center gap-2"
                 >
                   <Sparkles className="w-3.5 h-3.5" /> Submit Your Review
                 </button>
              </div>
            </motion.div>

            <div className="lg:w-2/3 relative">
              <div className="relative h-[400px] flex items-center">
                <AnimatePresence mode="wait">
                  {reviews.map((t, i) => i === activeTestimonial && (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: 50 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -50 }}
                      className="absolute inset-0 bg-white p-8 lg:p-16 rounded-sm border border-slate-100 flex flex-col justify-center shadow-lg shadow-slate-200/50"
                    >
                      {/* Animated Quote Mark */}
                      <motion.div
                        initial={{ scale: 0, rotate: -45 }}
                        whileInView={{ scale: 1, rotate: 0 }}
                        transition={{ 
                          type: "spring", 
                          stiffness: 260, 
                          damping: 20,
                          delay: 0.2 
                        }}
                        className="absolute top-8 left-8"
                      >
                        <Quote className="w-16 h-16 text-amber-600/10" />
                      </motion.div>

                      <div className="flex gap-1 mb-6">
                        {[...Array(t.rating)].map((_, starIdx) => (
                          <motion.div
                            key={starIdx}
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ delay: 0.3 + (starIdx * 0.1) }}
                          >
                            <Star className="w-4 h-4 text-amber-600 fill-amber-600" />
                          </motion.div>
                        ))}
                      </div>
                      <p className="text-slate-700 text-xl lg:text-2xl font-display font-medium leading-relaxed mb-8 italic relative z-10">"{t.text}"</p>
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center text-amber-600 font-bold">
                          {t.name[0]}
                        </div>
                        <div>
                          <h4 className="font-bold text-slate-900 uppercase tracking-widest text-sm">{t.name}</h4>
                          <p className="text-xs font-bold text-amber-600 uppercase tracking-tighter">{t.role}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
              
              <div className="flex gap-2 mt-8 lg:justify-start justify-center">
                {reviews.map((_, i) => (
                  <button 
                    key={i}
                    onClick={() => setActiveTestimonial(i)}
                    className={`h-1.5 transition-all duration-500 rounded-full ${activeTestimonial === i ? 'w-12 bg-amber-600' : 'w-4 bg-slate-200'}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* FAQ Section */}
      <motion.section 
        id="faq" 
        initial={{ opacity: 0, y: 35 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15, margin: "-40px 0px" }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="py-32 bg-white overflow-hidden"
      >
        <div className="max-w-3xl mx-auto px-6">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUpVariants}
            className="text-center mb-16 space-y-4"
          >
            <h2 className="text-amber-600 font-bold tracking-widest uppercase text-sm">Knowledge Base</h2>
            <h3 className="font-display text-4xl font-bold text-slate-900">Frequently Asked Questions</h3>
          </motion.div>

          <div className="space-y-4">
            {[
              { q: "What types of construction do you specialize in?", a: "We specialize in residential villas, luxury homes, commercial office spaces, and public infrastructure projects." },
              { q: "How long does a typical residential project take?", a: "Timeline varies based on scale, but most residential projects are completed within 12-18 months from ground-breaking." },
              { q: "Do you offer property management services?", a: "Yes, we provide comprehensive post-construction management and maintenance services for our developments." },
              { q: "What is your approach to sustainable building?", a: "We integrate eco-friendly materials, energy-efficient designs, and waste reduction strategies into all our project lifecycles." }
            ].map((item, idx) => (
              <motion.div 
                key={idx}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUpVariants}
                transition={{ delay: idx * 0.1 }}
                className={`group border rounded-sm transition-all duration-300 ${activeFaq === idx ? 'border-amber-600 bg-amber-50/30' : 'border-slate-100 bg-white hover:border-slate-200'}`}
              >
                <button 
                  onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                  className="w-full flex items-center justify-between p-6 text-left"
                >
                  <span className={`font-display font-bold text-lg transition-colors ${activeFaq === idx ? 'text-amber-600' : 'text-slate-900 group-hover:text-amber-600'}`}>
                    {item.q}
                  </span>
                  <div className={`shrink-0 ml-4 transition-transform duration-300 ${activeFaq === idx ? 'rotate-180' : ''}`}>
                    {activeFaq === idx ? (
                      <Minus className="w-5 h-5 text-amber-600" />
                    ) : (
                      <Plus className="w-5 h-5 text-slate-400 group-hover:text-amber-600" />
                    )}
                  </div>
                </button>
                
                <AnimatePresence>
                  {activeFaq === idx && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: "easeInOut" }}
                      className="overflow-hidden"
                    >
                      <div className="px-6 pb-6 pt-0">
                        <div className="h-px bg-amber-100 mb-6" />
                        <p className="text-slate-500 leading-relaxed text-sm">
                          {item.a}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* Careers Section */}
      <motion.section 
        id="careers" 
        initial={{ opacity: 0, y: 35 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15, margin: "-40px 0px" }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="py-32 bg-slate-50 overflow-hidden"
      >
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-16">
            <div className="lg:w-1/3">
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUpVariants}
                className="space-y-6 sticky top-32"
              >
                <div className="space-y-4">
                  <h2 className="text-amber-600 font-bold tracking-widest uppercase text-sm">Join Our Team</h2>
                  <h3 className="font-display text-4xl lg:text-5xl font-bold text-slate-900 leading-tight">
                    Our Commitment to <span className="text-amber-600">Community Growth</span>
                  </h3>
                </div>
                <p className="text-slate-600 text-lg leading-relaxed">
                  At APS, we believe that building better structures starts with building better teams. We're looking for passionate individuals who want to make a lasting impact on the landscapes we transform.
                </p>
                <button 
                  onClick={() => setIsCareerDrawerOpen(true)}
                  className="bg-slate-900 text-white px-10 py-5 rounded-sm hover:bg-amber-600 transition-all font-bold uppercase tracking-widest text-sm inline-flex items-center gap-3 group"
                >
                  {t('joinOurTeam')} <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </motion.div>
            </div>

            <div className="lg:w-2/3 grid sm:grid-cols-2 gap-6">
              {[
                { title: "Collaborative Culture", desc: "We foster an environment where every voice is heard and every idea counts.", icon: Users },
                { title: "Professional Growth", desc: "Continuous learning and development opportunities for every team member.", icon: Target },
                { title: "Innovation Driven", desc: "Access to the latest tools and technologies in the construction industry.", icon: Hammer },
                { title: "Sustainable Focus", desc: "Commitment to eco-friendly practices that benefit our local communities.", icon: Building2 }
              ].map((value, idx) => (
                <motion.div
                  key={idx}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeUpVariants}
                  transition={{ delay: idx * 0.1 }}
                  className="bg-white p-8 rounded-sm border border-slate-200 shadow-sm hover:shadow-md transition-shadow group"
                >
                  <div className="w-12 h-12 bg-slate-50 text-amber-600 rounded-sm mb-6 flex items-center justify-center group-hover:bg-amber-600 group-hover:text-white transition-colors">
                    <value.icon className="w-6 h-6" />
                  </div>
                  <h4 className="font-display font-bold text-xl text-slate-900 mb-3">{value.title}</h4>
                  <p className="text-slate-500 text-sm leading-relaxed">{value.desc}</p>
                </motion.div>
              ))}
              
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUpVariants}
                className="sm:col-span-2 bg-slate-900 p-8 rounded-sm overflow-hidden relative group min-h-[200px] flex items-center"
              >
                <div className="relative z-10 space-y-2">
                  <h4 className="text-white font-display text-2xl font-bold">Ready to make an impact?</h4>
                  <p className="text-slate-300 text-sm max-w-lg">Send your CV and portfolio to our recruitment team and let's build the future together.</p>
                </div>
                <div className="absolute right-[-20px] top-[-20px] opacity-10 group-hover:scale-110 transition-transform duration-500">
                  <Briefcase className="w-48 h-48 text-white stroke-[1px]" />
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Regional Map Section */}
      <ProjectMap onSelectProject={setSelectedProject} />

      {/* Sustainable Future Section */}
      <motion.section 
        initial={{ opacity: 0, y: 35 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15, margin: "-40px 0px" }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="py-32 bg-slate-900 text-white overflow-hidden relative"
      >
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-10 pointer-events-none">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,100 L100,0 L100,100 Z" fill="currentColor" />
          </svg>
        </div>
        
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div className="space-y-4">
                <h3 className="text-amber-500 font-bold uppercase tracking-[0.3em] text-sm">Eco-Conscious Building</h3>
                <h2 className="font-display text-4xl lg:text-6xl font-bold leading-tight">Engineering a <span className="italic text-amber-500">Sustainable</span> Tomorrow</h2>
              </div>
              
              <p className="text-slate-400 text-lg leading-relaxed">
                We don't just build for today; we engineer for generations. Our construction philosophy merges ancient wisdom with futuristic energy technology to create zero-impact environments.
              </p>

              <motion.div 
                variants={containerVariants}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                className="grid sm:grid-cols-2 gap-6 pt-4"
              >
                {[
                  { title: "Solar Integration", desc: "Every project is optimized for maximum solar energy capture and storage." },
                  { title: "Rainwater Harvesting", desc: "Advanced filtration systems integrated into foundational structures." },
                  { title: "Smart Automation", desc: "AI-driven utility management to reduce carbon footprints by up to 40%." },
                  { title: "Ethical Sourcing", desc: "100% of our materials are sourced from verified sustainable partners." }
                ].map((item, i) => (
                  <motion.div 
                    key={i} 
                    variants={fadeUpVariants}
                    className="space-y-2 p-4 bg-white/5 border border-white/10 rounded-sm hover:border-amber-500/50 transition-colors group"
                  >
                    <Check className="w-5 h-5 text-amber-500 group-hover:scale-120 transition-transform" />
                    <h4 className="font-bold text-sm uppercase tracking-widest">{item.title}</h4>
                    <p className="text-xs text-slate-500 leading-normal">{item.desc}</p>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative aspect-square"
            >
              <div className="absolute inset-0 border border-amber-600/30 rounded-full animate-[spin_20s_linear_infinite] opacity-20" />
              <div className="absolute inset-4 border border-white/10 rounded-full animate-[spin_15s_linear_infinite_reverse] opacity-10" />
              <LazyImage 
                src={sustainableImg} 
                alt="Sustainable Architecture" 
                className="w-full h-full rounded-sm grayscale hover:grayscale-0 transition-all duration-700 shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-amber-600 p-8 rounded-sm shadow-2xl">
                 <div className="text-xs font-bold uppercase tracking-[0.2em] mb-1">Eco-Rating</div>
                 <div className="text-4xl font-black italic">A+++</div>
              </div>
            </motion.div>
          </div>
        </div>
      </motion.section>

          </motion.div>
        )}
      </AnimatePresence>

      <motion.footer 
        id="contact" 
        initial={{ opacity: 0, y: 35 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.1, margin: "-40px 0px" }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="bg-slate-50 pt-24 pb-12 border-t border-slate-200 overflow-hidden"
      >
        <div className="max-w-7xl mx-auto px-6">
          {/* Trusted Partners Section */}
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="pb-20 mb-20 border-b border-slate-200"
          >
            <motion.p variants={fadeUpVariants} className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.3em] text-center mb-10">Our Trusted Partners & Material Suppliers</motion.p>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center justify-items-center opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
              {[
                { name: "UltraTech", color: "text-slate-900" },
                { name: "TATA Steel", color: "text-blue-900" },
                { name: "Asian Paints", color: "text-red-600" },
                { name: "Kajaria", color: "text-slate-800" },
                { name: "Saint-Gobain", color: "text-blue-600" },
                { name: "Jaquar", color: "text-slate-900" }
              ].map((partner, i) => (
                <motion.div
                  key={i}
                  variants={fadeUpVariants}
                  whileHover={{ scale: 1.15 }}
                  className="flex flex-col items-center gap-2 group cursor-pointer"
                >
                  <div className={`font-display font-black text-xl tracking-tighter ${partner.color} opacity-40 group-hover:opacity-100 transition-opacity`}>
                    {partner.name}
                  </div>
                  <div className="h-[1px] w-0 bg-amber-600 group-hover:w-full transition-all duration-300" />
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-10 lg:gap-8 mb-20"
          >
            {/* Column 1: Brand & Legacy */}
            <motion.div variants={fadeUpVariants} className="space-y-6 sm:col-span-2 lg:col-span-1">
              <div className="font-display font-bold text-2xl text-slate-900 tracking-tight">APS.</div>
              <p className="text-slate-500 text-sm leading-relaxed">
                {language === 'ml' 
                  ? "മികച്ച പാർപ്പിടങ്ങളും വാണിജ്യ സമുച്ചയങ്ങളും നിർമ്മിച്ച് ഉപഭോക്താക്കൾക്ക് തനിമയാർന്ന അനുഭവങ്ങൾ സമ്മാനിക്കുന്ന മുൻനിര ബിൽഡേഴ്‌സ്." 
                  : "A premier name in property development, infrastructure, and custom homes, committed to engineering excellence and luxury living."}
              </p>
              <div className="space-y-4">
                <h5 className="font-bold text-slate-900 uppercase text-[10px] tracking-[0.2em] opacity-60">
                  {language === 'ml' ? "ഞങ്ങളെ പിന്തുടരുക" : "Follow Our Journey"}
                </h5>
                <div className="flex gap-2.5">
                  {[
                    { icon: Instagram, label: "Instagram" },
                    { icon: Facebook, label: "Facebook" },
                    { icon: Linkedin, label: "LinkedIn" }
                  ].map((social, i) => (
                    <a 
                      key={i}
                      href="#" 
                      className="w-10 h-10 bg-white border border-slate-200 flex items-center justify-center rounded-sm text-slate-400 hover:text-amber-600 hover:border-amber-600 hover:shadow-lg hover:shadow-slate-200 transition-all duration-300"
                      aria-label={social.label}
                    >
                      <social.icon className="w-4 h-4" />
                    </a>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Column 2: Service Categories */}
            <motion.div variants={fadeUpVariants}>
              <h5 className="font-bold text-slate-900 uppercase text-xs tracking-widest mb-6">
                {language === 'ml' ? "സേവനങ്ങൾ" : "Our Services"}
              </h5>
              <ul className="space-y-3 text-sm text-slate-600">
                <li>
                  <a href="#services" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{t('residentialDev')}</span>
                  </a>
                </li>
                <li>
                  <a href="#services" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{t('commercialProjects')}</span>
                  </a>
                </li>
                <li>
                  <a href="#services" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{t('qualityInfrastructure')}</span>
                  </a>
                </li>
                <li>
                  <a href="#about" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{language === 'ml' ? "സുസ്ഥിര നിർമ്മാണം" : "Sustainable Design"}</span>
                  </a>
                </li>
                <li>
                  <a href="#vastu" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{language === 'ml' ? "വാസ്തു കൺസൾട്ടേഷൻ" : "Vastu Consultation"}</span>
                  </a>
                </li>
              </ul>
            </motion.div>

            {/* Column 3: Key Project Types */}
            <motion.div variants={fadeUpVariants}>
              <h5 className="font-bold text-slate-900 uppercase text-xs tracking-widest mb-6">
                {language === 'ml' ? "പ്രോജക്ട് വിഭാഗങ്ങൾ" : "Project Types"}
              </h5>
              <ul className="space-y-3 text-sm text-slate-600">
                <li>
                  <a href="#portfolio" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{language === 'ml' ? "ലക്ഷ്വറി വില്ലകൾ" : "Luxury Villas"}</span>
                  </a>
                </li>
                <li>
                  <a href="#portfolio" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{language === 'ml' ? "പരിസ്ഥിതി സൗഹൃദ വീടുകൾ" : "Eco-friendly Homes"}</span>
                  </a>
                </li>
                <li>
                  <a href="#portfolio" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{language === 'ml' ? "ആധുനിക അപ്പാർട്ട്മെന്റുകൾ" : "Modern Apartments"}</span>
                  </a>
                </li>
                <li>
                  <a href="#portfolio" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{language === 'ml' ? "വാണിജ്യ പ്ലാസകൾ" : "Commercial Plazas"}</span>
                  </a>
                </li>
                <li>
                  <a href="#portfolio" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{language === 'ml' ? "പൊതു അടിസ്ഥാന സൗകര്യങ്ങൾ" : "Public Infrastructure"}</span>
                  </a>
                </li>
              </ul>
            </motion.div>

            {/* Column 4: Quick Navigation */}
            <motion.div variants={fadeUpVariants}>
              <h5 className="font-bold text-slate-900 uppercase text-xs tracking-widest mb-6">
                {language === 'ml' ? "ദ്രുത ലിങ്കുകൾ" : "Quick Links"}
              </h5>
              <ul className="space-y-3 text-sm text-slate-600">
                <li>
                  <a href="#about" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{t('aboutUs')}</span>
                  </a>
                </li>
                <li>
                  <a href="#project-map" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{t('regionalPresence')}</span>
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{language === 'ml' ? "പതിവ് ചോദ്യങ്ങൾ" : "FAQ & Support"}</span>
                  </a>
                </li>
                <li>
                  <a href="#careers" className="hover:text-amber-600 transition-colors flex items-center gap-1.5 group">
                    <span className="w-1.5 h-1.5 bg-amber-600 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300" />
                    <span>{t('joinOurTeam')}</span>
                  </a>
                </li>
              </ul>
            </motion.div>

            {/* Column 5: Contact & Inquiries */}
            <motion.div variants={fadeUpVariants} className="space-y-6">
              <div>
                <h5 className="font-bold text-slate-900 uppercase text-xs tracking-widest mb-4">
                  {language === 'ml' ? "ബന്ധപ്പെടുക" : "Contact"}
                </h5>
                <ul className="space-y-3 text-sm text-slate-600">
                  <li className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-amber-600 mt-1 shrink-0" /> 
                    <span>123 Building Complex, Tech Park Avenue, Kochi, Kerala</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-amber-600 shrink-0" /> 
                    <a href="tel:7907656700" className="hover:text-amber-600 transition-colors">+91 79076 56700</a>
                  </li>
                  <li className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-amber-600 shrink-0" /> 
                    <a href="mailto:apsbuilders@gmail.com" className="hover:text-amber-600 transition-colors">apsbuilders@gmail.com</a>
                  </li>
                </ul>
              </div>

              <div>
                <h5 className="font-bold text-slate-900 uppercase text-xs tracking-widest mb-3">
                  {t('newsletter')}
                </h5>
                <div className="flex border-b border-slate-300 pb-2">
                  <input type="email" placeholder="Email Address" className="bg-transparent text-sm w-full outline-none text-slate-700" />
                  <button className="text-amber-600 hover:scale-110 transition-transform"><ChevronRight className="w-5 h-5" /></button>
                </div>
              </div>
            </motion.div>
          </motion.div>

          <div className="flex flex-col md:flex-row items-center justify-between gap-6 pt-12 border-t border-slate-200 text-xs font-bold text-slate-400 uppercase tracking-widest">
            <div>© 2026 {t('copyright')}</div>
            <div className="flex items-center gap-8">
              <div className="flex gap-2 p-1 bg-slate-100 rounded-sm">
                <button 
                  onClick={() => setLanguage('en')}
                  className={`px-3 py-1 rounded-sm text-[10px] transition-all ${language === 'en' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  English
                </button>
                <button 
                  onClick={() => setLanguage('ml')}
                  className={`px-3 py-1 rounded-sm text-[10px] transition-all ${language === 'ml' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  മലയാളം
                </button>
              </div>
              <div className="h-4 w-[1px] bg-slate-200 hidden sm:block" />
              <a href="#" className="hover:text-slate-900 transition-colors">{t('privacyPolicy')}</a>
              <a href="#" className="hover:text-slate-900 transition-colors">{t('termsOfUse')}</a>
            </div>
          </div>
        </div>
      </motion.footer>

      {/* Contact Drawer Overlay */}
      <AnimatePresence>
        {isContactDrawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsContactDrawerOpen(false)}
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[100]"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-full max-w-md bg-white z-[110] shadow-2xl flex flex-col"
            >
              <div className="p-8 flex items-center justify-between border-b border-slate-100">
                <div className="space-y-1">
                  <h2 className="font-display text-2xl font-bold text-slate-900">Request a Quote</h2>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Let's build something exceptional</p>
                </div>
                <button 
                  onClick={() => setIsContactDrawerOpen(false)}
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400 hover:text-slate-900"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8">
                <div className="mb-8 p-6 bg-emerald-50 border border-emerald-100 rounded-sm">
                  <div className="flex items-center gap-2 mb-4">
                    <MessageCircle className="w-4 h-4 text-emerald-600" />
                    <h3 className="text-xs font-bold text-emerald-900 uppercase tracking-widest">Connect on WhatsApp</h3>
                  </div>
                  <p className="text-[10px] text-emerald-700 font-medium mb-4 leading-relaxed uppercase tracking-wider">
                    Experience our automated project qualification flow for faster consultation priority.
                  </p>
                  <button 
                    onClick={() => setIsWhatsAppModalOpen(true)}
                    className="w-full py-3 bg-emerald-600 text-white font-bold text-[10px] uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-md flex items-center justify-center gap-2"
                  >
                    Start Qualifier Flow
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="mb-8 p-4 bg-slate-50 border border-slate-100 rounded-sm">
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-widest mb-3">Quick Contact</h3>
                  <div className="flex flex-col gap-3">
                    <a 
                      href="mailto:apsbuilders@gmail.com?subject=Inquiry regarding APS Builders &body=Hello APS Team,"
                      className="flex items-center justify-center gap-3 w-full py-3 bg-white border border-slate-200 text-slate-700 font-bold text-xs uppercase tracking-[0.1em] hover:border-amber-600 hover:text-amber-600 transition-all shadow-sm"
                    >
                      <Mail className="w-4 h-4 text-[#EA4335]" />
                      Message on Gmail
                    </a>
                  </div>
                </div>

                <div className="relative flex items-center justify-center mb-8">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-100" />
                  </div>
                  <span className="relative px-4 bg-white text-[10px] font-bold text-slate-400 uppercase tracking-widest">or fill the form</span>
                </div>

                <div className="flex border-b border-slate-100 mb-8 p-1 bg-slate-50 rounded-sm">
                  <button 
                    onClick={() => setContactFormData({...contactFormData, isCallback: false})}
                    className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest transition-all rounded-sm ${!contactFormData.isCallback ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                  >
                    {t('sendMessage')}
                  </button>
                  <button 
                    onClick={() => setContactFormData({...contactFormData, isCallback: true})}
                    className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest transition-all rounded-sm ${contactFormData.isCallback ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                  >
                    {t('requestCallback')}
                  </button>
                </div>

                <form className="space-y-6" onSubmit={handleContactSubmit}>
                  {contactSuccess ? (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="bg-green-50 border border-green-100 p-6 rounded-sm text-center space-y-4"
                    >
                      <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto">
                        <Check className="w-6 h-6" />
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-slate-900 font-bold uppercase text-xs tracking-widest">
                          {contactFormData.isCallback ? t('callbackScheduled') : 'Inquiry Received'}
                        </h4>
                        <p className="text-[10px] text-slate-500 uppercase tracking-tighter">
                          {contactFormData.isCallback ? t('callbackDesc') : 'Our team will contact you within 24 hours.'}
                        </p>
                      </div>
                    </motion.div>
                  ) : (
                    <>
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Full Name</label>
                        <input 
                          required
                          type="text" 
                          value={contactFormData.name}
                          onChange={(e) => setContactFormData({...contactFormData, name: e.target.value})}
                          placeholder="Enter your name"
                          className={`w-full px-4 py-3 bg-slate-50 border ${contactFormErrors.name ? 'border-red-500' : 'border-slate-100'} focus:border-amber-600 focus:bg-white outline-none transition-all rounded-sm text-sm`}
                        />
                        {contactFormErrors.name && <p className="text-[9px] text-red-500 font-bold uppercase tracking-tighter">{contactFormErrors.name}</p>}
                      </div>

                      <div className="grid grid-cols-1 gap-6">
                        {!contactFormData.isCallback && (
                          <div className="space-y-2">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Email Address</label>
                            <input 
                              required
                              type="email" 
                              value={contactFormData.email}
                              onChange={(e) => setContactFormData({...contactFormData, email: e.target.value})}
                              placeholder="name@example.com"
                              className={`w-full px-4 py-3 bg-slate-50 border ${contactFormErrors.email ? 'border-red-500' : 'border-slate-100'} focus:border-amber-600 focus:bg-white outline-none transition-all rounded-sm text-sm`}
                            />
                            {contactFormErrors.email && <p className="text-[9px] text-red-500 font-bold uppercase tracking-tighter">{contactFormErrors.email}</p>}
                          </div>
                        )}

                        <div className="space-y-2">
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                            {contactFormData.isCallback ? 'WhatsApp Number' : 'Phone Number'}
                          </label>
                          <div className="relative">
                            <input 
                              required
                              type="tel" 
                              value={contactFormData.phone}
                              onChange={(e) => setContactFormData({...contactFormData, phone: e.target.value})}
                              placeholder="+91 XXXXX XXXXX"
                              className={`w-full px-4 py-3 bg-slate-50 border ${contactFormErrors.phone ? 'border-red-500' : 'border-slate-100'} focus:border-amber-600 focus:bg-white outline-none transition-all rounded-sm text-sm ${contactFormData.isCallback ? 'pl-10' : ''}`}
                            />
                            {contactFormData.isCallback && (
                              <MessageCircle className="w-4 h-4 text-green-500 absolute left-3 top-1/2 -translate-y-1/2" />
                            )}
                          </div>
                          {contactFormErrors.phone && <p className="text-[9px] text-red-500 font-bold uppercase tracking-tighter">{contactFormErrors.phone}</p>}
                        </div>

                        {contactFormData.isCallback && (
                          <div className="space-y-2">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('preferredTime')}</label>
                            <input 
                              required
                              type="datetime-local" 
                              value={contactFormData.preferredTime}
                              onChange={(e) => setContactFormData({...contactFormData, preferredTime: e.target.value})}
                              className={`w-full px-4 py-3 bg-slate-50 border ${contactFormErrors.preferredTime ? 'border-red-500' : 'border-slate-100'} focus:border-amber-600 focus:bg-white outline-none transition-all rounded-sm text-sm`}
                            />
                            {contactFormErrors.preferredTime && <p className="text-[9px] text-red-500 font-bold uppercase tracking-tighter">{contactFormErrors.preferredTime}</p>}
                          </div>
                        )}
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Project Type</label>
                        <select 
                          required
                          value={contactFormData.projectType}
                          onChange={(e) => setContactFormData({...contactFormData, projectType: e.target.value})}
                          className={`w-full px-4 py-3 bg-slate-50 border ${contactFormErrors.projectType ? 'border-red-500' : 'border-slate-100'} focus:border-amber-600 focus:bg-white outline-none transition-all rounded-sm text-sm appearance-none cursor-pointer`}
                        >
                          <option value="">Select a category</option>
                          <option value="residential">Residential Villa</option>
                          <option value="commercial">Commercial Space</option>
                          <option value="industrial">Industrial Facility</option>
                          <option value="renovation">Renovation</option>
                        </select>
                        {contactFormErrors.projectType && <p className="text-[9px] text-red-500 font-bold uppercase tracking-tighter">{contactFormErrors.projectType}</p>}
                      </div>

                      {!contactFormData.isCallback && (
                        <div className="space-y-2">
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Project Details</label>
                          <textarea 
                            required
                            rows={4}
                            value={contactFormData.details}
                            onChange={(e) => setContactFormData({...contactFormData, details: e.target.value})}
                            placeholder="Describe your vision..."
                            className={`w-full px-4 py-3 bg-slate-50 border ${contactFormErrors.details ? 'border-red-500' : 'border-slate-100'} focus:border-amber-600 focus:bg-white outline-none transition-all rounded-sm text-sm resize-none`}
                          />
                          {contactFormErrors.details && <p className="text-[9px] text-red-500 font-bold uppercase tracking-tighter">{contactFormErrors.details}</p>}
                        </div>
                      )}

                      <div className="pt-4">
                        <button 
                          type="submit"
                          disabled={isContactSubmitting}
                          className="w-full bg-slate-900 text-white py-4 font-bold rounded-sm hover:bg-amber-600 transition-all uppercase tracking-widest text-sm shadow-lg shadow-slate-900/10 flex items-center justify-center gap-2"
                        >
                          {isContactSubmitting ? (
                            <>
                              <Loader2 className="w-4 h-4 animate-spin" /> {contactFormData.isCallback ? 'Scheduling...' : 'Sending...'}
                            </>
                          ) : (
                            contactFormData.isCallback ? t('requestCallback') : 'Send Message'
                          )}
                        </button>
                      </div>
                    </>
                  )}

                  <div className="pt-8 border-t border-slate-100">
                    <div className="flex items-center gap-4 text-slate-500">
                      <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center shrink-0">
                        <Phone className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-[10px] font-bold uppercase tracking-widest leading-none mb-1">Direct Line</div>
                        <div className="text-sm font-bold text-slate-900">+91 8590 400 500</div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </motion.div>
          </>
        )}

        {/* Careers Drawer Overlay */}
        {isCareerDrawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCareerDrawerOpen(false)}
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[100]"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-full max-w-md bg-white z-[110] shadow-2xl flex flex-col"
            >
              <CareerApplicationForm
                onClose={() => setIsCareerDrawerOpen(false)}
                t={t}
                playSuccessSound={playSuccessSound}
              />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {selectedProject && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              role="dialog"
              aria-modal="true"
              aria-labelledby="project-modal-title"
              aria-describedby="project-modal-description"
              className="fixed inset-0 z-[400] flex items-center justify-center p-4 md:p-8 bg-slate-900/90 backdrop-blur-sm"
              onClick={() => {
                setSelectedProject(null);
                setProjectSubscribed(false);
                setProjectSubEmail("");
                setCurrentProjectImageIndex(0);
                setActiveVideoUrl(null);
              }}
            >
              <motion.div
                layoutId={selectedProject.id ? `project-card-${selectedProject.id}` : undefined}
                variants={modalDialogVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
                className="bg-white max-w-5xl w-full overflow-hidden rounded-sm relative shadow-2xl h-fit max-h-[90vh]"
                onClick={(e) => e.stopPropagation()}
              >
              <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
                <button
                  onClick={() => setIsExpandedDetailsOpen(true)}
                  aria-label={`Expand full structural and architectural details for ${selectedProject.title}`}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/90 hover:bg-amber-600 text-white rounded-full text-xs font-bold uppercase tracking-wider transition-all shadow-md backdrop-blur-sm border border-slate-700/50 hover:border-amber-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 group cursor-pointer"
                  title="Expand Full Structural & Architectural Details (Zero-Scroll)"
                >
                  <Maximize2 className="w-3.5 h-3.5 text-amber-400 group-hover:text-white transition-colors" aria-hidden="true" />
                  <span className="hidden sm:inline">Expand Specs</span>
                </button>
                <button 
                  onClick={() => {
                    setSelectedProject(null);
                    setIsExpandedDetailsOpen(false);
                    setCurrentProjectImageIndex(0);
                    setActiveVideoUrl(null);
                    setActiveProjectTab('details');
                  }}
                  aria-label={`Close ${selectedProject.title} project details modal`}
                  className="p-2 bg-white/80 md:bg-white/10 hover:bg-amber-600 hover:text-white transition-all rounded-full text-slate-900 md:text-slate-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                >
                  <X className="w-6 h-6" aria-hidden="true" />
                </button>
              </div>

              <div className="flex flex-col md:flex-row">
                <motion.div 
                  variants={modalImageVariants}
                  className="md:w-3/5 bg-slate-900 flex flex-col text-slate-300 overflow-hidden relative group select-none"
                  onMouseEnter={() => setIsHoveringCarousel(true)}
                  onMouseLeave={() => setIsHoveringCarousel(false)}
                >
                  <div className="relative aspect-video md:aspect-[4/3] w-full bg-slate-950 overflow-hidden flex items-center justify-center">
                    {selectedProject.images && selectedProject.images.length > 0 ? (
                      <>
                        {/* Automatic 3-Second Slideshow Live Progress Bar */}
                        {selectedProject.images.length > 1 && (
                          <div className="absolute top-0 left-0 right-0 h-1.5 bg-black/40 z-30 overflow-hidden" aria-hidden="true">
                            <motion.div
                              key={`modal-progress-${currentProjectImageIndex}-${slideshowKey}-${isSlideshowPlaying && !isHoveringCarousel}`}
                              initial={{ width: "0%" }}
                              animate={{ width: isSlideshowPlaying && !isHoveringCarousel ? "100%" : "0%" }}
                              transition={{
                                duration: isSlideshowPlaying && !isHoveringCarousel ? 3 : 0,
                                ease: "linear",
                              }}
                              className="h-full bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.9)]"
                            />
                          </div>
                        )}

                        <AnimatePresence mode="wait" initial={false}>
                          <LazyImage 
                            key={currentProjectImageIndex}
                            initial={{ opacity: 0, x: 80 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -80 }}
                            transition={{ 
                              x: { type: "spring", stiffness: 300, damping: 30 },
                              opacity: { duration: 0.25 }
                            }}
                            drag="x"
                            dragConstraints={{ left: 0, right: 0 }}
                            dragElastic={0.8}
                            onDragEnd={(_, info) => {
                              const swipeThreshold = 50;
                              if (info.offset.x > swipeThreshold) {
                                setCurrentProjectImageIndex(prev => (prev - 1 + selectedProject.images!.length) % selectedProject.images!.length);
                                setSlideshowKey(k => k + 1);
                              } else if (info.offset.x < -swipeThreshold) {
                                setCurrentProjectImageIndex(prev => (prev + 1) % selectedProject.images!.length);
                                setSlideshowKey(k => k + 1);
                              }
                            }}
                            src={selectedProject.images[currentProjectImageIndex]} 
                            alt={`${selectedProject.title} architectural view - photo ${currentProjectImageIndex + 1} of ${selectedProject.images.length}`} 
                            className="w-full h-full cursor-grab active:cursor-grabbing transition-all duration-700 object-cover"
                            style={{ filter: getMaterialFilter(selectedMaterial) }}
                            onClick={() => setLightboxImage(selectedProject.images![currentProjectImageIndex])}
                          />
                        </AnimatePresence>
                        
                        {/* Top Overlay Controls */}
                        <div className="absolute top-4 left-4 z-20 flex items-center gap-2">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              setIsExpandedDetailsOpen(true);
                            }}
                            aria-label={`Expand structural & architectural dossier for ${selectedProject.title}`}
                            className="p-1.5 px-3 bg-black/60 hover:bg-amber-600 text-white rounded-full transition-all backdrop-blur-md flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider shadow-lg border border-white/10 hover:border-amber-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 cursor-pointer"
                            title="Expand Full Technical & Blueprint Details"
                          >
                            <Maximize2 className="w-3.5 h-3.5 text-amber-400" aria-hidden="true" />
                            <span>Expand</span>
                          </button>

                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              setLightboxImage(selectedProject.images![currentProjectImageIndex]);
                            }}
                            aria-label={`View fullscreen photo gallery for ${selectedProject.title}`}
                            className="p-2 bg-black/40 hover:bg-amber-600 text-white rounded-full transition-all backdrop-blur-md shadow-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                            title="View Fullscreen"
                          >
                            <ZoomIn className="w-4 h-4" aria-hidden="true" />
                          </button>

                          {/* Automatic Slideshow Toggle Button */}
                          {selectedProject.images.length > 1 && (
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                setIsSlideshowPlaying(prev => !prev);
                                setSlideshowKey(k => k + 1);
                              }}
                              aria-label={isSlideshowPlaying ? "Pause automatic 3-second photo slideshow" : "Start automatic 3-second photo slideshow"}
                              className={`p-1.5 px-3 rounded-full transition-all backdrop-blur-md flex items-center gap-1.5 text-white shadow-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 ${
                                isSlideshowPlaying
                                  ? 'bg-amber-600/90 hover:bg-amber-600 ring-2 ring-amber-400/30' 
                                  : 'bg-black/50 hover:bg-black/70'
                              }`}
                              title={isSlideshowPlaying ? "Pause Automatic Slideshow (3s)" : "Start Automatic Slideshow (3s)"}
                            >
                              {isSlideshowPlaying ? (
                                <>
                                  <Pause className="w-3.5 h-3.5 fill-current" aria-hidden="true" />
                                  <span className="text-[10px] font-bold uppercase tracking-wider">
                                    {isHoveringCarousel ? 'Paused' : '3s'}
                                  </span>
                                </>
                              ) : (
                                <>
                                  <Play className="w-3.5 h-3.5 fill-current" aria-hidden="true" />
                                  <span className="text-[10px] font-bold uppercase tracking-wider">Play</span>
                                </>
                              )}
                            </button>
                          )}
                          
                          {selectedProject.videoUrl && (
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                setActiveVideoUrl(selectedProject.videoUrl!);
                              }}
                              aria-label={`Watch virtual video tour for ${selectedProject.title}`}
                              className="p-1.5 px-3 bg-slate-900/80 hover:bg-amber-600 text-white rounded-full transition-all backdrop-blur-md flex items-center justify-center gap-1.5 shadow-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                              title="Play Video Tour"
                            >
                              <Play className="w-3.5 h-3.5 fill-current" aria-hidden="true" />
                              <span className="text-[10px] font-bold uppercase tracking-wider">Tour</span>
                            </button>
                          )}
                        </div>
                        
                        {/* Carousel Arrow Controls */}
                        <div className="absolute inset-0 flex items-center justify-between p-4 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              setCurrentProjectImageIndex(prev => (prev - 1 + selectedProject.images!.length) % selectedProject.images!.length);
                              setSlideshowKey(k => k + 1);
                            }}
                            aria-label="View previous project photo"
                            className="p-2.5 bg-slate-900/70 text-white rounded-full hover:bg-amber-600 transition-all backdrop-blur-sm pointer-events-auto shadow-xl hover:scale-105 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                            title="Previous Image"
                          >
                            <ChevronRight className="w-5 h-5 rotate-180" aria-hidden="true" />
                          </button>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              setCurrentProjectImageIndex(prev => (prev + 1) % selectedProject.images!.length);
                              setSlideshowKey(k => k + 1);
                            }}
                            aria-label="View next project photo"
                            className="p-2.5 bg-slate-900/70 text-white rounded-full hover:bg-amber-600 transition-all backdrop-blur-sm pointer-events-auto shadow-xl hover:scale-105 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                            title="Next Image"
                          >
                            <ChevronRight className="w-5 h-5" aria-hidden="true" />
                          </button>
                        </div>
                      </>
                    ) : selectedProject.image ? (
                      <LazyImage 
                        src={selectedProject.image} 
                        alt={`Main exterior of ${selectedProject.title}`} 
                        className="w-full h-full transition-all duration-700 object-cover"
                        style={{ filter: getMaterialFilter(selectedMaterial) }}
                      />
                    ) : (
                      <Building2 className="w-24 h-24 stroke-[0.5px]" aria-hidden="true" />
                    )}
                  </div>

                  {/* Sorted Photo Thumbnail Filmstrip Bar (Zero-Scroll Gallery Access) */}
                  {selectedProject.images && selectedProject.images.length > 1 && (
                    <div className="bg-slate-950 p-2.5 border-t border-slate-800 flex items-center justify-between gap-2 overflow-x-auto">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 shrink-0">
                          Photos ({selectedProject.images.length}):
                        </span>
                        <div className="flex items-center gap-2">
                          {selectedProject.images.map((imgUrl, imgIdx) => (
                            <button
                              key={imgIdx}
                              onClick={() => {
                                setCurrentProjectImageIndex(imgIdx);
                                setSlideshowKey(k => k + 1);
                              }}
                              aria-label={`Jump to photo ${imgIdx + 1} of ${selectedProject.title}`}
                              className={`relative w-14 h-10 rounded-xs overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                                currentProjectImageIndex === imgIdx 
                                  ? 'border-amber-500 shadow-md scale-105' 
                                  : 'border-slate-700 opacity-60 hover:opacity-100 hover:border-slate-400'
                              }`}
                            >
                              <img 
                                src={imgUrl} 
                                alt={`Thumbnail ${imgIdx + 1}`} 
                                className="w-full h-full object-cover"
                              />
                              <span className="absolute bottom-0 right-0 bg-black/80 text-white text-[8px] font-mono px-1">
                                {imgIdx + 1}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="text-[10px] text-amber-400 font-mono font-bold shrink-0 hidden sm:block">
                        {currentProjectImageIndex + 1} / {selectedProject.images.length}
                      </div>
                    </div>
                  )}
                </motion.div>
                <ModalScrollProgress>
                  {/* Tab Navigation (Ongoing Projects) */}
                  {selectedProject.status === "Under Construction" && (
                    <motion.div 
                      variants={modalDetailItemVariants}
                      className="flex border-b border-slate-100 bg-white sticky top-0 z-30" 
                      role="tablist" 
                      aria-label="Project View Modes"
                    >
                      <button 
                        role="tab"
                        aria-selected={activeProjectTab === 'details'}
                        aria-controls="project-tab-details"
                        aria-label="View project specifications and details"
                        onClick={() => setActiveProjectTab('details')}
                        className={`flex-1 py-3 text-[10px] font-black uppercase tracking-[0.2em] relative transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 ${
                          activeProjectTab === 'details' ? 'text-slate-900' : 'text-slate-400 hover:bg-slate-50'
                        }`}
                      >
                        Project Info
                        {activeProjectTab === 'details' && (
                          <motion.div layoutId="modalTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-600" />
                        )}
                      </button>
                      <button 
                        role="tab"
                        aria-selected={activeProjectTab === 'live'}
                        aria-controls="project-tab-live"
                        aria-label="View live construction site camera feed"
                        onClick={() => setActiveProjectTab('live')}
                        className={`flex-1 py-3 text-[10px] font-black uppercase tracking-[0.2em] relative transition-all flex items-center justify-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 ${
                          activeProjectTab === 'live' ? 'text-slate-900' : 'text-slate-400 hover:bg-slate-50'
                        }`}
                      >
                        <div className={`w-1.5 h-1.5 rounded-full ${activeProjectTab === 'live' ? 'bg-rose-500 animate-pulse' : 'bg-slate-300'}`} aria-hidden="true" />
                        Live Site Cam
                        {activeProjectTab === 'live' && (
                          <motion.div layoutId="modalTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-600" />
                        )}
                      </button>
                    </motion.div>
                  )}

                  <div className="p-6 md:p-8 space-y-6 overflow-hidden">
                    <AnimatePresence mode="wait">
                      {activeProjectTab === 'live' ? (
                        <motion.div
                          id="project-tab-live"
                          role="tabpanel"
                          aria-label="Live Site Camera Panel"
                          key="live"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          transition={{ duration: 0.2 }}
                        >
                          <ProjectLiveCam 
                            projectTitle={selectedProject.title} 
                            location={selectedProject.location || "Site"} 
                          />
                        </motion.div>
                      ) : (
                        <motion.div
                          id="project-tab-details"
                          role="tabpanel"
                          aria-label="Project Details Panel"
                          key="details"
                          variants={modalDetailsContainerVariants}
                          initial="hidden"
                          animate="visible"
                          className="space-y-5"
                        >
                          {/* Title & Location Header */}
                          <motion.div variants={modalDetailItemVariants} className="space-y-1">
                            <span className="text-amber-600 text-xs font-bold uppercase tracking-widest">{selectedProject.type}</span>
                            <h2 id="project-modal-title" className="font-display text-2xl font-bold text-slate-900">{selectedProject.title}</h2>
                            <p className="flex items-center gap-2 text-slate-500 text-xs font-medium italic">
                              <MapPin className="w-3.5 h-3.5 text-amber-600" aria-hidden="true" /> {selectedProject.location}
                            </p>
                          </motion.div>
                  
                          {/* Zero-Scroll Expand Button for Full Structural & Architectural Specs */}
                          <motion.button 
                            variants={modalDetailItemVariants}
                            whileHover={{ scale: 1.01 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => setIsExpandedDetailsOpen(true)}
                            className="w-full flex items-center justify-between p-3 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-sm border border-slate-700/80 hover:border-amber-500 hover:shadow-lg transition-all group text-left cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                            aria-label={`Expand full structural and architectural details for ${selectedProject.title} without scrolling`}
                          >
                            <div className="flex items-center gap-2.5">
                              <div className="p-1.5 bg-amber-500/20 text-amber-400 rounded-sm group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors shrink-0">
                                <Layers className="w-3.5 h-3.5" aria-hidden="true" />
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="text-xs font-bold uppercase tracking-wider text-slate-100">Full Structural Dossier</span>
                                  <span className="text-[8px] font-extrabold bg-amber-500 text-slate-950 px-1 py-0.2 rounded uppercase tracking-wider">Zero-Scroll</span>
                                </div>
                                <p className="text-[10px] text-slate-400 line-clamp-1">3D load models, floor plans, MEP & testing audits</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-1 text-amber-400 text-xs font-bold uppercase tracking-wider group-hover:translate-x-1 transition-transform shrink-0 ml-2">
                              <span>Expand</span>
                              <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                            </div>
                          </motion.button>

                          {/* Zero-Scroll Sub-Tabs (Overview vs Design & 3D vs Engineering) */}
                          <motion.div variants={modalDetailItemVariants} className="flex border-b border-slate-200 bg-slate-50 p-1 rounded-sm">
                            <button
                              onClick={() => setModalSubTab('overview')}
                              className={`flex-1 py-1.5 px-2 text-[10px] font-bold uppercase tracking-wider rounded-xs transition-all ${
                                modalSubTab === 'overview' 
                                  ? 'bg-white text-slate-900 shadow-xs font-black' 
                                  : 'text-slate-500 hover:text-slate-900'
                              }`}
                            >
                              Overview
                            </button>
                            <button
                              onClick={() => setModalSubTab('design')}
                              className={`flex-1 py-1.5 px-2 text-[10px] font-bold uppercase tracking-wider rounded-xs transition-all ${
                                modalSubTab === 'design' 
                                  ? 'bg-white text-slate-900 shadow-xs font-black' 
                                  : 'text-slate-500 hover:text-slate-900'
                              }`}
                            >
                              Design & 3D
                            </button>
                            <button
                              onClick={() => setModalSubTab('engineering')}
                              className={`flex-1 py-1.5 px-2 text-[10px] font-bold uppercase tracking-wider rounded-xs transition-all ${
                                modalSubTab === 'engineering' 
                                  ? 'bg-white text-slate-900 shadow-xs font-black' 
                                  : 'text-slate-500 hover:text-slate-900'
                              }`}
                            >
                              Specs & ROI
                            </button>
                          </motion.div>

                          {/* SUB-TAB 1: OVERVIEW */}
                          {modalSubTab === 'overview' && (
                            <motion.div 
                              key="tab-overview"
                              initial={{ opacity: 0, y: 6 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -6 }}
                              className="space-y-4"
                            >
                              <div id="project-details-content">
                                <p id="project-modal-description" className="text-slate-600 leading-relaxed text-xs">
                                  {selectedProject.description || "This project represents our commitment to architectural excellence and quality construction. Every detail was meticulously planned to ensure maximum durability and aesthetic appeal."}
                                </p>
                              </div>
                        
                              <VoiceGuidedTour project={selectedProject} />
                        
                              <div className="space-y-2 pt-1">
                                <div className="flex justify-between items-end">
                                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Project Status</span>
                                  <span className="text-xs font-bold text-slate-900">{selectedProject.status}</span>
                                </div>
                                <div 
                                  className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden"
                                  role="progressbar"
                                  aria-label={`Project Completion: ${selectedProject.status}`}
                                  aria-valuenow={selectedProject.status === "Completed" ? 100 : selectedProject.status === "Under Construction" ? 60 : 25}
                                  aria-valuemin={0}
                                  aria-valuemax={100}
                                >
                                  <motion.div 
                                    initial={{ width: 0 }}
                                    animate={{ 
                                      width: selectedProject.status === "Completed" ? "100%" : 
                                             selectedProject.status === "Under Construction" ? "60%" : "25%" 
                                    }}
                                    transition={{ duration: 1, ease: "easeOut" }}
                                    className={`h-full rounded-full ${
                                      selectedProject.status === "Completed" ? "bg-green-500" : 
                                      selectedProject.status === "Under Construction" ? "bg-amber-600" : "bg-blue-500"
                                    }`}
                                  />
                                </div>
                                <div className="flex justify-between text-[8px] font-bold text-slate-300 uppercase tracking-tighter" aria-hidden="true">
                                  <span>Planning</span>
                                  <span>Development</span>
                                  <span>Completed</span>
                                </div>

                                {(selectedProject.startDate || selectedProject.estimatedCompletion) && (
                                  <div className="grid grid-cols-2 gap-3 pt-2">
                                    {selectedProject.startDate && (
                                      <div className="bg-slate-50 p-2.5 rounded-sm border border-slate-100">
                                         <p className="text-[7px] font-bold text-slate-400 uppercase tracking-widest mb-0.5">Commenced</p>
                                         <p className="text-xs font-bold text-slate-900">{selectedProject.startDate}</p>
                                      </div>
                                    )}
                                    {selectedProject.estimatedCompletion && (
                                      <div className="bg-slate-50 p-2.5 rounded-sm border border-slate-100">
                                         <p className="text-[7px] font-bold text-slate-400 uppercase tracking-widest mb-0.5">Completion</p>
                                         <p className="text-xs font-bold text-amber-600">{selectedProject.estimatedCompletion}</p>
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>

                              {/* Project Milestone Tracker */}
                              <div className="pt-2 border-t border-slate-100">
                                <ProjectMilestoneTracker 
                                  milestones={selectedProject.milestones || [
                                    { label: "Foundation & Piling", date: selectedProject.startDate || "Q1 2024", status: "Completed" },
                                    { label: "Structural Framing & Slabs", date: "Q2 2024", status: selectedProject.status === "Planning" ? "Pending" : "Completed" },
                                    { label: "Finishing & MEP Installations", date: "Q3 2024", status: selectedProject.status === "Completed" ? "Completed" : selectedProject.status === "Under Construction" ? "In Progress" : "Pending" },
                                    { label: "Final Quality Handover", date: selectedProject.estimatedCompletion || "Q4 2024", status: selectedProject.status === "Completed" ? "Completed" : "Pending" }
                                  ]} 
                                  projectId={String(selectedProject.id)}
                                  projectTitle={selectedProject.title}
                                  projectImage={selectedProject.image}
                                />
                              </div>
                        
                              <ul className="grid grid-cols-2 gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-tight pt-1">
                                <li className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 bg-amber-600 rounded-full" aria-hidden="true" /> Premium Materials</li>
                                <li className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 bg-amber-600 rounded-full" aria-hidden="true" /> Expert Engineering</li>
                                <li className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 bg-amber-600 rounded-full" aria-hidden="true" /> Timely Delivery</li>
                                <li className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 bg-amber-600 rounded-full" aria-hidden="true" /> Green Building</li>
                              </ul>

                              {/* Weather & Update Subscription */}
                              <div className="pt-2 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <ProjectWeatherWidget location={selectedProject.location || "Site Location"} />
                                <SiteUpdateSubscription />
                              </div>
                            </motion.div>
                          )}

                          {/* SUB-TAB 2: DESIGN & 3D */}
                          {modalSubTab === 'design' && (
                            <motion.div 
                              key="tab-design"
                              initial={{ opacity: 0, y: 6 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -6 }}
                              className="space-y-4"
                            >
                              {/* Architectural 3D Viewer Section */}
                              {selectedProject.architecturalViews && selectedProject.architecturalViews.length > 0 && (
                                <div className="space-y-2">
                                  <h4 className="text-[10px] font-bold text-slate-900 uppercase tracking-widest">
                                    Interactive 3D Render
                                  </h4>
                                  <div className="h-[220px] w-full rounded-sm overflow-hidden border border-slate-200">
                                     <ArchitecturalViewer views={selectedProject.architecturalViews} />
                                  </div>
                                </div>
                              )}

                              {/* Material Customizer Tool */}
                              <div>
                                <MaterialCustomizer 
                                  selected={selectedMaterial} 
                                  onSelect={setSelectedMaterial}
                                  projectType={selectedProject.type}
                                  projectTitle={selectedProject.title}
                                  projectDescription={selectedProject.description}
                                />
                              </div>

                              {/* Interactive Plan Annotator */}
                              <div className="pt-2 border-t border-slate-100">
                                <FloorPlanAnnotator 
                                  planTitle={
                                    selectedProject.architecturalViews?.find(v => v.type === 'blueprint')?.title || 
                                    "Primary Structural Logic"
                                  }
                                  planUrl={
                                    selectedProject.architecturalViews?.find(v => v.type === 'blueprint')?.url || 
                                    selectedProject.image
                                  }
                                />
                              </div>
                            </motion.div>
                          )}

                          {/* SUB-TAB 3: SPECS & ROI */}
                          {modalSubTab === 'engineering' && (
                            <motion.div 
                              key="tab-engineering"
                              initial={{ opacity: 0, y: 6 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -6 }}
                              className="space-y-4"
                            >
                              {/* Structural Highlights */}
                              <div>
                                <ProjectStructuralSpecs 
                                  project={selectedProject} 
                                  onExpand={() => setIsExpandedDetailsOpen(true)}
                                />
                              </div>

                              {/* Investment ROI Analysis */}
                              <div className="pt-2 border-t border-slate-100">
                                <ProjectROIChart 
                                  initialInvestment={selectedProject.cost || 25000000} 
                                  projectTitle={selectedProject.title} 
                                />
                              </div>

                              {/* Instant Cost Estimate Widget */}
                              <div className="pt-2 border-t border-slate-100">
                                <ProjectCostWidget 
                                  projectType={selectedProject.type}
                                  projectName={selectedProject.title}
                                />
                              </div>

                              {/* Project Team */}
                              <div className="pt-2 border-t border-slate-100">
                                <ProjectTeam onInquiry={(member) => setSelectedInquiryMember(member)} />
                              </div>

                              {/* QR Code Sharing */}
                              <div className="pt-2 border-t border-slate-100">
                                <ProjectQRCode 
                                  url={window.location.href} 
                                  projectName={selectedProject.title} 
                                />
                              </div>
                            </motion.div>
                          )}

                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  <motion.div 
                    variants={modalButtonsContainerVariants}
                    initial="hidden"
                    animate="visible"
                    className="pt-4 space-y-3 px-8 md:px-12 pb-12"
                  >
                    <motion.button 
                      variants={modalButtonVariants}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setIsContactDrawerOpen(true)}
                      aria-label={`Inquire about ${selectedProject.title} - opens inquiry form`}
                      className="w-full bg-slate-900 text-white py-4 font-bold text-sm hover:bg-amber-600 transition-all uppercase tracking-widest focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                    >
                      Inquire About Project
                    </motion.button>

                    <motion.button 
                      variants={modalButtonVariants}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setIsSiteVisitFormOpen(true)}
                      aria-label={`Book an on-site visit for ${selectedProject.title}`}
                      className="w-full bg-amber-600 text-white py-4 font-bold text-sm hover:bg-slate-900 transition-all uppercase tracking-widest flex items-center justify-center gap-2 group shadow-xl focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                    >
                      <Calendar className="w-4 h-4 group-hover:scale-110 transition-transform" aria-hidden="true" />
                      Book a Site Visit
                    </motion.button>
                    
                    <motion.button 
                      variants={modalButtonVariants}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={async () => {
                        if (navigator.share) {
                          try {
                            await navigator.share({
                              title: `APS Builders - ${selectedProject.title}`,
                              text: `Check out this project by APS Builders & Developers: ${selectedProject.title} in ${selectedProject.location}`,
                              url: window.location.href,
                            });
                          } catch (error) {
                            console.log('Error sharing:', error);
                          }
                        } else {
                          navigator.clipboard.writeText(`${selectedProject.title} located in ${selectedProject.location}. Visit APS Builders for more details.`);
                          alert("Project information copied to clipboard!");
                        }
                      }}
                      aria-label={`Share ${selectedProject.title} project details`}
                      className="w-full border border-slate-200 text-slate-500 py-3 font-bold text-[10px] hover:bg-slate-50 hover:text-amber-600 transition-all uppercase tracking-widest flex items-center justify-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                    >
                      <Share2 className="w-3.5 h-3.5" aria-hidden="true" /> Share Project
                    </motion.button>

                    <motion.button 
                      variants={modalButtonVariants}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        const message = encodeURIComponent(`Hi, check out this amazing project by APS Builders & Developers: *${selectedProject.title}* in ${selectedProject.location}.\n\nView details: ${window.location.href}`);
                        window.open(`https://wa.me/?text=${message}`, '_blank');
                      }}
                      aria-label={`Share ${selectedProject.title} details on WhatsApp`}
                      className="w-full bg-[#25D366] text-white py-3 font-bold text-[10px] hover:bg-green-600 transition-all uppercase tracking-widest flex items-center justify-center gap-2 rounded-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-green-500"
                    >
                      <MessageCircle className="w-3.5 h-3.5" aria-hidden="true" /> Share on WhatsApp
                    </motion.button>

                    <motion.button 
                      variants={modalButtonVariants}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        const message = encodeURIComponent(`Hi, check out this amazing project by APS Builders & Developers: *${selectedProject.title}* in ${selectedProject.location}.\n\nView details: ${window.location.href}`);
                        window.location.href = `sms:?body=${message}`;
                      }}
                      aria-label={`Share ${selectedProject.title} details via SMS`}
                      className="w-full border border-slate-200 text-slate-700 py-3 font-bold text-[10px] hover:bg-slate-50 transition-all uppercase tracking-widest flex items-center justify-center gap-2 rounded-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                    >
                      <MessageSquare className="w-3.5 h-3.5" aria-hidden="true" /> Share via SMS
                    </motion.button>

                    <motion.button 
                      variants={modalButtonVariants}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => window.print()}
                      aria-label={`Print summary and technical datasheet for ${selectedProject.title}`}
                      className="w-full border-2 border-slate-900 text-slate-900 py-4 font-bold text-sm hover:bg-slate-900 hover:text-white transition-all uppercase tracking-widest flex items-center justify-center gap-2 shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                    >
                      <Printer className="w-4 h-4" aria-hidden="true" />
                      Print Summary
                    </motion.button>
                    
                    <motion.div variants={modalButtonVariants} className="pt-4 border-t border-slate-100 mt-2">
                       {projectSubscribed ? (
                         <motion.div 
                           initial={{ opacity: 0, scale: 0.95 }}
                           animate={{ opacity: 1, scale: 1 }}
                           role="status"
                           aria-live="polite"
                           className="bg-green-50 p-4 rounded-sm border border-green-100 flex items-center gap-3"
                         >
                           <ShieldCheck className="w-5 h-5 text-green-600 shrink-0" aria-hidden="true" />
                           <div className="text-[10px] font-bold text-green-700 uppercase tracking-widest">
                             Notification active for updates
                           </div>
                         </motion.div>
                       ) : (
                         <div className="space-y-4">
                           <div className="flex flex-col gap-1">
                             <h4 className="text-[10px] font-bold text-slate-900 uppercase tracking-widest">Get Live Status Updates</h4>
                             <p className="text-[9px] text-slate-400 uppercase tracking-tighter">Subscribe to construction milestones for this site.</p>
                           </div>
                           <div className="flex gap-2">
                             <input 
                               type="email"
                               value={projectSubEmail}
                               onChange={(e) => setProjectSubEmail(e.target.value)}
                               placeholder="Enter email..."
                               aria-label={`Email address to receive live milestone updates for ${selectedProject.title}`}
                               className="flex-1 bg-slate-50 border border-slate-100 px-3 py-2 text-xs focus:border-amber-600 outline-none transition-all rounded-sm"
                             />
                             <button 
                               onClick={() => {
                                 if (projectSubEmail.includes('@')) {
                                   setIsProjectSubmitting(true);
                                   setTimeout(() => {
                                     setProjectSubscribed(true);
                                     setIsProjectSubmitting(false);
                                   }, 1000);
                                 }
                               }}
                               disabled={isProjectSubmitting || !projectSubEmail}
                               aria-label={`Subscribe to construction updates for ${selectedProject.title}`}
                               className="bg-amber-600 text-white px-4 py-2 text-[10px] font-bold uppercase tracking-widest hover:bg-slate-900 transition-all disabled:opacity-50 shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                             >
                               {isProjectSubmitting ? <Loader2 className="w-3 h-3 animate-spin" aria-hidden="true" /> : "Subscribe"}
                             </button>
                           </div>
                         </div>
                       )}
                    </motion.div>
                  </motion.div>
                </ModalScrollProgress>
              </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Expanded Full Structural & Architectural Details Modal (Zero-Scroll Full Screen View) */}
        {selectedProject && (
          <ProjectExpandedDetailsModal
            isOpen={isExpandedDetailsOpen}
            onClose={() => setIsExpandedDetailsOpen(false)}
            project={selectedProject}
            onInquire={() => setIsSiteVisitFormOpen(true)}
          />
        )}
      
      {/* WhatsApp Floating Button - only rendered and visible on the initial home screen */}
      <AnimatePresence>
        {isHomeScreenOnly && (
          <motion.button 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.3 }}
            onClick={() => setIsWhatsAppModalOpen(true)}
            className="fixed bottom-8 right-8 w-14 h-14 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-2xl z-[90] hover:scale-110 active:scale-95 transition-transform duration-300 group"
            aria-label="Contact on WhatsApp"
          >
            <MessageCircle className="w-8 h-8 fill-white/20" />
            <div className="absolute right-full mr-4 bg-white px-4 py-2 rounded-sm shadow-xl text-slate-900 border border-slate-100 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap hidden md:block">
              <div className="text-[10px] font-bold uppercase tracking-widest text-amber-600 mb-0.5">Quick Assistance</div>
              <div className="text-sm font-bold text-slate-900">Start Project Inquiry</div>
              <div className="absolute top-1/2 -translate-y-1/2 left-full border-8 border-transparent border-l-white" />
            </div>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Newsletter Modal */}
      <AnimatePresence>
        {isNewsletterOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white max-w-lg w-full rounded-sm overflow-hidden shadow-2xl relative"
            >
              <button 
                onClick={() => setIsNewsletterOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-900 transition-colors z-10"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex flex-col md:flex-row">
                <div className="bg-amber-600 p-8 md:w-1/3 flex flex-col justify-center items-center text-white text-center">
                  <Mail className="w-12 h-12 mb-4" />
                  <div className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-80">Join Us</div>
                </div>
                
                <div className="p-8 md:w-2/3 space-y-6">
                  {subscribed ? (
                    <motion.div 
                      initial={{ opacity: 0 }} 
                      animate={{ opacity: 1 }}
                      className="text-center py-8"
                    >
                      <div className="w-12 h-12 bg-green-50 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <ShieldCheck className="w-6 h-6" />
                      </div>
                      <h4 className="font-display font-bold text-xl text-slate-900 mb-2">You're Subscribed!</h4>
                      <p className="text-slate-500 text-sm">Thank you for joining our community. We'll keep you posted.</p>
                      <button 
                        onClick={() => setIsNewsletterOpen(false)}
                        className="mt-6 text-amber-600 font-bold text-xs uppercase tracking-widest hover:underline"
                      >
                        Back to Browsing
                      </button>
                    </motion.div>
                  ) : (
                    <>
                      <div className="space-y-2">
                        <h3 className="font-display text-2xl font-bold text-slate-900 leading-tight">Stay Updated on Construction Trends</h3>
                        <p className="text-slate-500 text-sm leading-relaxed">Join our inner circle for exclusive project updates, design trends, and architectural insights from Kerala's leaders.</p>
                      </div>

                      <div className="space-y-4 pt-2">
                        <div className="relative">
                          <input 
                            type="email"
                            value={newsletterEmail}
                            onChange={(e) => setNewsletterEmail(e.target.value)}
                            placeholder="your@email.com"
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-sm text-sm focus:border-amber-600 outline-none transition-all pr-12"
                          />
                          <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                        </div>
                        <button 
                          onClick={() => {
                            if (newsletterEmail.includes('@')) {
                              setSubscribed(true);
                            }
                          }}
                          className="w-full bg-slate-900 text-white font-bold text-xs uppercase tracking-[0.2em] py-4 rounded-sm hover:bg-amber-600 transition-all shadow-lg shadow-slate-900/10 active:scale-95"
                        >
                          Subscribe Now
                        </button>
                        <p className="text-[10px] text-slate-400 text-center uppercase tracking-tighter">No spam. Only high-quality architectural updates.</p>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AIChatWidget currentProject={selectedProject} />
      <BackToTop />

      <AnimatePresence>
        {isReviewFormOpen && (
          <ReviewForm 
            onClose={() => setIsReviewFormOpen(false)} 
            onSubmit={(newReview) => {
              setReviews(prev => [newReview, ...prev]);
              setActiveTestimonial(0);
            }} 
          />
        )}
      </AnimatePresence>

      {/* Site Visit Booking Modal */}
      <AnimatePresence>
        {isSiteVisitFormOpen && selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white max-w-lg w-full rounded-sm shadow-2xl overflow-hidden"
            >
              <div className="p-8">
                <SiteVisitForm 
                  projectName={selectedProject.title} 
                  onClose={() => setIsSiteVisitFormOpen(false)} 
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Role-Specific Inquiry Modal */}
      <AnimatePresence>
        {selectedInquiryMember && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[310] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white max-w-lg w-full rounded-sm shadow-2xl overflow-hidden"
            >
              <div className="p-8">
                <RoleInquiryForm 
                  member={selectedInquiryMember} 
                  onClose={() => setSelectedInquiryMember(null)} 
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {(lightboxImage || activeVideoUrl) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            role="dialog"
            aria-modal="true"
            aria-label={activeVideoUrl ? "Virtual Site Video Tour" : "Fullscreen architectural photo gallery"}
            className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/95 backdrop-blur-xl p-4 md:p-12 cursor-zoom-out"
            onClick={() => {
              setLightboxImage(null);
              setActiveVideoUrl(null);
            }}
          >
            <motion.button
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              aria-label="Close fullscreen view"
              className="absolute top-8 right-8 z-[210] p-3 text-white hover:text-amber-600 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-full"
              onClick={() => {
                setLightboxImage(null);
                setActiveVideoUrl(null);
              }}
            >
              <X className="w-10 h-10" aria-hidden="true" />
            </motion.button>

            <motion.div
              layoutId="lightbox-media"
              initial={{ scale: 0.95, opacity: 0, filter: "blur(10px)" }}
              animate={{ scale: 1, opacity: 1, filter: "blur(0px)" }}
              exit={{ scale: 0.95, opacity: 0, filter: "blur(10px)" }}
              transition={{ 
                type: "spring",
                damping: 30,
                stiffness: 300,
                opacity: { duration: 0.4 }
              }}
              className="relative max-w-7xl max-h-full w-full flex items-center justify-center p-4 bg-slate-900 shadow-2xl overflow-hidden rounded-sm border border-slate-800 select-none group"
              onClick={(e) => e.stopPropagation()}
              onMouseEnter={() => setIsHoveringCarousel(true)}
              onMouseLeave={() => setIsHoveringCarousel(false)}
            >
              {/* Fullscreen 3-Second Slideshow Progress Bar */}
              {selectedProject?.images && selectedProject.images.length > 1 && !activeVideoUrl && (
                <div className="absolute top-0 left-0 right-0 h-1.5 bg-black/50 z-30 overflow-hidden" aria-hidden="true">
                  <motion.div
                    key={`fullscreen-progress-${currentProjectImageIndex}-${slideshowKey}-${isSlideshowPlaying && !isHoveringCarousel}`}
                    initial={{ width: "0%" }}
                    animate={{ width: isSlideshowPlaying && !isHoveringCarousel ? "100%" : "0%" }}
                    transition={{
                      duration: isSlideshowPlaying && !isHoveringCarousel ? 3 : 0,
                      ease: "linear",
                    }}
                    className="h-full bg-amber-500 shadow-[0_0_12px_rgba(245,158,11,1)]"
                  />
                </div>
              )}

              {/* Top Fullscreen Controls */}
              {selectedProject?.images && selectedProject.images.length > 1 && !activeVideoUrl && (
                <div className="absolute top-6 left-6 z-30 flex items-center gap-3">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsSlideshowPlaying(prev => !prev);
                      setSlideshowKey(k => k + 1);
                    }}
                    aria-label={isSlideshowPlaying ? "Pause automatic 3-second slideshow" : "Resume automatic 3-second slideshow"}
                    className={`p-2 px-4 rounded-full transition-all backdrop-blur-md flex items-center gap-2 text-white shadow-xl focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 ${
                      isSlideshowPlaying
                        ? 'bg-amber-600/90 hover:bg-amber-600 ring-2 ring-amber-400/40' 
                        : 'bg-black/60 hover:bg-black/80 border border-white/10'
                    }`}
                    title={isSlideshowPlaying ? "Pause Automatic Slideshow (3s)" : "Resume Automatic Slideshow (3s)"}
                  >
                    {isSlideshowPlaying ? (
                      <>
                        <Pause className="w-4 h-4 fill-current" aria-hidden="true" />
                        <span className="text-xs font-bold uppercase tracking-wider">
                          {isHoveringCarousel ? 'Paused (Hover)' : '3s Slideshow'}
                        </span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 fill-current" aria-hidden="true" />
                        <span className="text-xs font-bold uppercase tracking-wider">Play (3s)</span>
                      </>
                    )}
                  </button>

                  <div className="text-xs font-bold text-white bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10" aria-label={`Photo ${currentProjectImageIndex + 1} of ${selectedProject.images.length}`}>
                    {currentProjectImageIndex + 1} / {selectedProject.images.length}
                  </div>
                </div>
              )}

              {activeVideoUrl ? (
                <div className="w-full aspect-video">
                  <iframe 
                    src={activeVideoUrl} 
                    className="w-full h-full border-0 rounded-sm"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowFullScreen
                    title={`Virtual Site Video Tour for ${selectedProject?.title || "Project"}`}
                  ></iframe>
                </div>
              ) : (
                <div className="relative w-full flex items-center justify-center">
                  <AnimatePresence mode="wait" initial={false}>
                    <LazyImage 
                      key={currentProjectImageIndex}
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.98 }}
                      transition={{ duration: 0.25 }}
                      src={lightboxImage!} 
                      alt={`Fullscreen high resolution view of ${selectedProject?.title || 'project'} - photo ${currentProjectImageIndex + 1}`} 
                      className="max-w-full max-h-[85vh] flex items-center justify-center object-contain"
                      showSkeleton={true}
                    />
                  </AnimatePresence>

                  {/* Fullscreen Next / Prev Controls */}
                  {selectedProject?.images && selectedProject.images.length > 1 && (
                    <div className="absolute inset-x-0 flex items-center justify-between px-4 pointer-events-none z-20">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          const nextIdx = (currentProjectImageIndex - 1 + selectedProject.images!.length) % selectedProject.images!.length;
                          setCurrentProjectImageIndex(nextIdx);
                          setLightboxImage(selectedProject.images![nextIdx]);
                          setSlideshowKey(k => k + 1);
                        }}
                        aria-label="View previous fullscreen image"
                        className="p-3 bg-black/60 hover:bg-amber-600 text-white rounded-full transition-all backdrop-blur-md pointer-events-auto shadow-2xl hover:scale-110 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                        title="Previous Image (Left Arrow)"
                      >
                        <ChevronRight className="w-6 h-6 rotate-180" aria-hidden="true" />
                      </button>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          const nextIdx = (prev => (prev + 1) % selectedProject.images!.length)(currentProjectImageIndex);
                          setCurrentProjectImageIndex(nextIdx);
                          setLightboxImage(selectedProject.images![nextIdx]);
                          setSlideshowKey(k => k + 1);
                        }}
                        aria-label="View next fullscreen image"
                        className="p-3 bg-black/60 hover:bg-amber-600 text-white rounded-full transition-all backdrop-blur-md pointer-events-auto shadow-2xl hover:scale-110 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                        title="Next Image (Right Arrow)"
                      >
                        <ChevronRight className="w-6 h-6" aria-hidden="true" />
                      </button>
                    </div>
                  )}
                </div>
              )}
              
              <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent">
                 <div className="flex items-center justify-between">
                   <div className="flex items-center gap-3">
                     <div className="w-1 h-8 bg-amber-600" aria-hidden="true" />
                     <div>
                       <h4 className="text-white font-display font-bold uppercase tracking-widest text-sm">
                         {activeVideoUrl ? "Virtual Site Tour" : (selectedProject?.title || "Site Detail Insight")}
                       </h4>
                       <p className="text-slate-400 text-[10px] uppercase tracking-tighter">
                         {selectedProject?.location ? `${selectedProject.location} • ` : ""}APS Builders & Developers • High Quality Media
                       </p>
                     </div>
                   </div>

                   {/* Fullscreen bottom slide dots */}
                   {selectedProject?.images && selectedProject.images.length > 1 && !activeVideoUrl && (
                     <div className="hidden sm:flex items-center gap-1.5 bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10" role="tablist" aria-label="Fullscreen images list">
                       {selectedProject.images.map((_, i) => (
                         <button
                           key={i}
                           role="tab"
                           aria-selected={currentProjectImageIndex === i}
                           aria-label={`Go to fullscreen image ${i + 1} of ${selectedProject.images.length}`}
                           onClick={(e) => {
                             e.stopPropagation();
                             setCurrentProjectImageIndex(i);
                             setLightboxImage(selectedProject.images![i]);
                             setSlideshowKey(k => k + 1);
                           }}
                           className={`h-1.5 rounded-full transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-white ${
                             currentProjectImageIndex === i ? 'w-6 bg-amber-500 shadow-sm' : 'w-2 bg-white/40 hover:bg-white/70'
                           }`}
                           title={`Go to image ${i + 1}`}
                         />
                       ))}
                     </div>
                   )}
                 </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      </motion.div>
      
      {/* Automated WhatsApp Flow Modal */}
      <AnimatePresence>
        {isWhatsAppModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            role="dialog"
            aria-modal="true"
            aria-label="WhatsApp Project Inquiry Assistant"
            className="fixed inset-0 z-[500] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 px-6"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white max-w-lg w-full rounded-sm shadow-2xl relative"
            >
               <button 
                 onClick={() => setIsWhatsAppModalOpen(false)}
                 aria-label="Close WhatsApp inquiry modal"
                 className="absolute top-4 right-4 z-50 p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400 hover:text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
               >
                 <X className="w-5 h-5" aria-hidden="true" />
               </button>
               <WhatsAppLeadQualifier />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Live Service Worker Milestone Notification Toast */}
      <AnimatePresence>
        {activeMilestoneToast && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-6 right-6 z-[1000] max-w-sm w-full bg-slate-900 text-white rounded-xl shadow-2xl p-4 border border-amber-500/40 overflow-hidden"
            id="service-worker-milestone-toast"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-400 to-amber-600 animate-pulse" />
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-amber-500/20 rounded-lg flex items-center justify-center text-amber-400 shrink-0 border border-amber-500/30">
                <Sparkles className="w-5 h-5 animate-spin-slow" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1 mb-0.5">
                  <span className="text-[9px] font-mono uppercase tracking-widest text-amber-400 font-bold">
                    Push Milestone Alert
                  </span>
                  <button 
                    onClick={() => setActiveMilestoneToast(null)}
                    className="text-slate-400 hover:text-white p-0.5"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <h5 className="text-xs font-bold text-white truncate mb-0.5">
                  {activeMilestoneToast.projectTitle}
                </h5>
                <p className="text-[11px] text-slate-300 line-clamp-2 leading-relaxed">
                  Stage &ldquo;{activeMilestoneToast.milestone}&rdquo; completed & verified on site.
                </p>
                
                <div className="mt-2.5 flex items-center gap-2">
                  <button
                    onClick={() => {
                      const match = PROJECTS.find(p => String(p.id) === String(activeMilestoneToast.projectId) || p.title.toLowerCase().includes(activeMilestoneToast.projectTitle.toLowerCase()));
                      if (match) setSelectedProject(match);
                      setActiveMilestoneToast(null);
                    }}
                    className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 text-[10px] font-bold uppercase tracking-wider rounded transition-colors"
                  >
                    View Project Blueprint
                  </button>
                  <button
                    onClick={() => setActiveMilestoneToast(null)}
                    className="px-2 py-1 text-slate-400 hover:text-slate-200 text-[10px] uppercase font-medium"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {selectedProject && <ProjectPrintSummary project={selectedProject} />}

      {/* Floating Pill to Return / Lock to Coming Soon */}
      {!showComingSoon && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          onClick={() => {
            sessionStorage.removeItem('aps_preview_unlocked');
            setShowComingSoon(true);
          }}
          aria-label="Lock Site to Coming Soon Preview"
          className="fixed bottom-6 left-6 z-[70] group flex items-center gap-2 px-3.5 py-2 rounded-full bg-slate-950/90 text-white border border-amber-500/40 hover:border-amber-400 shadow-2xl backdrop-blur-md transition-all hover:scale-105 active:scale-95 text-[11px] font-mono uppercase cursor-pointer"
        >
          <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          <span className="font-semibold text-amber-300">Lock to Preview 🔒</span>
        </motion.button>
      )}
    </div>
  );
}

