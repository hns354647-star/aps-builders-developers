export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio: string;
  image: string;
}

export const LEADERSHIP: TeamMember[] = [
  {
    id: "l1",
    name: "Aman P. Sharma",
    role: "Founder & Chief Architect",
    bio: "With over 15 years of experience in sustainable urban planning, Aman leads the architectural vision of APS, focusing on the intersection of luxury and environmental responsibility.",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: "l2",
    name: "Vikram Malhotra",
    role: "Project Director",
    bio: "Vikram oversees all on-site construction operations, ensuring that the highest standards of safety and engineering precision are met across every square foot of development.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: "l3",
    name: "Sarah Fernandes",
    role: "Lead Interior Designer",
    bio: "Sarah brings a unique editorial eye to our residential projects, specializing in bespoke minimal interiors that maximize natural lighting and functional flow.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: "l4",
    name: "Rajesh Kulkarni",
    role: "Chief Engineer",
    bio: "An expert in structural integrity and modern ventilation systems, Rajesh ensures that every APS build is as resilient as it is aesthetically pleasing.",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=400"
  }
];
