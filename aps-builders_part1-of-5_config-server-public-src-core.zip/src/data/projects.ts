import villaImg from "../assets/images/luxury_villa_with_people_1780826940427.png";
import commercialImg from "../assets/images/commercial_plaza_with_people_1780827020678.png";
import sustainableImg from "../assets/images/sustainable_home_with_people_1780826956508.png";
import estateImg from "../assets/images/residential_estate_with_people_1780827005899.png";
import officeImg from "../assets/images/panchayath_office_with_people_1780826972320.png";
import glassTowerImg from "../assets/images/aps_glass_tower_1780810854036.png";
import duplexImg from "../assets/images/aps_contemporary_duplex_1780810868582.png";
import villaDevImg from "../assets/images/aps_premium_villa_dev_1780810996152.png";
import educationalImg from "../assets/images/educational_block_with_people_1780826987325.png";
import schoolGateImg from "../assets/images/aps_school_gate_1780811027011.png";
import institutionalImg from "../assets/images/aps_institutional_facility_1780811041275.png";
import apartmentImg from "../assets/images/aps_luxury_apartments_1780811619781.png";

export interface ProjectMilestone {
  label: string;
  date: string;
  status: 'Completed' | 'In Progress' | 'Pending';
}

export interface Project {
  id: string;
  title: string;
  location: string;
  type: string;
  status: string;
  image?: string;
  images?: string[];
  videoUrl?: string;
  description?: string;
  year?: string;
  startDate?: string;
  estimatedCompletion?: string;
  cost?: number; // In INR
  milestone?: string; // e.g. "Foundation Laid", "Permit Approved"
  milestones?: ProjectMilestone[];
  architecturalViews?: {
    id: string;
    title: string;
    type: '3d' | 'blueprint' | 'elevation';
    url: string;
  }[];
}

export const PROJECTS: Project[] = [
  { 
    id: "p1",
    title: "Modern Luxury Villa", 
    location: "Kochi, Kerala", 
    type: "Residential", 
    status: "Completed", 
    year: "2023",
    image: villaImg,
    images: [villaImg, sustainableImg, estateImg],
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Sample video
    description: "A high-end minimal villa featuring smart home integration and sustainable cooling systems.",
    startDate: "Jan 2024",
    estimatedCompletion: "Dec 2024",
    cost: 35000000, // 3.5 Crore
    milestone: "Foundation Laid",
    milestones: [
      { label: "Site Preparation", date: "Jan 12, 2024", status: "Completed" },
      { label: "Foundation Work", date: "Feb 20, 2024", status: "Completed" },
      { label: "Structural Framing", date: "May 15, 2024", status: "Completed" },
      { label: "Interior Finishing", date: "Oct 10, 2024", status: "In Progress" },
      { label: "Final Inspection", date: "Dec 15, 2024", status: "Pending" }
    ],
    architecturalViews: [
      { id: "v1", title: "External 3D Render", type: "3d", url: "https://modelviewer.dev/shared-assets/models/Astronaut.glb" }, // Using a sample model
      { id: "v2", title: "Main Floor Plan", type: "blueprint", url: villaImg },
      { id: "v3", title: "Front Elevation", type: "elevation", url: estateImg }
    ]
  },
  { 
    id: "p2",
    title: "Sustainable Home Project", 
    location: "Kottayam, Kerala", 
    type: "Residential", 
    status: "Under Construction",
    year: "2024",
    image: sustainableImg,
    images: [sustainableImg, villaImg, apartmentImg],
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Sample video
    description: "Eco-friendly residence using recycled materials and solar power grid.",
    startDate: "Mar 2023",
    estimatedCompletion: "Oct 2024",
    cost: 22000000, // 2.2 Crore
    milestone: "Roofing Phase",
    milestones: [
      { label: "Design Approval", date: "Mar 10, 2023", status: "Completed" },
      { label: "Foundation", date: "Jun 05, 2023", status: "Completed" },
      { label: "Shell Construction", date: "Nov 22, 2023", status: "Completed" },
      { label: "Roofing & Insulation", date: "Jun 15, 2024", status: "In Progress" },
      { label: "Solar Installation", date: "Aug 20, 2024", status: "Pending" },
      { label: "Handover", date: "Oct 30, 2024", status: "Pending" }
    ],
    architecturalViews: [
      { id: "s1", title: "Solar Grid Map", type: "blueprint", url: sustainableImg },
      { id: "s2", title: "Elevation B", type: "elevation", url: villaImg }
    ]
  },
  { 
    id: "p3",
    title: "Grand Residential Estate", 
    location: "Thrissur, Kerala", 
    type: "Residential", 
    status: "Completed", 
    year: "2022",
    cost: 65000000, // 6.5 Crore
    image: estateImg,
    images: [estateImg, glassTowerImg, duplexImg],
    description: "Sprawling luxury estate combining traditional Kerala architecture with modern amenities.",
    milestone: "Handover Complete"
  },
  { 
    id: "p4",
    title: "Luxury Apartment Complex", 
    location: "Ernakulam, Kerala", 
    type: "Residential", 
    status: "Planning", 
    year: "2025",
    image: apartmentImg,
    images: [apartmentImg, glassTowerImg, commercialImg],
    description: "Upcoming multi-story complex with rooftop infinity pool and urban gardens.",
    milestone: "Permit Approved"
  },
  { 
    id: "p5",
    title: "Grama Panchayath Office", 
    location: "Chinnakanal", 
    type: "Infrastructure", 
    status: "Completed", 
    year: "2021",
    image: officeImg,
    images: [officeImg, institutionalImg, schoolGateImg],
    description: "Modern public service facility designed for accessibility and efficiency.",
    milestone: "Completed"
  },
  { 
    id: "p6",
    title: "The Glass Tower Residence", 
    location: "Ernakulam, Kerala", 
    type: "Residential", 
    status: "Under Construction", 
    year: "2024",
    cost: 1200000000, // 120 Crore (Building complex)
    milestone: "Structural Glazing",
    image: glassTowerImg,
    images: [glassTowerImg, apartmentImg, commercialImg],
    description: "Futuristic glass-facade residential tower offering panoramic city views.",
    architecturalViews: [
      { id: "g1", title: "Tower Structure", type: "3d", url: "https://modelviewer.dev/shared-assets/models/Astronaut.glb" },
      { id: "g2", title: "Penthouse Plan", type: "blueprint", url: apartmentImg }
    ]
  },
  { 
    id: "p7",
    title: "Premium Commercial Plaza", 
    location: "Alappuzha, Kerala", 
    type: "Commercial", 
    status: "Planning", 
    year: "2025",
    image: commercialImg,
    images: [commercialImg, glassTowerImg, villaDevImg],
    description: "Signature retail and office destination in the heart of Alappuzha.",
    milestone: "Site Analysis"
  },
  { 
    id: "p8",
    title: "Contemporary Duplex", 
    location: "Kollam, Kerala", 
    type: "Residential", 
    status: "Completed", 
    year: "2023",
    image: duplexImg,
    images: [duplexImg, sustainableImg, villaImg],
    description: "Space-efficient modern duplex with custom interior wood craftsmanship.",
    milestone: "Finishing Works"
  },
  { 
    id: "p9",
    title: "Premium Villa Development", 
    location: "Idukki, Kerala", 
    type: "Residential", 
    status: "Under Construction", 
    year: "2024",
    image: villaDevImg,
    images: [villaDevImg, estateImg, glassTowerImg],
    description: "Hill-top residential community focused on environmental preservation.",
    milestone: "Retaining Wall Built"
  },
  { 
    id: "p10",
    title: "Educational Institute Block", 
    location: "Pathanamthitta", 
    type: "Institutional", 
    status: "Completed", 
    year: "2022",
    image: educationalImg,
    images: [educationalImg, schoolGateImg, officeImg],
    description: "Advanced learning facility with modern labs and auditorium."
  },
  { 
    id: "p11",
    title: "NSHSS School Gate", 
    location: "Nedumudy", 
    type: "Infrastructure", 
    status: "Completed", 
    year: "2020",
    image: schoolGateImg,
    images: [schoolGateImg, institutionalImg, officeImg],
    description: "Iconic entrance design for a heritage educational institution."
  },
  { 
    id: "p12",
    title: "Institutional Facility", 
    location: "Alappuzha", 
    type: "Institutional", 
    status: "Planning", 
    year: "2026",
    image: institutionalImg,
    images: [institutionalImg, schoolGateImg, officeImg],
    description: "Upcoming specialized facility for institutional and social services."
  },
  {
    id: "crystal-point",
    title: "Crystal Point",
    location: "Coastal Kerala",
    type: "Residential",
    status: "Featured",
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1920&q=80",
    images: [
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1920&q=80",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1920&q=80",
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1920&q=80"
    ],
    description: "A sanctuary where modern design meets the raw, untamed beauty of the ocean.",
  }
];
