/**
 * High-Resolution Editorial Dataset for Archidomo
 * Mimics Sanity CMS documents with bilingual support (FR / EN)
 */

export interface SanityProject {
  _id: string;
  title: string;
  slug: string;
  type: 'villa' | 'chalet';
  area: number;
  location: string;
  region: 'annecy' | 'alpes' | 'geneve' | 'riviera' | 'provence';
  year: number;
  featured?: boolean;
  order: number;
  teaser: {
    fr: string;
    en: string;
  };
  description: {
    fr: string;
    en: string;
  };
  heroImage: {
    url: string;
    alt: string;
    caption?: string;
  };
  previewImage: {
    url: string;
    alt: string;
  };
  gallery: Array<{
    url: string;
    alt: string;
    caption: { fr: string; en: string };
    layoutStyle: 'full' | 'portrait' | 'square' | 'wide';
  }>;
  specifications: {
    materials: { fr: string; en: string };
    exposure: { fr: string; en: string };
    amenities: { fr: string; en: string };
  };
}

export interface InspirationCategory {
  id: string;
  title: { fr: string; en: string };
  caption: { fr: string; en: string };
  images: Array<{
    url: string;
    alt: string;
    caption: { fr: string; en: string };
  }>;
}

export interface NewsPost {
  _id: string;
  title: { fr: string; en: string };
  slug: string;
  date: string;
  category: { fr: string; en: string };
  coverImage: string;
  readTime: string;
  excerpt: { fr: string; en: string };
  body: { fr: string[]; en: string[] };
}

export interface OfficeLocation {
  city: string;
  label: string;
  address: string;
  postalCode: string;
  region: string;
  phone: string;
  email: string;
  googleMapsUrl: string;
  coordinates: { lat: number; lng: number };
}

// 8 Hero Slides (Final slide is wide 1920x940 crop)
export const HERO_SLIDES = [
  {
    id: 1,
    title: "Villa Elektra",
    location: "Lac de Genève, Suisse",
    url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=2200&q=85",
    alt: "Architecture contemporaine de prestige sur les rives du lac Léman",
    isFinalWideCrop: false,
  },
  {
    id: 2,
    title: "Chalet Ultima",
    location: "Courchevel 1850",
    url: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=2200&q=85",
    alt: "Chalet d'exception au sommet des Alpes enneigées",
    isFinalWideCrop: false,
  },
  {
    id: 3,
    title: "Villa Akila",
    location: "Talloires, Lac d'Annecy",
    url: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=2200&q=85",
    alt: "Villa moderne avec piscine miroir surplombant le lac d'Annecy",
    isFinalWideCrop: false,
  },
  {
    id: 4,
    title: "Chalets Twin & Brother",
    location: "Courchevel",
    url: "https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=2200&q=85",
    alt: "Double chalet d'architecte mêlant mélèze brûlé et pierre de taille",
    isFinalWideCrop: false,
  },
  {
    id: 5,
    title: "Villa Gibson",
    location: "Cannes Californie",
    url: "https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=2200&q=85",
    alt: "Résidence contemporaine dominant la baie de Cannes",
    isFinalWideCrop: false,
  },
  {
    id: 6,
    title: "Chalet Haven",
    location: "Megève, Mont d'Arbois",
    url: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=2200&q=85",
    alt: "Refuge alpin haut de gamme aux baies vitrées monumentales",
    isFinalWideCrop: false,
  },
  {
    id: 7,
    title: "Villa Restanque",
    location: "Nice Cap de Nice",
    url: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=2200&q=85",
    alt: "Villa minérale insérée dans la falaise méditerranéenne",
    isFinalWideCrop: false,
  },
  {
    id: 8,
    title: "Le Belvédère Alpin",
    location: "Haute-Savoie",
    url: "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=1920&h=940&q=85",
    alt: "Vue panoramique 1920x940 de l'horizon alpin et de l'architecture épurée",
    isFinalWideCrop: true,
  },
];

// Featured Project: Villa Elektra
export const FEATURED_PROJECT: SanityProject = {
  _id: "villa-elektra",
  title: "Villa Elektra",
  slug: "villa-elektra",
  type: "villa",
  area: 1150,
  location: "Lac de Genève",
  region: "geneve",
  year: 2025,
  featured: true,
  order: 0,
  teaser: {
    fr: "Un tour de passe-passe majestueux où la masse de béton s'efface devant les reflets du lac Léman.",
    en: "A majestic sleight of hand where monolithic concrete dissolves into the infinite reflections of Lake Geneva.",
  },
  description: {
    fr: "Suspendue entre ciel et eau sur les rives suisses du lac Léman, la Villa Elektra incarne l'épure architecturale poussée à son paroxysme. Les porte-à-faux audacieux de 14 mètres semblent flotter sans point d'appui visible. Des baies vitrées de 6 mètres de haut s'escamotent intégralement dans les parois, abolissant toute frontière entre les salons de réception et la nappe lacustre. Les textures de béton brut désactivé dialoguent avec un noyer américain soyeux et la pierre calcaire de Bourgogne.",
    en: "Suspended between sky and water along the Swiss shores of Lake Geneva, Villa Elektra embodies radical architectural restraint. Daring 14-meter cantilevers appear to hover without apparent structural support. Six-meter motorized glass panes slide invisibly into structural pockets, dissolving any boundary between reception salons and the lake. Textures of sand-blasted concrete converse with warm American walnut and honed Burgundy limestone.",
  },
  heroImage: {
    url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=85",
    alt: "Façade principale de la Villa Elektra sur le lac de Genève",
    caption: "Porte-à-faux sculptural et reflets lacustres.",
  },
  previewImage: {
    url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=772&h=630&q=80",
    alt: "Villa Elektra Lac de Genève",
  },
  gallery: [
    {
      url: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1600&q=85",
      alt: "Piscine à débordement en porte-à-faux",
      caption: {
        fr: "Bassin miroir de 25 mètres en pierre de Vals.",
        en: "25-meter mirror infinity pool clad in Vals quartzite.",
      },
      layoutStyle: "wide",
    },
    {
      url: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85",
      alt: "Salon cathédrale avec vue panoramique",
      caption: {
        fr: "Hauteur sous plafond de 6,5 m baignée de lumière zénithale.",
        en: "6.5-meter cathedral ceiling bathed in directional daylight.",
      },
      layoutStyle: "portrait",
    },
    {
      url: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=85",
      alt: "Détail d'assemblage en noyer et marbre noir",
      caption: {
        fr: "Menuiserie millimétrée sur-mesure intégrée aux refends.",
        en: "Bespoke millimeter architectural millwork integrated into concrete piers.",
      },
      layoutStyle: "square",
    },
    {
      url: "https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&w=1800&q=85",
      alt: "Crépuscule sur la terrasse lacustre",
      caption: {
        fr: "Mise en lumière cinématique au crépuscule sur le Léman.",
        en: "Cinematic evening illumination overlooking Lake Geneva.",
      },
      layoutStyle: "full",
    },
  ],
  specifications: {
    materials: {
      fr: "Béton brut désactivé, Pierre de Vals, Noyer d'Amérique, Verre structural extra-clair",
      en: "Sand-blasted concrete, Vals stone, American walnut, structural low-iron glass",
    },
    exposure: {
      fr: "Plein Sud-Ouest avec cadrage frontal sur le Jura et le lac Léman",
      en: "South-West exposure with frontal panorama towards the Jura and Lake Geneva",
    },
    amenities: {
      fr: "Bassin miroir 25m, Spa privatif, Salle de cinéma acoustique, Garage souterrain 6 véhicules",
      en: "25m mirror lap pool, private wellness spa, acoustic screening salon, 6-car gallery",
    },
  },
};

// All 11 Projects for the Typographic Index + Portfolio
export const PROJECTS_INDEX: SanityProject[] = [
  {
    _id: "chalets-twin-brother",
    title: "Chalets Twin & Brother",
    slug: "chalets-twin-brother",
    type: "chalet",
    area: 800,
    location: "Courchevel",
    region: "alpes",
    year: 2024,
    order: 1,
    teaser: {
      fr: "Deux volumes fraternels unis par une passerelle de verre suspendue au-dessus du manteau neigeux.",
      en: "Two fraternal architectural volumes joined by a glazed skybridge above the virgin snow.",
    },
    description: {
      fr: "Conçus pour deux frères collectionneurs d'art contemporain, ces chalets jumeaux réinterprètent la morphologie alpine traditionnelle. Le mélèze brûlé selon la technique japonaise Shou Sugi Ban dialogue avec la pierre de taille locale. À l'intérieur, les volumes monumentaux abritent des toiles monumentales et un spa taillé à même la roche.",
      en: "Designed for two contemporary art collecting brothers, these twin chalets reinvent the alpine vernacular. Charred larch timber converses with local quarried stone. Within, monumental double-height volumes accommodate major art pieces and a wellness sanctuary hewn directly into living rock.",
    },
    heroImage: {
      url: "https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=1600&q=85",
      alt: "Chalets Twin & Brother à Courchevel",
      caption: "Double silhouette dans la forêt de mélèzes.",
    },
    previewImage: {
      url: "https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=772&h=630&q=80",
      alt: "Chalets Twin & Brother Courchevel",
    },
    gallery: [
      {
        url: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=85",
        alt: "Terrasse sous la neige",
        caption: { fr: "Plein sud vers les cimes de Courchevel.", en: "South facing towards Courchevel peaks." },
        layoutStyle: "wide",
      },
      {
        url: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=85",
        alt: "Cheminée monumentale en acier corten",
        caption: { fr: "Foyer suspendu en acier patiné.", en: "Suspended patina steel fireplace." },
        layoutStyle: "portrait",
      },
    ],
    specifications: {
      materials: { fr: "Mélèze brûlé, Pierre de Luzerne, Acier corten", en: "Charred larch, Luzerne stone, Corten steel" },
      exposure: { fr: "Sud / Sud-Est, accès direct pistes", en: "South / South-East, ski-in / ski-out access" },
      amenities: { fr: "Ski room d'exception, Spa avec bain nordique extérieur", en: "Bespoke ski room, Alpine spa with outdoor cedar onsen" },
    },
  },
  {
    _id: "villa-akila",
    title: "Villa Akila",
    slug: "villa-akila",
    type: "villa",
    area: 480,
    location: "Lac d'Annecy",
    region: "annecy",
    year: 2024,
    order: 2,
    teaser: {
      fr: "Une plateforme minérale en équilibre parfait sur les contreforts de la Tournette.",
      en: "A mineral cantilevered terrace in quiet balance upon the slopes of La Tournette.",
    },
    description: {
      fr: "Bâtie sur une parcelle abrupte surplombant la baie de Talloires, la Villa Akila s'enracine dans la roche avant de s'élancer vers les eaux turquoise du lac d'Annecy. La toiture végétalisée se fond dans le paysage alpin, tandis que les terrasses en gradins offrent des perspectives changeantes au fil des saisons.",
      en: "Erected upon a steep promontory overlooking Talloires bay, Villa Akila anchors into mountain bedrock before lunging toward the turquoise lake. Its green roof merges into surrounding alpine pastures while stepped terraces offer shifting vistas with every season.",
    },
    heroImage: {
      url: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1600&q=85",
      alt: "Villa Akila sur le lac d'Annecy",
      caption: "L'horizontalité absolue face aux sommets.",
    },
    previewImage: {
      url: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=772&h=630&q=80",
      alt: "Villa Akila Lac d'Annecy",
    },
    gallery: [
      {
        url: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1600&q=85",
        alt: "Piscine à débordement sur Annecy",
        caption: { fr: "L'eau du bassin prolongeant l'horizon du lac.", en: "The pool mirror extending the lake's horizon." },
        layoutStyle: "wide",
      },
    ],
    specifications: {
      materials: { fr: "Béton blanc architectonique, Chêne sablé, Verre triple vitrage", en: "Architectural white concrete, Sanded oak, Triple glazed panes" },
      exposure: { fr: "Ouest / Coucher de soleil sur le Semnoz", en: "West / Sunset over Mount Semnoz" },
      amenities: { fr: "Ponton privé, Piscine chauffée géothermie", en: "Private lake deck, Geothermal heated lap pool" },
    },
  },
  {
    _id: "chalet-ultima",
    title: "Chalet Ultima",
    slug: "chalet-ultima",
    type: "chalet",
    area: 2100,
    location: "Courchevel",
    region: "alpes",
    year: 2023,
    order: 3,
    teaser: {
      fr: "Le sommet de l'hôtellerie privée : un domaine d'exception taillé pour les sommets.",
      en: "The pinnacle of private alpine luxury: an extraordinary residential estate designed for the summits.",
    },
    description: {
      fr: "Avec plus de 2100 m² habitables, Chalet Ultima réinvente le grand domaine alpin. Déployé sur six niveaux desservis par ascenseur panoramique, il réunit huit suites de maître, un héliport privatif, une piscine intérieure de 20 mètres bordée de marbre noir du Sahara et une cave à grands crus creusée sous la neige.",
      en: "Spanning over 2,100 m² of refined living space, Chalet Ultima redefines the grand alpine estate. Across six levels connected by a glass elevator, it presents eight master suites, private helipad, 20-meter indoor pool clad in Sahara noir marble, and a sommelier cellar carved beneath alpine snow.",
    },
    heroImage: {
      url: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=85",
      alt: "Chalet Ultima Courchevel 1850",
      caption: "Architecture monumentale au cœur de Courchevel 1850.",
    },
    previewImage: {
      url: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=772&h=630&q=80",
      alt: "Chalet Ultima Courchevel",
    },
    gallery: [
      {
        url: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1600&q=85",
        alt: "Façade illuminée de nuit",
        caption: { fr: "Écrin lumineux sur fond d'aiguilles alpines.", en: "Luminous silhouette against alpine spires." },
        layoutStyle: "wide",
      },
    ],
    specifications: {
      materials: { fr: "Vieux bois brossé, Marbre Sahara Noir, Bronze patiné", en: "Reclaimed hand-brushed timber, Sahara Noir marble, Aged bronze" },
      exposure: { fr: "360° panoramique avec vue directe sur la Saulire", en: "360-degree panorama directly facing La Saulire" },
      amenities: { fr: "Piscine intérieure 20m, Cryothérapie, Salle de bal privée", en: "20m indoor pool, Cryotherapy chamber, Private ballroom salon" },
    },
  },
  {
    _id: "villa-gibson",
    title: "Villa Gibson",
    slug: "villa-gibson",
    type: "villa",
    area: 620,
    location: "Cannes",
    region: "riviera",
    year: 2024,
    order: 4,
    teaser: {
      fr: "L'épure méditerranéenne : terrasses en cascade dominant les îles de Lérins.",
      en: "Mediterranean purity: cascading terraces overlooking the Lérins islands.",
    },
    description: {
      fr: "Implantée sur les hauteurs de Cannes dans le quartier exclusif de la Californie, la Villa Gibson est un hommage aux grands maîtres du modernisme californien et brésilien. Ses brise-soleil en béton texturé filtrent la vive lumière azuréenne, tandis que le salon traversant s'ouvre d'un côté sur un patio d'oliviers séculaires et de l'autre sur la mer Méditerranée.",
      en: "Perched above Cannes in the exclusive La Californie district, Villa Gibson pays homage to the masters of mid-century and tropical modernism. Sculptural brise-soleil slats filter intense Riviera sunlight while the open-through salon reveals an ancient olive courtyard on one flank and the Mediterranean on the other.",
    },
    heroImage: {
      url: "https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1600&q=85",
      alt: "Villa Gibson à Cannes",
      caption: "Lignes blanches pures et reflets d'azur.",
    },
    previewImage: {
      url: "https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=772&h=630&q=80",
      alt: "Villa Gibson Cannes",
    },
    gallery: [
      {
        url: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1600&q=85",
        alt: "Piscine suspendue au-dessus de la baie",
        caption: { fr: "Bassin à débordement orienté vers les îles.", en: "Infinity edge oriented towards the Lérins Islands." },
        layoutStyle: "wide",
      },
    ],
    specifications: {
      materials: { fr: "Travertin romain clair, Enduit à la chaux fine, Aluminium anodisé champagne", en: "Light Roman travertine, Venetian lime plaster, Champagne anodized aluminum" },
      exposure: { fr: "Plein Sud Méditerranée", en: "Direct South facing Mediterranean" },
      amenities: { fr: "Piscine suspendue, Jardin botanique méditerranéen", en: "Suspended infinity pool, Mediterranean botanical gardens" },
    },
  },
  {
    _id: "chalets-NOR-SNO",
    title: "Chalets NØR + SNØ",
    slug: "chalets-NOR-SNO",
    type: "chalet",
    area: 420,
    location: "Courchevel",
    region: "alpes",
    year: 2025,
    order: 5,
    teaser: {
      fr: "Minimalisme scandinave et rigueur suisse face aux sommets des 3 Vallées.",
      en: "Nordic minimalism meets Swiss precision confronting the peaks of the 3 Valleys.",
    },
    description: {
      fr: "Inspirés par la lumière boréale et l'architecture nordique, les Chalets NØR + SNØ rompent avec l'ornementation alpine classique pour proposer une pureté géométrique absolue. Les toitures asymétriques favorisent l'écoulement naturel de la neige tout en maximisant les apports solaires d'hiver.",
      en: "Inspired by boreal daylight and Nordic sensibility, Chalets NØR + SNØ abandon decorative alpine tropes to deliver geometric purity. Asymmetrical roof pitches channel snowfall naturally while maximizing passive winter solar warmth.",
    },
    heroImage: {
      url: "https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&w=1600&q=85",
      alt: "Chalets NØR + SNØ à Courchevel",
      caption: "Lignes tendues et contrastes d'ébène et de neige.",
    },
    previewImage: {
      url: "https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&w=772&h=630&q=80",
      alt: "Chalets NØR + SNØ Courchevel",
    },
    gallery: [
      {
        url: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=85",
        alt: "Détail de charpente apparente",
        caption: { fr: "Structure bois lamellé-collé sombre.", en: "Dark glued-laminated timber framework." },
        layoutStyle: "wide",
      },
    ],
    specifications: {
      materials: { fr: "Épicéa noir teinté masse, Zinc prépatiné gris ardoise, Granit suisse", en: "Mass-dyed black spruce, Pre-weathered slate zinc, Swiss granite" },
      exposure: { fr: "Est / Ouest traversant les crêtes", en: "East / West ridge orientation" },
      amenities: { fr: "Sauna panoramique vitré, Bain scandinave en cèdre", en: "Glazed panorama sauna, Cedarwood outdoor onsen" },
    },
  },
  {
    _id: "villa-restanque",
    title: "Villa Restanque",
    slug: "villa-restanque",
    type: "villa",
    area: 450,
    location: "Nice",
    region: "riviera",
    year: 2023,
    order: 6,
    teaser: {
      fr: "Une écriture minérale qui épouse les terrasses centenaires de la Côte d'Azur.",
      en: "A mineral syntax marrying the centennial dry-stone terraces of the French Riviera.",
    },
    description: {
      fr: "Nichée sur les collines niçoises, la Villa Restanque tire son nom des murets de pierre sèche traditionnels. Plutôt que de modifier le terrain naturel, le projet s'est glissé dans la topographie. Chaque niveau correspond à une terrasse plantée d'agrumes, d'oliviers et de cyprès de Florence.",
      en: "Tucked into the hills behind Nice, Villa Restanque draws its identity from traditional dry-stone agricultural terraces. Rather than excavating the natural relief, the design nests within topography. Each level opens onto an orchard terrace of citrus, olives, and Florentine cypresses.",
    },
    heroImage: {
      url: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1600&q=85",
      alt: "Villa Restanque à Nice",
      caption: "Intégration topographique dans la colline.",
    },
    previewImage: {
      url: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=772&h=630&q=80",
      alt: "Villa Restanque Nice",
    },
    gallery: [
      {
        url: "https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1600&q=85",
        alt: "Terrasse sous pergola bioclimatique",
        caption: { fr: "Ombrage filtré et vue panoramique sur la baie des Anges.", en: "Filtered shade and panoramic view of the Baie des Anges." },
        layoutStyle: "wide",
      },
    ],
    specifications: {
      materials: { fr: "Pierre sèche du pays niçois, Béton ocre désactivé, Menuiseries affleurantes", en: "Local dry stone, Ochre sand-blasted concrete, Flush minimalist joinery" },
      exposure: { fr: "Sud / Sud-Est vue mer", en: "South / South-East sea view" },
      amenities: { fr: "Piscine à débordement de 18 mètres, Cave à vin climatisée", en: "18-meter lap pool, Climate-controlled tasting cellar" },
    },
  },
  {
    _id: "villa-verdi",
    title: "Villa Verdi",
    slug: "villa-verdi",
    type: "villa",
    area: 380,
    location: "Aix-en-Provence",
    region: "provence",
    year: 2024,
    order: 7,
    teaser: {
      fr: "Un dialogue poétique avec la montagne Sainte-Victoire et les pins parasols.",
      en: "A poetic conversation with the Sainte-Victoire mountain and umbrella pines.",
    },
    description: {
      fr: "À quelques minutes d'Aix-en-Provence, la Villa Verdi revisite la bastide provençale dans une abstraction totale. De longs murs d'enceinte en béton teinté dans la masse protègent les espaces de vie des ardeurs du mistral tout en cadrant avec une précision cinématographique la silhouette de Cézanne.",
      en: "Minutes outside Aix-en-Provence, Villa Verdi reimagines the Provençal bastide through pure architectural abstraction. Long boundary walls in earth-toned concrete shelter private living spaces from mistral winds while framing Cézanne's mountain with cinematic precision.",
    },
    heroImage: {
      url: "https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&w=1600&q=85",
      alt: "Villa Verdi près d'Aix-en-Provence",
      caption: "Béton teinté et alignement sur la Sainte-Victoire.",
    },
    previewImage: {
      url: "https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&w=772&h=630&q=80",
      alt: "Villa Verdi Aix-en-Provence",
    },
    gallery: [
      {
        url: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1600&q=85",
        alt: "Patio ombragé avec fontaine miroir",
        caption: { fr: "Climatisation passive par bassin et courant d'air naturel.", en: "Passive cooling through water mirror and breezeways." },
        layoutStyle: "wide",
      },
    ],
    specifications: {
      materials: { fr: "Béton teinté argile rouge, Pierre de Rognes, Menuiseries acier corten", en: "Red-clay tinted concrete, Rognes limestone, Corten steel framing" },
      exposure: { fr: "Plein Sud cadré sur la Sainte-Victoire", en: "South-facing framed view of Sainte-Victoire" },
      amenities: { fr: "Bassin de nage 20m, Oliveraie préservée de 40 arbres", en: "20m lap lane, Preserved 40-tree olive orchard" },
    },
  },
  {
    _id: "chalet-haven",
    title: "Chalet Haven",
    slug: "chalet-haven",
    type: "chalet",
    area: 310,
    location: "Megève",
    region: "alpes",
    year: 2023,
    order: 8,
    teaser: {
      fr: "Un cocon intimiste au Mont d'Arbois, sculpté dans le chêne de fil et l'ardoise.",
      en: "An intimate sanctuary at Mont d'Arbois, sculpted from straight-grain oak and slate.",
    },
    description: {
      fr: "Chalet Haven propose une échelle résidentielle feutrée. Conçu comme une maison de famille à l'abri des regards, il privilégie les transitions douces : banquettes intégrées devant le feu, alcôves de lecture avec vue sur les aiguilles de Warens, et un niveau inférieur entièrement dédié à la récupération sportive.",
      en: "Chalet Haven celebrates intimate residential proportions. Conceived as a secluded family retreat, it orchestrates gentle spatial transitions: built-in banquettes around the hearth, reading alcoves overlooking the Warens needles, and a dedicated wellness level for post-ski recovery.",
    },
    heroImage: {
      url: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1600&q=85",
      alt: "Chalet Haven à Megève",
      caption: "Chaleur du bois et rigueur contemporaine au Mont d'Arbois.",
    },
    previewImage: {
      url: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=772&h=630&q=80",
      alt: "Chalet Haven Megève",
    },
    gallery: [
      {
        url: "https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=1600&q=85",
        alt: "Séjour sous pente avec charpente sculpturale",
        caption: { fr: "Travail d'ébénisterie sur-mesure.", en: "Custom architectural cabinetmaking." },
        layoutStyle: "wide",
      },
    ],
    specifications: {
      materials: { fr: "Chêne brossé huilé, Ardoise de Morzine, Laiton brossé", en: "Brushed oiled oak, Morzine natural slate, Satin brass" },
      exposure: { fr: "Sud-Ouest vue Mont-Blanc", en: "South-West view towards Mont-Blanc" },
      amenities: { fr: "Hammam en pierre, Jacuzzi extérieur à débordement", en: "Stone steam hammam, Outdoor overflow hot tub" },
    },
  },
  {
    _id: "villa-mirador",
    title: "Villa Mirador",
    slug: "villa-mirador",
    type: "villa",
    area: 350,
    location: "Lac de Genève",
    region: "geneve",
    year: 2024,
    order: 9,
    teaser: {
      fr: "Un belvédère de verre et d'acier tendu vers les reflets changeants du Léman.",
      en: "A glass and steel belvedere stretching toward the shifting reflections of Lake Geneva.",
    },
    description: {
      fr: "Sur la rive française du lac Léman, la Villa Mirador déploie une silhouette épurée rythmée par des voiles de béton clair et d'immenses parois de verre sans montants visibles. Les espaces intérieurs bénéficient d'une transparence absolue, donnant la sensation de vivre sur le lac.",
      en: "On the French shoreline of Lake Geneva, Villa Mirador reveals a disciplined silhouette articulated by pale concrete fins and expansive frameless glass walls. Living quarters enjoy absolute transparency, evoking life directly upon the lake.",
    },
    heroImage: {
      url: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=85",
      alt: "Villa Mirador sur le lac de Genève",
      caption: "Transparence totale et cadrage lacustre.",
    },
    previewImage: {
      url: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=772&h=630&q=80",
      alt: "Villa Mirador Lac de Genève",
    },
    gallery: [
      {
        url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=85",
        alt: "Vue depuis le salon en porte-à-faux",
        caption: { fr: "Perspective continue vers la rive suisse.", en: "Unbroken gaze across to the Swiss coast." },
        layoutStyle: "wide",
      },
    ],
    specifications: {
      materials: { fr: "Acier noir thermolaqué, Béton lissé, Verre feuilleté acoustique", en: "Powder-coated black steel, Burnished concrete, Acoustic laminated glass" },
      exposure: { fr: "Nord / Nord-Ouest lumière d'artiste constante", en: "North / North-West constant studio north light" },
      amenities: { fr: "Ascenseur vitré, Rampe de mise à l'eau privée", en: "Glass shaft elevator, Private boat slipway" },
    },
  },
  {
    _id: "chalet-arka",
    title: "Chalet Arka",
    slug: "chalet-arka",
    type: "chalet",
    area: 320,
    location: "Megève",
    region: "alpes",
    year: 2024,
    order: 10,
    teaser: {
      fr: "Une silhouette sculpturale en mélèze grisé nichée au creux d'un vallon préservé.",
      en: "A sculptural silhouette of weathered larch resting in the hollow of a preserved valley.",
    },
    description: {
      fr: "À l'écart des sentiers battus de Megève, le Chalet Arka adopte une volumétrie compacte et bioclimatique. La toiture à deux pans asymétriques protège les façades les plus exposées aux intempéries tout en dégageant un séjour double hauteur baigné de soleil au sud.",
      en: "Away from conventional Megève trails, Chalet Arka asserts a compact bioclimatic envelope. Its asymmetrical gabled roof shields weather-beaten elevations while welcoming abundant southern sunshine into a cathedral lounge.",
    },
    heroImage: {
      url: "https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=1600&q=85",
      alt: "Chalet Arka à Megève",
      caption: "Lignes contemporaines et intégration pastorale.",
    },
    previewImage: {
      url: "https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=772&h=630&q=80",
      alt: "Chalet Arka Megève",
    },
    gallery: [
      {
        url: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1600&q=85",
        alt: "Intérieur feutré en bois clair",
        caption: { fr: "Chêne blanchi et textiles en laine d'alpage.", en: "Bleached oak and regional alpine wool textiles." },
        layoutStyle: "wide",
      },
    ],
    specifications: {
      materials: { fr: "Mélèze vieilli naturellement, Cuivre pré-oxydé, Granit du Mont-Blanc", en: "Naturally aged larch, Pre-oxidized copper, Mont-Blanc granite" },
      exposure: { fr: "Sud / Sud-Est", en: "South / South-East" },
      amenities: { fr: "Bain nordique en cèdre rouge, Ski-room sur-mesure chauffé", en: "Red cedar wood onsen, Heated custom ski gallery" },
    },
  },
  {
    _id: "villa-seren",
    title: "Villa Seren",
    slug: "villa-seren",
    type: "villa",
    area: 360,
    location: "Lac d'Annecy",
    region: "annecy",
    year: 2025,
    order: 11,
    teaser: {
      fr: "Un havre de silence et de lumière posé sur la rive ouest du lac d'Annecy.",
      en: "A sanctuary of quietude and light reposing upon the western bank of Lake Annecy.",
    },
    description: {
      fr: "Face au château de Duingt et aux falaises du Roc de Chère, la Villa Seren joue la carte d'une discrétion totale. Depuis la rive, seuls apparaissent des horizontales minérales et le miroitement des baies vitrées reflétant les peupliers centenaires du parc.",
      en: "Confronting Duingt Castle and the cliffs of Roc de Chère, Villa Seren opts for supreme discretion. From the water, only subtle horizontal stone lines and glass reflections mirroring hundred-year-old poplars reveal its quiet presence.",
    },
    heroImage: {
      url: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1600&q=85",
      alt: "Villa Seren au bord du lac d'Annecy",
      caption: "Harmonie d'eau et de roche sur la rive ouest.",
    },
    previewImage: {
      url: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=772&h=630&q=80",
      alt: "Villa Seren Lac d'Annecy",
    },
    gallery: [
      {
        url: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1600&q=85",
        alt: "Piscine miroir bordant le salon",
        caption: { fr: "Continuité entre plan d'eau artificiel et lac naturel.", en: "Continuity between artificial pool and natural lake." },
        layoutStyle: "wide",
      },
    ],
    specifications: {
      materials: { fr: "Pierre calcaire bouchardée, Verre haute performance, Chêne massif grisé", en: "Bush-hammered limestone, High-performance structural glass, Gray solid oak" },
      exposure: { fr: "Est / Lever de soleil sur la Tournette", en: "East / Sunrise directly over Mount Tournette" },
      amenities: { fr: "Ponton d'amarrage, Sauna avec vue immergée", en: "Private mooring dock, Glazed lakefront sauna" },
    },
  },
];

// Agency collage images for Section 4.2 "Notre agence"
export const AGENCY_COLLAGE = [
  {
    url: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85",
    alt: "Espace de vie d'une villa contemporaine Archidomo",
    caption: { fr: "Volume cathédrale et cadrage paysager", en: "Cathedral volume and framed scenery" },
    aspectRatio: "aspect-[4/5]",
  },
  {
    url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=85",
    alt: "Porte-à-faux géométrique sur le lac",
    caption: { fr: "Porte-à-faux architectural", en: "Architectural cantilever" },
    aspectRatio: "aspect-square",
  },
  {
    url: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=85",
    alt: "Matières nobles : noyer, pierre de Vals et verre",
    caption: { fr: "Précision des détails", en: "Millimeter precision" },
    aspectRatio: "aspect-[3/4]",
  },
  {
    url: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=85",
    alt: "Chalet d'exception sous la neige",
    caption: { fr: "Sommets alpins", en: "Alpine summits" },
    aspectRatio: "aspect-[16/10]",
  },
];

// Section 4.5 "La vision" images
export const VISION_DATA = {
  bgImage: "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=2200&q=85",
  title: {
    fr: "La vision",
    en: "The vision",
  },
  paragraph: {
    fr: "Des espaces qui relient les êtres à ce qui les élève. Une beauté qui s'éprouve plutôt qu'elle ne s'abstrait. Parfois spectaculaire, jamais ostentatoire. Une expérience rare, profondément personnelle.",
    en: "Spaces that connect people to what uplifts them. Beauty that is felt rather than abstract. Sometimes spectacular, never ostentatious. A rare, deeply personal experience.",
  },
  portraitLeft: {
    url: "https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=900&h=1140&q=85",
    alt: "Atelier de réflexion inspiré par la montagne",
    caption: {
      fr: "Les idées naissent ici, inspirées par les sommets et le miroir du lac.",
      en: "Ideas are born here, inspired by mountain ridges and the mirror of the lake.",
    },
  },
  portraitRight: {
    url: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=900&h=1140&q=85",
    alt: "Réalisation contemporaine en Haute-Savoie",
    caption: {
      fr: "La réalité n'est pas une limite mais des possibilités à transcender.",
      en: "Reality is not a boundary, but endless possibilities to transcend.",
    },
  },
};

// Section 4.6 "Inspiration" (5 category rows with 3:4 portrait pairs)
export const INSPIRATION_CATEGORIES: InspirationCategory[] = [
  {
    id: "architecture",
    title: {
      fr: "Architecture",
      en: "Architecture",
    },
    caption: {
      fr: "Des lignes qui créent l'espace et célèbrent le caractère.",
      en: "Lines that shape volume and celebrate character.",
    },
    images: [
      {
        url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&h=1067&q=85",
        alt: "Porte-à-faux géométrique épuré",
        caption: { fr: "Porte-à-faux tendu et béton matricé.", en: "Cantilevered mass in fair-faced concrete." },
      },
      {
        url: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=800&h=1067&q=85",
        alt: "Plafond cathédrale et volumes ouverts",
        caption: { fr: "Espaces continus et cadrages zénithaux.", en: "Continuous volumes and zenithal framing." },
      },
    ],
  },
  {
    id: "vues",
    title: {
      fr: "Vues",
      en: "Views",
    },
    caption: {
      fr: "Un hommage à 360° aux panoramas qui émerveillent jour après jour.",
      en: "A 360-degree tribute to panoramas that astonish day after day.",
    },
    images: [
      {
        url: "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=800&h=1067&q=85",
        alt: "Horizon alpin au crépuscule",
        caption: { fr: "Le théâtre perpétuel des crêtes alpines.", en: "The perpetual drama of alpine ridges." },
      },
      {
        url: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=800&h=1067&q=85",
        alt: "Reflets calmes sur le lac d'Annecy",
        caption: { fr: "Miroir d'eau depuis les terrasses hautes.", en: "Reflective expanse seen from upper terraces." },
      },
    ],
  },
  {
    id: "piscines-exterieurs",
    title: {
      fr: "Piscines & extérieurs",
      en: "Pools & Outdoors",
    },
    caption: {
      fr: "Piscines et jardins se fondant dans l'horizon infini.",
      en: "Pools and curated landscapes merging into the horizon.",
    },
    images: [
      {
        url: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=800&h=1067&q=85",
        alt: "Bassin miroir en pierre de Vals",
        caption: { fr: "Bassin miroir de 25 mètres à fleur d'herbe.", en: "Flush 25-meter stone mirror pool." },
      },
      {
        url: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&h=1067&q=85",
        alt: "Terrasse méditerranéenne avec oliviers",
        caption: { fr: "Prolongement paysager en restanques végétalisées.", en: "Stepped landscape terraces with indigenous flora." },
      },
    ],
  },
  {
    id: "atmospheres-interieurs",
    title: {
      fr: "Atmosphères d'intérieurs",
      en: "Interior Atmospheres",
    },
    caption: {
      fr: "Un design qui privilégie le plaisir d'habiter, des matières éloquentes.",
      en: "Design that celebrates the art of living through eloquent materiality.",
    },
    images: [
      {
        url: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=800&h=1067&q=85",
        alt: "Salon feutré avec boiseries en chêne fumé",
        caption: { fr: "Chêne fumé, marbre taillé et draperies de lin pur.", en: "Smoked oak, fluted marble, and pure linen draperies." },
      },
      {
        url: "https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&w=800&h=1067&q=85",
        alt: "Cuisine architecturale sur-mesure",
        caption: { fr: "Monolithe d'îlot en granit brossé et noyer.", en: "Monolithic brushed granite and walnut island." },
      },
    ],
  },
  {
    id: "concepts-esquisses",
    title: {
      fr: "Concepts & Esquisses",
      en: "Concepts & Sketches",
    },
    caption: {
      fr: "Avant le bâti, il y a le geste : chaque projet commence par un premier dessin.",
      en: "Before the structure, there is the gesture: every vision begins with a first stroke.",
    },
    images: [
      {
        url: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=800&h=1067&q=85",
        alt: "Esquisse architecturale et maquette d'étude",
        caption: { fr: "La naissance des lignes de force sur le calque.", en: "Genesis of architectural tension on tracing paper." },
      },
      {
        url: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&h=1067&q=85",
        alt: "Échantillons de matériaux minéraux et bois",
        caption: { fr: "Sélection des échantillons bruts au showroom.", en: "Tactile curation of raw textures at the showroom." },
      },
    ],
  },
];

// Showroom Annecy (Immersion)
export const SHOWROOM_DATA = {
  title: {
    fr: "Immersion – Le Showroom d'Annecy",
    en: "Immersion – The Annecy Showroom",
  },
  subtitle: {
    fr: "Un lieu confidentiel au bord du lac où s'élaborent les projets d'exception.",
    en: "A confidential haven by the lake where exceptional residences take form.",
  },
  address: "Route du Port, 74290 Talloires-Montmin (Lac d'Annecy)",
  phone: "+33 4 50 22 18 40",
  email: "showroom@archidomo.fr",
  description: {
    fr: "Situé à Talloires-Montmin, au bord des eaux calmes du lac d'Annecy, notre showroom 'Immersion' a été imaginé comme un manifeste vivant. Les acquéreurs et maîtres d'ouvrage y découvrent à échelle réelle les assemblages de béton matricé, les menuiseries minimalistes suisses sans profilés apparents, la bibliothèque de pierres alpines de Vals et les essences de bois brûlé.",
    en: "Located in Talloires-Montmin along the tranquil waters of Lake Annecy, our 'Immersion' showroom was conceived as a living architectural manifesto. Here, clients and commissioners experience full-scale mockups: fair-faced architectural concrete, frameless Swiss glazing systems, an exhaustive archive of Vals quartzite, and tactile Shou Sugi Ban charcoaled woods.",
  },
  gallery: [
    {
      url: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1400&q=85",
      alt: "Vue principale du showroom Archidomo à Talloires",
      caption: { fr: "Espace d'échange et salon de présentation.", en: "Consultation lounge and client gallery." },
    },
    {
      url: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=85",
      alt: "Médiathèque de matériaux et échantillons",
      caption: { fr: "Matériauthèque tactile : pierres, bois et alliages.", en: "Tactile materials lab: stone, timbers, and metals." },
    },
    {
      url: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1200&q=85",
      alt: "Table de dessin et maquettes de concours",
      caption: { fr: "Maquettes d'études en bois massif et plâtre.", en: "Physical scale models in solid lime and plaster." },
    },
  ],
};

// 3 Offices (Google Maps links)
export const OFFICES: OfficeLocation[] = [
  {
    city: "Annecy",
    label: "Showroom Immersion",
    address: "Route du Port, 74290 Talloires-Montmin",
    postalCode: "74290",
    region: "Haute-Savoie",
    phone: "+33 4 50 22 18 40",
    email: "annecy@archidomo.fr",
    googleMapsUrl: "https://maps.google.com/?q=Talloires-Montmin+74290",
    coordinates: { lat: 45.8394, lng: 6.2132 },
  },
  {
    city: "Cannes",
    label: "Agence Côte d'Azur",
    address: "Sophia Antipolis, 06560 Valbonne / Cannes",
    postalCode: "06560",
    region: "Alpes-Maritimes",
    phone: "+33 4 93 00 24 10",
    email: "cannes@archidomo.fr",
    googleMapsUrl: "https://maps.google.com/?q=Sophia+Antipolis+06560",
    coordinates: { lat: 43.6163, lng: 7.0552 },
  },
  {
    city: "Lyon",
    label: "Bureau d'Études & Direction",
    address: "Place du Change, 69005 Lyon",
    postalCode: "69005",
    region: "Rhône",
    phone: "+33 4 78 30 15 90",
    email: "lyon@archidomo.fr",
    googleMapsUrl: "https://maps.google.com/?q=Place+du+Change+69005+Lyon",
    coordinates: { lat: 45.7645, lng: 4.8284 },
  },
];

// News posts
export const NEWS_POSTS: NewsPost[] = [
  {
    _id: "prix-architecture-alpes-2025",
    title: {
      fr: "Archidomo lauréat du Prix Européen d'Architecture Alpine",
      en: "Archidomo awarded the European Alpine Architecture Prize",
    },
    slug: "prix-architecture-alpes-2025",
    date: "14 Janvier 2026",
    category: {
      fr: "Presse & Distinctions",
      en: "Press & Awards",
    },
    coverImage: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=85",
    readTime: "4 min",
    excerpt: {
      fr: "Le jury international a salué la virtuosité technique et l'humilité paysagère des Chalets Twin & Brother à Courchevel.",
      en: "The international jury praised the technical virtuosity and landscape restraint of Chalets Twin & Brother in Courchevel.",
    },
    body: {
      fr: [
        "Réunis à Genève pour la 12ème édition des Trophées de l'Architecture de Montagne, les membres du jury ont récompensé l'approche sensible et contemporaine du cabinet Archidomo.",
        "Le projet des Chalets Twin & Brother a su démontrer qu'un ouvrage contemporain pouvait transcender les poncifs du pastiche savoyard sans renoncer à la chaleur du bois local et à la mémoire du lieu.",
        "Carole et Fabrice Gibert ont dédié cette reconnaissance aux artisans d'art et charpentiers compagnons qui ont façonné chaque millimètre de cette réalisation.",
      ],
      en: [
        "Convened in Geneva for the 12th annual Mountain Architecture Laureates, the jury recognized Archidomo's poetic contemporary philosophy.",
        "The Chalets Twin & Brother proved that contemporary alpine dwellings can supersede historical pastiche without losing local timber warmth or geographic memory.",
        "Founders Carole and Fabrice Gibert dedicated this accolade to the master artisans and craftspeople who meticulously crafted every structural detail.",
      ],
    },
  },
  {
    _id: "l-art-du-vide-editorial",
    title: {
      fr: "L'art du vide : concevoir une villa contemporaine au XXIe siècle",
      en: "The Art of Void: Designing a Contemporary Villa in the 21st Century",
    },
    slug: "l-art-du-vide-editorial",
    date: "28 Novembre 2025",
    category: {
      fr: "Éditorial & Vision",
      en: "Editorial & Vision",
    },
    coverImage: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=85",
    readTime: "6 min",
    excerpt: {
      fr: "Tribune de Fabrice Gibert sur l'importance du silence spatial et de la lumière naturelle face à la sur-stimulation contemporaine.",
      en: "An essay by Fabrice Gibert on the power of spatial silence and natural light amid modern sensory overload.",
    },
    body: {
      fr: [
        "Le luxe véritable n'est plus l'accumulation de matière, mais la maîtrise du vide. Dans un monde saturé de sollicitations visuelles, une résidence d'exception doit agir comme un filtre apaisant.",
        "Lorsque nous dessinons les plans de la Villa Elektra sur les rives du lac de Genève, le premier tracé n'est pas un mur : c'est un rayon de soleil hivernal à 16h20 et l'ondulation de l'eau.",
        "L'architecture ne doit pas crier sa présence. Elle doit s'effacer pour laisser place au spectacle pur de la nature environnante.",
      ],
      en: [
        "True luxury is no longer the accumulation of matter, but the mastery of void. In a world saturated with visual noise, a home must operate as a sanctuary.",
        "When sketching Villa Elektra on Lake Geneva, our initial gesture was not a load-bearing wall: it was the 4:20 PM winter sunray and lake water movement.",
        "Architecture should not proclaim its presence. It must retreat to let nature's theater command the senses.",
      ],
    },
  },
  {
    _id: "inauguration-showroom-talloires",
    title: {
      fr: "Immersion : ouverture du nouveau showroom expérientiel à Talloires",
      en: "Immersion: Opening of the new experiential showroom in Talloires",
    },
    slug: "inauguration-showroom-talloires",
    date: "12 Octobre 2025",
    category: {
      fr: "Chantier & Réalisation",
      en: "Studio News",
    },
    coverImage: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85",
    readTime: "3 min",
    excerpt: {
      fr: "Archidomo ouvre les portes de son laboratoire d'architecture confidentiel sur les rives du lac d'Annecy.",
      en: "Archidomo unveils its confidential architectural testing laboratory upon the shores of Lake Annecy.",
    },
    body: {
      fr: [
        "Conçu comme un pavillon d'exposition privé, l'espace 'Immersion' à Talloires-Montmin accueille désormais les futurs propriétaires de villas et chalets sur rendez-vous.",
        "Les visiteurs peuvent y toucher les finitions brutes, observer le comportement de la lumière sur différents verres solaires et simuler leur projet sur maquettes physiques.",
      ],
      en: [
        "Conceived as a private pavilion, 'Immersion' in Talloires-Montmin now welcomes future villa and chalet commissioners by private appointment.",
        "Visitors can touch raw textural finishes, observe natural light through various low-iron coatings, and review their residences through scale models.",
      ],
    },
  },
];
