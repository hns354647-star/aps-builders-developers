// Service Worker & Web Push Notification Client Service for APS Milestone Alerts

export interface MilestoneAlertPayload {
  projectId: string;
  projectTitle: string;
  milestone: string;
  stagePercent?: number;
  image?: string;
  date?: string;
  notes?: string;
}

const STORAGE_KEY_SUBSCRIBED_PROJECTS = 'aps_subscribed_milestone_projects';
const STORAGE_KEY_NOTIF_PREFS = 'aps_milestone_notif_preferences';

/**
 * Get all project IDs the user has subscribed to for milestone alerts
 */
export function getSubscribedProjectIds(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SUBSCRIBED_PROJECTS);
    if (!raw) {
      // Default to premier projects if not set
      const defaults = ['crystal-point', 'grand-palace', 'green-valley'];
      localStorage.setItem(STORAGE_KEY_SUBSCRIBED_PROJECTS, JSON.stringify(defaults));
      return defaults;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Error reading subscribed projects:', e);
    return ['crystal-point'];
  }
}

/**
 * Check if a specific project has active milestone push alerts enabled
 */
export function isProjectSubscribed(projectId: string): boolean {
  const ids = getSubscribedProjectIds();
  return ids.includes(projectId);
}

/**
 * Toggle subscription for a project ID. Returns new subscribed boolean state.
 */
export function toggleProjectSubscription(projectId: string): boolean {
  try {
    const current = getSubscribedProjectIds();
    let updated: string[];
    let isNowSubscribed = false;

    if (current.includes(projectId)) {
      updated = current.filter(id => id !== projectId);
      isNowSubscribed = false;
    } else {
      updated = [...current, projectId];
      isNowSubscribed = true;
    }

    localStorage.setItem(STORAGE_KEY_SUBSCRIBED_PROJECTS, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent('aps-subscription-changed', { detail: { projectId, isSubscribed: isNowSubscribed } }));
    return isNowSubscribed;
  } catch (e) {
    console.error('Error updating project subscription:', e);
    return false;
  }
}

/**
 * Check current notification permission state
 */
export function getNotificationPermission(): NotificationPermission | 'unsupported' {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission;
}

/**
 * Request notification permissions from the user
 */
export async function requestNotificationPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }

  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch (error) {
    console.warn('Error requesting notification permission:', error);
    return Notification.permission;
  }
}

/**
 * Dispatch a project milestone push alert through the active Service Worker
 */
export async function sendMilestoneNotification(payload: MilestoneAlertPayload): Promise<boolean> {
  const { projectId, projectTitle, milestone, image, date } = payload;

  const title = `🚨 Milestone Alert: ${projectTitle}`;
  const body = `Stage update: "${milestone}" has been successfully completed and inspected. Tap to view structural verification.`;

  // 1. If Service Worker is active, use ServiceWorkerRegistration to show rich native notification
  if ('serviceWorker' in navigator) {
    try {
      const reg = await navigator.serviceWorker.ready;
      if (reg) {
        // Send message to SW or trigger showNotification directly on registration
        if (Notification.permission === 'granted') {
          const swOptions: any = {
            body,
            icon: '/favicon.ico',
            image: image,
            badge: '/favicon.ico',
            tag: `milestone-${projectId}`,
            data: {
              projectId,
              milestone,
              date: date || new Date().toLocaleDateString(),
              url: `/?project=${projectId}`
            },
            actions: [
              { action: 'view_project', title: '🏗️ View Blueprint' },
              { action: 'dismiss', title: 'Dismiss' }
            ],
            vibrate: [200, 100, 200],
            renotify: true
          };
          await reg.showNotification(title, swOptions);
        }

        // Also postMessage to service worker for tracking
        if (reg.active) {
          reg.active.postMessage({
            type: 'TRIGGER_MILESTONE_NOTIFICATION',
            title,
            body,
            projectId,
            milestone,
            image,
            date
          });
        }

        // Dispatch in-app notification event for UI toasts
        window.dispatchEvent(new CustomEvent('aps-milestone-alert-received', { detail: payload }));
        return true;
      }
    } catch (swErr) {
      console.warn('Service worker notification dispatch error:', swErr);
    }
  }

  // 2. Fallback to standard Notification if permission is granted
  if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
    try {
      const notif = new Notification(title, {
        body,
        icon: '/favicon.ico',
        tag: `milestone-${projectId}`
      });
      notif.onclick = () => {
        window.focus();
        window.dispatchEvent(new CustomEvent('aps-open-project-modal', { detail: { projectId } }));
        notif.close();
      };
      window.dispatchEvent(new CustomEvent('aps-milestone-alert-received', { detail: payload }));
      return true;
    } catch (notifErr) {
      console.warn('Fallback Notification constructor failed:', notifErr);
    }
  }

  // In-app alert fallback
  window.dispatchEvent(new CustomEvent('aps-milestone-alert-received', { detail: payload }));
  return true;
}
