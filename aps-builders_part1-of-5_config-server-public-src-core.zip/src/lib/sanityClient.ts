/**
 * Sanity CDN & Client Utilities
 * Provides URL transformation following Sanity Image CDN specifications:
 * - width, height, crop rect, quality 80, fit=crop, auto=format
 */

export interface SanityImageSource {
  _type?: 'image';
  asset?: {
    _ref: string;
    _type?: 'reference';
  };
  url?: string;
  alt?: string;
  caption?: string;
}

export interface ImageTransformOptions {
  width?: number;
  height?: number;
  quality?: number;
  fit?: 'crop' | 'clip' | 'fill' | 'scale' | 'max' | 'min';
  auto?: 'format';
  cropRect?: {
    left: number;
    top: number;
    right: number;
    bottom: number;
  };
}

/**
 * Transforms an image source into a Sanity Image CDN URL with exact parameters
 */
export function buildSanityImageUrl(
  source: string | SanityImageSource,
  options: ImageTransformOptions = {}
): string {
  const {
    width,
    height,
    quality = 80,
    fit = 'crop',
    auto = 'format',
    cropRect,
  } = options;

  let rawUrl = '';

  if (typeof source === 'string') {
    rawUrl = source;
  } else if (source && source.url) {
    rawUrl = source.url;
  } else if (source && source.asset?._ref) {
    // Standard Sanity asset ref format: image-Tb9Ew8CXIwaY6R1kjMvI0uRR-2000x3000-jpg
    const ref = source.asset._ref;
    const parts = ref.split('-');
    if (parts.length >= 4) {
      const id = parts[1];
      const dimensions = parts[2];
      const format = parts[3];
      rawUrl = `https://cdn.sanity.io/images/archidomo_prod/production/${id}-${dimensions}.${format}`;
    }
  }

  if (!rawUrl) return '';

  try {
    const url = new URL(rawUrl);

    if (width) url.searchParams.set('w', width.toString());
    if (height) url.searchParams.set('h', height.toString());
    url.searchParams.set('q', quality.toString());
    url.searchParams.set('fit', fit);
    if (auto) url.searchParams.set('auto', auto);

    if (cropRect) {
      url.searchParams.set(
        'rect',
        `${cropRect.left},${cropRect.top},${cropRect.right},${cropRect.bottom}`
      );
    }

    return url.toString();
  } catch {
    // If not a full URL, append parameters
    const params = new URLSearchParams();
    if (width) params.set('w', width.toString());
    if (height) params.set('h', height.toString());
    params.set('q', quality.toString());
    params.set('fit', fit);
    if (auto) params.set('auto', auto);

    return `${rawUrl}?${params.toString()}`;
  }
}

/**
 * Next.js Image compatible loader function for Sanity
 */
export function sanityNextImageLoader({
  src,
  width,
  quality,
}: {
  src: string;
  width: number;
  quality?: number;
}): string {
  return buildSanityImageUrl(src, {
    width,
    quality: quality || 80,
    fit: 'crop',
    auto: 'format',
  });
}
