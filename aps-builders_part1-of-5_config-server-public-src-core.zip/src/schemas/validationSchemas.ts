import { z } from 'zod';

/**
 * Zod Schema for Site Visit Booking Form
 */
export const siteVisitSchema = z.object({
  selectedDate: z
    .number({ message: 'Please select an inspection date.' })
    .refine((val) => typeof val === 'number' && val > 0, {
      message: 'Please select an inspection date.'
    }),
  selectedTime: z
    .string({ message: 'Please select a preferred time slot.' })
    .min(1, 'Please select a preferred time slot.'),
  name: z
    .string({ message: 'Full name is required.' })
    .trim()
    .min(2, 'Name must be at least 2 characters.')
    .max(60, 'Name cannot exceed 60 characters.')
    .regex(/^[a-zA-Z\s.'-]+$/, 'Name should only contain letters and standard characters.'),
  phone: z
    .string({ message: 'Phone number is required.' })
    .trim()
    .min(10, 'Phone number must be at least 10 digits.')
    .max(16, 'Phone number is too long.')
    .regex(
      /^(\+91[\-\s]?)?[0]?(91)?[6789]\d{9}$|^(\+\d{1,3}[\s-]?)?\(?\d{2,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,9}$/,
      'Please enter a valid phone number (e.g. +91 98765 43210).'
    ),
  email: z
    .string({ message: 'Email address is required.' })
    .trim()
    .min(1, 'Email address is required.')
    .email('Please enter a valid email address (e.g. name@example.com).'),
  message: z
    .string()
    .max(500, 'Notes must be within 500 characters.')
    .optional()
    .or(z.literal(''))
});

export type SiteVisitFormData = z.infer<typeof siteVisitSchema>;

/**
 * Zod Schema for Career Application Form
 */
export const careerApplicationSchema = z.object({
  name: z
    .string({ message: 'Full name is required.' })
    .trim()
    .min(2, 'Name must be at least 2 characters.')
    .max(60, 'Name cannot exceed 60 characters.')
    .regex(/^[a-zA-Z\s.'-]+$/, 'Name should only contain letters and standard characters.'),
  email: z
    .string({ message: 'Email address is required.' })
    .trim()
    .min(1, 'Email address is required.')
    .email('Please enter a valid email address (e.g. name@example.com).'),
  phone: z
    .string({ message: 'Phone number is required.' })
    .trim()
    .min(10, 'Phone number must be at least 10 digits.')
    .max(16, 'Phone number is too long.')
    .regex(
      /^(\+91[\-\s]?)?[0]?(91)?[6789]\d{9}$|^(\+\d{1,3}[\s-]?)?\(?\d{2,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,9}$/,
      'Please enter a valid phone number (e.g. +91 98765 43210).'
    ),
  position: z
    .string({ message: 'Please select a position to apply for.' })
    .min(1, 'Please select a target position.')
    .refine(
      (val) => ['architect', 'project-mgr', 'site-eng', 'interior-designer', 'intern'].includes(val),
      { message: 'Please select a valid position from the list.' }
    ),
  portfolioLink: z
    .string({ message: 'Portfolio or Resume URL is required.' })
    .trim()
    .min(1, 'Portfolio or Resume URL is required.')
    .url('Please enter a valid URL including http:// or https://')
    .refine(
      (url) => url.startsWith('http://') || url.startsWith('https://'),
      { message: 'URL must start with https:// or http://' }
    )
});

export type CareerApplicationFormData = z.infer<typeof careerApplicationSchema>;

/**
 * Zod Schema for Role/Team Member Inquiry Form
 */
export const roleInquirySchema = z.object({
  name: z
    .string({ message: 'Your name is required.' })
    .trim()
    .min(2, 'Name must be at least 2 characters.')
    .max(60, 'Name cannot exceed 60 characters.'),
  phone: z
    .string({ message: 'Phone number is required.' })
    .trim()
    .min(10, 'Phone number must be at least 10 digits.')
    .max(16, 'Phone number is too long.')
    .regex(
      /^(\+91[\-\s]?)?[0]?(91)?[6789]\d{9}$|^(\+\d{1,3}[\s-]?)?\(?\d{2,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,9}$/,
      'Please enter a valid mobile number.'
    ),
  email: z
    .string({ message: 'Email address is required.' })
    .trim()
    .min(1, 'Email address is required.')
    .email('Please enter a valid email address.'),
  message: z
    .string({ message: 'Inquiry details are required.' })
    .trim()
    .min(10, 'Message must be at least 10 characters.')
    .max(1000, 'Message cannot exceed 1000 characters.')
});

export type RoleInquiryFormData = z.infer<typeof roleInquirySchema>;

/**
 * Zod Schema for Professional Quote Request Form
 */
export const quoteRequestSchema = z.object({
  name: z
    .string({ message: 'Full name is required.' })
    .trim()
    .min(2, 'Name must be at least 2 characters.')
    .max(70, 'Name cannot exceed 70 characters.')
    .regex(/^[a-zA-Z\s.'-]+$/, 'Name should only contain letters and standard punctuation.'),
  email: z
    .string({ message: 'Email address is required.' })
    .trim()
    .min(1, 'Email address is required.')
    .email('Please enter a valid business or personal email address.'),
  phone: z
    .string({ message: 'Phone number is required.' })
    .trim()
    .min(10, 'Phone number must be at least 10 digits.')
    .max(18, 'Phone number is too long.')
    .regex(
      /^(\+91[\-\s]?)?[0]?(91)?[6789]\d{9}$|^(\+\d{1,3}[\s-]?)?\(?\d{2,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,9}$/,
      'Please enter a valid contact number (e.g. +91 98765 43210).'
    ),
  projectType: z
    .string({ message: 'Project type is required.' })
    .min(1, 'Please select a valid project type.')
    .refine(
      (val) => [
        'waterfront-villa',
        'sky-suite-tower',
        'crown-penthouse',
        'commercial-plaza',
        'bespoke-residence',
        'hospitality-retreat',
        'architectural-advisory'
      ].includes(val),
      { message: 'Please select a recognized project category from the list.' }
    ),
  estimatedBudget: z
    .string()
    .optional()
    .or(z.literal('')),
  location: z
    .string()
    .trim()
    .max(100, 'Location cannot exceed 100 characters.')
    .optional()
    .or(z.literal('')),
  projectScope: z
    .string()
    .trim()
    .max(1200, 'Project description cannot exceed 1200 characters.')
    .optional()
    .or(z.literal(''))
});

export type QuoteRequestFormData = z.infer<typeof quoteRequestSchema>;

/**
 * Helper to validate a single field against a schema in real time
 */
export function validateField(
  schema: any,
  fieldName: string,
  value: unknown
): string | null {
  const shape = schema?.shape;
  if (!shape) return null;
  const fieldSchema = shape[fieldName];
  if (!fieldSchema) return null;

  const result = fieldSchema.safeParse(value);
  if (!result.success) {
    const issues = result.error?.issues || result.error?.errors || [];
    return issues[0]?.message || 'Invalid value';
  }
  return null;
}
