import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { Locale, translations } from '../i18n/translations';

interface LanguageContextType {
  locale: Locale;
  setLocale: (nextLocale: Locale) => void;
  toggleLocale: () => void;
  currentPath: string;
  navigateTo: (path: string) => void;
  t: typeof translations['fr'];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Determine initial path from window.location
  const getInitialPath = () => {
    if (typeof window === 'undefined') return '/';
    return window.location.pathname || '/';
  };

  const [currentPath, setCurrentPath] = useState<string>(getInitialPath);

  // Derive locale from path: starts with /en or /en/ -> English, else French
  const locale: Locale = useMemo(() => {
    return currentPath === '/en' || currentPath.startsWith('/en/') ? 'en' : 'fr';
  }, [currentPath]);

  // Strip or add /en prefix when switching
  const navigateTo = useCallback((targetPath: string) => {
    if (typeof window !== 'undefined') {
      window.history.pushState({}, '', targetPath);
    }
    setCurrentPath(targetPath);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const setLocale = useCallback((newLocale: Locale) => {
    if (newLocale === locale) return;

    let targetPath = currentPath;
    if (newLocale === 'en') {
      if (!targetPath.startsWith('/en')) {
        targetPath = targetPath === '/' ? '/en/' : `/en${targetPath}`;
      }
    } else {
      if (targetPath.startsWith('/en')) {
        targetPath = targetPath.replace(/^\/en(\/|$)/, '/');
        if (!targetPath) targetPath = '/';
      }
    }
    navigateTo(targetPath);
  }, [locale, currentPath, navigateTo]);

  const toggleLocale = useCallback(() => {
    setLocale(locale === 'fr' ? 'en' : 'fr');
  }, [locale, setLocale]);

  // Listen to browser popstate (back/forward)
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Update document language & title
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.lang = locale;
      const title = locale === 'fr' 
        ? "Architecte Maison Contemporaine & Villa Moderne | Archidomo Annecy"
        : "Contemporary Luxury Architect & Modern Villa | Archidomo Annecy";
      document.title = title;
    }
  }, [locale]);

  const t = translations[locale];

  return (
    <LanguageContext.Provider
      value={{
        locale,
        setLocale,
        toggleLocale,
        currentPath,
        navigateTo,
        t,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
