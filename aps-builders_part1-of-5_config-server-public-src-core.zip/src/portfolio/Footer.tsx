import React from "react";
import { ArrowUp } from "lucide-react";
import { PORTFOLIO_CREATIVE } from "./portfolioData";

interface FooterProps {
  onScrollToTop: () => void;
}

export default function Footer({ onScrollToTop }: FooterProps) {
  return (
    <footer className="w-full bg-[#0a0a0a] text-[#f4f2ec] border-t border-white/10 py-16 sm:py-20 select-none">
      <div className="max-w-7xl mx-auto px-6 sm:px-12 md:px-20 space-y-12">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 pb-12 border-b border-white/10">
          <div>
            <span className="font-serif text-2xl sm:text-3xl font-light text-white tracking-wider block">
              ARAVIND MENON
            </span>
            <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#e6c687] mt-1 block">
              ARCHITECTURAL & OBJECT ATELIER · ALAPPUZHA & DUBAI
            </span>
          </div>

          <button
            onClick={onScrollToTop}
            data-cursor-hover="true"
            data-cursor-label="TOP"
            className="flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-[#e6c687] hover:text-[#0e0e0e] text-xs font-mono uppercase tracking-widest transition-all cursor-pointer"
          >
            <span>Return to Zenith</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 text-xs font-mono text-white/50">
          <div className="space-y-2">
            <span className="text-white uppercase tracking-widest block text-[11px]">
              Studio Network
            </span>
            <p>Alappuzha (Primary HQ)</p>
            <p>Kochi Design Labs</p>
            <p>Bengaluru Research Yard</p>
            <p>Dubai Advisory Desk</p>
          </div>

          <div className="space-y-2">
            <span className="text-white uppercase tracking-widest block text-[11px]">
              Disciplines
            </span>
            <p>Tropical Architecture</p>
            <p>Interior Enclosures</p>
            <p>Bespoke Joinery & Objects</p>
            <p>Ecological Masterplanning</p>
          </div>

          <div className="space-y-2">
            <span className="text-white uppercase tracking-widest block text-[11px]">
              Selected Press
            </span>
            <p>Architectural Digest 100</p>
            <p>Wallpaper* Design Awards</p>
            <p>Dezeen Architecture Longlist</p>
            <p>Domus Modern India</p>
          </div>

          <div className="space-y-2">
            <span className="text-white uppercase tracking-widest block text-[11px]">
              Legal & Verification
            </span>
            <p>© 2008—2027 Aravind Menon</p>
            <p>Council of Architecture CA/2008/41920</p>
            <p>All Rights Reserved</p>
            <p className="text-[#e6c687]">Bespoke Craftsmanship</p>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] font-mono text-white/40">
          <span>Crafted with pure spatial restraint, typography and material honesty.</span>
          <span>ESTABLISHED IN GOD&apos;S OWN COUNTRY</span>
        </div>
      </div>
    </footer>
  );
}
