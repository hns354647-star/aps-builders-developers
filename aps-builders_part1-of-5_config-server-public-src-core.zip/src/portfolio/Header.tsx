import React, { useEffect, useState } from "react";
import { ArrowUpRight, Menu as MenuIcon, X } from "lucide-react";

interface HeaderProps {
  onOpenMenu: () => void;
  onGetInTouch: () => void;
  menuOpen: boolean;
}

export default function Header({ onOpenMenu, onGetInTouch, menuOpen }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 80);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-[120] transition-all duration-500 select-none ${
        isScrolled
          ? "py-3 bg-[#0e0e0e]/80 backdrop-blur-md border-b border-white/5"
          : "py-6 bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-10 flex items-center justify-between">
        {/* Minimalist Logo Mark */}
        <a
          href="#hero"
          className="group flex items-center gap-3.5 focus:outline-none"
          data-cursor-hover="true"
          data-cursor-label="ATELIER"
        >
          <div className="relative w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center">
            {/* SVG Logo mark */}
            <svg viewBox="0 0 40 40" fill="none" className="w-full h-full text-[#f4f2ec] group-hover:text-[#e6c687] transition-colors">
              <circle cx="20" cy="20" r="18" stroke="currentColor" strokeWidth="1.2" opacity="0.6" />
              <path d="M20 7L32 31H8L20 7Z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
              <circle cx="20" cy="18" r="1.8" fill="currentColor" />
            </svg>
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-sm sm:text-base tracking-[0.18em] font-medium text-[#f4f2ec]">
              ARAVIND MENON
            </span>
            <span className="text-[9px] font-mono uppercase tracking-[0.22em] text-white/40 -mt-0.5">
              ATELIER · ARCHITECTURE
            </span>
          </div>
        </a>

        {/* Action Controls */}
        <div className="flex items-center gap-3 sm:gap-5">
          {/* Get in touch CTA */}
          <button
            onClick={onGetInTouch}
            data-cursor-hover="true"
            data-cursor-label="CONNECT"
            className="hidden sm:inline-flex items-center gap-2 px-5 py-2 rounded-full border border-white/15 bg-white/[0.03] hover:bg-[#e6c687] hover:border-[#e6c687] text-[#f4f2ec] hover:text-[#0e0e0e] text-xs font-mono uppercase tracking-widest transition-all duration-300 cursor-pointer shadow-sm group"
          >
            <span>Get in touch</span>
            <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </button>

          {/* Menu button */}
          <button
            onClick={onOpenMenu}
            data-cursor-hover="true"
            data-cursor-label={menuOpen ? "CLOSE" : "MENU"}
            className="relative flex items-center gap-2.5 px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 text-[#f4f2ec] text-xs font-mono uppercase tracking-widest transition-all cursor-pointer"
            aria-label="Toggle Navigation Menu"
          >
            {menuOpen ? (
              <>
                <X className="w-4 h-4 text-[#e6c687]" />
                <span className="hidden xs:inline">Close</span>
              </>
            ) : (
              <>
                <MenuIcon className="w-4 h-4 text-[#e6c687]" />
                <span className="hidden xs:inline">Index</span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
