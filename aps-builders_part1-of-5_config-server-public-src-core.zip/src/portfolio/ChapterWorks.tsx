import React, { useState } from "react";
import { Plus } from "lucide-react";
import WebGLImagePlane from "./WebGLImagePlane";
import {
  boutiqueHotelImg,
  artGalleryImg,
  churchImg,
  corporateHqImg,
  culturalCenterImg,
  infinityPoolImg,
  hillsideCabinImg,
  nalukettuInteriorImg,
  libraryInteriorImg,
  vastuBrahmasthanImg
} from "./portfolioImages";

const PRIMARY_WORKS = [
  {
    id: "work-1",
    title: "Vembanad Water Sanctuary",
    category: "Hospitality & Waterfront Pavilion",
    year: "2025",
    location: "Alappuzha, Kerala",
    speed: 0.9,
    image: boutiqueHotelImg,
    aspect: "aspect-[4/5]"
  },
  {
    id: "work-2",
    title: "The Basalt Art Pavilion",
    category: "Cultural & Exhibition Space",
    year: "2024",
    location: "Fort Kochi",
    speed: 1.2,
    image: artGalleryImg,
    aspect: "aspect-[4/3]"
  },
  {
    id: "work-3",
    title: "Monolithic Church of Light",
    category: "Sacred Architecture",
    year: "2023",
    location: "Kottayam Foothills",
    speed: 1.0,
    image: churchImg,
    aspect: "aspect-[3/4]"
  }
];

const SECONDARY_WORKS = [
  {
    id: "work-4",
    title: "Solstice Cantilever Pool",
    category: "Private Residential Estate",
    year: "2026",
    location: "Mararikulam Coast",
    speed: 1.1,
    image: infinityPoolImg,
    aspect: "aspect-[16/10]"
  },
  {
    id: "work-5",
    title: "The Tea Estate Glass Cabin",
    category: "Eco-Lodge & Retreat",
    year: "2024",
    location: "Munnar Highlands",
    speed: 0.85,
    image: hillsideCabinImg,
    aspect: "aspect-[4/5]"
  },
  {
    id: "work-6",
    title: "Chamber of Manuscript Archives",
    category: "Heritage Preservation",
    year: "2025",
    location: "Trivandrum",
    speed: 1.05,
    image: libraryInteriorImg,
    aspect: "aspect-[4/3]"
  }
];

const ADDITIONAL_WORKS = [
  {
    id: "work-7",
    title: "Monolithic Nalukettu Atrium",
    category: "Courtyard Residence",
    year: "2025",
    location: "Alappuzha",
    speed: 1.0,
    image: nalukettuInteriorImg,
    aspect: "aspect-[4/3]"
  },
  {
    id: "work-8",
    title: "Corporate Waterfront Spire",
    category: "Commercial Architecture",
    year: "2024",
    location: "Marine Drive Kochi",
    speed: 1.15,
    image: corporateHqImg,
    aspect: "aspect-[3/4]"
  },
  {
    id: "work-9",
    title: "Centre for Performing Arts",
    category: "Civic Architecture",
    year: "2026",
    location: "Kozhikode",
    speed: 0.95,
    image: culturalCenterImg,
    aspect: "aspect-[16/9]"
  }
];

export default function ChapterWorks() {
  const [showAll, setShowAll] = useState(false);

  return (
    <section
      id="chapter-works"
      className="relative min-h-screen w-full bg-[#0e0e0e] text-[#f4f2ec] py-24 sm:py-32 border-t border-white/10 select-none overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-12 md:px-20">
        {/* Chapter Header & Live Counter */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-16 pb-6 border-b border-white/10">
          <div>
            <div className="flex items-center gap-4 mb-3">
              <span className="font-mono text-sm tracking-widest text-[#e6c687] px-3 py-1 border border-[#e6c687]/40 rounded-full">
                CHAPTER II
              </span>
              <span className="font-mono text-xs uppercase tracking-[0.25em] text-white/40">
                PORTFOLIO CATALOGUE
              </span>
            </div>
            <h2 className="font-serif text-4xl sm:text-6xl md:text-7xl font-light text-[#f4f2ec] tracking-tight">
              Selected <span className="font-bold text-[#e6c687]">works.</span>
            </h2>
          </div>

          <div className="flex items-baseline gap-2 font-mono text-xs text-white/50">
            <span className="text-2xl font-serif text-[#e6c687]">
              {showAll ? "09" : "06"}
            </span>
            <span className="tracking-widest uppercase">/ 42 REALIZED COMMISSIONS</span>
          </div>
        </div>

        {/* ROW 1 of Three Images */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 items-start mb-20">
          {PRIMARY_WORKS.map((work) => (
            <div key={work.id} className="group space-y-3">
              <div className="rounded-2xl overflow-hidden shadow-xl">
                <WebGLImagePlane
                  src={work.image}
                  alt={work.title}
                  aspect={work.aspect}
                  speed={work.speed}
                />
              </div>

              <div className="flex items-baseline justify-between pt-2">
                <h3 className="font-serif text-lg font-semibold text-white group-hover:text-[#e6c687] transition-colors">
                  {work.title}
                </h3>
                <span className="text-xs font-mono text-[#e6c687]">{work.year}</span>
              </div>
              <p className="text-xs font-mono text-white/50 tracking-wider">
                {work.category} · {work.location}
              </p>
            </div>
          ))}
        </div>

        {/* GIANT INTERLEAVED STATEMENT 1 */}
        <div className="py-14 sm:py-20 text-center overflow-hidden">
          <p className="font-serif text-4xl sm:text-7xl md:text-8xl tracking-tight text-white/10 uppercase select-none font-bold hover:text-[#e6c687]/25 transition-colors duration-500">
            BOLD WHEN NEEDED
          </p>
        </div>

        {/* ROW 2 of Three Images */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 items-start mb-20">
          {SECONDARY_WORKS.map((work) => (
            <div key={work.id} className="group space-y-3">
              <div className="rounded-2xl overflow-hidden shadow-xl">
                <WebGLImagePlane
                  src={work.image}
                  alt={work.title}
                  aspect={work.aspect}
                  speed={work.speed}
                />
              </div>

              <div className="flex items-baseline justify-between pt-2">
                <h3 className="font-serif text-lg font-semibold text-white group-hover:text-[#e6c687] transition-colors">
                  {work.title}
                </h3>
                <span className="text-xs font-mono text-[#e6c687]">{work.year}</span>
              </div>
              <p className="text-xs font-mono text-white/50 tracking-wider">
                {work.category} · {work.location}
              </p>
            </div>
          ))}
        </div>

        {/* GIANT INTERLEAVED STATEMENT 2 */}
        <div className="py-14 sm:py-20 text-center overflow-hidden">
          <p className="font-serif text-4xl sm:text-7xl md:text-8xl tracking-tight text-white/10 uppercase select-none font-bold hover:text-[#e6c687]/25 transition-colors duration-500">
            QUIET WHEN CALLED
          </p>
        </div>

        {/* EXPANDABLE ROW 3 */}
        {showAll && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 items-start mb-20 animate-fade-in">
            {ADDITIONAL_WORKS.map((work) => (
              <div key={work.id} className="group space-y-3">
                <div className="rounded-2xl overflow-hidden shadow-xl">
                  <WebGLImagePlane
                    src={work.image}
                    alt={work.title}
                    aspect={work.aspect}
                    speed={work.speed}
                  />
                </div>

                <div className="flex items-baseline justify-between pt-2">
                  <h3 className="font-serif text-lg font-semibold text-white group-hover:text-[#e6c687] transition-colors">
                    {work.title}
                  </h3>
                  <span className="text-xs font-mono text-[#e6c687]">{work.year}</span>
                </div>
                <p className="text-xs font-mono text-white/50 tracking-wider">
                  {work.category} · {work.location}
                </p>
              </div>
            ))}
          </div>
        )}

        {/* Load all works CTA Button */}
        <div className="text-center pt-8">
          <button
            onClick={() => setShowAll(!showAll)}
            data-cursor-hover="true"
            data-cursor-label={showAll ? "COLLAPSE" : "EXPAND"}
            className="inline-flex items-center gap-3 px-8 py-4 rounded-full border border-white/20 hover:border-[#e6c687] bg-white/[0.03] hover:bg-[#e6c687] text-[#f4f2ec] hover:text-[#0e0e0e] text-xs font-mono uppercase tracking-[0.25em] font-semibold transition-all duration-300 cursor-pointer shadow-lg group"
          >
            <span>{showAll ? "Display Curated Selection" : "Load All Works & Archives"}</span>
            <Plus className={`w-4 h-4 transition-transform ${showAll ? "rotate-45" : "group-hover:rotate-90"}`} />
          </button>
        </div>
      </div>
    </section>
  );
}
