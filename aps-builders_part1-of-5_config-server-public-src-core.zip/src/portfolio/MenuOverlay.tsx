import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowUpRight, Mail, Phone, MapPin, Globe } from "lucide-react";
import { CHAPTERS, PORTFOLIO_CREATIVE } from "./portfolioData";

interface MenuOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectChapter: (id: string) => void;
}

export default function MenuOverlay({ isOpen, onClose, onSelectChapter }: MenuOverlayProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          key="menu-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.4 } }}
          className="fixed inset-0 z-[115] bg-[#0e0e0e]/95 backdrop-blur-2xl text-[#f4f2ec] flex flex-col justify-between overflow-y-auto px-6 sm:px-12 md:px-20 py-24 select-none"
        >
          {/* Subtle Grid Watermark lines */}
          <div className="absolute inset-0 pointer-events-none opacity-5 bg-[radial-gradient(#e6c687_1px,transparent_1px)] [background-size:24px_24px]" />

          {/* Top category label */}
          <div className="relative z-10 flex items-center justify-between pb-6 border-b border-white/10 text-xs font-mono uppercase tracking-[0.25em] text-white/40">
            <span>TABLE OF CHAPTERS & INQUIRY</span>
            <span>INDEX 01 — 05</span>
          </div>

          {/* Main chapters list */}
          <div className="relative z-10 py-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            <div className="lg:col-span-7 space-y-3">
              {CHAPTERS.map((ch, idx) => (
                <motion.div
                  key={ch.id}
                  initial={{ x: -30, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.1 + idx * 0.06, duration: 0.5, ease: "easeOut" }}
                >
                  <button
                    onClick={() => {
                      onSelectChapter(ch.id);
                      onClose();
                    }}
                    data-cursor-hover="true"
                    data-cursor-label={`GOTO ${ch.roman}`}
                    className="w-full text-left group flex items-baseline justify-between py-2 border-b border-white/5 hover:border-[#e6c687]/50 transition-colors"
                  >
                    <div className="flex items-baseline gap-4 sm:gap-8">
                      <span className="font-mono text-sm sm:text-base text-[#e6c687] group-hover:text-white transition-colors">
                        {ch.roman}.
                      </span>
                      <span className="font-serif text-3xl sm:text-5xl md:text-6xl text-[#f4f2ec] font-light group-hover:text-[#e6c687] group-hover:translate-x-3 transition-all duration-300">
                        {ch.name}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="hidden sm:inline text-xs font-mono uppercase tracking-widest text-white/40 group-hover:text-white transition-colors">
                        {ch.subtitle}
                      </span>
                      <ArrowUpRight className="w-5 h-5 text-white/30 group-hover:text-[#e6c687] group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
                    </div>
                  </button>
                </motion.div>
              ))}
            </div>

            {/* Right details column: Studio, contact, locations */}
            <div className="lg:col-span-5 lg:pl-12 flex flex-col justify-between space-y-10 border-t lg:border-t-0 lg:border-l border-white/10 pt-8 lg:pt-0">
              {/* Studio Bio excerpt */}
              <div className="space-y-3">
                <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-[#e6c687]">
                  Atelier Philosophy
                </span>
                <p className="font-serif text-base text-white/80 leading-relaxed font-light">
                  {PORTFOLIO_CREATIVE.statement}
                </p>
              </div>

              {/* Direct Access & Contacts */}
              <div className="space-y-4">
                <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-white/40">
                  Dialogue & Direct Line
                </span>
                <div className="space-y-2 text-sm font-sans">
                  <a
                    href={`mailto:${PORTFOLIO_CREATIVE.contact.email}`}
                    className="flex items-center gap-2.5 text-[#f4f2ec] hover:text-[#e6c687] transition-colors"
                    data-cursor-hover="true"
                  >
                    <Mail className="w-4 h-4 text-[#e6c687]" />
                    <span>{PORTFOLIO_CREATIVE.contact.email}</span>
                  </a>
                  <a
                    href={`tel:${PORTFOLIO_CREATIVE.contact.phone.replace(/[^0-9+]/g, "")}`}
                    className="flex items-center gap-2.5 text-[#f4f2ec] hover:text-[#e6c687] transition-colors"
                    data-cursor-hover="true"
                  >
                    <Phone className="w-4 h-4 text-[#e6c687]" />
                    <span>{PORTFOLIO_CREATIVE.contact.phone}</span>
                  </a>
                  <div className="flex items-center gap-2.5 text-white/60 text-xs">
                    <MapPin className="w-4 h-4 text-white/40 shrink-0" />
                    <span>{PORTFOLIO_CREATIVE.contact.address}</span>
                  </div>
                </div>
              </div>

              {/* Atelier Offices */}
              <div className="space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-white/40">
                  Studio Network
                </span>
                <div className="flex flex-wrap gap-2">
                  {PORTFOLIO_CREATIVE.cities.map((city) => (
                    <span
                      key={city.name}
                      className="px-2.5 py-1 text-[11px] font-mono border border-white/10 rounded-full text-white/70"
                    >
                      {city.name} · {city.status}
                    </span>
                  ))}
                </div>
              </div>

              {/* Socials & Legal */}
              <div className="flex items-center justify-between text-[11px] font-mono text-white/40 pt-4 border-t border-white/10">
                <div className="flex gap-4">
                  <a href="#instagram" className="hover:text-white transition-colors">Instagram</a>
                  <a href="#linkedin" className="hover:text-white transition-colors">LinkedIn</a>
                  <a href="#presskit" className="hover:text-white transition-colors">Monograph 2026</a>
                </div>
                <span>© ARAVIND MENON</span>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
