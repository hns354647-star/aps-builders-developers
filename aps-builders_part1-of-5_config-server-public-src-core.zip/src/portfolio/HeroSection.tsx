import React from "react";
import { ArrowDown } from "lucide-react";
import { PORTFOLIO_CREATIVE } from "./portfolioData";
import { villaDroneImg } from "./portfolioImages";

interface HeroSectionProps {
  onBeginStory: () => void;
}

export default function HeroSection({ onBeginStory }: HeroSectionProps) {
  return (
    <section
      id="hero"
      className="relative min-h-screen w-full flex flex-col justify-between overflow-hidden bg-[#0e0e0e] text-[#f4f2ec] px-6 sm:px-12 md:px-20 pt-28 pb-12 select-none"
    >
      {/* Background Cinematic Visual with parallax scale and dark overlay */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <img
          src={villaDroneImg}
          alt="Aravind Menon Architecture - Backwater Sanctuary Drone View"
          className="w-full h-full object-cover scale-105 animate-hero-zoom opacity-35 filter brightness-75 contrast-125"
        />
        {/* Soft Vignette and Gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0e0e0e] via-[#0e0e0e]/60 to-[#0e0e0e]/40" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_30%,#0e0e0e_90%)]" />
      </div>

      {/* Top Discipline Tag */}
      <div className="relative z-10 flex items-center justify-between text-xs font-mono uppercase tracking-[0.25em] text-white/50 pt-4">
        <span className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#e6c687] animate-pulse" />
          MONOGRAPHIC PORTFOLIO · CHAPTER SYSTEM
        </span>
        <span className="hidden md:inline">EDITION 2026 / 2027</span>
      </div>

      {/* Central Headline Statement */}
      <div className="relative z-10 my-auto py-12 max-w-5xl">
        <p className="text-xs sm:text-sm font-mono uppercase tracking-[0.35em] text-[#e6c687] mb-4">
          AN INQUIRY INTO TROPICAL FORM & SILENCE
        </p>

        <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl lg:text-8xl leading-[1.08] tracking-tight text-[#f4f2ec] font-light">
          Can <strong className="font-bold text-[#e6c687] italic">design</strong> shape{" "}
          <span className="block sm:inline">how we feel?</span>
        </h1>

        {/* Roles List */}
        <div className="mt-8 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs sm:text-sm font-mono uppercase tracking-[0.2em] text-white/60">
          {PORTFOLIO_CREATIVE.disciplines.map((item, idx) => (
            <span key={idx} className="flex items-center gap-2">
              <span className="text-[#e6c687]">/</span>
              <span className="hover:text-white transition-colors">{item}</span>
            </span>
          ))}
        </div>
      </div>

      {/* Bottom Scroll Cue */}
      <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-end justify-between gap-6 pt-6 border-t border-white/10">
        <div className="max-w-md">
          <p className="text-xs font-sans text-white/50 leading-relaxed">
            Every structure is conceived as a slow shelter against monsoonal downpours, a lens for the coastal sun, and an enduring monument to natural materiality.
          </p>
        </div>

        <button
          onClick={onBeginStory}
          data-cursor-hover="true"
          data-cursor-label="BEGIN"
          className="group flex items-center gap-3 text-xs font-mono uppercase tracking-[0.25em] text-[#e6c687] hover:text-white transition-colors cursor-pointer"
        >
          <span>Scroll down to begin the story</span>
          <div className="w-8 h-8 rounded-full border border-[#e6c687]/40 group-hover:border-white flex items-center justify-center transition-colors">
            <ArrowDown className="w-3.5 h-3.5 animate-bounce text-[#e6c687] group-hover:text-white" />
          </div>
        </button>
      </div>
    </section>
  );
}
