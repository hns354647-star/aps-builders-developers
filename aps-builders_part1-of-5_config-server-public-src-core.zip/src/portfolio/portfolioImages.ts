import villaDroneImg from "../assets/images/luxury_villa_drone_kerala_1780828001461.png";
import glassTowerImg from "../assets/images/aps_glass_tower_1780810854036.png";
import boutiqueHotelImg from "../assets/images/boutique_hotel_backwaters_1780827576126.png";
import artGalleryImg from "../assets/images/contemporary_art_gallery_kochi_1780827605840.png";
import museumNightImg from "../assets/images/contemporary_museum_kerala_night_1780827949977.png";
import corporateHqImg from "../assets/images/corporate_hq_dawn_1780827906397.png";
import hillsideCabinImg from "../assets/images/hillside_modern_cabin_1780827709690.png";
import boathouseImg from "../assets/images/luxury_boathouse_reimagined_kerala_1780828051209.png";
import infinityPoolImg from "../assets/images/luxury_infinity_pool_night_1780827664726.png";
import penthouseImg from "../assets/images/luxury_penthouse_interior_1780827920432.png";
import churchImg from "../assets/images/minimalist_modern_church_kerala_1780827590876.png";
import culturalCenterImg from "../assets/images/modern_cultural_center_kerala_1780828070617.png";
import libraryInteriorImg from "../assets/images/modern_library_interior_1780827694824.png";
import nalukettuInteriorImg from "../assets/images/modern_nalukettu_interior_1780827679869.png";
import wellnessRetreatImg from "../assets/images/premium_wellness_retreat_misty_1780827966245.png";
import palaceMixImg from "../assets/images/royal_palace_modern_mix_1780827876354.png";
import traditionalHallImg from "../assets/images/traditional_kerala_modern_hall_1780828030670.png";
import vastuDoorNorthImg from "../assets/images/vastu_door_north_1780813345048.png";
import vastuDoorEastImg from "../assets/images/vastu_door_east_1780813328926.png";
import vastuDoorSouthImg from "../assets/images/vastu_door_south_1780813770045.png";
import vastuBrahmasthanImg from "../assets/images/vastu_home_brahmasthan_1780813360455.png";
import architectPortraitImg from "../assets/images/architect_portrait_about_1780827079505.png";

export {
  villaDroneImg,
  glassTowerImg,
  boutiqueHotelImg,
  artGalleryImg,
  museumNightImg,
  corporateHqImg,
  hillsideCabinImg,
  boathouseImg,
  infinityPoolImg,
  penthouseImg,
  churchImg,
  culturalCenterImg,
  libraryInteriorImg,
  nalukettuInteriorImg,
  wellnessRetreatImg,
  palaceMixImg,
  traditionalHallImg,
  vastuDoorNorthImg,
  vastuDoorEastImg,
  vastuDoorSouthImg,
  vastuBrahmasthanImg,
  architectPortraitImg
};
