import React from "react";
import WebGLImagePlane from "./WebGLImagePlane";
import {
  glassTowerImg,
  wellnessRetreatImg,
  museumNightImg,
  corporateHqImg,
  culturalCenterImg,
  boathouseImg,
  villaDroneImg
} from "./portfolioImages";

export default function ChapterArchitecture() {
  const TALL_GALLERY = [
    { title: "Kochi Marine Tower", loc: "Marine Drive", img: glassTowerImg },
    { title: "Misty Valley Pavilion", loc: "Wayanad Hills", img: wellnessRetreatImg },
    { title: "Nocturne Art Museum", loc: "Fort Kochi", img: museumNightImg },
    { title: "Canal-Front Villa", loc: "Vembanad Shore", img: boathouseImg },
    { title: "Glass Spire & Podium", loc: "Town Center", img: corporateHqImg },
    { title: "Civic Amphitheatre", loc: "Kozhikode", img: culturalCenterImg }
  ];

  return (
    <section
      id="chapter-architecture"
      className="relative min-h-screen w-full bg-[#0e0e0e] text-[#f4f2ec] py-24 sm:py-32 border-t border-white/10 select-none overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-12 md:px-20 mb-20">
        {/* Chapter Header Marker */}
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-sm tracking-widest text-[#e6c687] px-3 py-1 border border-[#e6c687]/40 rounded-full">
            CHAPTER IV
          </span>
          <span className="font-mono text-xs uppercase tracking-[0.25em] text-white/40">
            STRUCTURAL MONOLITHS & TROPICAL ENCLOSURES
          </span>
        </div>

        {/* Circular Expanding Architectural Image Stage */}
        <div className="relative py-12 flex flex-col items-center justify-center text-center mb-24">
          {/* Subtle Circle framing container */}
          <div className="relative w-72 h-72 sm:w-96 sm:h-96 md:w-[480px] md:h-[480px] rounded-full overflow-hidden border border-[#e6c687]/30 shadow-[0_0_60px_rgba(230,198,135,0.15)] group transition-all duration-700">
            <img
              src={museumNightImg}
              alt="Nocturne Contemporary Museum Architecture Kerala"
              className="w-full h-full object-cover scale-110 group-hover:scale-100 transition-transform duration-1000"
            />
            {/* Ambient vignette */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0e0e0e]/80 via-transparent to-[#0e0e0e]/60" />
            <div className="absolute inset-0 flex items-center justify-center p-6">
              <span className="font-serif text-xl sm:text-2xl text-white font-light tracking-wide uppercase">
                SPATIAL VOID & FORM
              </span>
            </div>
          </div>

          {/* Big Statements */}
          <div className="mt-14 max-w-4xl space-y-4">
            <h3 className="font-serif text-3xl sm:text-6xl md:text-7xl font-light text-[#f4f2ec] leading-tight">
              Shaping <strong className="font-bold text-[#e6c687]">bold form</strong> & feel.
            </h3>
            <p className="font-serif text-xl sm:text-2xl text-white/50 italic">
              &ldquo;Where form dares and function obeys.&rdquo;
            </p>
          </div>
        </div>
      </div>

      {/* Horizontal Gallery of Tall Images repeated as marquee */}
      <div className="w-full overflow-hidden py-10 mb-20">
        <div className="flex gap-8 animate-marquee-left">
          {[...TALL_GALLERY, ...TALL_GALLERY].map((item, idx) => (
            <div
              key={idx}
              className="w-64 sm:w-72 md:w-80 shrink-0 group rounded-2xl overflow-hidden border border-white/10 bg-[#121212] p-3 transition-colors hover:border-[#e6c687]/50"
            >
              <div className="rounded-xl overflow-hidden aspect-[9/16] mb-3 relative">
                <img
                  src={item.img}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-[#0e0e0e]/75 backdrop-blur-md text-[10px] font-mono text-[#e6c687]">
                  {item.loc}
                </div>
              </div>
              <div className="px-1 py-1 flex items-baseline justify-between">
                <h4 className="font-serif text-base text-white font-medium group-hover:text-[#e6c687] transition-colors">
                  {item.title}
                </h4>
                <span className="text-[10px] font-mono uppercase text-white/40">CIVIL ARCH</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Refined & Dignified Materials Closing Banner */}
      <div className="max-w-7xl mx-auto px-6 sm:px-12 md:px-20 text-center">
        <div className="p-10 sm:p-16 rounded-3xl bg-gradient-to-b from-[#141414] to-[#0e0e0e] border border-[#e6c687]/25 shadow-2xl relative overflow-hidden">
          <p className="text-xs font-mono uppercase tracking-[0.3em] text-[#e6c687] mb-4">
            THE TACTILE SYNTAX
          </p>
          <h2 className="font-serif text-3xl sm:text-5xl md:text-6xl text-white font-light max-w-4xl mx-auto leading-tight">
            Crafted with <span className="font-bold text-[#e6c687]">refined & dignified</span> materials.
          </h2>
          <p className="mt-6 text-sm font-sans text-white/60 max-w-2xl mx-auto leading-relaxed">
            From marine-grade reinforced concrete standing resilient against high monsoonal humidity to hand-split Malabar granite slabs and century-old salvaged teak beams — every surface conveys permanence.
          </p>

          <div className="mt-8 flex flex-wrap justify-center gap-3">
            {[
              "Marine Coastal Concrete",
              "Hand-Split Basalt",
              "Seasoned Nilambur Teak",
              "Low-E Acoustic Solar Glass",
              "Bell-Metal Bronze Accents"
            ].map((mat) => (
              <span
                key={mat}
                className="px-4 py-2 rounded-full border border-white/10 bg-white/5 text-xs font-mono text-white/80"
              >
                {mat}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
