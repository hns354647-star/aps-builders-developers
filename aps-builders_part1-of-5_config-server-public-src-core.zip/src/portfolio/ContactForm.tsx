import React, { useState } from "react";
import { Send, CheckCircle2, AlertCircle } from "lucide-react";
import { PORTFOLIO_CREATIVE } from "./portfolioData";

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    projectType: "Residential Architecture",
    budget: "$250k - $500k",
    message: "",
    privacyConsent: false
  });

  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setStatus("error");
      setErrorMessage("Please complete all required fields.");
      return;
    }

    if (!formData.privacyConsent) {
      setStatus("error");
      setErrorMessage("Kindly accept the privacy consent to initiate dialogue.");
      return;
    }

    setStatus("submitting");

    // Realistic atelier submission flow
    setTimeout(() => {
      setStatus("success");
    }, 1200);
  };

  return (
    <div className="w-full max-w-2xl bg-[#121212] border border-white/10 rounded-2xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
      {/* Decorative subtle gold hairline */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#e6c687] to-transparent opacity-80" />

      {status === "success" ? (
        <div className="py-12 text-center space-y-4" aria-live="polite">
          <div className="w-14 h-14 rounded-full bg-[#e6c687]/15 border border-[#e6c687] flex items-center justify-center mx-auto text-[#e6c687]">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="font-serif text-2xl sm:text-3xl text-[#f4f2ec]">
            Your inquiry has reached the Atelier
          </h3>
          <p className="font-sans text-sm text-white/70 max-w-md mx-auto leading-relaxed">
            Thank you, {formData.name}. Aravind Menon and the project directors will review your brief
            and respond within 48 business hours with an initial consultation proposal.
          </p>
          <div className="pt-4">
            <button
              onClick={() => {
                setStatus("idle");
                setFormData({
                  name: "",
                  email: "",
                  phone: "",
                  projectType: "Residential Architecture",
                  budget: "$250k - $500k",
                  message: "",
                  privacyConsent: false
                });
              }}
              className="px-6 py-2.5 rounded-full border border-white/20 text-xs font-mono uppercase tracking-widest text-white/70 hover:text-white hover:border-[#e6c687] transition-colors"
            >
              Submit Another Brief
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6" noValidate>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Name */}
            <div>
              <label htmlFor="name" className="block text-xs font-mono uppercase tracking-widest text-white/60 mb-2">
                Name or Entity *
              </label>
              <input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                placeholder="e.g. Eleanor Vance"
                className="w-full px-4 py-3 bg-[#0a0a0a] border border-white/10 rounded-xl text-sm text-[#f4f2ec] placeholder-white/20 focus:outline-none focus:border-[#e6c687] transition-colors font-sans"
              />
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-xs font-mono uppercase tracking-widest text-white/60 mb-2">
                Email Address *
              </label>
              <input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                placeholder="eleanor@domain.com"
                className="w-full px-4 py-3 bg-[#0a0a0a] border border-white/10 rounded-xl text-sm text-[#f4f2ec] placeholder-white/20 focus:outline-none focus:border-[#e6c687] transition-colors font-sans"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Phone */}
            <div>
              <label htmlFor="phone" className="block text-xs font-mono uppercase tracking-widest text-white/60 mb-2">
                Phone / WhatsApp (Optional)
              </label>
              <input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+91 or Intl code"
                className="w-full px-4 py-3 bg-[#0a0a0a] border border-white/10 rounded-xl text-sm text-[#f4f2ec] placeholder-white/20 focus:outline-none focus:border-[#e6c687] transition-colors font-sans"
              />
            </div>

            {/* Project Scope */}
            <div>
              <label htmlFor="projectType" className="block text-xs font-mono uppercase tracking-widest text-white/60 mb-2">
                Engagement Discipline
              </label>
              <select
                id="projectType"
                value={formData.projectType}
                onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                className="w-full px-4 py-3 bg-[#0a0a0a] border border-white/10 rounded-xl text-sm text-[#f4f2ec] focus:outline-none focus:border-[#e6c687] transition-colors font-sans"
              >
                <option value="Residential Architecture">Masterplanned Villa / Estate</option>
                <option value="Hospitality & Resorts">Hospitality & Waterfront Retreat</option>
                <option value="Interior Architecture">Luxury Interior Architecture</option>
                <option value="Artisanal Objects">Artisanal Furniture / Object Commission</option>
                <option value="Institutional & Public">Institutional / Cultural Gallery</option>
              </select>
            </div>
          </div>

          {/* Message Brief */}
          <div>
            <label htmlFor="message" className="block text-xs font-mono uppercase tracking-widest text-white/60 mb-2">
              Vision & Project Context *
            </label>
            <textarea
              id="message"
              rows={4}
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              required
              placeholder="Tell us about the site location, spatial aspirations, and timeline..."
              className="w-full px-4 py-3 bg-[#0a0a0a] border border-white/10 rounded-xl text-sm text-[#f4f2ec] placeholder-white/20 focus:outline-none focus:border-[#e6c687] transition-colors font-sans resize-none"
            />
          </div>

          {/* Privacy Checkbox */}
          <div className="flex items-start gap-3">
            <input
              type="checkbox"
              id="privacy"
              checked={formData.privacyConsent}
              onChange={(e) => setFormData({ ...formData, privacyConsent: e.target.checked })}
              className="mt-1 h-4 w-4 rounded border-white/20 bg-black/50 text-[#e6c687] focus:ring-0 cursor-pointer accent-[#e6c687]"
            />
            <label htmlFor="privacy" className="text-xs text-white/50 leading-relaxed font-sans cursor-pointer select-none">
              I consent to ARAVIND MENON Atelier storing and reviewing this project brief in accordance with our confidential client privacy covenant.
            </label>
          </div>

          {status === "error" && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-red-950/40 border border-red-500/30 text-red-300 text-xs font-sans">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Submit CTA */}
          <button
            type="submit"
            disabled={status === "submitting"}
            data-cursor-hover="true"
            data-cursor-label="TRANSMIT"
            className="w-full py-4 rounded-xl bg-gradient-to-r from-[#e6c687] to-[#d4af37] hover:from-white hover:to-[#e6c687] text-[#0e0e0e] font-mono text-xs uppercase tracking-[0.25em] font-bold transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50"
          >
            {status === "submitting" ? (
              <span>Transmitting Brief...</span>
            ) : (
              <>
                <span>Transmit Project Brief</span>
                <Send className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      )}
    </div>
  );
}
