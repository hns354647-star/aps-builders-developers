import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";

interface PreloaderProps {
  onComplete: () => void;
}

export default function Preloader({ onComplete }: PreloaderProps) {
  const [progress, setProgress] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  useEffect(() => {
    const startTime = performance.now();
    const duration = 1600; // 1.6s luxury intro counter

    const updateCounter = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const pct = Math.min(Math.round((elapsed / duration) * 100), 100);
      setProgress(pct);

      if (pct < 100) {
        requestAnimationFrame(updateCounter);
      } else {
        setTimeout(() => {
          setIsFinished(true);
          setTimeout(onComplete, 700);
        }, 150);
      }
    };

    requestAnimationFrame(updateCounter);
  }, [onComplete]);

  return (
    <AnimatePresence>
      {!isFinished && (
        <motion.div
          key="preloader"
          initial={{ opacity: 1 }}
          exit={{ y: "-100%", transition: { duration: 0.85, ease: [0.76, 0, 0.24, 1] } }}
          className="fixed inset-0 z-[10000] flex flex-col justify-between bg-[#0e0e0e] text-[#f4f2ec] p-8 md:p-14 select-none pointer-events-auto"
        >
          {/* Top atelier moniker */}
          <div className="flex items-center justify-between text-xs tracking-[0.3em] uppercase font-mono text-white/40">
            <span>ARAVIND MENON · ARCHITECTURAL ATELIER</span>
            <span>CHRONICLE 2008—2027</span>
          </div>

          {/* Central insignia monogram */}
          <div className="flex flex-col items-center justify-center text-center">
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.9, ease: "easeOut" }}
              className="relative mb-6"
            >
              <svg width="84" height="84" viewBox="0 0 100 100" fill="none" className="text-[#e6c687]">
                <circle cx="50" cy="50" r="46" stroke="currentColor" strokeWidth="1" strokeDasharray="3 3" opacity="0.35" />
                <path d="M50 16L80 78H20L50 16Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M50 42V78" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                <circle cx="50" cy="38" r="3" fill="currentColor" />
              </svg>
            </motion.div>

            <h1 className="font-serif text-3xl sm:text-5xl md:text-6xl tracking-tight text-[#f4f2ec] font-light">
              ARAVIND MENON
            </h1>
            <p className="mt-2 text-xs sm:text-sm font-sans tracking-[0.25em] uppercase text-white/50">
              Spatial Forms · Bespoke Objects · Tropical Modernity
            </p>
          </div>

          {/* Bottom Progress Bar & Counter */}
          <div className="space-y-4">
            <div className="flex items-baseline justify-between text-xs font-mono text-white/40">
              <span className="tracking-widest uppercase">Initializing Sanctuary & Chapter Timeline</span>
              <span className="text-2xl font-serif text-[#e6c687] font-normal">{progress.toString().padStart(3, "0")} %</span>
            </div>

            <div className="h-[2px] w-full bg-white/10 overflow-hidden relative">
              <motion.div
                className="h-full bg-gradient-to-r from-[#e6c687] to-white"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
