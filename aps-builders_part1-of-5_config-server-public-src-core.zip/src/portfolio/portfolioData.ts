export interface ProjectItem {
  id: string;
  title: string;
  category: string;
  year: string;
  location: string;
  scope: string;
  image: string;
  tallImage?: string;
  aspect?: string;
  speed?: number;
}

export interface ObjectItem {
  id: string;
  name: string;
  material: string;
  edition: string;
  year: string;
  image: string;
}

export interface ChapterMeta {
  id: string;
  roman: string;
  name: string;
  subtitle: string;
}

export const PORTFOLIO_CREATIVE = {
  name: "ARAVIND MENON",
  title: "Architectural & Object Atelier",
  disciplines: ["Masterplanning", "Tropical Architecture", "Interior Architecture", "Bespoke Objects"],
  tagline: "Can design shape how we feel?",
  shortBio:
    "Aravind Menon leads an architectural and object atelier rooted in Kerala's coastal climate and distilled through austere, contemporary minimalism. Every project explores the interplay between monsoonal rainfall, monolithic basalt stone, seasoned teak timber, and light-filled spatial voids.",
  statement:
    "We do not design buildings to impress the street; we sculpt enclosures that quiet the pulse, anchor the soul, and outlive the shifting winds of transient trends.",
  globalReach: "projects realized across",
  cities: [
    { name: "Alappuzha", role: "Atelier & Fabrication Yard", status: "Primary HQ" },
    { name: "Kochi", role: "Design Studio & Waterfront Labs", status: "Active" },
    { name: "Bengaluru", role: "Material & Structural Research", status: "Branch" },
    { name: "Dubai", role: "Hospitality & Private Residences", status: "Liaison" },
    { name: "Singapore", role: "Tropical Ecology Advisory", status: "Collaborative" }
  ],
  stats: [
    { count: 18, suffix: "+", label: "Years of Craft", desc: "Unbroken studio practice since 2008" },
    { count: 42, suffix: "", label: "Built Works", desc: "Private estates, resorts & public spaces" },
    { count: 16, suffix: "", label: "Object Editions", desc: "Sculpted furniture, bronze & teak pieces" },
    { count: 29, suffix: "", label: "International Accolades", desc: "WAF, Dezeen & IIA citations" }
  ],
  contact: {
    email: "atelier@aravindmenon.design",
    phone: "+91 (0) 477 225 8901",
    whatsapp: "+91 79076 56700",
    address: "Palace Ward, Canal Road, Alappuzha, Kerala 688011",
    representation: "By private appointment only"
  },
  clientsAndPress: [
    "DEZEEN",
    "ARCHDAILY",
    "WALLPAPER*",
    "ARCHITECTURAL DIGEST",
    "ELLE DECOR",
    "THE PLAN",
    "DOMUS INDIA",
    "HABITAT REVIEW"
  ]
};

export const CHAPTERS: ChapterMeta[] = [
  { id: "chapter-about", roman: "I", name: "About", subtitle: "Philosophy & Lineage" },
  { id: "chapter-works", roman: "II", name: "Works", subtitle: "Selected Built Forms" },
  { id: "chapter-objects", roman: "III", name: "Objects", subtitle: "Artisanal Pieces" },
  { id: "chapter-architecture", roman: "IV", name: "Architecture", subtitle: "Monolithic Enclosures" },
  { id: "chapter-contact", roman: "V", name: "Contact", subtitle: "Dialogue & Inquiries" }
];
