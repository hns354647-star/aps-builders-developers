import React from "react";
import WebGLImagePlane from "./WebGLImagePlane";
import {
  vastuDoorEastImg,
  vastuDoorNorthImg,
  vastuDoorSouthImg,
  penthouseImg,
  nalukettuInteriorImg,
  traditionalHallImg,
  vastuBrahmasthanImg
} from "./portfolioImages";
import InfiniteMarquee from "./InfiniteMarquee";

export default function ChapterObjects() {
  const OBJECT_ITEMS_TOP = [
    { name: "Teak & Brass Temple Lattice", material: "Seasoned Nilambur Teak, Unlacquered Cast Brass", img: vastuDoorEastImg },
    { name: "Carved Nalukettu Pillar", material: "Anjili Hardwood, Hand-chiseled", img: vastuDoorNorthImg },
    { name: "Monolithic Basalt Hearth", material: "Fluted Volcanic Basalt, Charred Ash", img: vastuDoorSouthImg },
    { name: "Puzha Lounge Bench", material: "Solid Rosewood, Natural Coconut Coir Weave", img: penthouseImg }
  ];

  const OBJECT_ITEMS_BOTTOM = [
    { name: "Brahmasthan Bronze Vessel", material: "Hand-beaten Bell Metal (Odu)", img: vastuBrahmasthanImg },
    { name: "Acoustic Slatted Wall System", material: "Acoustic Felt, Kerala Teak Battens", img: nalukettuInteriorImg },
    { name: "Chamber Chandelier 04", material: "Mouth-blown Amber Glass & Aged Bronze", img: traditionalHallImg },
    { name: "Backwater Daybed Suite", material: "Weathered Teak, Raw Khadi Linen", img: penthouseImg }
  ];

  return (
    <section
      id="chapter-objects"
      className="relative min-h-screen w-full bg-[#0e0e0e] text-[#f4f2ec] py-24 sm:py-32 border-t border-white/10 select-none overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-12 md:px-20 mb-20">
        {/* Chapter Header Marker */}
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-sm tracking-widest text-[#e6c687] px-3 py-1 border border-[#e6c687]/40 rounded-full">
            CHAPTER III
          </span>
          <span className="font-mono text-xs uppercase tracking-[0.25em] text-white/40">
            OBJECTS, JOINERY & MATERIAL EDITIONS
          </span>
        </div>

        {/* Scaled Image Hero Block */}
        <div className="space-y-8 mb-24">
          <div className="max-w-3xl">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#e6c687] block mb-3">
              MATERIAL PROVENANCE
            </span>
            <h2 className="font-serif text-4xl sm:text-6xl md:text-7xl font-light text-[#f4f2ec] leading-tight">
              Designed to <strong className="font-bold text-[#e6c687]">endure</strong>, <br />
              shaped to speak.
            </h2>
          </div>

          {/* Full-bleed focal hero image */}
          <div className="rounded-3xl overflow-hidden border border-white/10 shadow-2xl relative group">
            <WebGLImagePlane
              src={traditionalHallImg}
              alt="Artisanal Hand-Carved Kerala Architecture & Objects"
              aspect="aspect-[21/9]"
            />
            <div className="absolute bottom-6 left-6 right-6 p-6 rounded-2xl bg-[#0e0e0e]/80 backdrop-blur-md border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h4 className="font-serif text-lg text-white font-semibold">
                  The Sanctuary Ceremonial Hall
                </h4>
                <p className="text-xs font-mono text-white/50">
                  Custom carved roof truss joinery, unbolted dowel joinery & aged bell-metal accents
                </p>
              </div>
              <span className="text-xs font-mono uppercase tracking-widest px-3 py-1.5 rounded-full border border-[#e6c687]/30 text-[#e6c687]">
                Masterpiece Edition 01
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Opposite-direction horizontal marquees of product images */}
      <div className="space-y-6 mb-24">
        {/* Marquee 1 (Left) */}
        <div className="overflow-hidden">
          <div className="flex gap-6 animate-marquee-left">
            {[...OBJECT_ITEMS_TOP, ...OBJECT_ITEMS_TOP].map((item, idx) => (
              <div
                key={idx}
                className="w-72 sm:w-80 shrink-0 p-4 rounded-2xl bg-[#121212] border border-white/5 hover:border-[#e6c687]/40 transition-colors group"
              >
                <div className="rounded-xl overflow-hidden mb-3 aspect-[4/3]">
                  <img
                    src={item.img}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <h4 className="font-serif text-base text-white font-medium group-hover:text-[#e6c687] transition-colors">
                  {item.name}
                </h4>
                <p className="text-[11px] font-mono text-white/40 mt-1">
                  {item.material}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Big Interleaved Words */}
        <div className="py-8 text-center border-y border-white/5">
          <p className="font-serif text-3xl sm:text-6xl md:text-7xl font-light tracking-[0.1em] uppercase text-[#e6c687] select-none">
            FEARLESS, TIMELESS & RELENTLESS
          </p>
        </div>

        {/* Marquee 2 (Right) */}
        <div className="overflow-hidden">
          <div className="flex gap-6 animate-marquee-right">
            {[...OBJECT_ITEMS_BOTTOM, ...OBJECT_ITEMS_BOTTOM].map((item, idx) => (
              <div
                key={idx}
                className="w-72 sm:w-80 shrink-0 p-4 rounded-2xl bg-[#121212] border border-white/5 hover:border-[#e6c687]/40 transition-colors group"
              >
                <div className="rounded-xl overflow-hidden mb-3 aspect-[4/3]">
                  <img
                    src={item.img}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <h4 className="font-serif text-base text-white font-medium group-hover:text-[#e6c687] transition-colors">
                  {item.name}
                </h4>
                <p className="text-[11px] font-mono text-white/40 mt-1">
                  {item.material}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Featured in Block with Press Names & Four Small Images */}
      <div className="max-w-7xl mx-auto px-6 sm:px-12 md:px-20">
        <div className="p-8 sm:p-12 rounded-3xl bg-[#121212] border border-white/10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-6 border-b border-white/10">
            <div>
              <span className="text-[10px] font-mono uppercase tracking-[0.3em] text-[#e6c687]">
                EDITORIAL CRITIQUE & GALLERIES
              </span>
              <h3 className="font-serif text-2xl sm:text-4xl text-white font-light mt-1">
                Featured in International Design Reviews
              </h3>
            </div>
            <span className="text-xs font-mono text-white/40">
              MUSEUM OF CONTEMPORARY CRAFT · MILAN TRIENNALE · VENICE BIENNALE
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {[
              { title: "Wallpaper* Design Awards", note: "Best Bespoke Joinery 2025", img: vastuDoorNorthImg },
              { title: "Dezeen Material Awards", note: "Basalt & Teak Harmony", img: vastuDoorSouthImg },
              { title: "AD 100 Architectural Review", note: "The Tropical Monolith", img: penthouseImg },
              { title: "Elle Decor International", note: "Quietude in Craft", img: vastuBrahmasthanImg }
            ].map((card, i) => (
              <div key={i} className="group space-y-2">
                <div className="rounded-xl overflow-hidden border border-white/10 aspect-square">
                  <img
                    src={card.img}
                    alt={card.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <h5 className="font-serif text-sm font-semibold text-white group-hover:text-[#e6c687] transition-colors">
                  {card.title}
                </h5>
                <p className="text-[11px] font-mono text-white/50">
                  {card.note}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
