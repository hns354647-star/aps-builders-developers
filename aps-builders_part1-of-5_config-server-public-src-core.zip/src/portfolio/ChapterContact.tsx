import React from "react";
import { Mail, Phone, MapPin, ArrowUpRight, MessageSquare } from "lucide-react";
import Counter from "./Counter";
import ContactForm from "./ContactForm";
import { PORTFOLIO_CREATIVE } from "./portfolioData";

export default function ChapterContact() {
  return (
    <section
      id="chapter-contact"
      className="relative min-h-screen w-full bg-[#0e0e0e] text-[#f4f2ec] py-24 sm:py-32 border-t border-white/10 select-none overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-12 md:px-20">
        {/* Chapter Header Marker */}
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-sm tracking-widest text-[#e6c687] px-3 py-1 border border-[#e6c687]/40 rounded-full">
            CHAPTER V
          </span>
          <span className="font-mono text-xs uppercase tracking-[0.25em] text-white/40">
            DIALOGUE, METRICS & INITIATION
          </span>
        </div>

        {/* Closing Statement */}
        <div className="mb-20 max-w-4xl">
          <h2 className="font-serif text-4xl sm:text-6xl md:text-7xl font-light text-[#f4f2ec] leading-[1.1]">
            Design that <span className="font-bold text-[#e6c687]">wins</span>,{" "}
            <span className="font-bold italic text-white">speaks</span> &{" "}
            <span className="font-bold text-[#e6c687] underline decoration-white/20 underline-offset-8">lasts</span>.
          </h2>
          <p className="mt-6 text-base sm:text-lg font-sans text-white/70 max-w-2xl leading-relaxed font-light">
            We collaborate with patron clients, cultural institutions, and discerning developers who value patience, spatial integrity, and authentic architectural longevity.
          </p>
        </div>

        {/* Four Counters that count up when in view */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 mb-24 pb-16 border-b border-white/10">
          {PORTFOLIO_CREATIVE.stats.map((stat, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-[#121212] border border-white/5 space-y-2 hover:border-[#e6c687]/40 transition-colors"
            >
              <div className="font-serif text-4xl sm:text-5xl md:text-6xl font-normal text-[#e6c687]">
                <Counter end={stat.count} suffix={stat.suffix} duration={1800} />
              </div>
              <h4 className="font-serif text-sm sm:text-base text-white font-medium">
                {stat.label}
              </h4>
              <p className="text-xs font-mono text-white/40">
                {stat.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Contact is the first gesture of trust + Form Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 sm:gap-16 items-start">
          {/* Left Column: Headline & Studio Details */}
          <div className="lg:col-span-5 space-y-10">
            <div>
              <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#e6c687] block mb-3">
                PROJECT INQUIRIES
              </span>
              <h3 className="font-serif text-3xl sm:text-5xl text-white font-light leading-tight">
                Contact is the{" "}
                <span className="font-bold text-[#e6c687]">first gesture</span> of trust.
              </h3>
              <p className="mt-4 text-sm font-sans text-white/60 leading-relaxed font-light">
                Whether you envision a lakefront residence in Alappuzha, an art foundation in Kochi, or a private island commission — every great structure starts with an unhurried conversation.
              </p>
            </div>

            {/* Direct Contacts List */}
            <div className="space-y-4 pt-4 border-t border-white/10 text-sm font-sans">
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-[#e6c687] shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-white/40 block">
                    Electronic Letter
                  </span>
                  <a
                    href={`mailto:${PORTFOLIO_CREATIVE.contact.email}`}
                    className="text-white hover:text-[#e6c687] transition-colors font-mono"
                  >
                    {PORTFOLIO_CREATIVE.contact.email}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-[#e6c687] shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-white/40 block">
                    Telephone Inquiry
                  </span>
                  <a
                    href={`tel:${PORTFOLIO_CREATIVE.contact.phone.replace(/[^0-9+]/g, "")}`}
                    className="text-white hover:text-[#e6c687] transition-colors font-mono"
                  >
                    {PORTFOLIO_CREATIVE.contact.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <MessageSquare className="w-5 h-5 text-[#25D366] shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-white/40 block">
                    Direct WhatsApp Concierge
                  </span>
                  <a
                    href={`https://wa.me/917907656700?text=Hello%20Aravind%20Menon%20Atelier%2C%20I%20would%20like%20to%20discuss%20an%20architectural%20commission.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-white hover:text-[#e6c687] transition-colors font-mono"
                  >
                    {PORTFOLIO_CREATIVE.contact.whatsapp}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-white/40 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-white/40 block">
                    Principal Atelier
                  </span>
                  <p className="text-white/70 font-sans">
                    {PORTFOLIO_CREATIVE.contact.address}
                  </p>
                  <span className="text-[11px] font-mono text-[#e6c687] block mt-1">
                    {PORTFOLIO_CREATIVE.contact.representation}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Form */}
          <div className="lg:col-span-7">
            <ContactForm />
          </div>
        </div>
      </div>
    </section>
  );
}
