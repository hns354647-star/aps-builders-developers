import React, { useEffect, useState } from "react";
import { ArrowUp } from "lucide-react";
import { CHAPTERS } from "./portfolioData";

interface ChapterNavProps {
  activeChapter: string;
  onSelectChapter: (id: string) => void;
  onScrollToTop: () => void;
}

export default function ChapterNav({
  activeChapter,
  onSelectChapter,
  onScrollToTop
}: ChapterNavProps) {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [showBackToStart, setShowBackToStart] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const total = document.documentElement.scrollHeight - window.innerHeight;
      if (total > 0) {
        const pct = Math.min(Math.max(window.scrollY / total, 0), 1);
        setScrollProgress(pct);
      }
      setShowBackToStart(window.scrollY > window.innerHeight * 0.7);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="fixed right-6 sm:right-10 top-1/2 -translate-y-1/2 z-[100] flex flex-col items-center gap-4 select-none">
      {/* Dynamic Vertical Timeline Track */}
      <div className="relative flex flex-col items-center py-2 px-1 rounded-full bg-[#0e0e0e]/70 backdrop-blur-md border border-white/10 shadow-2xl">
        {/* Progress Fill Background line */}
        <div className="absolute top-2 bottom-2 w-[1px] bg-white/10" />
        <div
          className="absolute top-2 w-[1.5px] bg-[#e6c687] transition-all duration-150"
          style={{ height: `${scrollProgress * 92}%` }}
        />

        {/* Roman Numeral Chapter Buttons */}
        <div className="relative z-10 flex flex-col items-center gap-4 py-2">
          {CHAPTERS.map((ch) => {
            const isActive = activeChapter === ch.id;
            return (
              <button
                key={ch.id}
                onClick={() => onSelectChapter(ch.id)}
                data-cursor-hover="true"
                data-cursor-label={`CH. ${ch.roman}`}
                className="group relative flex items-center justify-center p-1.5 focus:outline-none cursor-pointer"
                title={`${ch.roman}: ${ch.name}`}
              >
                {/* Dot / Indicator */}
                <span
                  className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                    isActive
                      ? "bg-[#e6c687] scale-125 shadow-[0_0_12px_#e6c687]"
                      : "bg-white/20 group-hover:bg-white/60"
                  }`}
                />

                {/* Roman Tooltip appearing on hover */}
                <span
                  className={`absolute right-7 px-2.5 py-1 rounded-md text-[10px] font-mono tracking-widest uppercase transition-all duration-200 pointer-events-none whitespace-nowrap ${
                    isActive
                      ? "opacity-100 translate-x-0 bg-[#e6c687] text-[#0e0e0e] font-bold shadow-md"
                      : "opacity-0 translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 bg-[#161616] text-[#f4f2ec] border border-white/10"
                  }`}
                >
                  {ch.roman} · {ch.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Back to Start Floating Pill Button */}
      {showBackToStart && (
        <button
          onClick={onScrollToTop}
          data-cursor-hover="true"
          data-cursor-label="TOP"
          className="p-2.5 rounded-full bg-[#0e0e0e]/80 hover:bg-[#e6c687] border border-white/10 text-white/70 hover:text-[#0e0e0e] transition-all duration-300 shadow-xl cursor-pointer hover:scale-110"
          aria-label="Scroll back to top"
        >
          <ArrowUp className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}
