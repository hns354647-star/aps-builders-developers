import React, { useEffect, useRef, useState } from "react";

export default function CustomCursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const followerRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [hoverLabel, setHoverLabel] = useState<string | null>(null);

  useEffect(() => {
    // Only enable on desktop pointer devices
    const isTouch = "ontouchstart" in window || navigator.maxTouchPoints > 0;
    if (isTouch) return;

    setIsVisible(true);

    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;
    let followerX = mouseX;
    let followerY = mouseY;
    let rafId: number;

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;

      if (cursorRef.current) {
        cursorRef.current.style.transform = `translate3d(${mouseX}px, ${mouseY}px, 0)`;
      }

      // Check hovered interactive elements
      const target = e.target as HTMLElement | null;
      if (target) {
        const interactive = target.closest("a, button, [data-cursor-hover], [data-cursor-view]");
        if (interactive) {
          setIsHovered(true);
          const label = interactive.getAttribute("data-cursor-label");
          setHoverLabel(label || null);
        } else {
          setIsHovered(false);
          setHoverLabel(null);
        }
      }
    };

    const handleMouseLeave = () => {
      setIsVisible(false);
    };

    const handleMouseEnter = () => {
      setIsVisible(true);
    };

    // Smooth lerp follower
    const render = () => {
      followerX += (mouseX - followerX) * 0.16;
      followerY += (mouseY - followerY) * 0.16;

      if (followerRef.current) {
        followerRef.current.style.transform = `translate3d(${followerX}px, ${followerY}px, 0)`;
      }

      rafId = requestAnimationFrame(render);
    };

    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    document.addEventListener("mouseleave", handleMouseLeave);
    document.addEventListener("mouseenter", handleMouseEnter);
    rafId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseleave", handleMouseLeave);
      document.removeEventListener("mouseenter", handleMouseEnter);
      cancelAnimationFrame(rafId);
    };
  }, []);

  if (!isVisible) return null;

  return (
    <>
      {/* Tiny precise center dot */}
      <div
        ref={cursorRef}
        className="fixed top-0 left-0 pointer-events-none z-[9999] -translate-x-1/2 -translate-y-1/2 transition-opacity duration-300 will-change-transform"
        style={{ opacity: isHovered ? 0 : 1 }}
      >
        <div className="w-1.5 h-1.5 rounded-full bg-[#f4f2ec] shadow-[0_0_10px_rgba(255,255,255,0.7)]" />
      </div>

      {/* Trailing expansion ring with label */}
      <div
        ref={followerRef}
        className="fixed top-0 left-0 pointer-events-none z-[9998] -translate-x-1/2 -translate-y-1/2 will-change-transform transition-all duration-200"
      >
        <div
          className={`flex items-center justify-center rounded-full border transition-all duration-300 ${
            isHovered
              ? "w-16 h-16 bg-[#e6c687]/20 border-[#e6c687] backdrop-blur-[2px] scale-100"
              : "w-8 h-8 bg-transparent border-white/20 scale-75"
          }`}
        >
          {hoverLabel && (
            <span className="text-[9px] uppercase tracking-widest font-mono text-[#f4f2ec] font-semibold">
              {hoverLabel}
            </span>
          )}
        </div>
      </div>
    </>
  );
}
