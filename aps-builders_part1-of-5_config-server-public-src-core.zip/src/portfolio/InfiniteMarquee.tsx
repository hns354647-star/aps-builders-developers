import React from "react";

interface InfiniteMarqueeProps {
  items: string[];
  direction?: "left" | "right";
  speedSeconds?: number;
  separator?: string;
  className?: string;
  interleavedHeadline?: string;
}

export default function InfiniteMarquee({
  items,
  direction = "left",
  speedSeconds = 28,
  separator = "—",
  className = "",
  interleavedHeadline
}: InfiniteMarqueeProps) {
  // Render duplicate items for a true seamless infinite loop
  const content = (
    <div className="flex items-center shrink-0 space-x-10 sm:space-x-16">
      {items.map((item, idx) => (
        <span key={idx} className="flex items-center space-x-10 sm:space-x-16">
          <span className="hover:text-[#e6c687] transition-colors">{item}</span>
          <span className="text-white/20 select-none">{separator}</span>
        </span>
      ))}
    </div>
  );

  return (
    <div className={`w-full overflow-hidden select-none py-4 ${className}`}>
      {interleavedHeadline && (
        <div className="text-center mb-3">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#e6c687]">
            {interleavedHeadline}
          </span>
        </div>
      )}

      <div
        className={`flex ${
          direction === "left" ? "animate-marquee-left" : "animate-marquee-right"
        }`}
        style={{
          animationDuration: `${speedSeconds}s`,
          animationTimingFunction: "linear",
          animationIterationCount: "infinite"
        }}
      >
        {content}
        {content}
      </div>
    </div>
  );
}
