import React, { useState, useEffect } from "react";
import Preloader from "./Preloader";
import Header from "./Header";
import MenuOverlay from "./MenuOverlay";
import ChapterNav from "./ChapterNav";
import CustomCursor from "./CustomCursor";
import HeroSection from "./HeroSection";
import ChapterAbout from "./ChapterAbout";
import ChapterWorks from "./ChapterWorks";
import ChapterObjects from "./ChapterObjects";
import ChapterArchitecture from "./ChapterArchitecture";
import ChapterContact from "./ChapterContact";
import Footer from "./Footer";
import { useLenisSmoothScroll } from "./useLenisSmoothScroll";

export default function PortfolioCinematic() {
  const [preloaderDone, setPreloaderDone] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeChapter, setActiveChapter] = useState("chapter-about");

  const { scrollTo } = useLenisSmoothScroll();

  // Active chapter tracking based on viewport
  useEffect(() => {
    const handleScroll = () => {
      const chapters = [
        "chapter-about",
        "chapter-works",
        "chapter-objects",
        "chapter-architecture",
        "chapter-contact"
      ];

      for (const id of chapters) {
        const el = document.getElementById(id);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= window.innerHeight * 0.45 && rect.bottom >= window.innerHeight * 0.2) {
            setActiveChapter(id);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleSelectChapter = (id: string) => {
    scrollTo(`#${id}`);
    setActiveChapter(id);
  };

  const handleGetInTouch = () => {
    scrollTo("#chapter-contact");
  };

  const handleScrollToTop = () => {
    scrollTo(0);
  };

  return (
    <div className="relative min-h-screen bg-[#0e0e0e] text-[#f4f2ec] selection:bg-[#e6c687] selection:text-[#0e0e0e] font-sans antialiased overflow-x-hidden">
      {/* Cinematic Custom Cursor */}
      <CustomCursor />

      {/* Preloader with counter and logo monogram */}
      <Preloader onComplete={() => setPreloaderDone(true)} />

      {/* Global Cinematic Header */}
      <Header
        menuOpen={menuOpen}
        onOpenMenu={() => setMenuOpen(!menuOpen)}
        onGetInTouch={handleGetInTouch}
      />

      {/* Fullscreen Chapter Menu Overlay */}
      <MenuOverlay
        isOpen={menuOpen}
        onClose={() => setMenuOpen(false)}
        onSelectChapter={handleSelectChapter}
      />

      {/* Fixed Chapter Side Indicator (I to V) */}
      <ChapterNav
        activeChapter={activeChapter}
        onSelectChapter={handleSelectChapter}
        onScrollToTop={handleScrollToTop}
      />

      {/* MAIN CINEMATIC STORY CHAPTERS */}
      <main id="main-content">
        <HeroSection onBeginStory={() => handleSelectChapter("chapter-about")} />
        <ChapterAbout />
        <ChapterWorks />
        <ChapterObjects />
        <ChapterArchitecture />
        <ChapterContact />
      </main>

      {/* FOOTER */}
      <Footer onScrollToTop={handleScrollToTop} />
    </div>
  );
}
