import React, { useRef, useEffect, useState } from "react";

interface WebGLImagePlaneProps {
  src: string;
  alt: string;
  className?: string;
  aspect?: string;
  speed?: number;
}

/**
 * High-performance cinematic image plane:
 * Uses WebGL canvas with subtle chromatic displacement and wave ripples on hover/scroll,
 * while maintaining the DOM image as the reliable accessible fallback layer.
 */
export default function WebGLImagePlane({
  src,
  alt,
  className = "",
  aspect = "aspect-[4/3]"
}: WebGLImagePlaneProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [glAvailable, setGlAvailable] = useState(true);

  useEffect(() => {
    // Check WebGL availability & reduced motion preference
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReducedMotion) {
      setGlAvailable(false);
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;

    const gl = canvas.getContext("webgl", { alpha: true, antialias: true, premultipliedAlpha: false });
    if (!gl) {
      setGlAvailable(false);
      return;
    }

    // Vertex Shader: full-screen quad
    const vsSource = `
      attribute vec2 a_position;
      attribute vec2 a_texCoord;
      varying vec2 v_texCoord;
      void main() {
        gl_Position = vec4(a_position, 0.0, 1.0);
        v_texCoord = a_texCoord;
      }
    `;

    // Fragment Shader: subtle RGB chromatic aberration & gentle lens distortion
    const fsSource = `
      precision mediump float;
      uniform sampler2D u_image;
      uniform float u_time;
      uniform float u_hover;
      uniform vec2 u_mouse;
      varying vec2 v_texCoord;

      void main() {
        vec2 uv = v_texCoord;

        // Subtle displacement centered around mouse
        vec2 dist = uv - u_mouse;
        float len = length(dist);
        float ripple = sin(len * 18.0 - u_time * 2.5) * 0.008 * u_hover * (1.0 - smoothstep(0.0, 0.6, len));

        vec2 distortedUv = uv + (dist * ripple);

        // Chromatic split (RGB offset)
        float rOffset = 0.003 * u_hover;
        float bOffset = -0.003 * u_hover;

        float r = texture2D(u_image, distortedUv + vec2(rOffset, 0.0)).r;
        float g = texture2D(u_image, distortedUv).g;
        float b = texture2D(u_image, distortedUv + vec2(bOffset, 0.0)).b;

        // Subtle vignette at corners
        float vignette = smoothstep(1.3, 0.4, length(uv - 0.5));
        gl_FragColor = vec4(r, g, b, 1.0) * vignette;
      }
    `;

    const createShader = (gl: WebGLRenderingContext, type: number, source: string) => {
      const shader = gl.createShader(type);
      if (!shader) return null;
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      return shader;
    };

    const vs = createShader(gl, gl.VERTEX_SHADER, vsSource);
    const fs = createShader(gl, gl.FRAGMENT_SHADER, fsSource);
    if (!vs || !fs) return;

    const program = gl.createProgram();
    if (!program) return;
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);

    // Quad geometry
    const positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    gl.bufferData(
      gl.ARRAY_BUFFER,
      new Float32Array([
        -1, -1, 0, 1,
        1, -1, 1, 1,
        -1, 1, 0, 0,
        -1, 1, 0, 0,
        1, -1, 1, 1,
        1, 1, 1, 0,
      ]),
      gl.STATIC_DRAW
    );

    const posLoc = gl.getAttribLocation(program, "a_position");
    const texLoc = gl.getAttribLocation(program, "a_texCoord");
    const timeLoc = gl.getUniformLocation(program, "u_time");
    const hoverLoc = gl.getUniformLocation(program, "u_hover");
    const mouseLoc = gl.getUniformLocation(program, "u_mouse");

    // Load texture
    const texture = gl.createTexture();
    const image = new Image();
    image.crossOrigin = "anonymous";
    image.src = src;

    let textureLoaded = false;
    image.onload = () => {
      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      textureLoaded = true;
      setIsLoaded(true);
    };

    let hoverTarget = 0;
    let hoverCurrent = 0;
    let mouseTarget = [0.5, 0.5];
    let mouseCurrent = [0.5, 0.5];
    let rafId: number;

    const onMouseEnter = () => {
      hoverTarget = 1;
    };
    const onMouseLeave = () => {
      hoverTarget = 0;
    };
    const onMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width;
      const y = (e.clientY - rect.top) / rect.height;
      mouseTarget = [x, y];
    };

    const container = containerRef.current;
    if (container) {
      container.addEventListener("mouseenter", onMouseEnter);
      container.addEventListener("mouseleave", onMouseLeave);
      container.addEventListener("mousemove", onMouseMove);
    }

    const render = (time: number) => {
      if (!canvas || !gl) return;

      // Handle canvas resize
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const displayWidth = Math.floor(canvas.clientWidth * dpr);
      const displayHeight = Math.floor(canvas.clientHeight * dpr);
      if (canvas.width !== displayWidth || canvas.height !== displayHeight) {
        canvas.width = displayWidth;
        canvas.height = displayHeight;
        gl.viewport(0, 0, displayWidth, displayHeight);
      }

      hoverCurrent += (hoverTarget - hoverCurrent) * 0.08;
      mouseCurrent[0] += (mouseTarget[0] - mouseCurrent[0]) * 0.1;
      mouseCurrent[1] += (mouseTarget[1] - mouseCurrent[1]) * 0.1;

      if (textureLoaded) {
        gl.useProgram(program);
        gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);

        gl.enableVertexAttribArray(posLoc);
        gl.vertexAttribPointer(posLoc, 2, gl.FLOAT, false, 16, 0);

        gl.enableVertexAttribArray(texLoc);
        gl.vertexAttribPointer(texLoc, 2, gl.FLOAT, false, 16, 8);

        gl.uniform1f(timeLoc, time * 0.001);
        gl.uniform1f(hoverLoc, hoverCurrent);
        gl.uniform2f(mouseLoc, mouseCurrent[0], mouseCurrent[1]);

        gl.drawArrays(gl.TRIANGLES, 0, 6);
      }

      rafId = requestAnimationFrame(render);
    };

    rafId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(rafId);
      if (container) {
        container.removeEventListener("mouseenter", onMouseEnter);
        container.removeEventListener("mouseleave", onMouseLeave);
        container.removeEventListener("mousemove", onMouseMove);
      }
      gl.deleteProgram(program);
      gl.deleteBuffer(positionBuffer);
      gl.deleteTexture(texture);
    };
  }, [src]);

  return (
    <div
      ref={containerRef}
      className={`relative overflow-hidden bg-[#121212] ${aspect} ${className} group`}
      data-cursor-hover="true"
      data-cursor-label="OBSERVE"
    >
      {/* Accessible DOM image (fallback & initial visual) */}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        className={`w-full h-full object-cover transition-all duration-700 ${
          glAvailable && isLoaded ? "opacity-0" : "opacity-100 group-hover:scale-105"
        }`}
      />

      {/* WebGL Canvas Layer */}
      {glAvailable && (
        <canvas
          ref={canvasRef}
          className={`absolute inset-0 w-full h-full pointer-events-none transition-opacity duration-700 ${
            isLoaded ? "opacity-100" : "opacity-0"
          }`}
        />
      )}

      {/* Sleek architectural grain & hairline border */}
      <div className="absolute inset-0 pointer-events-none border border-white/10 group-hover:border-[#e6c687]/40 transition-colors duration-500" />
    </div>
  );
}
