import React from "react";
import { PORTFOLIO_CREATIVE } from "./portfolioData";
import { architectPortraitImg, palaceMixImg } from "./portfolioImages";
import WebGLImagePlane from "./WebGLImagePlane";
import InfiniteMarquee from "./InfiniteMarquee";

export default function ChapterAbout() {
  return (
    <section
      id="chapter-about"
      className="relative min-h-screen w-full bg-[#0e0e0e] text-[#f4f2ec] py-24 sm:py-32 border-t border-white/10 select-none overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-12 md:px-20">
        {/* Chapter Header Roman Marker */}
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-sm tracking-widest text-[#e6c687] px-3 py-1 border border-[#e6c687]/40 rounded-full">
            CHAPTER I
          </span>
          <span className="font-mono text-xs uppercase tracking-[0.25em] text-white/40">
            PHILOSOPHY, LINEAGE & REACH
          </span>
        </div>

        {/* Pinned Big Name Wordmark & Portrait Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-24">
          {/* Portrait */}
          <div className="lg:col-span-5 relative group">
            <div className="relative overflow-hidden rounded-2xl border border-white/10">
              <WebGLImagePlane
                src={architectPortraitImg}
                alt="Aravind Menon, Principal Architect"
                aspect="aspect-[3/4]"
              />
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-[#0e0e0e]/85 backdrop-blur-md border border-white/10 flex items-center justify-between">
                <div>
                  <span className="font-serif text-sm font-semibold text-white block">
                    Aravind Menon
                  </span>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#e6c687]">
                    Founder & Principal Director
                  </span>
                </div>
                <span className="text-xs font-mono text-white/40">EST. 2008</span>
              </div>
            </div>
          </div>

          {/* Big Name Wordmark & Two-column Story */}
          <div className="lg:col-span-7 space-y-8">
            <h2 className="font-serif text-5xl sm:text-7xl md:text-8xl tracking-tighter text-[#f4f2ec] leading-[0.95] font-light">
              ARAVIND <br />
              <span className="font-bold text-[#e6c687]">MENON.</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm font-sans text-white/70 leading-relaxed font-light">
              <p>
                {PORTFOLIO_CREATIVE.shortBio}
              </p>
              <div className="space-y-4">
                <p className="border-l-2 border-[#e6c687] pl-4 text-white font-serif text-base italic leading-snug">
                  &ldquo;{PORTFOLIO_CREATIVE.statement}&rdquo;
                </p>
                <p className="text-xs font-mono uppercase tracking-wider text-white/40">
                  Disciplines: Masterplanning · Bespoke Joinery · Bioclimatic Glass
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Infinite Logo Marquee of Clients & Publications */}
        <div className="py-12 border-y border-white/10 mb-24">
          <div className="text-center mb-4">
            <span className="text-[10px] font-mono uppercase tracking-[0.3em] text-white/40">
              CITATIONS, PRESS MONOGRAPHS & DISTINCTIONS
            </span>
          </div>
          <InfiniteMarquee
            items={PORTFOLIO_CREATIVE.clientsAndPress}
            speedSeconds={22}
            className="text-lg sm:text-2xl font-serif tracking-[0.2em] uppercase text-white/80"
          />
        </div>

        {/* City Strip: HQ plus offices that highlight on scroll */}
        <div className="mb-24">
          <div className="flex items-baseline justify-between mb-8 pb-3 border-b border-white/10">
            <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#e6c687]">
              ATELIER GEOGRAPHIC PRESENCE
            </span>
            <span className="text-xs font-mono text-white/40">LOCATIONS 01 — 05</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {PORTFOLIO_CREATIVE.cities.map((city, idx) => (
              <div
                key={city.name}
                data-cursor-hover="true"
                data-cursor-label={city.name.toUpperCase()}
                className="group p-5 rounded-2xl bg-[#121212] border border-white/5 hover:border-[#e6c687]/60 transition-all duration-300 flex flex-col justify-between h-40"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-white/30">0{idx + 1}</span>
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-white/5 text-[#e6c687]">
                    {city.status}
                  </span>
                </div>
                <div>
                  <h4 className="font-serif text-xl text-white group-hover:text-[#e6c687] transition-colors">
                    {city.name}
                  </h4>
                  <p className="text-[11px] font-sans text-white/50 mt-1">
                    {city.role}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Global Reach line with a word that scales in & closing wide image */}
        <div className="space-y-12">
          <div className="text-center max-w-4xl mx-auto py-8">
            <p className="text-xs font-mono uppercase tracking-[0.3em] text-[#e6c687] mb-3">
              TERRITORIAL HORIZONS
            </p>
            <h3 className="font-serif text-3xl sm:text-5xl md:text-6xl text-[#f4f2ec] font-light leading-tight">
              An architectural practice with a{" "}
              <span className="font-bold text-[#e6c687] underline decoration-white/20 underline-offset-8">
                global reach
              </span>{" "}
              and an intimate vernacular soul.
            </h3>
            <p className="mt-6 text-sm font-sans text-white/60 max-w-xl mx-auto leading-relaxed">
              Every commission begins with an archaeological study of the earth, observing where the rain pools, how the afternoon coastal breeze travels, and how indigenous basalt and teak can form an eternal dialogue.
            </p>
          </div>

          <div className="rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
            <WebGLImagePlane
              src={palaceMixImg}
              alt="Vernacular and Contemporary Architectural Fusion"
              aspect="aspect-[21/9]"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
