/**
 * Sanity Studio Schema: Project
 * Represents luxury contemporary villas and mountain chalets
 */
export const projectSchema = {
  name: 'project',
  title: 'Projet d\'Architecture',
  type: 'document',
  fields: [
    {
      name: 'title',
      title: 'Titre du projet',
      type: 'string',
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'slug',
      title: 'Slug (identifiant URL)',
      type: 'slug',
      options: {
        source: 'title',
        maxLength: 96,
      },
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'type',
      title: 'Type de réalisation',
      type: 'string',
      options: {
        list: [
          { title: 'Villa Contemporaine', value: 'villa' },
          { title: 'Chalet d\'Exception', value: 'chalet' },
        ],
        layout: 'radio',
      },
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'area',
      title: 'Surface (m²)',
      type: 'number',
      validation: (Rule: any) => Rule.required().positive(),
    },
    {
      name: 'location',
      title: 'Localisation (ex: Lac d\'Annecy, Courchevel)',
      type: 'string',
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'region',
      title: 'Région pour filtrage',
      type: 'string',
      options: {
        list: [
          { title: 'Lac d\'Annecy', value: 'annecy' },
          { title: 'Alpes (Courchevel, Megève)', value: 'alpes' },
          { title: 'Lac de Genève', value: 'geneve' },
          { title: 'Côte d\'Azur (Cannes, Nice)', value: 'riviera' },
          { title: 'Provence', value: 'provence' },
        ],
      },
    },
    {
      name: 'year',
      title: 'Année de livraison',
      type: 'number',
      validation: (Rule: any) => Rule.min(2015).max(2030),
    },
    {
      name: 'featured',
      title: 'Projet mis en avant (Hero / Featured section)',
      type: 'boolean',
      initialValue: false,
    },
    {
      name: 'order',
      title: 'Ordre d\'affichage',
      type: 'number',
      initialValue: 10,
    },
    {
      name: 'teaser',
      title: 'Phrase d\'accroche (FR)',
      type: 'string',
      description: 'Court texte d\'introduction pour l\'index et l\'en-tête.',
    },
    {
      name: 'teaserEn',
      title: 'Phrase d\'accroche (EN)',
      type: 'string',
    },
    {
      name: 'description',
      title: 'Description détaillée (FR)',
      type: 'text',
      rows: 5,
    },
    {
      name: 'descriptionEn',
      title: 'Description détaillée (EN)',
      type: 'text',
      rows: 5,
    },
    {
      name: 'heroImage',
      title: 'Image principale (Cover / Full-bleed)',
      type: 'image',
      options: {
        hotspot: true,
      },
      fields: [
        {
          name: 'alt',
          type: 'string',
          title: 'Texte alternatif d\'accessibilité',
        },
        {
          name: 'caption',
          type: 'string',
          title: 'Légende',
        },
      ],
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'gallery',
      title: 'Galerie d\'images haute résolution',
      type: 'array',
      of: [
        {
          type: 'image',
          options: {
            hotspot: true,
          },
          fields: [
            {
              name: 'alt',
              type: 'string',
              title: 'Texte alternatif',
            },
            {
              name: 'caption',
              type: 'string',
              title: 'Légende architecturale',
            },
            {
              name: 'layoutStyle',
              type: 'string',
              title: 'Format d\'affichage dans la grille',
              options: {
                list: [
                  { title: 'Plein écran (16:9)', value: 'full' },
                  { title: 'Portrait élancé (3:4)', value: 'portrait' },
                  { title: 'Carré (1:1)', value: 'square' },
                  { title: 'Grand format éditorial', value: 'wide' },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      name: 'specifications',
      title: 'Spécifications architecturales',
      type: 'object',
      fields: [
        { name: 'materials', type: 'string', title: 'Matériaux dominants (ex: Pierre de Vals, Béton matricé, Chêne fumé)' },
        { name: 'exposure', type: 'string', title: 'Orientation / Exposition' },
        { name: 'amenities', type: 'string', title: 'Équipements (Piscine miroir, Spa, Cave vitrée...)' },
      ],
    },
  ],
  preview: {
    select: {
      title: 'title',
      subtitle: 'location',
      media: 'heroImage',
    },
  },
};

export default projectSchema;
