/**
 * Sanity Studio Schema: News Post (Actualités & Presse)
 */
export const newsPostSchema = {
  name: 'newsPost',
  title: 'Actualité / Article',
  type: 'document',
  fields: [
    {
      name: 'title',
      title: 'Titre (FR)',
      type: 'string',
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'titleEn',
      title: 'Titre (EN)',
      type: 'string',
    },
    {
      name: 'slug',
      title: 'Slug URL',
      type: 'slug',
      options: { source: 'title' },
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'date',
      title: 'Date de publication',
      type: 'date',
      options: { dateFormat: 'DD/MM/YYYY' },
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'category',
      title: 'Catégorie',
      type: 'string',
      options: {
        list: [
          { title: 'Presse & Distinctions', value: 'press' },
          { title: 'Chantier & Réalisation', value: 'construction' },
          { title: 'Éditorial & Vision', value: 'editorial' },
        ],
      },
    },
    {
      name: 'coverImage',
      title: 'Image de couverture',
      type: 'image',
      options: { hotspot: true },
      fields: [
        { name: 'alt', type: 'string', title: 'Texte alternatif' },
      ],
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'excerpt',
      title: 'Extrait (FR)',
      type: 'text',
      rows: 3,
    },
    {
      name: 'excerptEn',
      title: 'Extrait (EN)',
      type: 'text',
      rows: 3,
    },
    {
      name: 'body',
      title: 'Contenu principal (FR)',
      type: 'array',
      of: [{ type: 'block' }],
    },
    {
      name: 'bodyEn',
      title: 'Contenu principal (EN)',
      type: 'array',
      of: [{ type: 'block' }],
    },
  ],
};

export default newsPostSchema;
