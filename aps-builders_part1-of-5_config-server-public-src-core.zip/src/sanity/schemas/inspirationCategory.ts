/**
 * Sanity Studio Schema: Inspiration Category
 * Categorized rows for the Inspiration section
 */
export const inspirationCategorySchema = {
  name: 'inspirationCategory',
  title: 'Catégorie d\'Inspiration',
  type: 'document',
  fields: [
    {
      name: 'title',
      title: 'Titre (FR)',
      type: 'string',
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'titleEn',
      title: 'Titre (EN)',
      type: 'string',
    },
    {
      name: 'order',
      title: 'Ordre',
      type: 'number',
    },
    {
      name: 'caption',
      title: 'Légende courte (FR)',
      type: 'string',
      validation: (Rule: any) => Rule.required(),
    },
    {
      name: 'captionEn',
      title: 'Légende courte (EN)',
      type: 'string',
    },
    {
      name: 'images',
      title: 'Images (au minimum 2, format 3:4 portrait)',
      type: 'array',
      of: [
        {
          type: 'image',
          options: { hotspot: true },
          fields: [
            { name: 'alt', type: 'string', title: 'Alt text' },
            { name: 'caption', type: 'string', title: 'Légende détaillée' },
          ],
        },
      ],
      validation: (Rule: any) => Rule.min(2),
    },
  ],
};

export default inspirationCategorySchema;
