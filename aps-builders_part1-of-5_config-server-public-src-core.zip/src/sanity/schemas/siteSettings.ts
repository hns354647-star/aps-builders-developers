/**
 * Sanity Studio Schema: Site Settings
 * Global studio metadata, contacts, social channels, and offices
 */
export const siteSettingsSchema = {
  name: 'siteSettings',
  title: 'Paramètres du Site',
  type: 'document',
  fields: [
    {
      name: 'siteName',
      title: 'Nom du cabinet',
      type: 'string',
      initialValue: 'Archidomo',
    },
    {
      name: 'baseline',
      title: 'Baseline (FR)',
      type: 'string',
      initialValue: 'Cabinet d\'architecte maison contemporaine & chalets d\'exception',
    },
    {
      name: 'baselineEn',
      title: 'Baseline (EN)',
      type: 'string',
      initialValue: 'Contemporary luxury home & exceptional chalet architectural firm',
    },
    {
      name: 'phone',
      title: 'Téléphone principal',
      type: 'string',
      initialValue: '+33 4 50 22 18 40',
    },
    {
      name: 'email',
      title: 'Adresse email générale',
      type: 'string',
      initialValue: 'contact@archidomo.fr',
    },
    {
      name: 'socialLinks',
      title: 'Réseaux sociaux',
      type: 'object',
      fields: [
        { name: 'instagram', type: 'url', title: 'Instagram' },
        { name: 'linkedin', type: 'url', title: 'LinkedIn' },
      ],
    },
    {
      name: 'offices',
      title: 'Bureaux & Showrooms',
      type: 'array',
      of: [
        {
          type: 'object',
          fields: [
            { name: 'city', type: 'string', title: 'Ville / Nom' },
            { name: 'label', type: 'string', title: 'Sous-titre (ex: Showroom, Agence Riviera)' },
            { name: 'address', type: 'string', title: 'Adresse complète' },
            { name: 'postalCode', type: 'string', title: 'Code Postal' },
            { name: 'googleMapsUrl', type: 'url', title: 'Lien Google Maps' },
            { name: 'phone', type: 'string', title: 'Téléphone dédié' },
            { name: 'email', type: 'string', title: 'Email dédié' },
          ],
        },
      ],
    },
  ],
};

export default siteSettingsSchema;
