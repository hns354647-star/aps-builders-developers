import projectSchema from './project';
import inspirationCategorySchema from './inspirationCategory';
import newsPostSchema from './newsPost';
import siteSettingsSchema from './siteSettings';
import homepageSchema from './homepage';

export const schemaTypes = [
  projectSchema,
  inspirationCategorySchema,
  newsPostSchema,
  siteSettingsSchema,
  homepageSchema,
];

export {
  projectSchema,
  inspirationCategorySchema,
  newsPostSchema,
  siteSettingsSchema,
  homepageSchema,
};
