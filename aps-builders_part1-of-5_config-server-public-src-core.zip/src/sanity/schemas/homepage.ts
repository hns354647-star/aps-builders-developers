/**
 * Sanity Studio Schema: Homepage
 * Editorial configuration for the home page sections
 */
export const homepageSchema = {
  name: 'homepage',
  title: 'Page d\'Accueil',
  type: 'document',
  fields: [
    {
      name: 'heroH1',
      title: 'Titre H1 Hero (FR)',
      type: 'string',
      initialValue: 'Archidomo : Cabinet d\'architecte maison contemporaine',
    },
    {
      name: 'heroH1En',
      title: 'Titre H1 Hero (EN)',
      type: 'string',
      initialValue: 'Archidomo : Contemporary Home Architectural Studio',
    },
    {
      name: 'heroTagline',
      title: 'Accroche Hero (FR)',
      type: 'text',
      rows: 2,
      initialValue: 'Le studio conçoit des résidences d\'exception dans des lieux rares, en France et dans le monde entier.',
    },
    {
      name: 'heroTaglineEn',
      title: 'Accroche Hero (EN)',
      type: 'text',
      rows: 2,
      initialValue: 'The studio designs exceptional residences in rare places, across France and worldwide.',
    },
    {
      name: 'heroSlides',
      title: 'Carrousel Hero (8 photographies haute résolution)',
      type: 'array',
      of: [
        {
          type: 'image',
          options: { hotspot: true },
          fields: [
            { name: 'projectTitle', type: 'string', title: 'Titre du projet' },
            { name: 'location', type: 'string', title: 'Lieu' },
            { name: 'isFinalWideCrop', type: 'boolean', title: 'Dernière diapositive (format panoramique 1920x940)' },
          ],
        },
      ],
      validation: (Rule: any) => Rule.min(8).max(8),
    },
    {
      name: 'featuredProject',
      title: 'Projet vedette (Villa Elektra)',
      type: 'reference',
      to: [{ type: 'project' }],
    },
  ],
};

export default homepageSchema;
